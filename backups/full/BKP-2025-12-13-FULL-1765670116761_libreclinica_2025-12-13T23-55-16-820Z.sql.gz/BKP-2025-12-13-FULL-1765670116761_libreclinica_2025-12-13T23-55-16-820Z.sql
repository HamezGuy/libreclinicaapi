--
-- PostgreSQL database dump
--

\restrict FWLLvijq95jRgkaQniCDjlvZXRjo8fRzZZvtzvqnNc4Y1OrW7G6tRQtXsglwfwL

-- Dumped from database version 14.20
-- Dumped by pg_dump version 14.20

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: event_crf_initial_trigger(); Type: FUNCTION; Schema: public; Owner: libreclinica
--

CREATE FUNCTION public.event_crf_initial_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$DECLARE
			pk INTEGER;
			entity_name_value TEXT;
			
        BEGIN
            IF (TG_OP = 'INSERT') THEN
				SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
				SELECT INTO entity_name_value 'Status';
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value, event_crf_id )
		                    VALUES (pk, '41', now(), NEW.owner_id, 'event_crf', NEW.event_crf_id, entity_name_value,'2', NEW.status_id, NEW.event_crf_id );
				RETURN NULL;
            END IF;
        RETURN NULL;
        END;
        $$;


ALTER FUNCTION public.event_crf_initial_trigger() OWNER TO libreclinica;

--
-- Name: event_crf_trigger(); Type: FUNCTION; Schema: public; Owner: libreclinica
--

CREATE FUNCTION public.event_crf_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$DECLARE
			pk INTEGER;
			entity_name_value TEXT;
		BEGIN
			IF (TG_OP = 'UPDATE') THEN
				IF(OLD.status_id <> NEW.status_id) THEN
				/*---------------*/
				/*Event CRF status changed*/
				SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
				SELECT INTO entity_name_value 'Status';

				IF(OLD.status_id = '1' AND NEW.status_id = '2') THEN
				    IF (NEW.electronic_signature_status) THEN
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value, event_crf_id,study_event_id, event_crf_version_id )
		                    VALUES (pk, '14', now(), NEW.update_id, 'event_crf', NEW.event_crf_id, entity_name_value, OLD.status_id, NEW.status_id, NEW.event_crf_id, NEW.study_event_id ,NEW.crf_version_id);
		            ELSE
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value, event_crf_id ,study_event_id, event_crf_version_id)
		                    VALUES (pk, '8', now(), NEW.update_id, 'event_crf', NEW.event_crf_id, entity_name_value, OLD.status_id, NEW.status_id, NEW.event_crf_id , NEW.study_event_id ,NEW.crf_version_id);
		            END IF;
				ELSIF (OLD.status_id = '1' AND NEW.status_id = '4') THEN
				    IF (NEW.electronic_signature_status) THEN
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value, event_crf_id ,study_event_id, event_crf_version_id)
		                    VALUES (pk, '15', now(), NEW.update_id, 'event_crf', NEW.event_crf_id, entity_name_value, OLD.status_id, NEW.status_id, NEW.event_crf_id , NEW.study_event_id ,NEW.crf_version_id);
		            ELSE
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value, event_crf_id ,study_event_id, event_crf_version_id)
		                    VALUES (pk, '10', now(), NEW.update_id, 'event_crf', NEW.event_crf_id, entity_name_value, OLD.status_id, NEW.status_id, NEW.event_crf_id , NEW.study_event_id ,NEW.crf_version_id);
		            END IF;
				ELSIF (OLD.status_id = '4' AND NEW.status_id = '2') THEN
		    		IF (NEW.electronic_signature_status) THEN
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value, event_crf_id ,study_event_id, event_crf_version_id)
		                    VALUES (pk, '16', now(), NEW.update_id, 'event_crf', NEW.event_crf_id, entity_name_value, OLD.status_id, NEW.status_id, NEW.event_crf_id , NEW.study_event_id ,NEW.crf_version_id);
				    ELSE
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value, event_crf_id ,study_event_id, event_crf_version_id)
		                    VALUES (pk, '11', now(), NEW.update_id, 'event_crf', NEW.event_crf_id, entity_name_value, OLD.status_id, NEW.status_id, NEW.event_crf_id , NEW.study_event_id ,NEW.crf_version_id);
				    END IF;
                 				ELSIF ( NEW.status_id = '11') THEN
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value, event_crf_id ,study_event_id, event_crf_version_id)
		                    VALUES (pk, '40', now(), NEW.update_id, 'event_crf', NEW.event_crf_id, entity_name_value, OLD.status_id, NEW.status_id, NEW.event_crf_id , NEW.study_event_id ,NEW.crf_version_id);

				END IF;
				/*---------------*/
				END IF;

				IF(OLD.date_interviewed <> NEW.date_interviewed) THEN
				/*---------------*/
				/*Event CRF date interviewed*/
				SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
				SELECT INTO entity_name_value 'Date interviewed';
				INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value, event_crf_id ,study_event_id, event_crf_version_id)
					VALUES (pk, '9', now(), NEW.update_id, 'event_crf', NEW.event_crf_id, entity_name_value, OLD.date_interviewed, NEW.date_interviewed, NEW.event_crf_id , NEW.study_event_id ,NEW.crf_version_id);
				/*---------------*/
				END IF;

				IF((OLD.interviewer_name <> NEW.interviewer_name) AND (OLD.interviewer_name <> '')) THEN
				/*---------------*/
				/*Event CRF interviewer name*/
				SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
				SELECT INTO entity_name_value 'Interviewer Name';
				INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value, event_crf_id ,study_event_id, event_crf_version_id)
					VALUES (pk, '9', now(), NEW.update_id, 'event_crf', NEW.event_crf_id, entity_name_value, OLD.interviewer_name, NEW.interviewer_name, NEW.event_crf_id , NEW.study_event_id ,NEW.crf_version_id);
				/*---------------*/
				END IF;

				IF(OLD.sdv_status <> NEW.sdv_status) THEN
				SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
				SELECT INTO entity_name_value 'EventCRF SDV Status';
				INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value, event_crf_id ,study_event_id, event_crf_version_id)
					VALUES (pk, '32', now(), NEW.sdv_update_id, 'event_crf', NEW.event_crf_id, entity_name_value, (select case when OLD.sdv_status is true then 'TRUE' else 'FALSE' end),
					(select case when NEW.sdv_status is true then 'TRUE' else 'FALSE' end), NEW.event_crf_id , NEW.study_event_id ,NEW.crf_version_id);
				/*---------------*/
				END IF;
			RETURN NULL;  /*return values ignored for 'after' triggers*/
			END IF;
		END;
		$$;


ALTER FUNCTION public.event_crf_trigger() OWNER TO libreclinica;

--
-- Name: event_crf_version_change_trigger(); Type: FUNCTION; Schema: public; Owner: libreclinica
--

CREATE FUNCTION public.event_crf_version_change_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$DECLARE
			pk INTEGER;
			crf_old_name TEXT;
			crf_new_name TEXT;
			
		BEGIN
			IF (TG_OP = 'UPDATE') THEN
				IF(OLD.crf_version_id <> NEW.crf_version_id) THEN
				 /*---------------*/

				    SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
				   SELECT INTO crf_old_name cf.name FROM crf_version cf WHERE cf.crf_version_id = OLD.crf_version_id;
				    SELECT INTO crf_new_name cf.name FROM crf_version cf WHERE cf.crf_version_id = NEW.crf_version_id;
				    
				    
				    
				    
					INSERT INTO audit_log_event(  
					audit_id, 
					audit_date,  
					audit_table,  
					user_id ,
					entity_id ,
					entity_name ,
					audit_log_event_type_id ,
					old_value ,
					new_value ,
					event_crf_id ,
					study_event_id
					 )
				
					VALUES (
					pk, 
					now(),
					'event_crf',
					NEW.update_id,
					OLD.event_crf_id, 
					'CRF version',
					'33',
					crf_old_name, 
					crf_new_name,
					OLD.event_crf_id,
					OLD.study_event_id
					);
				/*---------------*/
				END IF;
				RETURN NULL;  /*return values ignored for 'after' triggers*/
			END IF;
		RETURN NULL;  /*return values ignored for 'after' triggers*/
		END;
		$$;


ALTER FUNCTION public.event_crf_version_change_trigger() OWNER TO libreclinica;

--
-- Name: event_definition_crf_trigger(); Type: FUNCTION; Schema: public; Owner: libreclinica
--

CREATE FUNCTION public.event_definition_crf_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$DECLARE
            pk INTEGER;
            se_id INTEGER;
            cv_id INTEGER;
            entity_name_value TEXT;
            BEGIN
                IF (TG_OP = 'UPDATE') THEN
                    IF(OLD.status_id <> NEW.status_id) THEN
                        /*---------------*/
                        /*Event CRF status changed*/
                        SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
                        SELECT INTO entity_name_value 'Status';
                        IF(NEW.status_id = '5') THEN
                            SELECT INTO se_id se.study_event_id FROM study_event se WHERE se.study_event_definition_id = NEW.study_event_definition_id;
                            SELECT INTO cv_id ec.crf_version_id FROM event_crf ec, study_event se WHERE se.study_event_definition_id = NEW.study_event_definition_id and ec.study_event_id = se.study_event_id;

                            INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, study_event_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value, event_crf_id, event_crf_version_id)
                                        VALUES (pk, '13',se_id, now(), NEW.update_id, 'event_definition_crf', NEW.event_definition_crf_id, entity_name_value, OLD.status_id, NEW.status_id, NEW.event_definition_crf_id, cv_id);
                        END IF;
                    END IF;
                    RETURN NULL;  /*return values ignored for 'after' triggers*/
                END IF;
            END;
        $$;


ALTER FUNCTION public.event_definition_crf_trigger() OWNER TO libreclinica;

--
-- Name: fix_duplicates_in_study_defs(); Type: FUNCTION; Schema: public; Owner: libreclinica
--

CREATE FUNCTION public.fix_duplicates_in_study_defs() RETURNS void
    LANGUAGE plpgsql
    AS $$DECLARE
		    maxOrdinal INTEGER DEFAULT 1;
		    mviews RECORD;
		    mviews2 RECORD;
		
		    BEGIN
			FOR mviews2 in select ordinal, count(*) as cnt from study_event_definition sed group by ordinal
				LOOP
				IF mviews2.cnt > 1 THEN
		
					FOR mviews in select study_event_definition_id as sid from study_event_definition sed order by sed.study_event_definition_id
						LOOP
						UPDATE study_event_definition set ordinal = maxOrdinal where study_event_definition_id = mviews.sid;
						
						maxOrdinal := maxOrdinal + 1;
			
						END LOOP;
					EXIT;
				END IF;
				END LOOP;
		    END;
		    $$;


ALTER FUNCTION public.fix_duplicates_in_study_defs() OWNER TO libreclinica;

--
-- Name: fix_rule_referencing_cross_study(); Type: FUNCTION; Schema: public; Owner: libreclinica
--

CREATE FUNCTION public.fix_rule_referencing_cross_study() RETURNS void
    LANGUAGE plpgsql
    AS $$DECLARE
		    
		     newExpressionId INTEGER DEFAULT 0;
		     newRuleId INTEGER DEFAULT 0;
		     mviews RECORD;
		
		    BEGIN
		
		    FOR mviews in select r.rule_expression_id as rrule_expression_id, rs.study_id as rsstudy_id, rsr.rule_id as rsrrule_id, rsr.id as rsrid  from rule_set rs, rule r,rule_set_rule rsr where  rsr.rule_set_id = rs.id and rule_id = r.id and  rs.study_id != r.study_id 
		    LOOP
		        newExpressionId := NEXTVAL('rule_expression_id_seq');
		        newRuleId := NEXTVAL('rule_id_seq');
		        INSERT INTO rule_expression select newExpressionId,value,context,owner_id,date_created,date_updated,update_id,status_id,0 from rule_expression where id = mviews.rrule_expression_id;
		        INSERT INTO rule SELECT newRuleId,name,description,oc_oid,enabled,newExpressionId,owner_id,date_created,date_updated,update_id,status_id,0,mviews.rsstudy_id FROM rule WHERE id = mviews.rsrrule_id ;
		        UPDATE rule_set_rule rsr set rule_id = newRuleId where rsr.id = mviews.rsrid;
		    END LOOP;
		
		    END;
		    $$;


ALTER FUNCTION public.fix_rule_referencing_cross_study() OWNER TO libreclinica;

--
-- Name: global_subject_trigger(); Type: FUNCTION; Schema: public; Owner: libreclinica
--

CREATE FUNCTION public.global_subject_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$DECLARE
			pk INTEGER;
			entity_name_value TEXT;
		BEGIN
			IF (TG_OP = 'INSERT') THEN
				/*---------------*/
				 /*Subject created*/
				SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
				INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id)
					VALUES (pk, '5', now(), NEW.owner_id, 'subject', NEW.subject_id);
				RETURN NULL; /*return values ignored for 'after' triggers*/
				/*---------------*/
			ELSIF (TG_OP = 'UPDATE') THEN
				IF(OLD.status_id <> NEW.status_id) THEN
				/*---------------*/
				 /*Subject status changed*/
				SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
				SELECT INTO entity_name_value 'Status';
				INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
					VALUES (pk, '6', now(), NEW.update_id, 'subject', NEW.subject_id, entity_name_value, OLD.status_id, NEW.status_id);
				/*---------------*/
				END IF;
		
				IF(OLD.unique_identifier <> NEW.unique_identifier) THEN
				/*---------------*/
				/*Subject value changed*/
				SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
				SELECT INTO entity_name_value 'Person ID';
				INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
					VALUES (pk, '7', now(), NEW.update_id, 'subject', NEW.subject_id, entity_name_value, OLD.unique_identifier, NEW.unique_identifier);
				/*---------------*/
				END IF;
		
				IF(OLD.date_of_birth <> NEW.date_of_birth) THEN
				/*---------------*/
				 /*Subject value changed*/
				SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
				SELECT INTO entity_name_value 'Date of Birth';
				INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
					VALUES (pk, '7', now(), NEW.update_id, 'subject', NEW.subject_id, entity_name_value, OLD.date_of_birth, NEW.date_of_birth);
				/*---------------*/
				END IF;
		
		        IF(OLD.gender <> NEW.gender) THEN
		   		/*---------------*/
		   		/*Subject value changed*/
		   		SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
		   		SELECT INTO entity_name_value 'Gender';
		   		INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
				VALUES (pk, '7', now(), NEW.update_id, 'subject', NEW.subject_id, entity_name_value, OLD.gender, NEW.gender);
		   		/*---------------*/
		   		END IF;
				
			RETURN NULL;  /*return values ignored for 'after' triggers*/
			END IF;
		END;
		$$;


ALTER FUNCTION public.global_subject_trigger() OWNER TO libreclinica;

--
-- Name: item_data_initial_trigger(); Type: FUNCTION; Schema: public; Owner: libreclinica
--

CREATE FUNCTION public.item_data_initial_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$DECLARE
            pk INTEGER;
            entity_name_value TEXT;
            std_evnt_id INTEGER;
            crf_version_id INTEGER;
        BEGIN
            IF (TG_OP = 'INSERT' and length(NEW.value)>0) THEN
				SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
				SELECT INTO entity_name_value item.name FROM item WHERE item.item_id = NEW.item_id;
		        SELECT INTO std_evnt_id ec.study_event_id FROM event_crf ec WHERE ec.event_crf_id = NEW.event_crf_id;
		        SELECT INTO crf_version_id ec.crf_version_id FROM event_crf ec WHERE ec.event_crf_id = NEW.event_crf_id;
		        INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, reason_for_change, new_value, event_crf_id, study_event_id, event_crf_version_id ,item_data_repeat_key)
		                VALUES (pk, '1', now(), NEW.owner_id, 'item_data', NEW.item_data_id, entity_name_value, 'initial value', NEW.value, NEW.event_crf_id, std_evnt_id, crf_version_id , NEW.ordinal);
				RETURN NULL;
            END IF;
        RETURN NULL;
        END;
        $$;


ALTER FUNCTION public.item_data_initial_trigger() OWNER TO libreclinica;

--
-- Name: item_data_trigger(); Type: FUNCTION; Schema: public; Owner: libreclinica
--

CREATE FUNCTION public.item_data_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$DECLARE
            pk INTEGER;
            entity_name_value TEXT;
            status INTEGER;
            std_evnt_id INTEGER;
            crf_version_id INTEGER;
        BEGIN
                SELECT INTO status status_id FROM event_crf WHERE event_crf_id = OLD.event_crf_id;
                SELECT INTO std_evnt_id ec.study_event_id FROM event_crf ec WHERE ec.event_crf_id = OLD.event_crf_id;
                SELECT INTO crf_version_id ec.crf_version_id FROM event_crf ec WHERE ec.event_crf_id = OLD.event_crf_id;
        
            IF (TG_OP = 'DELETE') THEN
                /*---------------*/
                 /*Item data deleted (by deleting an event crf)*/
                SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
                SELECT INTO entity_name_value item.name FROM item WHERE item.item_id = OLD.item_id;
                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, event_crf_id, study_event_id, event_crf_version_id)
                        VALUES (pk, '13', now(), OLD.update_id, 'item_data', OLD.item_data_id, entity_name_value, OLD.value, OLD.event_crf_id, std_evnt_id, crf_version_id);
                RETURN NULL; --return values ignored for 'after' triggers
            ELSIF (TG_OP = 'UPDATE') THEN
        
                IF(OLD.value <> NEW.value and status=11) THEN
                /*---------------*/
                 /*Item data updated*/
                SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
                SELECT INTO entity_name_value item.name FROM item WHERE item.item_id = NEW.item_id;
                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value, event_crf_id ,study_event_id, event_crf_version_id,item_data_repeat_key)
                    VALUES (pk, '13', now(), NEW.update_id, 'item_data', NEW.item_data_id, entity_name_value, OLD.value, NEW.value, NEW.event_crf_id ,std_evnt_id, crf_version_id , NEW.ordinal);
                DELETE FROM rule_action_run_log where item_data_id = NEW.item_data_id;  
                /*---------------*/
                ELSEIF(OLD.value <> NEW.value) THEN
                /*---------------*/
                 /*Item data updated*/
                SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
                SELECT INTO entity_name_value item.name FROM item WHERE item.item_id = NEW.item_id;
                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value, event_crf_id,study_event_id, event_crf_version_id,item_data_repeat_key)
                    VALUES (pk, '1', now(), NEW.update_id, 'item_data', NEW.item_data_id, entity_name_value, OLD.value, NEW.value, NEW.event_crf_id,std_evnt_id, crf_version_id , NEW.ordinal);
                DELETE FROM rule_action_run_log where item_data_id = NEW.item_data_id;  
                /*---------------*/
                END IF;
                RETURN NULL;  /*return values ignored for 'after' triggers*/
            END IF;
        RETURN NULL;  /*return values ignored for 'after' triggers*/
        END;
        $$;


ALTER FUNCTION public.item_data_trigger() OWNER TO libreclinica;

--
-- Name: populate_ssid_in_didm_trigger(); Type: FUNCTION; Schema: public; Owner: libreclinica
--

CREATE FUNCTION public.populate_ssid_in_didm_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        BEGIN
            update dn_item_data_map  set study_subject_id = 
            (
                select DISTINCT se.study_subject_id from study_event se, event_crf ec, item_data id where 
                id.event_crf_id = ec.event_crf_id and ec.study_event_id = se.study_event_id and id.item_data_id = dn_item_data_map.item_data_id
            ) where study_subject_id is null;
        RETURN NULL;    
        END;
        $$;


ALTER FUNCTION public.populate_ssid_in_didm_trigger() OWNER TO libreclinica;

--
-- Name: repeating_item_data_trigger(); Type: FUNCTION; Schema: public; Owner: libreclinica
--

CREATE FUNCTION public.repeating_item_data_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$DECLARE
		 pk INTEGER;
		 entity_name_value TEXT;
		 std_evnt_id INTEGER;
		 crf_version_id INTEGER;
		 validator_id INTEGER;
		 event_crf_status_id INTEGER;
		
		
		BEGIN
		 IF (TG_OP = 'INSERT') THEN
		  /*---------------*/ 
		  SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
		  SELECT INTO entity_name_value item.name FROM item WHERE item.item_id = NEW.item_id;
		        SELECT INTO std_evnt_id ec.study_event_id FROM event_crf ec WHERE ec.event_crf_id = NEW.event_crf_id;
		        SELECT INTO crf_version_id ec.crf_version_id FROM event_crf ec WHERE ec.event_crf_id = NEW.event_crf_id;
		 SELECT INTO validator_id ec.validator_id FROM event_crf ec WHERE ec.event_crf_id = NEW.event_crf_id;
		 SELECT INTO event_crf_status_id ec.status_id FROM event_crf ec WHERE ec.event_crf_id = NEW.event_crf_id;
		 
		        IF (NEW.status_id = '2' AND NEW.ordinal > 1 AND validator_id > 0 AND event_crf_status_id  = '4') THEN  /*DDE*/
		          
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, new_value, event_crf_id, study_event_id, event_crf_version_id)
		                VALUES (pk, '30', now(), NEW.owner_id, 'item_data', NEW.item_data_id, entity_name_value, NEW.value, NEW.event_crf_id, std_evnt_id, crf_version_id);
		        ELSE 
		          IF(NEW.status_id ='2' AND NEW.ordinal > 1  AND event_crf_status_id  = '2') THEN /*ADE*/
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, new_value, event_crf_id, study_event_id, event_crf_version_id)
		                VALUES (pk, '30', now(), NEW.owner_id, 'item_data', NEW.item_data_id, entity_name_value, NEW.value, NEW.event_crf_id, std_evnt_id, crf_version_id);
		          END IF;
		       END IF;
		  RETURN NULL;  /*return values ignored for 'after' triggers*/
		 
		 END IF;
		RETURN NULL;  /*return values ignored for 'after' triggers*/
		END; $$;


ALTER FUNCTION public.repeating_item_data_trigger() OWNER TO libreclinica;

--
-- Name: study_event_trigger(); Type: FUNCTION; Schema: public; Owner: libreclinica
--

CREATE FUNCTION public.study_event_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$DECLARE
            pk INTEGER;
        BEGIN
            IF (TG_OP = 'INSERT') THEN
                SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
                IF(NEW.subject_event_status_id = '1') THEN
                    INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
                    VALUES (pk, '17', now(), NEW.owner_id, 'study_event', NEW.study_event_id, 'Status','0', NEW.subject_event_status_id);
                END IF;
            END IF;
        
            IF (TG_OP = 'UPDATE') THEN
                IF(OLD.subject_event_status_id <> NEW.subject_event_status_id) THEN
                    SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
                    IF(NEW.subject_event_status_id = '1') THEN
                        INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
                        VALUES (pk, '17', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Status', OLD.subject_event_status_id, NEW.subject_event_status_id);
                    ELSIF(NEW.subject_event_status_id = '3') THEN
                        INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
                        VALUES (pk, '18', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Status', OLD.subject_event_status_id, NEW.subject_event_status_id);
                    ELSIF(NEW.subject_event_status_id = '4') THEN
                        INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
                        VALUES (pk, '19', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Status', OLD.subject_event_status_id, NEW.subject_event_status_id);
                    ELSIF(NEW.subject_event_status_id = '5') THEN
                        INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
                        VALUES (pk, '20', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Status', OLD.subject_event_status_id, NEW.subject_event_status_id);
                    ELSIF(NEW.subject_event_status_id = '6') THEN
                        INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
                        VALUES (pk, '21', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Status', OLD.subject_event_status_id, NEW.subject_event_status_id);
                    ELSIF(NEW.subject_event_status_id = '7') THEN
                        INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
                        VALUES (pk, '22', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Status', OLD.subject_event_status_id, NEW.subject_event_status_id);
                    ELSIF(NEW.subject_event_status_id = '8') THEN
                        INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
                        VALUES (pk, '31', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Status', OLD.subject_event_status_id, NEW.subject_event_status_id);
                    END IF;
                END IF;
                IF(OLD.status_id <> NEW.status_id) THEN
                    IF(NEW.status_id = '5' or NEW.status_id = '1') THEN
                        SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
                        INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
                        VALUES (pk, '23', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Status', OLD.status_id, NEW.status_id);
                    END IF;
                END IF;
                IF(OLD.date_start <> NEW.date_start) THEN
                    SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
                    INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
                    VALUES (pk, '24', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Start date', OLD.date_start, NEW.date_start);
                END IF;
                IF(OLD.date_end <> NEW.date_end) THEN
                    SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
                    INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
                    VALUES (pk, '25', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'End date', OLD.date_end, NEW.date_end);
                END IF;
                IF(OLD.location <> NEW.location) THEN
                    SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
                    INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
                    VALUES (pk, '26', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Location', OLD.location, NEW.location);
                END IF;
                RETURN NULL;  /*return values ignored for 'after' triggers*/
            END IF;
            RETURN NULL;
        END;$$;


ALTER FUNCTION public.study_event_trigger() OWNER TO libreclinica;

--
-- Name: study_event_trigger_new(); Type: FUNCTION; Schema: public; Owner: libreclinica
--

CREATE FUNCTION public.study_event_trigger_new() RETURNS trigger
    LANGUAGE plpgsql
    AS $$DECLARE
			pk INTEGER;
		BEGIN
			IF (TG_OP = 'INSERT') THEN
		        SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
		        IF(NEW.subject_event_status_id = '1') THEN
		            INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
		            VALUES (pk, '17', now(), NEW.owner_id, 'study_event', NEW.study_event_id, 'Status','0', NEW.subject_event_status_id);
		        END IF;
		    END IF;
		
			IF (TG_OP = 'UPDATE') THEN
				IF(OLD.subject_event_status_id <> NEW.subject_event_status_id) THEN
		            SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
		            IF(NEW.subject_event_status_id = '1') THEN
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
		                VALUES (pk, '17', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Status', OLD.subject_event_status_id, NEW.subject_event_status_id);
		            ELSIF(NEW.subject_event_status_id = '3') THEN
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
		                VALUES (pk, '18', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Status', OLD.subject_event_status_id, NEW.subject_event_status_id);
		            ELSIF(NEW.subject_event_status_id = '4') THEN
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
		                VALUES (pk, '19', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Status', OLD.subject_event_status_id, NEW.subject_event_status_id);
		            ELSIF(NEW.subject_event_status_id = '5') THEN
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
		                VALUES (pk, '20', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Status', OLD.subject_event_status_id, NEW.subject_event_status_id);
		            ELSIF(NEW.subject_event_status_id = '6') THEN
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
		                VALUES (pk, '21', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Status', OLD.subject_event_status_id, NEW.subject_event_status_id);
		            ELSIF(NEW.subject_event_status_id = '7') THEN
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
		                VALUES (pk, '22', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Status', OLD.subject_event_status_id, NEW.subject_event_status_id);
		            ELSIF(NEW.subject_event_status_id = '8') THEN
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
		                VALUES (pk, '31', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Status', OLD.subject_event_status_id, NEW.subject_event_status_id);
				    END IF;
			    END IF;
		        IF(OLD.status_id <> NEW.status_id) THEN
		            IF(NEW.status_id = '5' and OLD.status_id = '1') THEN
		                SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
		                VALUES (pk, '23', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Status', OLD.status_id, NEW.status_id);
		            END IF;
		            IF(OLD.status_id = '5' and NEW.status_id = '1') THEN
		                SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
		                INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
		                VALUES (pk, '35', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Status', OLD.status_id, NEW.status_id);
		            END IF;
		        END IF;
		        IF(OLD.date_start <> NEW.date_start) THEN
		            SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
		            INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
		            VALUES (pk, '24', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Start date', OLD.date_start, NEW.date_start);
		        END IF;
		        IF(OLD.date_end <> NEW.date_end) THEN
		            SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
		            INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
		            VALUES (pk, '25', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'End date', OLD.date_end, NEW.date_end);
		        END IF;
		        IF(OLD.location <> NEW.location) THEN
		            SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
		            INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
		            VALUES (pk, '26', now(), NEW.update_id, 'study_event', NEW.study_event_id, 'Location', OLD.location, NEW.location);
		        END IF;
		    	RETURN NULL;  /*return values ignored for 'after' triggers*/
			END IF;
			RETURN NULL;
		END;$$;


ALTER FUNCTION public.study_event_trigger_new() OWNER TO libreclinica;

--
-- Name: study_subject_trigger(); Type: FUNCTION; Schema: public; Owner: libreclinica
--

CREATE FUNCTION public.study_subject_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$DECLARE
			pk INTEGER;
			entity_name_value TEXT;
		    old_unique_identifier TEXT;
		    new_unique_identifier TEXT;
		
		BEGIN
			IF (TG_OP = 'INSERT') THEN
				/*---------------*/
				 /*Study subject created*/
				SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
				INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id)
					VALUES (pk, '2', now(), NEW.owner_id, 'study_subject', NEW.study_subject_id);
				RETURN NULL; /*return values ignored for 'after' triggers*/
				/*---------------*/
			ELSIF (TG_OP = 'UPDATE') THEN
				IF(OLD.status_id <> NEW.status_id) THEN
				 /*---------------*/
				/*Study subject status changed*/
				SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
				SELECT INTO entity_name_value 'Status';
				INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
					VALUES (pk, '3', now(), NEW.update_id, 'study_subject', NEW.study_subject_id, entity_name_value, OLD.status_id, NEW.status_id);
				/*---------------*/
				END IF;
		
				IF(OLD.label <> NEW.label) THEN
				/*---------------*/
				 /*Study subject value changed*/
				SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
				SELECT INTO entity_name_value 'Study Subject ID';
				INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
					VALUES (pk, '4', now(), NEW.update_id, 'study_subject', NEW.study_subject_id, entity_name_value, OLD.label, NEW.label);
				/*---------------*/
				END IF;
		
				IF(OLD.secondary_label <> NEW.secondary_label) THEN
				/*---------------*/
				/*Study subject value changed*/
				SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
				SELECT INTO entity_name_value 'Secondary Subject ID';
				INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
					VALUES (pk, '4', now(), NEW.update_id, 'study_subject', NEW.study_subject_id, entity_name_value, OLD.secondary_label, NEW.secondary_label);
				/*---------------*/
				END IF;
		
				IF(OLD.enrollment_date <> NEW.enrollment_date) THEN
				/*---------------*/
				/*Study subject value changed*/
				SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
				SELECT INTO entity_name_value 'Enrollment Date';
				INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
					VALUES (pk, '4', now(), NEW.update_id, 'study_subject', NEW.study_subject_id, entity_name_value, OLD.enrollment_date, NEW.enrollment_date);
				 /*---------------*/
				END IF;

				IF(OLD.time_zone <> NEW.time_zone) THEN
				/*---------------*/
				/*Study subject value changed*/
				SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
				SELECT INTO entity_name_value 'Time Zone';
				INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
					VALUES (pk, '4', now(), NEW.update_id, 'study_subject', NEW.study_subject_id, entity_name_value, OLD.time_zone, NEW.time_zone);
				 /*---------------*/
				END IF;

	
		        IF(OLD.study_id <> NEW.study_id) THEN
		         /*---------------*/
		         /*Subject reassigned*/
		        SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
		        SELECT INTO entity_name_value 'Study id';
		        SELECT INTO old_unique_identifier study.unique_identifier FROM study study WHERE study.study_id = OLD.study_id;
		        SELECT INTO new_unique_identifier study.unique_identifier FROM study study WHERE study.study_id = NEW.study_id;
		        INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
		            VALUES (pk, '27', now(), NEW.update_id, 'study_subject', NEW.study_subject_id, entity_name_value, old_unique_identifier, new_unique_identifier);
		        /*---------------*/
		        END IF;
		
				RETURN NULL;  /*return values ignored for 'after' triggers*/
			END IF;
		END;
		$$;


ALTER FUNCTION public.study_subject_trigger() OWNER TO libreclinica;

--
-- Name: subject_group_assignment_trigger(); Type: FUNCTION; Schema: public; Owner: libreclinica
--

CREATE FUNCTION public.subject_group_assignment_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$DECLARE
            pk INTEGER;
            group_name TEXT;
            old_group_name TEXT;
            new_group_name TEXT;
            study_group_class_name TEXT;
            BEGIN
            IF (TG_OP = 'INSERT') THEN
            SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
            SELECT INTO group_name sg.name FROM study_group sg WHERE sg.study_group_id = NEW.study_group_id;
            SELECT INTO study_group_class_name sgc.name FROM study_group sg join study_group_class sgc ON sg.study_group_class_id = sgc.study_group_class_id WHERE sg.study_group_id = NEW.study_group_id ;
            INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
            VALUES (pk, '28', now(), NEW.owner_id, 'subject_group_map', NEW.study_subject_id, study_group_class_name,'', group_name);
            END IF;
            IF (TG_OP = 'UPDATE') THEN
            IF(OLD.study_group_id <> NEW.study_group_id) THEN
            SELECT INTO pk NEXTVAL('audit_log_event_audit_id_seq');
            SELECT INTO old_group_name sg.name FROM study_group sg WHERE sg.study_group_id = OLD.study_group_id;
            SELECT INTO new_group_name sg.name FROM study_group sg WHERE sg.study_group_id = NEW.study_group_id;
            SELECT INTO study_group_class_name sgc.name FROM study_group sg join study_group_class sgc ON sg.study_group_class_id = sgc.study_group_class_id WHERE sg.study_group_id = NEW.study_group_id ;
            INSERT INTO audit_log_event(audit_id, audit_log_event_type_id, audit_date, user_id, audit_table, entity_id, entity_name, old_value, new_value)
            VALUES (pk, '29', now(), NEW.update_id, 'subject_group_map', NEW.study_subject_id, study_group_class_name,old_group_name, new_group_name);
            END IF;
            RETURN NULL;  /*return values ignored for 'after' triggers*/
            END IF;
            RETURN NULL;
            END;$$;


ALTER FUNCTION public.subject_group_assignment_trigger() OWNER TO libreclinica;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: archived_dataset_file; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.archived_dataset_file (
    archived_dataset_file_id integer NOT NULL,
    name character varying(255),
    dataset_id integer,
    export_format_id integer,
    file_reference character varying(1000),
    run_time integer,
    file_size integer,
    date_created timestamp(6) without time zone,
    owner_id integer
);


ALTER TABLE public.archived_dataset_file OWNER TO libreclinica;

--
-- Name: archived_dataset_file_archived_dataset_file_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.archived_dataset_file_archived_dataset_file_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.archived_dataset_file_archived_dataset_file_id_seq OWNER TO libreclinica;

--
-- Name: archived_dataset_file_archived_dataset_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.archived_dataset_file_archived_dataset_file_id_seq OWNED BY public.archived_dataset_file.archived_dataset_file_id;


--
-- Name: audit_event; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.audit_event (
    audit_id integer NOT NULL,
    audit_date timestamp without time zone NOT NULL,
    audit_table character varying(500) NOT NULL,
    user_id integer,
    entity_id integer,
    reason_for_change character varying(1000),
    action_message character varying(4000)
);


ALTER TABLE public.audit_event OWNER TO libreclinica;

--
-- Name: audit_event_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.audit_event_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_event_audit_id_seq OWNER TO libreclinica;

--
-- Name: audit_event_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.audit_event_audit_id_seq OWNED BY public.audit_event.audit_id;


--
-- Name: audit_event_context; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.audit_event_context (
    audit_id integer,
    study_id integer,
    subject_id integer,
    study_subject_id integer,
    role_name character varying(200),
    event_crf_id integer,
    study_event_id integer,
    study_event_definition_id integer,
    crf_id integer,
    crf_version_id integer,
    study_crf_id integer,
    item_id integer
);


ALTER TABLE public.audit_event_context OWNER TO libreclinica;

--
-- Name: audit_event_values; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.audit_event_values (
    audit_id integer,
    column_name character varying(255),
    old_value character varying(2000),
    new_value character varying(2000)
);


ALTER TABLE public.audit_event_values OWNER TO libreclinica;

--
-- Name: audit_log_event; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.audit_log_event (
    audit_id integer NOT NULL,
    audit_date timestamp without time zone NOT NULL,
    audit_table character varying(500) NOT NULL,
    user_id integer,
    entity_id integer,
    entity_name character varying(500),
    reason_for_change character varying(1000),
    audit_log_event_type_id integer,
    old_value character varying(2000),
    new_value character varying(2000),
    event_crf_id integer,
    study_event_id integer,
    event_crf_version_id integer,
    item_data_repeat_key character varying(4000)
);


ALTER TABLE public.audit_log_event OWNER TO libreclinica;

--
-- Name: audit_log_event_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.audit_log_event_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_log_event_audit_id_seq OWNER TO libreclinica;

--
-- Name: audit_log_event_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.audit_log_event_audit_id_seq OWNED BY public.audit_log_event.audit_id;


--
-- Name: audit_log_event_type; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.audit_log_event_type (
    audit_log_event_type_id integer NOT NULL,
    name character varying(255)
);


ALTER TABLE public.audit_log_event_type OWNER TO libreclinica;

--
-- Name: audit_log_event_type_audit_log_event_type_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.audit_log_event_type_audit_log_event_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_log_event_type_audit_log_event_type_id_seq OWNER TO libreclinica;

--
-- Name: audit_log_event_type_audit_log_event_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.audit_log_event_type_audit_log_event_type_id_seq OWNED BY public.audit_log_event_type.audit_log_event_type_id;


--
-- Name: audit_user_api_log; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.audit_user_api_log (
    id integer NOT NULL,
    audit_id character varying(36) NOT NULL,
    user_id integer,
    username character varying(255) NOT NULL,
    user_role character varying(50),
    http_method character varying(10) NOT NULL,
    endpoint_path character varying(500) NOT NULL,
    query_params text,
    request_body text,
    response_status integer,
    ip_address character varying(45),
    user_agent text,
    duration_ms integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_user_api_log OWNER TO libreclinica;

--
-- Name: audit_user_api_log_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.audit_user_api_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_user_api_log_id_seq OWNER TO libreclinica;

--
-- Name: audit_user_api_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.audit_user_api_log_id_seq OWNED BY public.audit_user_api_log.id;


--
-- Name: audit_user_login; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.audit_user_login (
    id integer NOT NULL,
    user_name character varying(255),
    user_account_id integer,
    login_attempt_date timestamp without time zone,
    login_status_code integer,
    version integer,
    details character varying(255)
);


ALTER TABLE public.audit_user_login OWNER TO libreclinica;

--
-- Name: audit_user_login_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.audit_user_login_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_user_login_id_seq OWNER TO libreclinica;

--
-- Name: audit_user_login_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.audit_user_login_id_seq OWNED BY public.audit_user_login.id;


--
-- Name: authorities; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.authorities (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    authority character varying(50) NOT NULL,
    version integer
);


ALTER TABLE public.authorities OWNER TO libreclinica;

--
-- Name: authorities_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.authorities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.authorities_id_seq OWNER TO libreclinica;

--
-- Name: authorities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.authorities_id_seq OWNED BY public.authorities.id;


--
-- Name: completion_status; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.completion_status (
    completion_status_id integer NOT NULL,
    status_id integer,
    name character varying(255),
    description character varying(1000)
);


ALTER TABLE public.completion_status OWNER TO libreclinica;

--
-- Name: completion_status_completion_status_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.completion_status_completion_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.completion_status_completion_status_id_seq OWNER TO libreclinica;

--
-- Name: completion_status_completion_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.completion_status_completion_status_id_seq OWNED BY public.completion_status.completion_status_id;


--
-- Name: configuration; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.configuration (
    id integer NOT NULL,
    key character varying(255),
    value character varying(255),
    description character varying(512),
    version integer
);


ALTER TABLE public.configuration OWNER TO libreclinica;

--
-- Name: configuration_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.configuration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.configuration_id_seq OWNER TO libreclinica;

--
-- Name: configuration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.configuration_id_seq OWNED BY public.configuration.id;


--
-- Name: crf; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.crf (
    crf_id integer NOT NULL,
    status_id integer,
    name character varying(255),
    description character varying(2048),
    owner_id integer,
    date_created date,
    date_updated date,
    update_id integer,
    oc_oid character varying(40) NOT NULL,
    source_study_id integer
);


ALTER TABLE public.crf OWNER TO libreclinica;

--
-- Name: crf_crf_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.crf_crf_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.crf_crf_id_seq OWNER TO libreclinica;

--
-- Name: crf_crf_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.crf_crf_id_seq OWNED BY public.crf.crf_id;


--
-- Name: crf_version; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.crf_version (
    crf_version_id integer NOT NULL,
    crf_id integer NOT NULL,
    name character varying(255),
    description character varying(4000),
    revision_notes character varying(255),
    status_id integer,
    date_created date,
    date_updated date,
    owner_id integer,
    update_id integer,
    oc_oid character varying(40) NOT NULL,
    xform text,
    xform_name character varying(255)
);


ALTER TABLE public.crf_version OWNER TO libreclinica;

--
-- Name: crf_version_crf_version_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.crf_version_crf_version_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.crf_version_crf_version_id_seq OWNER TO libreclinica;

--
-- Name: crf_version_crf_version_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.crf_version_crf_version_id_seq OWNED BY public.crf_version.crf_version_id;


--
-- Name: crf_version_media; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.crf_version_media (
    crf_version_media_id integer NOT NULL,
    crf_version_id integer NOT NULL,
    name character varying(255) NOT NULL,
    path character varying(4000) NOT NULL
);


ALTER TABLE public.crf_version_media OWNER TO libreclinica;

--
-- Name: crf_version_media_crf_version_media_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.crf_version_media_crf_version_media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.crf_version_media_crf_version_media_id_seq OWNER TO libreclinica;

--
-- Name: crf_version_media_crf_version_media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.crf_version_media_crf_version_media_id_seq OWNED BY public.crf_version_media.crf_version_media_id;


--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO libreclinica;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO libreclinica;

--
-- Name: dataset; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dataset (
    dataset_id integer NOT NULL,
    study_id integer,
    status_id integer,
    name character varying(255),
    description character varying(2000),
    sql_statement text,
    num_runs integer,
    date_start date,
    date_end date,
    date_created date,
    date_updated date,
    date_last_run date,
    owner_id integer,
    approver_id integer,
    update_id integer,
    show_event_location boolean DEFAULT false,
    show_event_start boolean DEFAULT false,
    show_event_end boolean DEFAULT false,
    show_subject_dob boolean DEFAULT false,
    show_subject_gender boolean DEFAULT false,
    show_event_status boolean DEFAULT false,
    show_subject_status boolean DEFAULT false,
    show_subject_unique_id boolean DEFAULT false,
    show_subject_age_at_event boolean DEFAULT false,
    show_crf_status boolean DEFAULT false,
    show_crf_version boolean DEFAULT false,
    show_crf_int_name boolean DEFAULT false,
    show_crf_int_date boolean DEFAULT false,
    show_group_info boolean DEFAULT false,
    show_disc_info boolean DEFAULT false,
    odm_metadataversion_name character varying(255),
    odm_metadataversion_oid character varying(255),
    odm_prior_study_oid character varying(255),
    odm_prior_metadataversion_oid character varying(255),
    show_secondary_id boolean DEFAULT false,
    dataset_item_status_id integer
);


ALTER TABLE public.dataset OWNER TO libreclinica;

--
-- Name: dataset_crf_version_map; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dataset_crf_version_map (
    dataset_id integer,
    event_definition_crf_id integer
);


ALTER TABLE public.dataset_crf_version_map OWNER TO libreclinica;

--
-- Name: dataset_dataset_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.dataset_dataset_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dataset_dataset_id_seq OWNER TO libreclinica;

--
-- Name: dataset_dataset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.dataset_dataset_id_seq OWNED BY public.dataset.dataset_id;


--
-- Name: dataset_filter_map; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dataset_filter_map (
    dataset_id integer,
    filter_id integer,
    ordinal integer
);


ALTER TABLE public.dataset_filter_map OWNER TO libreclinica;

--
-- Name: dataset_item_status; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dataset_item_status (
    dataset_item_status_id integer NOT NULL,
    name character varying(50),
    description character varying(255)
);


ALTER TABLE public.dataset_item_status OWNER TO libreclinica;

--
-- Name: dataset_item_status_dataset_item_status_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.dataset_item_status_dataset_item_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dataset_item_status_dataset_item_status_id_seq OWNER TO libreclinica;

--
-- Name: dataset_item_status_dataset_item_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.dataset_item_status_dataset_item_status_id_seq OWNED BY public.dataset_item_status.dataset_item_status_id;


--
-- Name: dataset_study_group_class_map; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dataset_study_group_class_map (
    dataset_id integer NOT NULL,
    study_group_class_id integer NOT NULL
);


ALTER TABLE public.dataset_study_group_class_map OWNER TO libreclinica;

--
-- Name: dc_computed_event; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dc_computed_event (
    dc_summary_event_id integer NOT NULL,
    dc_event_id integer NOT NULL,
    item_target_id integer,
    summary_type character varying(255)
);


ALTER TABLE public.dc_computed_event OWNER TO libreclinica;

--
-- Name: dc_computed_event_dc_summary_event_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.dc_computed_event_dc_summary_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dc_computed_event_dc_summary_event_id_seq OWNER TO libreclinica;

--
-- Name: dc_computed_event_dc_summary_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.dc_computed_event_dc_summary_event_id_seq OWNED BY public.dc_computed_event.dc_summary_event_id;


--
-- Name: dc_event; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dc_event (
    dc_event_id integer NOT NULL,
    decision_condition_id integer,
    ordinal integer NOT NULL,
    type character varying(256) NOT NULL
);


ALTER TABLE public.dc_event OWNER TO libreclinica;

--
-- Name: dc_event_dc_event_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.dc_event_dc_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dc_event_dc_event_id_seq OWNER TO libreclinica;

--
-- Name: dc_event_dc_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.dc_event_dc_event_id_seq OWNED BY public.dc_event.dc_event_id;


--
-- Name: dc_primitive; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dc_primitive (
    dc_primitive_id integer NOT NULL,
    decision_condition_id integer,
    item_id integer,
    dynamic_value_item_id integer,
    comparison character varying(3) NOT NULL,
    constant_value character varying(4000)
);


ALTER TABLE public.dc_primitive OWNER TO libreclinica;

--
-- Name: dc_primitive_dc_primitive_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.dc_primitive_dc_primitive_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dc_primitive_dc_primitive_id_seq OWNER TO libreclinica;

--
-- Name: dc_primitive_dc_primitive_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.dc_primitive_dc_primitive_id_seq OWNED BY public.dc_primitive.dc_primitive_id;


--
-- Name: dc_section_event; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dc_section_event (
    dc_event_id integer NOT NULL,
    section_id integer NOT NULL
);


ALTER TABLE public.dc_section_event OWNER TO libreclinica;

--
-- Name: dc_section_event_dc_event_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.dc_section_event_dc_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dc_section_event_dc_event_id_seq OWNER TO libreclinica;

--
-- Name: dc_section_event_dc_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.dc_section_event_dc_event_id_seq OWNED BY public.dc_section_event.dc_event_id;


--
-- Name: dc_send_email_event; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dc_send_email_event (
    dc_event_id integer NOT NULL,
    to_address character varying(1000) NOT NULL,
    subject character varying(1000),
    body character varying(4000)
);


ALTER TABLE public.dc_send_email_event OWNER TO libreclinica;

--
-- Name: dc_send_email_event_dc_event_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.dc_send_email_event_dc_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dc_send_email_event_dc_event_id_seq OWNER TO libreclinica;

--
-- Name: dc_send_email_event_dc_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.dc_send_email_event_dc_event_id_seq OWNED BY public.dc_send_email_event.dc_event_id;


--
-- Name: dc_substitution_event; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dc_substitution_event (
    dc_event_id integer NOT NULL,
    item_id integer,
    value character varying(1000) NOT NULL
);


ALTER TABLE public.dc_substitution_event OWNER TO libreclinica;

--
-- Name: dc_substitution_event_dc_event_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.dc_substitution_event_dc_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dc_substitution_event_dc_event_id_seq OWNER TO libreclinica;

--
-- Name: dc_substitution_event_dc_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.dc_substitution_event_dc_event_id_seq OWNED BY public.dc_substitution_event.dc_event_id;


--
-- Name: dc_summary_item_map; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dc_summary_item_map (
    dc_summary_event_id integer,
    item_id integer,
    ordinal integer
);


ALTER TABLE public.dc_summary_item_map OWNER TO libreclinica;

--
-- Name: decision_condition; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.decision_condition (
    decision_condition_id integer NOT NULL,
    crf_version_id integer,
    status_id integer,
    label character varying(1000) NOT NULL,
    comments character varying(3000) NOT NULL,
    quantity integer NOT NULL,
    type character varying(3) NOT NULL,
    owner_id integer,
    date_created date,
    date_updated date,
    update_id integer
);


ALTER TABLE public.decision_condition OWNER TO libreclinica;

--
-- Name: decision_condition_decision_condition_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.decision_condition_decision_condition_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.decision_condition_decision_condition_id_seq OWNER TO libreclinica;

--
-- Name: decision_condition_decision_condition_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.decision_condition_decision_condition_id_seq OWNED BY public.decision_condition.decision_condition_id;


--
-- Name: discrepancy_note; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.discrepancy_note (
    discrepancy_note_id integer NOT NULL,
    description character varying(2040),
    discrepancy_note_type_id integer,
    resolution_status_id integer,
    detailed_notes character varying(1000),
    date_created timestamp with time zone,
    owner_id integer,
    parent_dn_id integer,
    entity_type character varying(30),
    study_id integer,
    assigned_user_id integer
);


ALTER TABLE public.discrepancy_note OWNER TO libreclinica;

--
-- Name: discrepancy_note_discrepancy_note_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.discrepancy_note_discrepancy_note_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discrepancy_note_discrepancy_note_id_seq OWNER TO libreclinica;

--
-- Name: discrepancy_note_discrepancy_note_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.discrepancy_note_discrepancy_note_id_seq OWNED BY public.discrepancy_note.discrepancy_note_id;


--
-- Name: discrepancy_note_type; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.discrepancy_note_type (
    discrepancy_note_type_id integer NOT NULL,
    name character varying(50),
    description character varying(255)
);


ALTER TABLE public.discrepancy_note_type OWNER TO libreclinica;

--
-- Name: discrepancy_note_type_discrepancy_note_type_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.discrepancy_note_type_discrepancy_note_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discrepancy_note_type_discrepancy_note_type_id_seq OWNER TO libreclinica;

--
-- Name: discrepancy_note_type_discrepancy_note_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.discrepancy_note_type_discrepancy_note_type_id_seq OWNED BY public.discrepancy_note_type.discrepancy_note_type_id;


--
-- Name: dn_age_days; Type: VIEW; Schema: public; Owner: libreclinica
--

CREATE VIEW public.dn_age_days AS
 SELECT dn.discrepancy_note_id,
        CASE
            WHEN (dn.resolution_status_id = ANY (ARRAY[1, 2, 3])) THEN date_part('day'::text, (CURRENT_TIMESTAMP - ( SELECT cdn.date_created
               FROM public.discrepancy_note cdn
              WHERE (cdn.discrepancy_note_id = ( SELECT max(idn.discrepancy_note_id) AS max
                       FROM public.discrepancy_note idn
                      WHERE (idn.parent_dn_id = dn.discrepancy_note_id))))))
            ELSE (NULL::integer)::double precision
        END AS days,
        CASE
            WHEN (dn.resolution_status_id = 4) THEN date_part('day'::text, (( SELECT cdn.date_created
               FROM public.discrepancy_note cdn
              WHERE (cdn.discrepancy_note_id = ( SELECT max(idn.discrepancy_note_id) AS max
                       FROM public.discrepancy_note idn
                      WHERE (idn.parent_dn_id = dn.discrepancy_note_id)))) - dn.date_created))
            WHEN (dn.resolution_status_id = ANY (ARRAY[1, 2, 3])) THEN date_part('day'::text, (CURRENT_TIMESTAMP - dn.date_created))
            ELSE (NULL::integer)::double precision
        END AS age
   FROM public.discrepancy_note dn
  WHERE (dn.parent_dn_id IS NULL);


ALTER TABLE public.dn_age_days OWNER TO libreclinica;

--
-- Name: dn_event_crf_map; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dn_event_crf_map (
    event_crf_id integer,
    discrepancy_note_id integer,
    column_name character varying(255)
);


ALTER TABLE public.dn_event_crf_map OWNER TO libreclinica;

--
-- Name: dn_item_data_map; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dn_item_data_map (
    item_data_id integer,
    discrepancy_note_id integer,
    column_name character varying(255),
    study_subject_id integer,
    activated boolean DEFAULT true
);


ALTER TABLE public.dn_item_data_map OWNER TO libreclinica;

--
-- Name: dn_study_event_map; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dn_study_event_map (
    study_event_id integer,
    discrepancy_note_id integer,
    column_name character varying(255)
);


ALTER TABLE public.dn_study_event_map OWNER TO libreclinica;

--
-- Name: dn_study_subject_map; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dn_study_subject_map (
    study_subject_id integer,
    discrepancy_note_id integer,
    column_name character varying(255)
);


ALTER TABLE public.dn_study_subject_map OWNER TO libreclinica;

--
-- Name: dn_subject_map; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dn_subject_map (
    subject_id integer,
    discrepancy_note_id integer,
    column_name character varying(255)
);


ALTER TABLE public.dn_subject_map OWNER TO libreclinica;

--
-- Name: dyn_item_form_metadata; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dyn_item_form_metadata (
    id integer NOT NULL,
    item_form_metadata_id integer,
    item_id integer,
    crf_version_id integer,
    show_item boolean DEFAULT true,
    event_crf_id integer,
    version integer,
    item_data_id integer,
    passed_dde integer DEFAULT 0
);


ALTER TABLE public.dyn_item_form_metadata OWNER TO libreclinica;

--
-- Name: dyn_item_form_metadata_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.dyn_item_form_metadata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dyn_item_form_metadata_id_seq OWNER TO libreclinica;

--
-- Name: dyn_item_form_metadata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.dyn_item_form_metadata_id_seq OWNED BY public.dyn_item_form_metadata.id;


--
-- Name: dyn_item_group_metadata; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.dyn_item_group_metadata (
    id integer NOT NULL,
    item_group_metadata_id integer,
    item_group_id integer,
    show_group boolean DEFAULT true,
    event_crf_id integer,
    version integer,
    passed_dde integer DEFAULT 0
);


ALTER TABLE public.dyn_item_group_metadata OWNER TO libreclinica;

--
-- Name: dyn_item_group_metadata_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.dyn_item_group_metadata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dyn_item_group_metadata_id_seq OWNER TO libreclinica;

--
-- Name: dyn_item_group_metadata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.dyn_item_group_metadata_id_seq OWNED BY public.dyn_item_group_metadata.id;


--
-- Name: event_crf; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.event_crf (
    event_crf_id integer NOT NULL,
    study_event_id integer,
    crf_version_id integer,
    date_interviewed date,
    interviewer_name character varying(255),
    completion_status_id integer,
    status_id integer,
    annotations character varying(4000),
    date_completed timestamp without time zone,
    validator_id integer,
    date_validate date,
    date_validate_completed timestamp without time zone,
    validator_annotations character varying(4000),
    validate_string character varying(256),
    owner_id integer,
    date_created timestamp with time zone,
    study_subject_id integer,
    date_updated timestamp with time zone,
    update_id integer,
    electronic_signature_status boolean DEFAULT false,
    sdv_status boolean DEFAULT false NOT NULL,
    old_status_id integer DEFAULT 1,
    sdv_update_id integer DEFAULT 0
);


ALTER TABLE public.event_crf OWNER TO libreclinica;

--
-- Name: event_crf_event_crf_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.event_crf_event_crf_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.event_crf_event_crf_id_seq OWNER TO libreclinica;

--
-- Name: event_crf_event_crf_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.event_crf_event_crf_id_seq OWNED BY public.event_crf.event_crf_id;


--
-- Name: event_crf_flag; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.event_crf_flag (
    id integer NOT NULL,
    path character varying(255),
    tag_id integer,
    flag_workflow_id integer,
    owner_id integer,
    update_id integer,
    date_created timestamp with time zone,
    date_updated timestamp with time zone
);


ALTER TABLE public.event_crf_flag OWNER TO libreclinica;

--
-- Name: event_crf_flag_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.event_crf_flag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.event_crf_flag_id_seq OWNER TO libreclinica;

--
-- Name: event_crf_flag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.event_crf_flag_id_seq OWNED BY public.event_crf_flag.id;


--
-- Name: event_crf_flag_workflow; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.event_crf_flag_workflow (
    id integer NOT NULL,
    workflow_id character varying(255),
    workflow_status character varying(255),
    owner_id integer,
    update_id integer,
    date_created timestamp with time zone,
    date_updated timestamp with time zone
);


ALTER TABLE public.event_crf_flag_workflow OWNER TO libreclinica;

--
-- Name: event_crf_flag_workflow_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.event_crf_flag_workflow_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.event_crf_flag_workflow_id_seq OWNER TO libreclinica;

--
-- Name: event_crf_flag_workflow_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.event_crf_flag_workflow_id_seq OWNED BY public.event_crf_flag_workflow.id;


--
-- Name: event_definition_crf; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.event_definition_crf (
    event_definition_crf_id integer NOT NULL,
    study_event_definition_id integer,
    study_id integer,
    crf_id integer,
    required_crf boolean,
    double_entry boolean,
    require_all_text_filled boolean,
    decision_conditions boolean,
    null_values character varying(255),
    default_version_id integer,
    status_id integer,
    owner_id integer,
    date_created date,
    date_updated date,
    update_id integer,
    ordinal integer,
    electronic_signature boolean DEFAULT false,
    hide_crf boolean DEFAULT false,
    source_data_verification_code integer,
    selected_version_ids character varying(150),
    parent_id integer,
    participant_form boolean DEFAULT false,
    allow_anonymous_submission boolean DEFAULT false,
    submission_url character varying(255)
);


ALTER TABLE public.event_definition_crf OWNER TO libreclinica;

--
-- Name: event_definition_crf_event_definition_crf_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.event_definition_crf_event_definition_crf_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.event_definition_crf_event_definition_crf_id_seq OWNER TO libreclinica;

--
-- Name: event_definition_crf_event_definition_crf_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.event_definition_crf_event_definition_crf_id_seq OWNED BY public.event_definition_crf.event_definition_crf_id;


--
-- Name: event_definition_crf_item_tag; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.event_definition_crf_item_tag (
    id integer NOT NULL,
    path character varying(255),
    tag_id integer,
    active boolean,
    owner_id integer,
    update_id integer,
    date_created timestamp with time zone,
    date_updated timestamp with time zone
);


ALTER TABLE public.event_definition_crf_item_tag OWNER TO libreclinica;

--
-- Name: event_definition_crf_item_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.event_definition_crf_item_tag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.event_definition_crf_item_tag_id_seq OWNER TO libreclinica;

--
-- Name: event_definition_crf_item_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.event_definition_crf_item_tag_id_seq OWNED BY public.event_definition_crf_item_tag.id;


--
-- Name: event_definition_crf_tag; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.event_definition_crf_tag (
    id integer NOT NULL,
    path character varying(255),
    tag_id integer,
    active boolean,
    owner_id integer,
    update_id integer,
    date_created timestamp with time zone,
    date_updated timestamp with time zone
);


ALTER TABLE public.event_definition_crf_tag OWNER TO libreclinica;

--
-- Name: event_definition_crf_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.event_definition_crf_tag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.event_definition_crf_tag_id_seq OWNER TO libreclinica;

--
-- Name: event_definition_crf_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.event_definition_crf_tag_id_seq OWNED BY public.event_definition_crf_tag.id;


--
-- Name: export_format; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.export_format (
    export_format_id integer NOT NULL,
    name character varying(255),
    description character varying(1000),
    mime_type character varying(255)
);


ALTER TABLE public.export_format OWNER TO libreclinica;

--
-- Name: export_format_export_format_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.export_format_export_format_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.export_format_export_format_id_seq OWNER TO libreclinica;

--
-- Name: export_format_export_format_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.export_format_export_format_id_seq OWNED BY public.export_format.export_format_id;


--
-- Name: filter; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.filter (
    filter_id integer NOT NULL,
    name character varying(255),
    description character varying(2000),
    sql_statement text,
    status_id integer,
    date_created date,
    date_updated date,
    owner_id integer NOT NULL,
    update_id integer
);


ALTER TABLE public.filter OWNER TO libreclinica;

--
-- Name: filter_crf_version_map; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.filter_crf_version_map (
    filter_id integer,
    crf_version_id integer
);


ALTER TABLE public.filter_crf_version_map OWNER TO libreclinica;

--
-- Name: filter_filter_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.filter_filter_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.filter_filter_id_seq OWNER TO libreclinica;

--
-- Name: filter_filter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.filter_filter_id_seq OWNED BY public.filter.filter_id;


--
-- Name: group_class_types; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.group_class_types (
    group_class_type_id integer NOT NULL,
    name character varying(255),
    description character varying(1000)
);


ALTER TABLE public.group_class_types OWNER TO libreclinica;

--
-- Name: group_class_types_group_class_type_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.group_class_types_group_class_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_class_types_group_class_type_id_seq OWNER TO libreclinica;

--
-- Name: group_class_types_group_class_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.group_class_types_group_class_type_id_seq OWNED BY public.group_class_types.group_class_type_id;


--
-- Name: item; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.item (
    item_id integer NOT NULL,
    name character varying(255),
    description character varying(4000),
    units character varying(64),
    phi_status boolean,
    item_data_type_id integer,
    item_reference_type_id integer,
    status_id integer,
    owner_id integer,
    date_created date,
    date_updated date,
    update_id integer,
    oc_oid character varying(40) NOT NULL
);


ALTER TABLE public.item OWNER TO libreclinica;

--
-- Name: item_data; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.item_data (
    item_data_id integer NOT NULL,
    item_id integer NOT NULL,
    event_crf_id integer,
    status_id integer,
    value character varying(4000),
    date_created date,
    date_updated date,
    owner_id integer,
    update_id integer,
    ordinal integer,
    old_status_id integer,
    deleted boolean DEFAULT false
);


ALTER TABLE public.item_data OWNER TO libreclinica;

--
-- Name: item_data_flag; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.item_data_flag (
    id integer NOT NULL,
    path character varying(255),
    tag_id integer,
    flag_workflow_id integer,
    owner_id integer,
    update_id integer,
    date_created timestamp with time zone,
    date_updated timestamp with time zone
);


ALTER TABLE public.item_data_flag OWNER TO libreclinica;

--
-- Name: item_data_flag_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.item_data_flag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_data_flag_id_seq OWNER TO libreclinica;

--
-- Name: item_data_flag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.item_data_flag_id_seq OWNED BY public.item_data_flag.id;


--
-- Name: item_data_flag_workflow; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.item_data_flag_workflow (
    id integer NOT NULL,
    workflow_id character varying(255),
    workflow_status character varying(255),
    owner_id integer,
    update_id integer,
    date_created timestamp with time zone,
    date_updated timestamp with time zone
);


ALTER TABLE public.item_data_flag_workflow OWNER TO libreclinica;

--
-- Name: item_data_flag_workflow_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.item_data_flag_workflow_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_data_flag_workflow_id_seq OWNER TO libreclinica;

--
-- Name: item_data_flag_workflow_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.item_data_flag_workflow_id_seq OWNED BY public.item_data_flag_workflow.id;


--
-- Name: item_data_item_data_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.item_data_item_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_data_item_data_id_seq OWNER TO libreclinica;

--
-- Name: item_data_item_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.item_data_item_data_id_seq OWNED BY public.item_data.item_data_id;


--
-- Name: item_data_type; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.item_data_type (
    item_data_type_id integer NOT NULL,
    code character varying(20),
    name character varying(255),
    definition character varying(1000),
    reference character varying(1000)
);


ALTER TABLE public.item_data_type OWNER TO libreclinica;

--
-- Name: item_data_type_item_data_type_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.item_data_type_item_data_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_data_type_item_data_type_id_seq OWNER TO libreclinica;

--
-- Name: item_data_type_item_data_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.item_data_type_item_data_type_id_seq OWNED BY public.item_data_type.item_data_type_id;


--
-- Name: item_form_metadata; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.item_form_metadata (
    item_form_metadata_id integer NOT NULL,
    item_id integer NOT NULL,
    crf_version_id integer,
    header character varying(2000),
    subheader character varying(240),
    parent_id integer,
    parent_label character varying(120),
    column_number integer,
    page_number_label character varying(5),
    question_number_label character varying(20),
    left_item_text character varying(4000),
    right_item_text character varying(2000),
    section_id integer NOT NULL,
    decision_condition_id integer,
    response_set_id integer NOT NULL,
    regexp character varying(1000),
    regexp_error_msg character varying(255),
    ordinal integer NOT NULL,
    required boolean,
    default_value character varying(4000),
    response_layout character varying(255),
    width_decimal character varying(10),
    show_item boolean DEFAULT true
);


ALTER TABLE public.item_form_metadata OWNER TO libreclinica;

--
-- Name: item_form_metadata_item_form_metadata_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.item_form_metadata_item_form_metadata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_form_metadata_item_form_metadata_id_seq OWNER TO libreclinica;

--
-- Name: item_form_metadata_item_form_metadata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.item_form_metadata_item_form_metadata_id_seq OWNED BY public.item_form_metadata.item_form_metadata_id;


--
-- Name: item_group; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.item_group (
    item_group_id integer NOT NULL,
    name character varying(255),
    crf_id integer NOT NULL,
    status_id integer,
    date_created date,
    date_updated date,
    owner_id integer,
    update_id integer,
    oc_oid character varying(40) NOT NULL
);


ALTER TABLE public.item_group OWNER TO libreclinica;

--
-- Name: item_group_item_group_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.item_group_item_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_group_item_group_id_seq OWNER TO libreclinica;

--
-- Name: item_group_item_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.item_group_item_group_id_seq OWNED BY public.item_group.item_group_id;


--
-- Name: item_group_metadata; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.item_group_metadata (
    item_group_metadata_id integer NOT NULL,
    item_group_id integer NOT NULL,
    header character varying(255),
    subheader character varying(255),
    layout character varying(100),
    repeat_number integer,
    repeat_max integer,
    repeat_array character varying(255),
    row_start_number integer,
    crf_version_id integer NOT NULL,
    item_id integer NOT NULL,
    ordinal integer NOT NULL,
    borders integer,
    show_group boolean DEFAULT true,
    repeating_group boolean DEFAULT true NOT NULL
);


ALTER TABLE public.item_group_metadata OWNER TO libreclinica;

--
-- Name: item_group_metadata_item_group_metadata_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.item_group_metadata_item_group_metadata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_group_metadata_item_group_metadata_id_seq OWNER TO libreclinica;

--
-- Name: item_group_metadata_item_group_metadata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.item_group_metadata_item_group_metadata_id_seq OWNED BY public.item_group_metadata.item_group_metadata_id;


--
-- Name: item_item_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.item_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_item_id_seq OWNER TO libreclinica;

--
-- Name: item_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.item_item_id_seq OWNED BY public.item.item_id;


--
-- Name: item_reference_type; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.item_reference_type (
    item_reference_type_id integer NOT NULL,
    name character varying(255),
    description character varying(1000)
);


ALTER TABLE public.item_reference_type OWNER TO libreclinica;

--
-- Name: item_reference_type_item_reference_type_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.item_reference_type_item_reference_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_reference_type_item_reference_type_id_seq OWNER TO libreclinica;

--
-- Name: item_reference_type_item_reference_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.item_reference_type_item_reference_type_id_seq OWNED BY public.item_reference_type.item_reference_type_id;


--
-- Name: measurement_unit; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.measurement_unit (
    id integer NOT NULL,
    oc_oid character varying(40) NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(255),
    version integer
);


ALTER TABLE public.measurement_unit OWNER TO libreclinica;

--
-- Name: measurement_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.measurement_unit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.measurement_unit_id_seq OWNER TO libreclinica;

--
-- Name: measurement_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.measurement_unit_id_seq OWNED BY public.measurement_unit.id;


--
-- Name: null_value_type; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.null_value_type (
    null_value_type_id integer NOT NULL,
    code character varying(20),
    name character varying(255),
    definition character varying(1000),
    reference character varying(1000)
);


ALTER TABLE public.null_value_type OWNER TO libreclinica;

--
-- Name: null_value_type_null_value_type_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.null_value_type_null_value_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.null_value_type_null_value_type_id_seq OWNER TO libreclinica;

--
-- Name: null_value_type_null_value_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.null_value_type_null_value_type_id_seq OWNED BY public.null_value_type.null_value_type_id;


--
-- Name: oc_qrtz_blob_triggers; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.oc_qrtz_blob_triggers (
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    blob_data bytea
);


ALTER TABLE public.oc_qrtz_blob_triggers OWNER TO libreclinica;

--
-- Name: oc_qrtz_calendars; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.oc_qrtz_calendars (
    calendar_name character varying(200) NOT NULL,
    sched_name character varying(120) DEFAULT 'TestScheduler'::character varying NOT NULL,
    calendar bytea
);


ALTER TABLE public.oc_qrtz_calendars OWNER TO libreclinica;

--
-- Name: oc_qrtz_cron_triggers; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.oc_qrtz_cron_triggers (
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    cron_expression character varying(120) NOT NULL,
    time_zone_id character varying(80),
    sched_name character varying(120) DEFAULT 'TestScheduler'::character varying NOT NULL
);


ALTER TABLE public.oc_qrtz_cron_triggers OWNER TO libreclinica;

--
-- Name: oc_qrtz_fired_triggers; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.oc_qrtz_fired_triggers (
    entry_id character varying(95) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    instance_name character varying(200) NOT NULL,
    fired_time bigint NOT NULL,
    priority integer NOT NULL,
    state character varying(16) NOT NULL,
    job_name character varying(200),
    job_group character varying(200),
    is_stateful boolean,
    requests_recovery boolean,
    sched_name character varying(120) DEFAULT 'TestScheduler'::character varying NOT NULL,
    is_nonconcurrent boolean,
    is_update_data boolean,
    sched_time bigint NOT NULL
);


ALTER TABLE public.oc_qrtz_fired_triggers OWNER TO libreclinica;

--
-- Name: oc_qrtz_job_details; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.oc_qrtz_job_details (
    job_name character varying(200) NOT NULL,
    job_group character varying(200) NOT NULL,
    description character varying(250),
    job_class_name character varying(250) NOT NULL,
    is_durable boolean NOT NULL,
    requests_recovery boolean NOT NULL,
    sched_name character varying(120) DEFAULT 'TestScheduler'::character varying NOT NULL,
    is_nonconcurrent boolean,
    is_update_data boolean,
    job_data bytea
);


ALTER TABLE public.oc_qrtz_job_details OWNER TO libreclinica;

--
-- Name: oc_qrtz_job_listeners; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.oc_qrtz_job_listeners (
    job_name character varying(200) NOT NULL,
    job_group character varying(200) NOT NULL,
    job_listener character varying(200) NOT NULL
);


ALTER TABLE public.oc_qrtz_job_listeners OWNER TO libreclinica;

--
-- Name: oc_qrtz_locks; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.oc_qrtz_locks (
    lock_name character varying(40) NOT NULL,
    sched_name character varying(120) DEFAULT 'TestScheduler'::character varying NOT NULL
);


ALTER TABLE public.oc_qrtz_locks OWNER TO libreclinica;

--
-- Name: oc_qrtz_paused_trigger_grps; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.oc_qrtz_paused_trigger_grps (
    trigger_group character varying(200) NOT NULL,
    sched_name character varying(120) DEFAULT 'TestScheduler'::character varying NOT NULL
);


ALTER TABLE public.oc_qrtz_paused_trigger_grps OWNER TO libreclinica;

--
-- Name: oc_qrtz_scheduler_state; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.oc_qrtz_scheduler_state (
    instance_name character varying(200) NOT NULL,
    last_checkin_time bigint NOT NULL,
    checkin_interval bigint NOT NULL,
    sched_name character varying(120) DEFAULT 'TestScheduler'::character varying NOT NULL
);


ALTER TABLE public.oc_qrtz_scheduler_state OWNER TO libreclinica;

--
-- Name: oc_qrtz_simple_triggers; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.oc_qrtz_simple_triggers (
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    repeat_count bigint NOT NULL,
    repeat_interval bigint NOT NULL,
    times_triggered bigint NOT NULL,
    sched_name character varying(120) DEFAULT 'TestScheduler'::character varying NOT NULL
);


ALTER TABLE public.oc_qrtz_simple_triggers OWNER TO libreclinica;

--
-- Name: oc_qrtz_trigger_listeners; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.oc_qrtz_trigger_listeners (
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    trigger_listener character varying(200) NOT NULL
);


ALTER TABLE public.oc_qrtz_trigger_listeners OWNER TO libreclinica;

--
-- Name: oc_qrtz_triggers; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.oc_qrtz_triggers (
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    job_name character varying(200) NOT NULL,
    job_group character varying(200) NOT NULL,
    description character varying(250),
    next_fire_time bigint,
    prev_fire_time bigint,
    priority integer,
    trigger_state character varying(16) NOT NULL,
    trigger_type character varying(8) NOT NULL,
    start_time bigint NOT NULL,
    end_time bigint,
    calendar_name character varying(200),
    misfire_instr smallint,
    sched_name character varying(120) DEFAULT 'TestScheduler'::character varying NOT NULL,
    job_data bytea
);


ALTER TABLE public.oc_qrtz_triggers OWNER TO libreclinica;

--
-- Name: openclinica_version; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.openclinica_version (
    id integer NOT NULL,
    name character varying(255),
    build_number character varying(1000),
    version integer,
    update_timestamp timestamp without time zone
);


ALTER TABLE public.openclinica_version OWNER TO libreclinica;

--
-- Name: openclinica_version_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.openclinica_version_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.openclinica_version_id_seq OWNER TO libreclinica;

--
-- Name: openclinica_version_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.openclinica_version_id_seq OWNED BY public.openclinica_version.id;


--
-- Name: privilege; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.privilege (
    priv_id integer NOT NULL,
    priv_name character varying(50),
    priv_desc character varying(2000)
);


ALTER TABLE public.privilege OWNER TO libreclinica;

--
-- Name: privilege_priv_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.privilege_priv_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.privilege_priv_id_seq OWNER TO libreclinica;

--
-- Name: privilege_priv_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.privilege_priv_id_seq OWNED BY public.privilege.priv_id;


--
-- Name: resolution_status; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.resolution_status (
    resolution_status_id integer NOT NULL,
    name character varying(50),
    description character varying(255)
);


ALTER TABLE public.resolution_status OWNER TO libreclinica;

--
-- Name: resolution_status_resolution_status_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.resolution_status_resolution_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.resolution_status_resolution_status_id_seq OWNER TO libreclinica;

--
-- Name: resolution_status_resolution_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.resolution_status_resolution_status_id_seq OWNED BY public.resolution_status.resolution_status_id;


--
-- Name: response_set; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.response_set (
    response_set_id integer NOT NULL,
    response_type_id integer,
    label character varying(80),
    options_text character varying(4000),
    options_values character varying(4000),
    version_id integer
);


ALTER TABLE public.response_set OWNER TO libreclinica;

--
-- Name: response_set_response_set_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.response_set_response_set_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.response_set_response_set_id_seq OWNER TO libreclinica;

--
-- Name: response_set_response_set_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.response_set_response_set_id_seq OWNED BY public.response_set.response_set_id;


--
-- Name: response_type; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.response_type (
    response_type_id integer NOT NULL,
    name character varying(255),
    description character varying(1000)
);


ALTER TABLE public.response_type OWNER TO libreclinica;

--
-- Name: response_type_response_type_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.response_type_response_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.response_type_response_type_id_seq OWNER TO libreclinica;

--
-- Name: response_type_response_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.response_type_response_type_id_seq OWNED BY public.response_type.response_type_id;


--
-- Name: role_privilege_map; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.role_privilege_map (
    role_id integer NOT NULL,
    priv_id integer NOT NULL,
    priv_value character varying(50)
);


ALTER TABLE public.role_privilege_map OWNER TO libreclinica;

--
-- Name: rule; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.rule (
    id integer NOT NULL,
    name character varying(255),
    description character varying(255),
    oc_oid character varying(40),
    enabled boolean,
    rule_expression_id integer NOT NULL,
    owner_id integer,
    date_created date,
    date_updated date,
    update_id integer,
    status_id integer,
    version integer,
    study_id integer
);


ALTER TABLE public.rule OWNER TO libreclinica;

--
-- Name: rule_action; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.rule_action (
    id integer NOT NULL,
    rule_set_rule_id integer NOT NULL,
    action_type integer NOT NULL,
    expression_evaluates_to boolean NOT NULL,
    message character varying(2040),
    email_to character varying(255),
    owner_id integer,
    date_created date,
    date_updated date,
    update_id integer,
    status_id integer,
    version integer,
    rule_action_run_id integer,
    oc_oid_reference character varying(4000),
    email_subject character varying(1020)
);


ALTER TABLE public.rule_action OWNER TO libreclinica;

--
-- Name: rule_action_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.rule_action_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rule_action_id_seq OWNER TO libreclinica;

--
-- Name: rule_action_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.rule_action_id_seq OWNED BY public.rule_action.id;


--
-- Name: rule_action_property; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.rule_action_property (
    id integer NOT NULL,
    rule_action_id integer,
    oc_oid character varying(512),
    value character varying(512),
    version integer,
    rule_expression_id integer,
    property character varying(4000)
);


ALTER TABLE public.rule_action_property OWNER TO libreclinica;

--
-- Name: rule_action_property_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.rule_action_property_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rule_action_property_id_seq OWNER TO libreclinica;

--
-- Name: rule_action_property_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.rule_action_property_id_seq OWNED BY public.rule_action_property.id;


--
-- Name: rule_action_run; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.rule_action_run (
    id integer NOT NULL,
    administrative_data_entry boolean,
    initial_data_entry boolean,
    double_data_entry boolean,
    import_data_entry boolean,
    batch boolean,
    version integer,
    not_started boolean,
    scheduled boolean,
    data_entry_started boolean,
    complete boolean,
    skipped boolean,
    stopped boolean
);


ALTER TABLE public.rule_action_run OWNER TO libreclinica;

--
-- Name: rule_action_run_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.rule_action_run_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rule_action_run_id_seq OWNER TO libreclinica;

--
-- Name: rule_action_run_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.rule_action_run_id_seq OWNED BY public.rule_action_run.id;


--
-- Name: rule_action_run_log; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.rule_action_run_log (
    id integer NOT NULL,
    action_type integer,
    item_data_id integer,
    value character varying(4000),
    rule_oc_oid character varying(40),
    version integer
);


ALTER TABLE public.rule_action_run_log OWNER TO libreclinica;

--
-- Name: rule_action_run_log_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.rule_action_run_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rule_action_run_log_id_seq OWNER TO libreclinica;

--
-- Name: rule_action_run_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.rule_action_run_log_id_seq OWNED BY public.rule_action_run_log.id;


--
-- Name: rule_action_stratification_factor; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.rule_action_stratification_factor (
    id integer NOT NULL,
    rule_action_id integer,
    version integer,
    rule_expression_id integer
);


ALTER TABLE public.rule_action_stratification_factor OWNER TO libreclinica;

--
-- Name: rule_action_stratification_factor_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.rule_action_stratification_factor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rule_action_stratification_factor_id_seq OWNER TO libreclinica;

--
-- Name: rule_action_stratification_factor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.rule_action_stratification_factor_id_seq OWNED BY public.rule_action_stratification_factor.id;


--
-- Name: rule_expression; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.rule_expression (
    id integer NOT NULL,
    value character varying(2040) NOT NULL,
    context integer NOT NULL,
    owner_id integer,
    date_created date,
    date_updated date,
    update_id integer,
    status_id integer,
    version integer
);


ALTER TABLE public.rule_expression OWNER TO libreclinica;

--
-- Name: rule_expression_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.rule_expression_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rule_expression_id_seq OWNER TO libreclinica;

--
-- Name: rule_expression_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.rule_expression_id_seq OWNED BY public.rule_expression.id;


--
-- Name: rule_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.rule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rule_id_seq OWNER TO libreclinica;

--
-- Name: rule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.rule_id_seq OWNED BY public.rule.id;


--
-- Name: rule_set; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.rule_set (
    id integer NOT NULL,
    rule_expression_id integer NOT NULL,
    study_event_definition_id integer,
    crf_id integer,
    crf_version_id integer,
    study_id integer NOT NULL,
    owner_id integer,
    date_created date,
    date_updated date,
    update_id integer,
    status_id integer,
    version integer,
    item_id integer,
    item_group_id integer,
    run_schedule boolean DEFAULT false,
    run_time character varying(255)
);


ALTER TABLE public.rule_set OWNER TO libreclinica;

--
-- Name: rule_set_audit; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.rule_set_audit (
    id integer NOT NULL,
    rule_set_id integer NOT NULL,
    date_updated date,
    updater_id integer,
    status_id integer,
    version integer
);


ALTER TABLE public.rule_set_audit OWNER TO libreclinica;

--
-- Name: rule_set_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.rule_set_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rule_set_audit_id_seq OWNER TO libreclinica;

--
-- Name: rule_set_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.rule_set_audit_id_seq OWNED BY public.rule_set_audit.id;


--
-- Name: rule_set_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.rule_set_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rule_set_id_seq OWNER TO libreclinica;

--
-- Name: rule_set_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.rule_set_id_seq OWNED BY public.rule_set.id;


--
-- Name: rule_set_rule; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.rule_set_rule (
    id integer NOT NULL,
    rule_set_id integer NOT NULL,
    rule_id integer NOT NULL,
    owner_id integer,
    date_created date,
    date_updated date,
    update_id integer,
    status_id integer,
    version integer
);


ALTER TABLE public.rule_set_rule OWNER TO libreclinica;

--
-- Name: rule_set_rule_audit; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.rule_set_rule_audit (
    id integer NOT NULL,
    rule_set_rule_id integer NOT NULL,
    date_updated date,
    updater_id integer,
    status_id integer,
    version integer
);


ALTER TABLE public.rule_set_rule_audit OWNER TO libreclinica;

--
-- Name: rule_set_rule_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.rule_set_rule_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rule_set_rule_audit_id_seq OWNER TO libreclinica;

--
-- Name: rule_set_rule_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.rule_set_rule_audit_id_seq OWNED BY public.rule_set_rule_audit.id;


--
-- Name: rule_set_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.rule_set_rule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rule_set_rule_id_seq OWNER TO libreclinica;

--
-- Name: rule_set_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.rule_set_rule_id_seq OWNED BY public.rule_set_rule.id;


--
-- Name: scd_item_metadata; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.scd_item_metadata (
    id integer NOT NULL,
    scd_item_form_metadata_id integer,
    control_item_form_metadata_id integer,
    control_item_name character varying(255),
    option_value character varying(500),
    message character varying(3000),
    version integer
);


ALTER TABLE public.scd_item_metadata OWNER TO libreclinica;

--
-- Name: scd_item_metadata_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.scd_item_metadata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scd_item_metadata_id_seq OWNER TO libreclinica;

--
-- Name: scd_item_metadata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.scd_item_metadata_id_seq OWNED BY public.scd_item_metadata.id;


--
-- Name: section; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.section (
    section_id integer NOT NULL,
    crf_version_id integer NOT NULL,
    status_id integer,
    label character varying(2000),
    title character varying(2000),
    subtitle character varying(2000),
    instructions character varying(2000),
    page_number_label character varying(5),
    ordinal integer,
    parent_id integer,
    date_created date,
    date_updated date,
    owner_id integer NOT NULL,
    update_id integer,
    borders integer
);


ALTER TABLE public.section OWNER TO libreclinica;

--
-- Name: section_section_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.section_section_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.section_section_id_seq OWNER TO libreclinica;

--
-- Name: section_section_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.section_section_id_seq OWNED BY public.section.section_id;


--
-- Name: status; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.status (
    status_id integer NOT NULL,
    name character varying(255),
    description character varying(1000)
);


ALTER TABLE public.status OWNER TO libreclinica;

--
-- Name: status_status_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.status_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.status_status_id_seq OWNER TO libreclinica;

--
-- Name: status_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.status_status_id_seq OWNED BY public.status.status_id;


--
-- Name: study; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.study (
    study_id integer NOT NULL,
    parent_study_id integer,
    unique_identifier character varying(30),
    secondary_identifier character varying(255),
    name character varying(255),
    summary character varying(255),
    date_planned_start date,
    date_planned_end date,
    date_created date,
    date_updated date,
    owner_id integer,
    update_id integer,
    type_id integer,
    status_id integer,
    principal_investigator character varying(255),
    facility_name character varying(255),
    facility_city character varying(255),
    facility_state character varying(20),
    facility_zip character varying(64),
    facility_country character varying(64),
    facility_recruitment_status character varying(60),
    facility_contact_name character varying(255),
    facility_contact_degree character varying(255),
    facility_contact_phone character varying(255),
    facility_contact_email character varying(255),
    protocol_type character varying(30),
    protocol_description character varying(1000),
    protocol_date_verification date,
    phase character varying(30),
    expected_total_enrollment integer,
    sponsor character varying(255),
    collaborators character varying(1000),
    medline_identifier character varying(255),
    url character varying(255),
    url_description character varying(255),
    conditions character varying(500),
    keywords character varying(255),
    eligibility character varying(500),
    gender character varying(30),
    age_max character varying(3),
    age_min character varying(3),
    healthy_volunteer_accepted boolean,
    purpose character varying(64),
    allocation character varying(64),
    masking character varying(30),
    control character varying(30),
    assignment character varying(30),
    endpoint character varying(64),
    interventions character varying(1000),
    duration character varying(30),
    selection character varying(30),
    timing character varying(30),
    official_title character varying(255),
    results_reference boolean,
    oc_oid character varying(40) NOT NULL,
    old_status_id integer DEFAULT 1
);


ALTER TABLE public.study OWNER TO libreclinica;

--
-- Name: study_event; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.study_event (
    study_event_id integer NOT NULL,
    study_event_definition_id integer,
    study_subject_id integer,
    location character varying(2000),
    sample_ordinal integer,
    date_start timestamp without time zone,
    date_end timestamp without time zone,
    owner_id integer,
    status_id integer,
    date_created timestamp with time zone,
    date_updated timestamp with time zone,
    update_id integer,
    subject_event_status_id integer,
    start_time_flag boolean,
    end_time_flag boolean
);


ALTER TABLE public.study_event OWNER TO libreclinica;

--
-- Name: study_event_definition; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.study_event_definition (
    study_event_definition_id integer NOT NULL,
    study_id integer,
    name character varying(2000),
    description character varying(2000),
    repeating boolean,
    type character varying(20),
    category character varying(2000),
    owner_id integer,
    status_id integer,
    date_created date,
    date_updated date,
    update_id integer,
    ordinal integer,
    oc_oid character varying(40) NOT NULL
);


ALTER TABLE public.study_event_definition OWNER TO libreclinica;

--
-- Name: study_event_definition_study_event_definition_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.study_event_definition_study_event_definition_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.study_event_definition_study_event_definition_id_seq OWNER TO libreclinica;

--
-- Name: study_event_definition_study_event_definition_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.study_event_definition_study_event_definition_id_seq OWNED BY public.study_event_definition.study_event_definition_id;


--
-- Name: study_event_study_event_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.study_event_study_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.study_event_study_event_id_seq OWNER TO libreclinica;

--
-- Name: study_event_study_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.study_event_study_event_id_seq OWNED BY public.study_event.study_event_id;


--
-- Name: study_group; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.study_group (
    study_group_id integer NOT NULL,
    name character varying(255),
    description character varying(1000),
    study_group_class_id integer
);


ALTER TABLE public.study_group OWNER TO libreclinica;

--
-- Name: study_group_class; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.study_group_class (
    study_group_class_id integer NOT NULL,
    name character varying(30),
    study_id integer,
    owner_id integer,
    date_created date,
    group_class_type_id integer,
    status_id integer,
    date_updated date,
    update_id integer,
    subject_assignment character varying(30)
);


ALTER TABLE public.study_group_class OWNER TO libreclinica;

--
-- Name: study_group_class_study_group_class_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.study_group_class_study_group_class_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.study_group_class_study_group_class_id_seq OWNER TO libreclinica;

--
-- Name: study_group_class_study_group_class_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.study_group_class_study_group_class_id_seq OWNED BY public.study_group_class.study_group_class_id;


--
-- Name: study_group_study_group_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.study_group_study_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.study_group_study_group_id_seq OWNER TO libreclinica;

--
-- Name: study_group_study_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.study_group_study_group_id_seq OWNED BY public.study_group.study_group_id;


--
-- Name: study_module_status; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.study_module_status (
    id integer NOT NULL,
    study_id integer,
    study integer DEFAULT 1,
    crf integer DEFAULT 1,
    event_definition integer DEFAULT 1,
    subject_group integer DEFAULT 1,
    rule integer DEFAULT 1,
    site integer DEFAULT 1,
    users integer DEFAULT 1,
    version integer,
    date_created date,
    date_updated date,
    owner_id integer,
    update_id integer,
    status_id integer
);


ALTER TABLE public.study_module_status OWNER TO libreclinica;

--
-- Name: study_module_status_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.study_module_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.study_module_status_id_seq OWNER TO libreclinica;

--
-- Name: study_module_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.study_module_status_id_seq OWNED BY public.study_module_status.id;


--
-- Name: study_parameter; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.study_parameter (
    study_parameter_id integer NOT NULL,
    handle character varying(50),
    name character varying(50),
    description character varying(255),
    default_value character varying(50),
    inheritable boolean DEFAULT true,
    overridable boolean
);


ALTER TABLE public.study_parameter OWNER TO libreclinica;

--
-- Name: study_parameter_study_parameter_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.study_parameter_study_parameter_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.study_parameter_study_parameter_id_seq OWNER TO libreclinica;

--
-- Name: study_parameter_study_parameter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.study_parameter_study_parameter_id_seq OWNED BY public.study_parameter.study_parameter_id;


--
-- Name: study_parameter_value; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.study_parameter_value (
    study_parameter_value_id integer NOT NULL,
    study_id integer,
    value character varying(50),
    parameter character varying(50)
);


ALTER TABLE public.study_parameter_value OWNER TO libreclinica;

--
-- Name: study_parameter_value_study_parameter_value_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.study_parameter_value_study_parameter_value_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.study_parameter_value_study_parameter_value_id_seq OWNER TO libreclinica;

--
-- Name: study_parameter_value_study_parameter_value_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.study_parameter_value_study_parameter_value_id_seq OWNED BY public.study_parameter_value.study_parameter_value_id;


--
-- Name: study_study_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.study_study_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.study_study_id_seq OWNER TO libreclinica;

--
-- Name: study_study_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.study_study_id_seq OWNED BY public.study.study_id;


--
-- Name: study_subject; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.study_subject (
    study_subject_id integer NOT NULL,
    label character varying(30),
    secondary_label character varying(30),
    subject_id integer,
    study_id integer,
    status_id integer,
    enrollment_date date,
    date_created timestamp with time zone,
    date_updated timestamp with time zone,
    owner_id integer,
    update_id integer,
    oc_oid character varying(40) NOT NULL,
    time_zone character varying(255) DEFAULT ''::character varying
);


ALTER TABLE public.study_subject OWNER TO libreclinica;

--
-- Name: study_subject_study_subject_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.study_subject_study_subject_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.study_subject_study_subject_id_seq OWNER TO libreclinica;

--
-- Name: study_subject_study_subject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.study_subject_study_subject_id_seq OWNED BY public.study_subject.study_subject_id;


--
-- Name: study_type; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.study_type (
    study_type_id integer NOT NULL,
    name character varying(255),
    description character varying(1000)
);


ALTER TABLE public.study_type OWNER TO libreclinica;

--
-- Name: study_type_study_type_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.study_type_study_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.study_type_study_type_id_seq OWNER TO libreclinica;

--
-- Name: study_type_study_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.study_type_study_type_id_seq OWNED BY public.study_type.study_type_id;


--
-- Name: study_user_role; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.study_user_role (
    role_name character varying(40),
    study_id integer,
    status_id integer,
    owner_id integer,
    date_created date,
    date_updated date,
    update_id integer,
    user_name character varying(40)
);


ALTER TABLE public.study_user_role OWNER TO libreclinica;

--
-- Name: subject; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.subject (
    subject_id integer NOT NULL,
    father_id integer,
    mother_id integer,
    status_id integer,
    date_of_birth date,
    gender character(1),
    unique_identifier character varying(255),
    date_created timestamp with time zone,
    owner_id integer,
    date_updated timestamp with time zone,
    update_id integer,
    dob_collected boolean
);


ALTER TABLE public.subject OWNER TO libreclinica;

--
-- Name: subject_event_status; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.subject_event_status (
    subject_event_status_id integer NOT NULL,
    name character varying(255),
    description character varying(1000)
);


ALTER TABLE public.subject_event_status OWNER TO libreclinica;

--
-- Name: subject_event_status_subject_event_status_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.subject_event_status_subject_event_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subject_event_status_subject_event_status_id_seq OWNER TO libreclinica;

--
-- Name: subject_event_status_subject_event_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.subject_event_status_subject_event_status_id_seq OWNED BY public.subject_event_status.subject_event_status_id;


--
-- Name: subject_group_map; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.subject_group_map (
    subject_group_map_id integer NOT NULL,
    study_group_class_id integer,
    study_subject_id integer,
    study_group_id integer,
    status_id integer,
    owner_id integer,
    date_created date,
    date_updated date,
    update_id integer,
    notes character varying(255)
);


ALTER TABLE public.subject_group_map OWNER TO libreclinica;

--
-- Name: subject_group_map_subject_group_map_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.subject_group_map_subject_group_map_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subject_group_map_subject_group_map_id_seq OWNER TO libreclinica;

--
-- Name: subject_group_map_subject_group_map_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.subject_group_map_subject_group_map_id_seq OWNED BY public.subject_group_map.subject_group_map_id;


--
-- Name: subject_subject_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.subject_subject_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subject_subject_id_seq OWNER TO libreclinica;

--
-- Name: subject_subject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.subject_subject_id_seq OWNED BY public.subject.subject_id;


--
-- Name: tag; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.tag (
    id integer NOT NULL,
    tag_name character varying(255),
    workflow character varying(255),
    owner_id integer,
    update_id integer,
    date_created timestamp with time zone,
    date_updated timestamp with time zone
);


ALTER TABLE public.tag OWNER TO libreclinica;

--
-- Name: tag_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.tag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tag_id_seq OWNER TO libreclinica;

--
-- Name: tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.tag_id_seq OWNED BY public.tag.id;


--
-- Name: usage_statistics_data; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.usage_statistics_data (
    id integer NOT NULL,
    param_key character varying(255),
    param_value character varying(1000),
    update_timestamp timestamp without time zone,
    version integer
);


ALTER TABLE public.usage_statistics_data OWNER TO libreclinica;

--
-- Name: usage_statistics_data_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.usage_statistics_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usage_statistics_data_id_seq OWNER TO libreclinica;

--
-- Name: usage_statistics_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.usage_statistics_data_id_seq OWNED BY public.usage_statistics_data.id;


--
-- Name: user_account; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.user_account (
    user_id integer NOT NULL,
    user_name character varying(64),
    passwd character varying(255),
    first_name character varying(50),
    last_name character varying(50),
    email character varying(120),
    active_study integer,
    institutional_affiliation character varying(255),
    status_id integer,
    owner_id integer,
    date_created date,
    date_updated date,
    date_lastvisit timestamp without time zone,
    passwd_timestamp date,
    passwd_challenge_question character varying(64),
    passwd_challenge_answer character varying(255),
    phone character varying(64),
    user_type_id integer,
    update_id integer,
    enabled boolean DEFAULT true NOT NULL,
    account_non_locked boolean DEFAULT true NOT NULL,
    lock_counter integer DEFAULT 0 NOT NULL,
    run_webservices boolean DEFAULT false NOT NULL,
    access_code character varying(64),
    time_zone character varying(255) DEFAULT ''::character varying,
    enable_api_key boolean DEFAULT false,
    api_key character varying(255)
);


ALTER TABLE public.user_account OWNER TO libreclinica;

--
-- Name: user_account_user_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.user_account_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_account_user_id_seq OWNER TO libreclinica;

--
-- Name: user_account_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.user_account_user_id_seq OWNED BY public.user_account.user_id;


--
-- Name: user_role; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.user_role (
    role_id integer NOT NULL,
    role_name character varying(50) NOT NULL,
    parent_id integer,
    role_desc character varying(2000)
);


ALTER TABLE public.user_role OWNER TO libreclinica;

--
-- Name: user_role_role_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.user_role_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_role_role_id_seq OWNER TO libreclinica;

--
-- Name: user_role_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.user_role_role_id_seq OWNED BY public.user_role.role_id;


--
-- Name: user_type; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.user_type (
    user_type_id integer NOT NULL,
    user_type character varying(50)
);


ALTER TABLE public.user_type OWNER TO libreclinica;

--
-- Name: user_type_user_type_id_seq; Type: SEQUENCE; Schema: public; Owner: libreclinica
--

CREATE SEQUENCE public.user_type_user_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_type_user_type_id_seq OWNER TO libreclinica;

--
-- Name: user_type_user_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: libreclinica
--

ALTER SEQUENCE public.user_type_user_type_id_seq OWNED BY public.user_type.user_type_id;


--
-- Name: versioning_map; Type: TABLE; Schema: public; Owner: libreclinica
--

CREATE TABLE public.versioning_map (
    crf_version_id integer,
    item_id integer
);


ALTER TABLE public.versioning_map OWNER TO libreclinica;

--
-- Name: view_dn_stats; Type: VIEW; Schema: public; Owner: libreclinica
--

CREATE VIEW public.view_dn_stats AS
 SELECT dn.discrepancy_note_id,
        CASE
            WHEN ((dn.resolution_status_id = 1) OR (dn.resolution_status_id = 2) OR (dn.resolution_status_id = 3)) THEN date_part('day'::text, (CURRENT_TIMESTAMP - totals.date_updated))
            ELSE (NULL::integer)::double precision
        END AS days,
        CASE
            WHEN ((dn.resolution_status_id = 1) OR (dn.resolution_status_id = 2) OR (dn.resolution_status_id = 3)) THEN date_part('day'::text, (CURRENT_TIMESTAMP - dn.date_created))
            WHEN (dn.resolution_status_id = 4) THEN date_part('day'::text, (totals.date_updated - dn.date_created))
            ELSE (NULL::integer)::double precision
        END AS age,
    totals.total_notes,
    dn.date_created,
    totals.date_updated
   FROM public.discrepancy_note dn,
    ( SELECT dn1.parent_dn_id,
            max(dn1.date_created) AS date_updated,
            count(dn1.discrepancy_note_id) AS total_notes
           FROM public.discrepancy_note dn1
          GROUP BY dn1.parent_dn_id) totals
  WHERE (((dn.parent_dn_id IS NULL) OR (dn.parent_dn_id = 0)) AND (dn.discrepancy_note_id = totals.parent_dn_id));


ALTER TABLE public.view_dn_stats OWNER TO libreclinica;

--
-- Name: view_dn_event_crf; Type: VIEW; Schema: public; Owner: libreclinica
--

CREATE VIEW public.view_dn_event_crf AS
 SELECT s.study_id,
    s.parent_study_id,
    ( SELECT event_definition_crf.hide_crf
           FROM public.event_definition_crf
          WHERE ((event_definition_crf.study_event_definition_id = sed.study_event_definition_id) AND ((event_definition_crf.study_id = s.study_id) OR (event_definition_crf.study_id = s.parent_study_id)) AND (event_definition_crf.crf_id = c.crf_id) AND ((event_definition_crf.parent_id = 0) OR (event_definition_crf.parent_id IS NULL)))) AS study_hide_crf,
    ( SELECT event_definition_crf.hide_crf
           FROM public.event_definition_crf
          WHERE ((event_definition_crf.study_event_definition_id = sed.study_event_definition_id) AND (event_definition_crf.study_id = s.study_id) AND (event_definition_crf.crf_id = c.crf_id) AND ((event_definition_crf.parent_id <> 0) OR (event_definition_crf.parent_id IS NOT NULL)))) AS site_hide_crf,
    dn.discrepancy_note_id,
    map.event_crf_id AS entity_id,
    map.column_name,
    ss.study_subject_id,
    ss.label,
    ss.status_id AS ss_status_id,
    dn.discrepancy_note_type_id,
    dn.resolution_status_id,
    s.unique_identifier AS site_id,
    ds.date_created,
    ds.date_updated,
    ds.days,
    ds.age,
    sed.name AS event_name,
    se.date_start,
    c.name AS crf_name,
    ec.status_id,
    NULL::integer AS item_id,
    map.column_name AS entity_name,
        CASE
            WHEN ((map.column_name)::text = 'date_interviewed'::text) THEN to_char((ec.date_interviewed)::timestamp with time zone, 'YYYY-MM-DD'::text)
            WHEN ((map.column_name)::text = 'interviewer_name'::text) THEN (ec.interviewer_name)::text
            ELSE btrim(''::text)
        END AS value,
    dn.entity_type,
    dn.description,
    dn.detailed_notes,
    ds.total_notes,
    ua.first_name,
    ua.last_name,
    ua.user_name,
    ua2.first_name AS owner_first_name,
    ua2.last_name AS owner_last_name,
    ua2.user_name AS owner_user_name
   FROM (((((((((((public.dn_event_crf_map map
     JOIN public.discrepancy_note dn ON (((dn.discrepancy_note_id = map.discrepancy_note_id) AND ((dn.entity_type)::text = 'eventCrf'::text) AND ((dn.parent_dn_id IS NULL) OR (dn.parent_dn_id = 0)))))
     JOIN public.view_dn_stats ds ON ((dn.discrepancy_note_id = ds.discrepancy_note_id)))
     JOIN public.user_account ua2 ON ((dn.owner_id = ua2.user_id)))
     JOIN public.event_crf ec ON ((map.event_crf_id = ec.event_crf_id)))
     JOIN public.study_event se ON ((ec.study_event_id = se.study_event_id)))
     JOIN public.crf_version cv ON ((ec.crf_version_id = cv.crf_version_id)))
     JOIN public.study_event_definition sed ON ((se.study_event_definition_id = sed.study_event_definition_id)))
     JOIN public.crf c ON ((cv.crf_id = c.crf_id)))
     JOIN public.study_subject ss ON ((se.study_subject_id = ss.study_subject_id)))
     JOIN public.study s ON ((ss.study_id = s.study_id)))
     LEFT JOIN public.user_account ua ON ((dn.assigned_user_id = ua.user_id)));


ALTER TABLE public.view_dn_event_crf OWNER TO libreclinica;

--
-- Name: view_dn_item_data; Type: VIEW; Schema: public; Owner: libreclinica
--

CREATE VIEW public.view_dn_item_data AS
 SELECT s.study_id,
    s.parent_study_id,
    ( SELECT event_definition_crf.hide_crf
           FROM public.event_definition_crf
          WHERE ((event_definition_crf.study_event_definition_id = sed.study_event_definition_id) AND ((event_definition_crf.study_id = s.study_id) OR (event_definition_crf.study_id = s.parent_study_id)) AND (event_definition_crf.crf_id = c.crf_id) AND ((event_definition_crf.parent_id = 0) OR (event_definition_crf.parent_id IS NULL)))) AS study_hide_crf,
    ( SELECT event_definition_crf.hide_crf
           FROM public.event_definition_crf
          WHERE ((event_definition_crf.study_event_definition_id = sed.study_event_definition_id) AND (event_definition_crf.study_id = s.study_id) AND (event_definition_crf.crf_id = c.crf_id) AND ((event_definition_crf.parent_id <> 0) OR (event_definition_crf.parent_id IS NOT NULL)))) AS site_hide_crf,
    dn.discrepancy_note_id,
    map.item_data_id AS entity_id,
    map.column_name,
    ss.study_subject_id,
    ss.label,
    ss.status_id AS ss_status_id,
    dn.discrepancy_note_type_id,
    dn.resolution_status_id,
    s.unique_identifier AS site_id,
    ds.date_created,
    ds.date_updated,
    ds.days,
    ds.age,
    sed.name AS event_name,
    se.date_start,
    c.name AS crf_name,
    ec.status_id,
    i.item_id,
    i.name AS entity_name,
    id.value,
    dn.entity_type,
    dn.description,
    dn.detailed_notes,
    ds.total_notes,
    ua.first_name,
    ua.last_name,
    ua.user_name,
    ua2.first_name AS owner_first_name,
    ua2.last_name AS owner_last_name,
    ua2.user_name AS owner_user_name
   FROM (((((((((((((public.dn_item_data_map map
     JOIN public.discrepancy_note dn ON (((dn.discrepancy_note_id = map.discrepancy_note_id) AND ((dn.entity_type)::text = 'itemData'::text) AND ((dn.parent_dn_id IS NULL) OR (dn.parent_dn_id = 0)))))
     JOIN public.view_dn_stats ds ON ((dn.discrepancy_note_id = ds.discrepancy_note_id)))
     JOIN public.user_account ua2 ON ((dn.owner_id = ua2.user_id)))
     JOIN public.item_data id ON ((map.item_data_id = id.item_data_id)))
     JOIN public.item i ON ((id.item_id = i.item_id)))
     JOIN public.event_crf ec ON ((id.event_crf_id = ec.event_crf_id)))
     JOIN public.study_event se ON ((ec.study_event_id = se.study_event_id)))
     JOIN public.crf_version cv ON ((ec.crf_version_id = cv.crf_version_id)))
     JOIN public.study_event_definition sed ON ((se.study_event_definition_id = sed.study_event_definition_id)))
     JOIN public.crf c ON ((cv.crf_id = c.crf_id)))
     JOIN public.study_subject ss ON ((se.study_subject_id = ss.study_subject_id)))
     JOIN public.study s ON ((ss.study_id = s.study_id)))
     LEFT JOIN public.user_account ua ON ((dn.assigned_user_id = ua.user_id)))
  WHERE (map.study_subject_id = ss.study_subject_id);


ALTER TABLE public.view_dn_item_data OWNER TO libreclinica;

--
-- Name: view_dn_study_event; Type: VIEW; Schema: public; Owner: libreclinica
--

CREATE VIEW public.view_dn_study_event AS
 SELECT s.study_id,
    s.parent_study_id,
    false AS study_hide_crf,
    false AS site_hide_crf,
    dn.discrepancy_note_id,
    map.study_event_id AS entity_id,
    map.column_name,
    ss.study_subject_id,
    ss.label,
    ss.status_id AS ss_status_id,
    dn.discrepancy_note_type_id,
    dn.resolution_status_id,
    s.unique_identifier AS site_id,
    ds.date_created,
    ds.date_updated,
    ds.days,
    ds.age,
    sed.name AS event_name,
    se.date_start,
    btrim(''::text) AS crf_name,
    0 AS status_id,
    NULL::integer AS item_id,
    map.column_name AS entity_name,
        CASE
            WHEN ((map.column_name)::text = 'start_date'::text) THEN to_char(se.date_start, 'YYYY-MM-DD'::text)
            WHEN ((map.column_name)::text = 'end_date'::text) THEN to_char(se.date_end, 'YYYY-MM-DD'::text)
            WHEN ((map.column_name)::text = 'location'::text) THEN (se.location)::text
            ELSE btrim(''::text)
        END AS value,
    dn.entity_type,
    dn.description,
    dn.detailed_notes,
    ds.total_notes,
    ua.first_name,
    ua.last_name,
    ua.user_name,
    ua2.first_name AS owner_first_name,
    ua2.last_name AS owner_last_name,
    ua2.user_name AS owner_user_name
   FROM ((((((((public.dn_study_event_map map
     JOIN public.discrepancy_note dn ON (((dn.discrepancy_note_id = map.discrepancy_note_id) AND ((dn.entity_type)::text = 'studyEvent'::text) AND ((dn.parent_dn_id IS NULL) OR (dn.parent_dn_id = 0)))))
     JOIN public.view_dn_stats ds ON ((dn.discrepancy_note_id = ds.discrepancy_note_id)))
     JOIN public.user_account ua2 ON ((dn.owner_id = ua2.user_id)))
     JOIN public.study_event se ON ((map.study_event_id = se.study_event_id)))
     JOIN public.study_subject ss ON ((se.study_subject_id = ss.study_subject_id)))
     JOIN public.study s ON ((ss.study_id = s.study_id)))
     JOIN public.study_event_definition sed ON ((se.study_event_definition_id = sed.study_event_definition_id)))
     LEFT JOIN public.user_account ua ON ((dn.assigned_user_id = ua.user_id)));


ALTER TABLE public.view_dn_study_event OWNER TO libreclinica;

--
-- Name: view_dn_study_subject; Type: VIEW; Schema: public; Owner: libreclinica
--

CREATE VIEW public.view_dn_study_subject AS
 SELECT s.study_id,
    s.parent_study_id,
    false AS study_hide_crf,
    false AS site_hide_crf,
    dn.discrepancy_note_id,
    map.study_subject_id AS entity_id,
    map.column_name,
    ss.study_subject_id,
    ss.label,
    ss.status_id AS ss_status_id,
    dn.discrepancy_note_type_id,
    dn.resolution_status_id,
    s.unique_identifier AS site_id,
    ds.date_created,
    ds.date_updated,
    ds.days,
    ds.age,
    btrim(''::text) AS event_name,
    NULL::timestamp with time zone AS date_start,
    btrim(''::text) AS crf_name,
    0 AS status_id,
    NULL::integer AS item_id,
    map.column_name AS entity_name,
    to_char((ss.enrollment_date)::timestamp with time zone, 'YYYY-MM-DD'::text) AS value,
    dn.entity_type,
    dn.description,
    dn.detailed_notes,
    ds.total_notes,
    ua.first_name,
    ua.last_name,
    ua.user_name,
    ua2.first_name AS owner_first_name,
    ua2.last_name AS owner_last_name,
    ua2.user_name AS owner_user_name
   FROM ((((((public.dn_study_subject_map map
     JOIN public.discrepancy_note dn ON (((dn.discrepancy_note_id = map.discrepancy_note_id) AND ((dn.entity_type)::text = 'studySub'::text) AND ((dn.parent_dn_id IS NULL) OR (dn.parent_dn_id = 0)))))
     JOIN public.view_dn_stats ds ON ((dn.discrepancy_note_id = ds.discrepancy_note_id)))
     JOIN public.user_account ua2 ON ((dn.owner_id = ua2.user_id)))
     JOIN public.study_subject ss ON ((map.study_subject_id = ss.study_subject_id)))
     JOIN public.study s ON ((ss.study_id = s.study_id)))
     LEFT JOIN public.user_account ua ON ((dn.assigned_user_id = ua.user_id)));


ALTER TABLE public.view_dn_study_subject OWNER TO libreclinica;

--
-- Name: view_dn_subject; Type: VIEW; Schema: public; Owner: libreclinica
--

CREATE VIEW public.view_dn_subject AS
 SELECT s.study_id,
    s.parent_study_id,
    false AS study_hide_crf,
    false AS site_hide_crf,
    dn.discrepancy_note_id,
    map.subject_id AS entity_id,
    map.column_name,
    ss.study_subject_id,
    ss.label,
    ss.status_id AS ss_status_id,
    dn.discrepancy_note_type_id,
    dn.resolution_status_id,
    s.unique_identifier AS site_id,
    ds.date_created,
    ds.date_updated,
    ds.days,
    ds.age,
    btrim(''::text) AS event_name,
    NULL::timestamp with time zone AS date_start,
    btrim(''::text) AS crf_name,
    0 AS status_id,
    NULL::integer AS item_id,
    map.column_name AS entity_name,
        CASE
            WHEN ((map.column_name)::text = 'unique_identifier'::text) THEN (su.unique_identifier)::text
            WHEN ((map.column_name)::text = 'gender'::text) THEN (su.gender)::text
            WHEN ((map.column_name)::text = 'date_of_birth'::text) THEN to_char((su.date_of_birth)::timestamp with time zone, 'YYYY-MM-DD'::text)
            ELSE btrim(''::text)
        END AS value,
    dn.entity_type,
    dn.description,
    dn.detailed_notes,
    ds.total_notes,
    ua.first_name,
    ua.last_name,
    ua.user_name,
    ua2.first_name AS owner_first_name,
    ua2.last_name AS owner_last_name,
    ua2.user_name AS owner_user_name
   FROM (((((((public.dn_subject_map map
     JOIN public.discrepancy_note dn ON (((dn.discrepancy_note_id = map.discrepancy_note_id) AND ((dn.entity_type)::text = 'subject'::text) AND ((dn.parent_dn_id IS NULL) OR (dn.parent_dn_id = 0)))))
     JOIN public.view_dn_stats ds ON ((dn.discrepancy_note_id = ds.discrepancy_note_id)))
     JOIN public.user_account ua2 ON ((dn.owner_id = ua2.user_id)))
     JOIN public.subject su ON ((map.subject_id = su.subject_id)))
     JOIN public.study_subject ss ON ((su.subject_id = ss.subject_id)))
     JOIN public.study s ON ((ss.study_id = s.study_id)))
     LEFT JOIN public.user_account ua ON ((dn.assigned_user_id = ua.user_id)));


ALTER TABLE public.view_dn_subject OWNER TO libreclinica;

--
-- Name: view_discrepancy_note; Type: VIEW; Schema: public; Owner: libreclinica
--

CREATE VIEW public.view_discrepancy_note AS
 SELECT view_dn_item_data.study_id,
    view_dn_item_data.parent_study_id,
    view_dn_item_data.study_hide_crf,
    view_dn_item_data.site_hide_crf,
    view_dn_item_data.discrepancy_note_id,
    view_dn_item_data.entity_id,
    view_dn_item_data.column_name,
    view_dn_item_data.study_subject_id,
    view_dn_item_data.label,
    view_dn_item_data.ss_status_id,
    view_dn_item_data.discrepancy_note_type_id,
    view_dn_item_data.resolution_status_id,
    view_dn_item_data.site_id,
    view_dn_item_data.date_created,
    view_dn_item_data.date_updated,
    view_dn_item_data.days,
    view_dn_item_data.age,
    view_dn_item_data.event_name,
    view_dn_item_data.date_start,
    view_dn_item_data.crf_name,
    view_dn_item_data.status_id,
    view_dn_item_data.item_id,
    view_dn_item_data.entity_name,
    view_dn_item_data.value,
    view_dn_item_data.entity_type,
    view_dn_item_data.description,
    view_dn_item_data.detailed_notes,
    view_dn_item_data.total_notes,
    view_dn_item_data.first_name,
    view_dn_item_data.last_name,
    view_dn_item_data.user_name,
    view_dn_item_data.owner_first_name,
    view_dn_item_data.owner_last_name,
    view_dn_item_data.owner_user_name
   FROM public.view_dn_item_data
UNION ALL
 SELECT view_dn_event_crf.study_id,
    view_dn_event_crf.parent_study_id,
    view_dn_event_crf.study_hide_crf,
    view_dn_event_crf.site_hide_crf,
    view_dn_event_crf.discrepancy_note_id,
    view_dn_event_crf.entity_id,
    view_dn_event_crf.column_name,
    view_dn_event_crf.study_subject_id,
    view_dn_event_crf.label,
    view_dn_event_crf.ss_status_id,
    view_dn_event_crf.discrepancy_note_type_id,
    view_dn_event_crf.resolution_status_id,
    view_dn_event_crf.site_id,
    view_dn_event_crf.date_created,
    view_dn_event_crf.date_updated,
    view_dn_event_crf.days,
    view_dn_event_crf.age,
    view_dn_event_crf.event_name,
    view_dn_event_crf.date_start,
    view_dn_event_crf.crf_name,
    view_dn_event_crf.status_id,
    view_dn_event_crf.item_id,
    view_dn_event_crf.entity_name,
    view_dn_event_crf.value,
    view_dn_event_crf.entity_type,
    view_dn_event_crf.description,
    view_dn_event_crf.detailed_notes,
    view_dn_event_crf.total_notes,
    view_dn_event_crf.first_name,
    view_dn_event_crf.last_name,
    view_dn_event_crf.user_name,
    view_dn_event_crf.owner_first_name,
    view_dn_event_crf.owner_last_name,
    view_dn_event_crf.owner_user_name
   FROM public.view_dn_event_crf
UNION ALL
 SELECT view_dn_study_event.study_id,
    view_dn_study_event.parent_study_id,
    view_dn_study_event.study_hide_crf,
    view_dn_study_event.site_hide_crf,
    view_dn_study_event.discrepancy_note_id,
    view_dn_study_event.entity_id,
    view_dn_study_event.column_name,
    view_dn_study_event.study_subject_id,
    view_dn_study_event.label,
    view_dn_study_event.ss_status_id,
    view_dn_study_event.discrepancy_note_type_id,
    view_dn_study_event.resolution_status_id,
    view_dn_study_event.site_id,
    view_dn_study_event.date_created,
    view_dn_study_event.date_updated,
    view_dn_study_event.days,
    view_dn_study_event.age,
    view_dn_study_event.event_name,
    view_dn_study_event.date_start,
    view_dn_study_event.crf_name,
    view_dn_study_event.status_id,
    view_dn_study_event.item_id,
    view_dn_study_event.entity_name,
    view_dn_study_event.value,
    view_dn_study_event.entity_type,
    view_dn_study_event.description,
    view_dn_study_event.detailed_notes,
    view_dn_study_event.total_notes,
    view_dn_study_event.first_name,
    view_dn_study_event.last_name,
    view_dn_study_event.user_name,
    view_dn_study_event.owner_first_name,
    view_dn_study_event.owner_last_name,
    view_dn_study_event.owner_user_name
   FROM public.view_dn_study_event
UNION ALL
 SELECT view_dn_study_subject.study_id,
    view_dn_study_subject.parent_study_id,
    view_dn_study_subject.study_hide_crf,
    view_dn_study_subject.site_hide_crf,
    view_dn_study_subject.discrepancy_note_id,
    view_dn_study_subject.entity_id,
    view_dn_study_subject.column_name,
    view_dn_study_subject.study_subject_id,
    view_dn_study_subject.label,
    view_dn_study_subject.ss_status_id,
    view_dn_study_subject.discrepancy_note_type_id,
    view_dn_study_subject.resolution_status_id,
    view_dn_study_subject.site_id,
    view_dn_study_subject.date_created,
    view_dn_study_subject.date_updated,
    view_dn_study_subject.days,
    view_dn_study_subject.age,
    view_dn_study_subject.event_name,
    view_dn_study_subject.date_start,
    view_dn_study_subject.crf_name,
    view_dn_study_subject.status_id,
    view_dn_study_subject.item_id,
    view_dn_study_subject.entity_name,
    view_dn_study_subject.value,
    view_dn_study_subject.entity_type,
    view_dn_study_subject.description,
    view_dn_study_subject.detailed_notes,
    view_dn_study_subject.total_notes,
    view_dn_study_subject.first_name,
    view_dn_study_subject.last_name,
    view_dn_study_subject.user_name,
    view_dn_study_subject.owner_first_name,
    view_dn_study_subject.owner_last_name,
    view_dn_study_subject.owner_user_name
   FROM public.view_dn_study_subject
UNION ALL
 SELECT view_dn_subject.study_id,
    view_dn_subject.parent_study_id,
    view_dn_subject.study_hide_crf,
    view_dn_subject.site_hide_crf,
    view_dn_subject.discrepancy_note_id,
    view_dn_subject.entity_id,
    view_dn_subject.column_name,
    view_dn_subject.study_subject_id,
    view_dn_subject.label,
    view_dn_subject.ss_status_id,
    view_dn_subject.discrepancy_note_type_id,
    view_dn_subject.resolution_status_id,
    view_dn_subject.site_id,
    view_dn_subject.date_created,
    view_dn_subject.date_updated,
    view_dn_subject.days,
    view_dn_subject.age,
    view_dn_subject.event_name,
    view_dn_subject.date_start,
    view_dn_subject.crf_name,
    view_dn_subject.status_id,
    view_dn_subject.item_id,
    view_dn_subject.entity_name,
    view_dn_subject.value,
    view_dn_subject.entity_type,
    view_dn_subject.description,
    view_dn_subject.detailed_notes,
    view_dn_subject.total_notes,
    view_dn_subject.first_name,
    view_dn_subject.last_name,
    view_dn_subject.user_name,
    view_dn_subject.owner_first_name,
    view_dn_subject.owner_last_name,
    view_dn_subject.owner_user_name
   FROM public.view_dn_subject;


ALTER TABLE public.view_discrepancy_note OWNER TO libreclinica;

--
-- Name: view_item_data_toolkit; Type: VIEW; Schema: public; Owner: libreclinica
--

CREATE VIEW public.view_item_data_toolkit AS
 SELECT DISTINCT id.item_data_id,
        CASE
            WHEN (s.parent_study_id IS NULL) THEN 0
            ELSE s.parent_study_id
        END AS parent_study_id,
    s.study_id,
    ss.label AS study_subject_id,
    ss.oc_oid AS ss_oid,
    sed.name AS study_event_defn,
    sed.oc_oid AS sed_oid,
    se.sample_ordinal AS event_ordinal,
    c.name AS crf_name,
    c.oc_oid AS crf_oid,
    ig.name AS group_name,
    ig.oc_oid AS group_oid,
    id.ordinal AS group_ordinal,
    i.oc_oid AS item_oid,
    ifm.left_item_text,
    id.value,
    ec.event_crf_id,
    ec.status_id AS event_crf_status_id
   FROM (((((((((((public.item_data id
     JOIN public.item i ON ((id.item_id = i.item_id)))
     JOIN public.item_form_metadata ifm ON ((ifm.item_id = i.item_id)))
     JOIN public.event_crf ec ON ((id.event_crf_id = ec.event_crf_id)))
     JOIN public.study_subject ss ON ((ss.study_subject_id = ec.study_subject_id)))
     JOIN public.study s ON ((s.study_id = ss.study_id)))
     JOIN public.crf_version cv ON ((ec.crf_version_id = cv.crf_version_id)))
     JOIN public.crf c ON ((c.crf_id = cv.crf_id)))
     JOIN public.item_group_metadata igm ON ((igm.item_id = id.item_id)))
     JOIN public.item_group ig ON ((ig.item_group_id = igm.item_group_id)))
     JOIN public.study_event se ON ((se.study_event_id = ec.study_event_id)))
     JOIN public.study_event_definition sed ON ((sed.study_event_definition_id = se.study_event_definition_id)))
  ORDER BY id.item_data_id;


ALTER TABLE public.view_item_data_toolkit OWNER TO libreclinica;

--
-- Name: view_item_data_toolkit_filtered; Type: VIEW; Schema: public; Owner: libreclinica
--

CREATE VIEW public.view_item_data_toolkit_filtered AS
 SELECT DISTINCT view.item_data_id,
    view.parent_study_id,
    view.study_id,
    view.study_subject_id,
    view.ss_oid,
    view.study_event_defn,
    view.sed_oid,
    view.event_ordinal,
    view.crf_name,
    view.crf_oid,
    view.group_name,
    view.group_oid,
    view.group_ordinal,
    view.item_oid,
    view.left_item_text,
    view.value,
    view.event_crf_id,
    view.event_crf_status_id,
    edci_tag.path,
    edc_tag.tag_id,
    idfw.workflow_status AS item_data_workflow_status
   FROM ((((((public.view_item_data_toolkit view
     JOIN public.event_definition_crf_tag edc_tag ON (((edc_tag.path)::text = (((view.sed_oid)::text || '.'::text) || (view.crf_oid)::text))))
     LEFT JOIN public.event_definition_crf_item_tag edci_tag ON ((((edci_tag.path)::text = (((((((view.sed_oid)::text || '.'::text) || (view.crf_oid)::text) || '.'::text) || (view.group_oid)::text) || '.'::text) || (view.item_oid)::text)) AND (edci_tag.active = true) AND (edci_tag.tag_id = edc_tag.tag_id))))
     LEFT JOIN public.item_data_flag id_flag ON (((id_flag.path)::text = (((((((((((((view.ss_oid)::text || '.'::text) || (view.sed_oid)::text) || '.'::text) || (view.event_ordinal)::text) || '.'::text) || (view.crf_oid)::text) || '.'::text) || (view.group_oid)::text) || '.'::text) || (view.group_ordinal)::text) || '.'::text) || (view.item_oid)::text))))
     LEFT JOIN public.event_crf_flag ec_flag ON ((((ec_flag.path)::text = (((((((view.ss_oid)::text || '.'::text) || (view.sed_oid)::text) || '.'::text) || (view.event_ordinal)::text) || '.'::text) || (view.crf_oid)::text)) AND (ec_flag.tag_id = edc_tag.tag_id))))
     LEFT JOIN public.item_data_flag_workflow idfw ON ((idfw.id = id_flag.flag_workflow_id)))
     LEFT JOIN public.event_crf_flag_workflow ecfw ON ((ecfw.id = ec_flag.flag_workflow_id)))
  ORDER BY view.event_crf_id;


ALTER TABLE public.view_item_data_toolkit_filtered OWNER TO libreclinica;

--
-- Name: view_site_hidden_event_definition_crf; Type: VIEW; Schema: public; Owner: libreclinica
--

CREATE VIEW public.view_site_hidden_event_definition_crf AS
 SELECT edc.event_definition_crf_id,
    edc.hide_crf,
    edc.study_id,
    se.study_event_id,
    cv.crf_version_id
   FROM ((public.event_definition_crf edc
     JOIN public.study_event se ON (((edc.study_event_definition_id = se.study_event_definition_id) AND (NOT (edc.event_definition_crf_id IN ( SELECT event_definition_crf.parent_id
           FROM public.event_definition_crf
          WHERE ((event_definition_crf.parent_id IS NOT NULL) OR (event_definition_crf.parent_id <> 0))))))))
     JOIN public.crf_version cv ON ((edc.crf_id = cv.crf_id)));


ALTER TABLE public.view_site_hidden_event_definition_crf OWNER TO libreclinica;

--
-- Name: view_study_hidden_event_definition_crf; Type: VIEW; Schema: public; Owner: libreclinica
--

CREATE VIEW public.view_study_hidden_event_definition_crf AS
 SELECT edc.event_definition_crf_id,
    edc.hide_crf,
    edc.study_id,
    se.study_event_id,
    cv.crf_version_id
   FROM ((public.event_definition_crf edc
     JOIN public.study_event se ON (((edc.study_event_definition_id = se.study_event_definition_id) AND (edc.parent_id IS NULL))))
     JOIN public.crf_version cv ON ((edc.crf_id = cv.crf_id)));


ALTER TABLE public.view_study_hidden_event_definition_crf OWNER TO libreclinica;

--
-- Name: archived_dataset_file archived_dataset_file_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.archived_dataset_file ALTER COLUMN archived_dataset_file_id SET DEFAULT nextval('public.archived_dataset_file_archived_dataset_file_id_seq'::regclass);


--
-- Name: audit_event audit_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.audit_event ALTER COLUMN audit_id SET DEFAULT nextval('public.audit_event_audit_id_seq'::regclass);


--
-- Name: audit_log_event audit_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.audit_log_event ALTER COLUMN audit_id SET DEFAULT nextval('public.audit_log_event_audit_id_seq'::regclass);


--
-- Name: audit_log_event_type audit_log_event_type_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.audit_log_event_type ALTER COLUMN audit_log_event_type_id SET DEFAULT nextval('public.audit_log_event_type_audit_log_event_type_id_seq'::regclass);


--
-- Name: audit_user_api_log id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.audit_user_api_log ALTER COLUMN id SET DEFAULT nextval('public.audit_user_api_log_id_seq'::regclass);


--
-- Name: audit_user_login id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.audit_user_login ALTER COLUMN id SET DEFAULT nextval('public.audit_user_login_id_seq'::regclass);


--
-- Name: authorities id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.authorities ALTER COLUMN id SET DEFAULT nextval('public.authorities_id_seq'::regclass);


--
-- Name: completion_status completion_status_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.completion_status ALTER COLUMN completion_status_id SET DEFAULT nextval('public.completion_status_completion_status_id_seq'::regclass);


--
-- Name: configuration id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.configuration ALTER COLUMN id SET DEFAULT nextval('public.configuration_id_seq'::regclass);


--
-- Name: crf crf_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.crf ALTER COLUMN crf_id SET DEFAULT nextval('public.crf_crf_id_seq'::regclass);


--
-- Name: crf_version crf_version_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.crf_version ALTER COLUMN crf_version_id SET DEFAULT nextval('public.crf_version_crf_version_id_seq'::regclass);


--
-- Name: crf_version_media crf_version_media_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.crf_version_media ALTER COLUMN crf_version_media_id SET DEFAULT nextval('public.crf_version_media_crf_version_media_id_seq'::regclass);


--
-- Name: dataset dataset_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dataset ALTER COLUMN dataset_id SET DEFAULT nextval('public.dataset_dataset_id_seq'::regclass);


--
-- Name: dataset_item_status dataset_item_status_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dataset_item_status ALTER COLUMN dataset_item_status_id SET DEFAULT nextval('public.dataset_item_status_dataset_item_status_id_seq'::regclass);


--
-- Name: dc_computed_event dc_summary_event_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_computed_event ALTER COLUMN dc_summary_event_id SET DEFAULT nextval('public.dc_computed_event_dc_summary_event_id_seq'::regclass);


--
-- Name: dc_event dc_event_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_event ALTER COLUMN dc_event_id SET DEFAULT nextval('public.dc_event_dc_event_id_seq'::regclass);


--
-- Name: dc_primitive dc_primitive_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_primitive ALTER COLUMN dc_primitive_id SET DEFAULT nextval('public.dc_primitive_dc_primitive_id_seq'::regclass);


--
-- Name: dc_section_event dc_event_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_section_event ALTER COLUMN dc_event_id SET DEFAULT nextval('public.dc_section_event_dc_event_id_seq'::regclass);


--
-- Name: dc_send_email_event dc_event_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_send_email_event ALTER COLUMN dc_event_id SET DEFAULT nextval('public.dc_send_email_event_dc_event_id_seq'::regclass);


--
-- Name: dc_substitution_event dc_event_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_substitution_event ALTER COLUMN dc_event_id SET DEFAULT nextval('public.dc_substitution_event_dc_event_id_seq'::regclass);


--
-- Name: decision_condition decision_condition_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.decision_condition ALTER COLUMN decision_condition_id SET DEFAULT nextval('public.decision_condition_decision_condition_id_seq'::regclass);


--
-- Name: discrepancy_note discrepancy_note_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.discrepancy_note ALTER COLUMN discrepancy_note_id SET DEFAULT nextval('public.discrepancy_note_discrepancy_note_id_seq'::regclass);


--
-- Name: discrepancy_note_type discrepancy_note_type_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.discrepancy_note_type ALTER COLUMN discrepancy_note_type_id SET DEFAULT nextval('public.discrepancy_note_type_discrepancy_note_type_id_seq'::regclass);


--
-- Name: dyn_item_form_metadata id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dyn_item_form_metadata ALTER COLUMN id SET DEFAULT nextval('public.dyn_item_form_metadata_id_seq'::regclass);


--
-- Name: dyn_item_group_metadata id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dyn_item_group_metadata ALTER COLUMN id SET DEFAULT nextval('public.dyn_item_group_metadata_id_seq'::regclass);


--
-- Name: event_crf event_crf_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_crf ALTER COLUMN event_crf_id SET DEFAULT nextval('public.event_crf_event_crf_id_seq'::regclass);


--
-- Name: event_crf_flag id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_crf_flag ALTER COLUMN id SET DEFAULT nextval('public.event_crf_flag_id_seq'::regclass);


--
-- Name: event_crf_flag_workflow id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_crf_flag_workflow ALTER COLUMN id SET DEFAULT nextval('public.event_crf_flag_workflow_id_seq'::regclass);


--
-- Name: event_definition_crf event_definition_crf_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_definition_crf ALTER COLUMN event_definition_crf_id SET DEFAULT nextval('public.event_definition_crf_event_definition_crf_id_seq'::regclass);


--
-- Name: event_definition_crf_item_tag id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_definition_crf_item_tag ALTER COLUMN id SET DEFAULT nextval('public.event_definition_crf_item_tag_id_seq'::regclass);


--
-- Name: event_definition_crf_tag id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_definition_crf_tag ALTER COLUMN id SET DEFAULT nextval('public.event_definition_crf_tag_id_seq'::regclass);


--
-- Name: export_format export_format_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.export_format ALTER COLUMN export_format_id SET DEFAULT nextval('public.export_format_export_format_id_seq'::regclass);


--
-- Name: filter filter_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.filter ALTER COLUMN filter_id SET DEFAULT nextval('public.filter_filter_id_seq'::regclass);


--
-- Name: group_class_types group_class_type_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.group_class_types ALTER COLUMN group_class_type_id SET DEFAULT nextval('public.group_class_types_group_class_type_id_seq'::regclass);


--
-- Name: item item_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item ALTER COLUMN item_id SET DEFAULT nextval('public.item_item_id_seq'::regclass);


--
-- Name: item_data item_data_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_data ALTER COLUMN item_data_id SET DEFAULT nextval('public.item_data_item_data_id_seq'::regclass);


--
-- Name: item_data_flag id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_data_flag ALTER COLUMN id SET DEFAULT nextval('public.item_data_flag_id_seq'::regclass);


--
-- Name: item_data_flag_workflow id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_data_flag_workflow ALTER COLUMN id SET DEFAULT nextval('public.item_data_flag_workflow_id_seq'::regclass);


--
-- Name: item_data_type item_data_type_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_data_type ALTER COLUMN item_data_type_id SET DEFAULT nextval('public.item_data_type_item_data_type_id_seq'::regclass);


--
-- Name: item_form_metadata item_form_metadata_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_form_metadata ALTER COLUMN item_form_metadata_id SET DEFAULT nextval('public.item_form_metadata_item_form_metadata_id_seq'::regclass);


--
-- Name: item_group item_group_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_group ALTER COLUMN item_group_id SET DEFAULT nextval('public.item_group_item_group_id_seq'::regclass);


--
-- Name: item_group_metadata item_group_metadata_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_group_metadata ALTER COLUMN item_group_metadata_id SET DEFAULT nextval('public.item_group_metadata_item_group_metadata_id_seq'::regclass);


--
-- Name: item_reference_type item_reference_type_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_reference_type ALTER COLUMN item_reference_type_id SET DEFAULT nextval('public.item_reference_type_item_reference_type_id_seq'::regclass);


--
-- Name: measurement_unit id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.measurement_unit ALTER COLUMN id SET DEFAULT nextval('public.measurement_unit_id_seq'::regclass);


--
-- Name: null_value_type null_value_type_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.null_value_type ALTER COLUMN null_value_type_id SET DEFAULT nextval('public.null_value_type_null_value_type_id_seq'::regclass);


--
-- Name: openclinica_version id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.openclinica_version ALTER COLUMN id SET DEFAULT nextval('public.openclinica_version_id_seq'::regclass);


--
-- Name: privilege priv_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.privilege ALTER COLUMN priv_id SET DEFAULT nextval('public.privilege_priv_id_seq'::regclass);


--
-- Name: resolution_status resolution_status_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.resolution_status ALTER COLUMN resolution_status_id SET DEFAULT nextval('public.resolution_status_resolution_status_id_seq'::regclass);


--
-- Name: response_set response_set_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.response_set ALTER COLUMN response_set_id SET DEFAULT nextval('public.response_set_response_set_id_seq'::regclass);


--
-- Name: response_type response_type_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.response_type ALTER COLUMN response_type_id SET DEFAULT nextval('public.response_type_response_type_id_seq'::regclass);


--
-- Name: rule id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule ALTER COLUMN id SET DEFAULT nextval('public.rule_id_seq'::regclass);


--
-- Name: rule_action id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_action ALTER COLUMN id SET DEFAULT nextval('public.rule_action_id_seq'::regclass);


--
-- Name: rule_action_property id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_action_property ALTER COLUMN id SET DEFAULT nextval('public.rule_action_property_id_seq'::regclass);


--
-- Name: rule_action_run id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_action_run ALTER COLUMN id SET DEFAULT nextval('public.rule_action_run_id_seq'::regclass);


--
-- Name: rule_action_run_log id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_action_run_log ALTER COLUMN id SET DEFAULT nextval('public.rule_action_run_log_id_seq'::regclass);


--
-- Name: rule_action_stratification_factor id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_action_stratification_factor ALTER COLUMN id SET DEFAULT nextval('public.rule_action_stratification_factor_id_seq'::regclass);


--
-- Name: rule_expression id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_expression ALTER COLUMN id SET DEFAULT nextval('public.rule_expression_id_seq'::regclass);


--
-- Name: rule_set id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_set ALTER COLUMN id SET DEFAULT nextval('public.rule_set_id_seq'::regclass);


--
-- Name: rule_set_audit id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_set_audit ALTER COLUMN id SET DEFAULT nextval('public.rule_set_audit_id_seq'::regclass);


--
-- Name: rule_set_rule id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_set_rule ALTER COLUMN id SET DEFAULT nextval('public.rule_set_rule_id_seq'::regclass);


--
-- Name: rule_set_rule_audit id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_set_rule_audit ALTER COLUMN id SET DEFAULT nextval('public.rule_set_rule_audit_id_seq'::regclass);


--
-- Name: scd_item_metadata id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.scd_item_metadata ALTER COLUMN id SET DEFAULT nextval('public.scd_item_metadata_id_seq'::regclass);


--
-- Name: section section_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.section ALTER COLUMN section_id SET DEFAULT nextval('public.section_section_id_seq'::regclass);


--
-- Name: status status_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.status ALTER COLUMN status_id SET DEFAULT nextval('public.status_status_id_seq'::regclass);


--
-- Name: study study_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study ALTER COLUMN study_id SET DEFAULT nextval('public.study_study_id_seq'::regclass);


--
-- Name: study_event study_event_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_event ALTER COLUMN study_event_id SET DEFAULT nextval('public.study_event_study_event_id_seq'::regclass);


--
-- Name: study_event_definition study_event_definition_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_event_definition ALTER COLUMN study_event_definition_id SET DEFAULT nextval('public.study_event_definition_study_event_definition_id_seq'::regclass);


--
-- Name: study_group study_group_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_group ALTER COLUMN study_group_id SET DEFAULT nextval('public.study_group_study_group_id_seq'::regclass);


--
-- Name: study_group_class study_group_class_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_group_class ALTER COLUMN study_group_class_id SET DEFAULT nextval('public.study_group_class_study_group_class_id_seq'::regclass);


--
-- Name: study_module_status id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_module_status ALTER COLUMN id SET DEFAULT nextval('public.study_module_status_id_seq'::regclass);


--
-- Name: study_parameter study_parameter_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_parameter ALTER COLUMN study_parameter_id SET DEFAULT nextval('public.study_parameter_study_parameter_id_seq'::regclass);


--
-- Name: study_parameter_value study_parameter_value_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_parameter_value ALTER COLUMN study_parameter_value_id SET DEFAULT nextval('public.study_parameter_value_study_parameter_value_id_seq'::regclass);


--
-- Name: study_subject study_subject_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_subject ALTER COLUMN study_subject_id SET DEFAULT nextval('public.study_subject_study_subject_id_seq'::regclass);


--
-- Name: study_type study_type_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_type ALTER COLUMN study_type_id SET DEFAULT nextval('public.study_type_study_type_id_seq'::regclass);


--
-- Name: subject subject_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.subject ALTER COLUMN subject_id SET DEFAULT nextval('public.subject_subject_id_seq'::regclass);


--
-- Name: subject_event_status subject_event_status_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.subject_event_status ALTER COLUMN subject_event_status_id SET DEFAULT nextval('public.subject_event_status_subject_event_status_id_seq'::regclass);


--
-- Name: subject_group_map subject_group_map_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.subject_group_map ALTER COLUMN subject_group_map_id SET DEFAULT nextval('public.subject_group_map_subject_group_map_id_seq'::regclass);


--
-- Name: tag id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.tag ALTER COLUMN id SET DEFAULT nextval('public.tag_id_seq'::regclass);


--
-- Name: usage_statistics_data id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.usage_statistics_data ALTER COLUMN id SET DEFAULT nextval('public.usage_statistics_data_id_seq'::regclass);


--
-- Name: user_account user_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.user_account ALTER COLUMN user_id SET DEFAULT nextval('public.user_account_user_id_seq'::regclass);


--
-- Name: user_role role_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.user_role ALTER COLUMN role_id SET DEFAULT nextval('public.user_role_role_id_seq'::regclass);


--
-- Name: user_type user_type_id; Type: DEFAULT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.user_type ALTER COLUMN user_type_id SET DEFAULT nextval('public.user_type_user_type_id_seq'::regclass);


--
-- Data for Name: archived_dataset_file; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.archived_dataset_file (archived_dataset_file_id, name, dataset_id, export_format_id, file_reference, run_time, file_size, date_created, owner_id) FROM stdin;
\.


--
-- Data for Name: audit_event; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.audit_event (audit_id, audit_date, audit_table, user_id, entity_id, reason_for_change, action_message) FROM stdin;
\.


--
-- Data for Name: audit_event_context; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.audit_event_context (audit_id, study_id, subject_id, study_subject_id, role_name, event_crf_id, study_event_id, study_event_definition_id, crf_id, crf_version_id, study_crf_id, item_id) FROM stdin;
\.


--
-- Data for Name: audit_event_values; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.audit_event_values (audit_id, column_name, old_value, new_value) FROM stdin;
\.


--
-- Data for Name: audit_log_event; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.audit_log_event (audit_id, audit_date, audit_table, user_id, entity_id, entity_name, reason_for_change, audit_log_event_type_id, old_value, new_value, event_crf_id, study_event_id, event_crf_version_id, item_data_repeat_key) FROM stdin;
1	2025-11-30 10:26:46.916554	subject	1	1	\N	\N	5	\N	\N	\N	\N	\N	\N
2	2025-11-30 10:26:46.942279	study_subject	1	1	\N	\N	2	\N	\N	\N	\N	\N	\N
3	2025-11-30 10:52:20.859416	subject	1	2	\N	\N	5	\N	\N	\N	\N	\N	\N
4	2025-11-30 10:52:20.859416	study_subject	1	2	\N	\N	2	\N	\N	\N	\N	\N	\N
5	2025-11-30 10:52:20.859416	study_subject	1	2	Subject	\N	\N	\N	\N	\N	\N	\N	\N
6	2025-11-30 10:52:37.808187	subject	1	3	\N	\N	5	\N	\N	\N	\N	\N	\N
7	2025-11-30 10:52:37.808187	study_subject	1	3	\N	\N	2	\N	\N	\N	\N	\N	\N
8	2025-11-30 10:52:37.808187	study_subject	1	3	Subject	\N	\N	\N	\N	\N	\N	\N	\N
9	2025-11-30 10:53:34.427625	subject	1	4	\N	\N	5	\N	\N	\N	\N	\N	\N
10	2025-11-30 10:53:34.427625	study_subject	1	4	\N	\N	2	\N	\N	\N	\N	\N	\N
11	2025-11-30 10:53:34.427625	study_subject	1	4	Subject	\N	\N	\N	\N	\N	\N	\N	\N
12	2025-12-02 07:55:59.817292	discrepancy_note	1	2	Query	\N	\N	\N	Test Query from Frontend - 01:55:59	\N	\N	\N	\N
13	2025-12-02 09:44:24.171838	event_crf	1	1	Status	\N	41	2	2	1	\N	\N	\N
14	2025-12-02 09:44:24.171838	event_crf	1	2	Status	\N	41	2	2	2	\N	\N	\N
15	2025-12-02 09:44:24.171838	event_crf	1	3	Status	\N	41	2	6	3	\N	\N	\N
16	2025-12-02 09:44:24.171838	event_crf	1	4	Status	\N	41	2	2	4	\N	\N	\N
17	2025-12-02 10:06:00.854114	event_crf	1	1	EventCRF SDV Status	\N	32	FALSE	TRUE	1	1	1	\N
18	2025-12-02 10:06:00.854114	event_crf	1	1	SDV Verified	\N	\N	\N	\N	\N	\N	\N	\N
19	2025-12-03 06:52:39.003578	subject	1	5	\N	\N	5	\N	\N	\N	\N	\N	\N
20	2025-12-03 06:52:39.003578	study_subject	1	5	\N	\N	2	\N	\N	\N	\N	\N	\N
21	2025-12-03 06:52:39.003578	study_subject	1	5	Subject	\N	\N	\N	\N	\N	\N	\N	\N
22	2025-12-04 14:17:37.036631	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
23	2025-12-04 14:19:16.632128	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
24	2025-12-04 14:19:16.667969	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
25	2025-12-04 14:19:36.270323	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
26	2025-12-04 14:19:42.863456	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
27	2025-12-04 14:20:00.911883	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
28	2025-12-04 14:23:57.558242	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
29	2025-12-04 14:23:58.099985	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
30	2025-12-04 14:24:04.681731	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
31	2025-12-04 14:24:04.718379	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
32	2025-12-04 14:24:14.533485	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
33	2025-12-04 14:24:14.588308	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
34	2025-12-04 14:24:17.213797	study_subject	1	1	SOAP-SUBJ-5934	Viewed subject SOAP-SUBJ-5934	10	\N	Viewed subject SOAP-SUBJ-5934	\N	\N	\N	\N
35	2025-12-04 14:24:18.744043	study_subject	1	1	SOAP-SUBJ-5934	Viewed subject SOAP-SUBJ-5934	10	\N	Viewed subject SOAP-SUBJ-5934	\N	\N	\N	\N
36	2025-12-04 14:24:22.650656	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
37	2025-12-04 14:24:22.678766	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
38	2025-12-04 14:24:24.210837	study_subject	1	2	FE-7064	Viewed subject FE-7064	10	\N	Viewed subject FE-7064	\N	\N	\N	\N
39	2025-12-04 14:24:31.58218	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
40	2025-12-04 14:24:40.704434	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
41	2025-12-04 14:24:40.997355	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
42	2025-12-04 14:38:34.41446	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
43	2025-12-04 14:38:34.438481	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
44	2025-12-04 14:41:25.012348	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
45	2025-12-04 14:41:25.039524	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
46	2025-12-04 14:41:36.973791	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
47	2025-12-04 14:41:37.005221	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
48	2025-12-04 14:41:42.672808	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
49	2025-12-04 14:41:42.701764	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
50	2025-12-04 14:41:53.60862	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
51	2025-12-04 14:41:53.637033	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
52	2025-12-04 14:47:12.059227	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
53	2025-12-04 14:47:12.085283	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
54	2025-12-04 14:48:48.37387	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
55	2025-12-04 14:49:39.572157	study_subject	1	2	FE-7064	Viewed subject FE-7064	10	\N	Viewed subject FE-7064	\N	\N	\N	\N
56	2025-12-04 14:49:40.607217	study_subject	1	1	SOAP-SUBJ-5934	Viewed subject SOAP-SUBJ-5934	10	\N	Viewed subject SOAP-SUBJ-5934	\N	\N	\N	\N
57	2025-12-04 14:57:22.447979	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
58	2025-12-04 14:57:22.472659	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
59	2025-12-04 14:58:45.400243	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
60	2025-12-04 14:58:45.4305	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
61	2025-12-04 15:00:29.895125	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
62	2025-12-04 15:00:29.921846	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
63	2025-12-04 15:01:54.273097	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
64	2025-12-04 15:01:54.322149	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
65	2025-12-04 15:06:46.055645	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
66	2025-12-04 15:06:46.08093	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
67	2025-12-04 15:10:58.077604	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
68	2025-12-04 15:11:16.682519	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
69	2025-12-04 15:11:16.706495	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
70	2025-12-04 15:11:37.274526	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
71	2025-12-04 15:11:37.297584	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
72	2025-12-04 15:16:28.678136	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
73	2025-12-04 15:16:28.701541	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
74	2025-12-04 15:30:12.22304	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
75	2025-12-04 15:30:12.245152	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
76	2025-12-04 15:30:18.786913	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
77	2025-12-04 15:30:21.113663	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
78	2025-12-04 15:30:26.201396	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
79	2025-12-04 15:32:07.824355	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
80	2025-12-04 15:33:01.080225	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
81	2025-12-04 15:33:29.075433	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
82	2025-12-04 15:33:29.098575	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
83	2025-12-04 15:33:29.129438	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
84	2025-12-04 15:33:29.151585	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
85	2025-12-04 15:33:50.283675	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
86	2025-12-04 15:33:50.31008	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
87	2025-12-04 15:33:50.447762	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
88	2025-12-04 15:33:50.494808	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
89	2025-12-04 15:34:03.678824	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
90	2025-12-04 16:06:26.839662	crf	1	22	Test Form	Created form template "Test Form" with 1 fields	2	\N	Created form template "Test Form" with 1 fields	\N	\N	\N	\N
91	2025-12-04 16:06:26.843084	crf	1	22	root	Created form: Test Form	2	\N	Created form: Test Form	\N	\N	\N	\N
92	2025-12-13 23:32:34.48418	system_backup	1	0	BKP-2025-12-13-FULL-1765668753747	Backup completed - checksum: 8ae62aebd1f067a1	1	\N	{"type":"full","status":"completed","size":115455}	\N	\N	\N	\N
\.


--
-- Data for Name: audit_log_event_type; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.audit_log_event_type (audit_log_event_type_id, name) FROM stdin;
1	Item data value updated
2	Study subject created
3	Study subject status changed
4	Study subject value changed
5	Subject created
6	Subject status changed
7	Subject global value changed
8	Event CRF marked complete
9	Event CRF properties changed
12	Item data status changed
13	Item data deleted
17	Study Event scheduled
18	Study Event data entry started
19	Study Event completed
20	Study Event stopped
21	Study Event skipped
22	Study Event locked
23	Study Event removed
24	Study Event start date changed
25	Study Event end date changed
26	Study Event location changed
27	Subject Site Assignment
28	Subject Group Assignment
29	Subject Group changed
30	Item data inserted for repeating row
31	Study Event signed
14	Event CRF complete with password
15	Event CRF Initial Data Entry complete with password
16	Event CRF Double Data Entry complete with password
10	Event CRF Initial Data Entry complete
11	Event CRF Double Data Entry complete
32	EventCRF SDV Status
35	Study Event restored
33	Change CRF version
40	event_crf_deleted
41	event_crf_started
\.


--
-- Data for Name: audit_user_api_log; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.audit_user_api_log (id, audit_id, user_id, username, user_role, http_method, endpoint_path, query_params, request_body, response_status, ip_address, user_agent, duration_ms, created_at) FROM stdin;
1	5a114a6b-8728-4be8-8015-5d1926116083	\N	anonymous	\N	GET	/api/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	8	2025-11-30 08:11:43.763791
2	78a34fa3-eb83-48b8-b666-9248d8b55781	\N	anonymous	\N	GET	/api/soap/status	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	6	2025-11-30 08:11:43.799354
3	33cc8ddf-8124-4e8b-beb5-67ece4fec7be	\N	anonymous	\N	GET	/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	7	2025-11-30 09:36:51.278606
4	960ebb4f-1380-4132-83e6-9897c80a9006	\N	anonymous	\N	GET	/api/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	12	2025-11-30 09:36:51.318234
5	b2e8de63-77c1-46ca-a3ca-4e4d412a030f	\N	anonymous	\N	GET	/api/soap/status	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	24	2025-11-30 09:38:29.020949
6	3a744b28-2c4a-4ec5-b9d9-13c67ab19ef3	\N	anonymous	\N	GET	/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	0	2025-11-30 10:06:05.186462
7	cab9317d-3d82-4b48-b1e9-085d8c93ef77	\N	anonymous	\N	GET	/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-11-30 10:15:22.534863
8	05c73fb9-7ce5-4141-a872-7d9d8b4db000	\N	anonymous	\N	GET	/api/studies	{}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	3	2025-11-30 10:15:22.651812
9	971995a1-ef34-4e66-89dc-c3c511cd57d8	\N	anonymous	\N	GET	/api/soap/status	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	12	2025-11-30 10:15:22.669604
10	07ee32a0-0398-45d1-ab10-d73f64d78012	\N	anonymous	\N	GET	/api/studies	{}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-11-30 10:15:35.931201
11	1c6aa9fd-abf9-45bc-b7c1-aeb10fd41761	\N	anonymous	\N	GET	/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-11-30 10:16:40.746412
12	037fe81d-d227-40c0-bf85-0fdf61130869	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	40	2025-11-30 10:16:40.838539
13	dc6a1ef7-9cb2-466f-9e22-e34afb29e9ee	\N	anonymous	\N	GET	/api/soap/status	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	5	2025-11-30 10:16:40.85231
14	2a30663d-b618-4915-a0f5-951e1c4ee951	\N	anonymous	\N	GET	/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-11-30 10:24:04.239871
15	838c93c9-7c13-41a4-9a39-28aa1b177435	\N	anonymous	\N	GET	/api/soap/status	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	3038	2025-11-30 10:24:07.313465
16	becf491d-e414-4fc1-bdea-e4343626af6c	\N	anonymous	\N	POST	/api/soap/test	{}	{"service":"study"}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	2	2025-11-30 10:24:25.39239
17	a4391823-fdf8-4744-ae95-a0428bb68d64	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	29	2025-11-30 10:24:40.666608
18	da19bc51-59dd-410f-9957-8f12a91d6daf	\N	anonymous	\N	POST	/api/soap/test	{}	{"service":"study"}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	0	2025-11-30 10:24:40.693459
19	08690aa5-888f-424c-83c8-541c9280130a	\N	anonymous	\N	GET	/api/studies	{}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	0	2025-11-30 10:24:40.702027
20	dfd5ffd5-5df3-4d42-96f7-229fa7fbe46b	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	25	2025-11-30 10:24:55.754338
21	b74020a3-5266-4286-895d-c30abf4e2e54	\N	anonymous	\N	GET	/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	0	2025-11-30 10:24:55.842978
22	90a5e383-1d85-47b6-9648-807d36ad9f3b	\N	anonymous	\N	GET	/api/soap/status	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	3025	2025-11-30 10:24:58.871198
23	9c15f248-69cd-424c-b395-ef1a1ff7fad0	\N	anonymous	\N	GET	/api/studies	{}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-11-30 10:24:58.876378
24	94a20e32-0eb7-42ee-bd1c-80719479c05b	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	22	2025-11-30 10:25:09.820129
25	9a02c6a5-ff15-460d-8584-e06e977a8b13	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	23	2025-11-30 10:25:25.916539
26	70cd9069-4f9d-4a3d-b95d-332f574739ad	\N	anonymous	\N	POST	/api/soap/test	{}	{"service":"study"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	89	2025-11-30 10:25:26.048682
27	b3a807ce-83ab-4165-b4e4-ce5d201cead5	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	21	2025-11-30 10:25:26.08324
28	6a7eba4d-263f-41d4-bc72-12424986fd37	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	22	2025-11-30 10:25:44.249485
29	32f58bf2-0ae1-4998-8dfa-dd4f1678bcc3	\N	anonymous	\N	POST	/api/subjects	{}	{"studyId":1,"enrollmentDate":"2025-11-30","gender":"M","studySubjectId":"SOAP-TEST-2691"}	400	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	6	2025-11-30 10:25:44.301222
30	5bded65e-55aa-449a-ab80-423334dc9526	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	23	2025-11-30 10:25:44.365898
31	7463d72a-6ab8-45cb-a6d9-1a4062c63baf	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	429	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-11-30 10:26:12.170944
32	8934f170-3b84-4265-b8ec-43fa63485345	\N	anonymous	\N	POST	/api/subjects	{}	{"studyId":1,"label":"SOAP-TEST-9663","enrollmentDate":"2025-11-30"}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-11-30 10:26:12.251511
33	16b280f8-4248-475e-8d4b-3b022b22f7b3	\N	anonymous	\N	GET	/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	0	2025-11-30 10:27:49.599209
34	9bc39d54-75a2-47b0-afed-d3e71decba89	\N	anonymous	\N	GET	/api/soap/status	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	3028	2025-11-30 10:27:52.653257
35	729704a5-3d93-4145-ae4d-4227adffda1a	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	44	2025-11-30 10:45:14.452042
36	4534b4ac-1ba8-4e08-bfe8-572bbbfe30df	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	13	2025-11-30 10:45:14.509437
37	193b5acc-91e6-4190-a463-80048cccd3f0	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	12	2025-11-30 10:45:14.568248
38	40fcc60e-affe-47c8-9084-e1e0e0f52753	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	24	2025-11-30 10:45:33.604909
39	84bc3d4e-0b77-4c31-8c88-6c2085aa67a0	\N	anonymous	\N	POST	/api/subjects	{}	{"label":"FRONTEND-SUBJ-3999","dateOfBirth":"1985-06-15","studyId":1,"gender":"m","personId":"FRONTEND-PERSON-3999","enrollmentDate":"2025-11-30"}	400	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	6	2025-11-30 10:45:33.658682
40	8ef7eb89-8b1e-4223-bfe1-bb119390bcfc	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	13	2025-11-30 10:45:33.709631
41	c9582041-ba8e-472e-996b-2d55aa872ef0	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	36	2025-11-30 10:46:07.313556
42	e7a9a56b-11df-4b8e-90d6-1d786883a100	\N	anonymous	\N	POST	/api/subjects	{}	{"studyId":1,"enrollmentDate":"2025-11-30","dateOfBirth":"1985-06-15","gender":"m","studySubjectId":"FE-TEST-4218"}	201	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1092	2025-11-30 10:46:08.450828
43	2e6effab-cde4-4e4f-b2e5-b02f2c1655fc	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	51	2025-11-30 10:52:20.657249
44	6e16cb2d-c41a-47b6-ac35-6cd22670f547	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	12	2025-11-30 10:52:20.711904
45	3c848732-cbeb-413e-a457-84b36ddeb20f	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	12	2025-11-30 10:52:20.771382
46	b5ecb6e4-055f-4951-ab15-3700959a25a4	\N	anonymous	\N	POST	/api/subjects	{}	{"studyId":1,"enrollmentDate":"2025-11-30","gender":"m","studySubjectId":"FE-7064"}	201	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	94	2025-11-30 10:52:20.875199
47	fb0a6401-9778-4ee3-bb50-edcf62f6254f	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	23	2025-11-30 10:52:37.696696
48	4ce91d25-8ca2-4640-9869-c892d120ba49	\N	anonymous	\N	POST	/api/subjects	{}	{"studyId":1,"enrollmentDate":"2025-11-30","dateOfBirth":"1995-01-15","gender":"f","studySubjectId":"SOAP-WRITE-6669"}	201	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	79	2025-11-30 10:52:37.822031
49	2286e3cf-4879-431e-8e49-edd6a87b3ecc	\N	anonymous	\N	GET	/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-11-30 10:53:34.202267
50	6d033227-5033-491c-b1ba-2e9444d18dc7	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	32	2025-11-30 10:53:34.272786
51	f8a61b33-e20d-4e2f-a5c9-87eb1b32e5b1	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	16	2025-11-30 10:53:34.33653
52	517ec734-fd4f-4e14-bb72-e0995d4d3287	\N	anonymous	\N	POST	/api/subjects	{}	{"studyId":1,"enrollmentDate":"2025-11-30","gender":"m","studySubjectId":"VERIFY-2008"}	201	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	82	2025-11-30 10:53:34.441586
53	5bc21b09-50f2-406d-82ed-055799d1db46	\N	anonymous	\N	GET	/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	2	2025-12-01 10:52:03.681653
54	a8098133-31b6-4249-acb5-f696cfaeff74	\N	anonymous	\N	GET	/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	0	2025-12-01 10:52:11.855831
55	ee2f3b23-ad66-4503-824b-64111aba7400	\N	anonymous	\N	GET	/api/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	3180	2025-12-02 06:22:32.978434
56	ff4213a9-1a21-4561-b1a9-4fe0a3726a92	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	42	2025-12-02 06:22:44.66509
57	936f1655-26f9-439e-98d7-e6549830e2ce	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	24	2025-12-02 06:22:54.347442
58	49635276-da5d-4be5-9c08-8aec613bec8e	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	25	2025-12-02 06:23:06.148758
59	c9f0f934-48f7-454c-a922-bc2ae4fb4357	\N	anonymous	\N	POST	/api/forms	{}	{"name":"Integration Test Template 20251202_002306","description":"Test from PowerShell integration test"}	201	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	22	2025-12-02 06:23:06.211952
60	e3bd0001-8285-43c7-bac3-fd3a76ba6057	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	25	2025-12-02 06:23:23.556778
61	86ff3363-016a-448b-beec-7882ab34985d	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	8	2025-12-02 06:23:23.591123
62	a0883785-cfe1-46db-8bfc-56174a1e1ea7	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	26	2025-12-02 06:23:35.585508
63	e30b825e-813f-451d-a0e5-8dc027e0dfc9	\N	anonymous	\N	PUT	/api/forms/1	{}	{"name":"Integration Test Template 20251202_002306","description":"Updated - Published!"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	10	2025-12-02 06:23:35.633155
64	9a2925a5-95f2-4358-a14f-2cfc32d490c5	\N	anonymous	\N	PUT	/api/forms/1	{}	{"status":"published"}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	2	2025-12-02 06:25:00.995132
65	3f17c9f0-96ec-478b-ac7b-f0d65ce0118d	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	31	2025-12-02 06:25:18.7713
66	02c958b3-ad69-439e-9588-ce8d320496c3	\N	anonymous	\N	PUT	/api/forms/1	{}	{"status":"draft"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	11	2025-12-02 06:25:18.820336
67	aacdff17-2998-4083-af93-6e66c6fa332c	\N	anonymous	\N	PUT	/api/forms/1	{}	{"status":"published"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	12	2025-12-02 06:25:18.952254
68	f358703b-0169-4627-90f4-a4bf010bcfda	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	51	2025-12-02 06:50:32.435578
69	d9e526e3-babd-4a86-ae71-8f67e50e5203	\N	anonymous	\N	POST	/api/forms	{}	{"name":"Angular E2E Test 20251202_005032","description":"Created from Angular UI"}	201	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	17	2025-12-02 06:50:32.495399
70	d1d90e94-0587-4b2e-87eb-e5ce8b3c528a	\N	anonymous	\N	PUT	/api/forms/2	{}	{"status":"draft"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	13	2025-12-02 06:50:32.658348
71	58f0bc8f-1ab1-434d-9aeb-95777e9bb8a4	\N	anonymous	\N	PUT	/api/forms/2	{}	{"status":"published"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	13	2025-12-02 06:50:32.809525
72	c1822e83-8eed-4f1d-a2df-d91bb6f42e3c	\N	anonymous	\N	DELETE	/api/forms/2	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	17	2025-12-02 06:50:32.960167
73	5e49a33d-ae5c-42f8-94e9-d433a353f3d9	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	47	2025-12-02 06:58:30.800132
74	ec53930d-65fb-4a27-97ce-b413f3878a61	\N	anonymous	\N	POST	/api/forms	{}	{"version":"1.0","name":"Template With Fields Test 005830","fields":[{"label":"Blood Pressure","placeholder":"e.g. 120/80","id":"field_1","type":"text","required":true},{"label":"Heart Rate","id":"field_2","type":"number","required":true},{"label":"Temperature","id":"field_3","type":"number","required":false}],"description":"Testing field sync","category":"vitals","status":"draft"}	201	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	16	2025-12-02 06:58:30.860396
75	fbd82798-3e5a-4588-91e8-6a9d36af6aa3	\N	anonymous	\N	GET	/api/forms/3	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	18	2025-12-02 06:58:30.872171
76	e53d26ab-7104-4c55-b9bc-b09ea21bd402	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	40	2025-12-02 07:00:17.24025
77	da15b394-3bbe-47b0-aff9-9449fe6847ca	\N	anonymous	\N	POST	/api/forms	{}	{"description":"Testing field storage","name":"Fields Test 010017","fields":[{"label":"Blood Pressure","id":"bp","type":"text","required":true},{"label":"Heart Rate","id":"hr","type":"number","required":true},{"label":"Temperature","id":"temp","type":"number","required":false}],"category":"Vital Signs"}	201	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	35	2025-12-02 07:00:17.321661
78	1f4d5521-57b6-4e4e-89b5-e8fb093c5fce	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	27	2025-12-02 07:00:34.025318
79	8570b4d1-c6f7-4914-9adc-7e8b2df9b6fb	\N	anonymous	\N	GET	/api/forms/4/metadata	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	11	2025-12-02 07:00:34.063053
80	d7902b46-fb8e-4a5d-9d50-c0e101346445	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	35	2025-12-02 07:01:37.096472
81	1f3a7a40-292c-49b2-800c-5a14cb6c7aec	\N	anonymous	\N	POST	/api/forms	{}	{"description":"Testing all field types","name":"Complete Form Test 010137","fields":[{"label":"Patient Name","helpText":"Enter full name","id":"name","type":"text","required":true},{"label":"Age","id":"age","type":"number","required":true},{"label":"Date of Birth","id":"dob","type":"date","required":true},{"label":"Clinical Notes","id":"notes","type":"textarea","required":false},{"label":"Informed Consent","id":"consent","type":"checkbox","required":true}],"category":"Patient Assessment"}	201	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	27	2025-12-02 07:01:37.163827
82	0c33fcb9-b710-430c-8a4b-1d4f65fc8c40	\N	anonymous	\N	GET	/api/forms/5/metadata	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	21	2025-12-02 07:01:37.179702
83	9c69810d-0828-4a05-8fcd-d608ed1ff6df	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	48	2025-12-02 07:15:26.126009
84	4c13b89b-f3c4-4179-b6e5-8aaa616693a2	\N	anonymous	\N	POST	/api/forms	{}	{"description":"Testing ALL field properties","name":"Full Field Test 011526","fields":[{"width":"full","id":"patient_name","type":"text","label":"Patient Name","helpText":"Patient's legal name","isPhiField":true,"validationRules":[{"message":"Name is required","type":"required"},{"message":"Min 2 chars","value":2,"type":"minLength"}],"placeholder":"Enter full name","required":true},{"id":"age","required":true,"unit":"years","type":"number","defaultValue":"18","label":"Age","max":150,"min":0},{"label":"Blood Type","options":[{"value":"A_POS","label":"A+"},{"value":"A_NEG","label":"A-"},{"value":"B_POS","label":"B+"},{"value":"O_POS","label":"O+"}],"id":"blood_type","type":"select","required":true},{"id":"consent","label":"Informed Consent","criticalDataPoint":true,"type":"checkbox","required":true,"auditRequired":true},{"id":"notes","label":"Clinical Notes","hidden":false,"type":"textarea","required":false,"placeholder":"Enter clinical observations...","width":"full"}],"category":"Comprehensive Test"}	201	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	45	2025-12-02 07:15:26.214578
85	4e1ffd9b-33df-48e8-846d-5e64c60b68e8	\N	anonymous	\N	GET	/api/forms/6/metadata	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	28	2025-12-02 07:15:26.237201
86	7a510ab7-564a-45d6-b3a1-badf89d12fac	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	42	2025-12-02 07:25:40.607981
113	b8f861cd-e1c3-4996-b4a3-0231d950f261	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	25	2025-12-02 07:44:00.399464
229	17bc73e1-088f-4f1e-9150-b108e05b3a52	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	90	2025-12-04 14:09:01.882766
87	3544ec74-9bef-4d55-8179-b796611d86d9	\N	anonymous	\N	POST	/api/forms	{}	{"version":"1.0","name":"Frontend Test Form 012540","fields":[{"name":"patient_name","placeholder":"John Doe","order":1,"type":"text","hidden":false,"label":"Patient Full Name","defaultValue":"","id":"field_name","readonly":false,"auditRequired":true,"isPhiField":true,"description":"Enter patient legal name","required":true,"helpText":"First and last name as on ID","width":"full","validationRules":[{"message":"Name is required","type":"required"},{"message":"Min 2 characters","value":2,"type":"minLength"},{"message":"Max 100 characters","value":100,"type":"maxLength"}],"section":"Demographics"},{"width":"quarter","id":"field_age","type":"number","defaultValue":"21","criticalDataPoint":false,"label":"Age","order":2,"min":0,"unit":"years","max":150,"required":true},{"id":"field_dob","format":"YYYY-MM-DD","width":"half","required":true,"isPhiField":true,"type":"date","order":3,"label":"Date of Birth"},{"id":"field_gender","width":"half","required":true,"type":"select","defaultValue":"","order":4,"label":"Gender","options":[{"value":"M","label":"Male"},{"value":"F","label":"Female"},{"value":"O","label":"Other"},{"value":"N","label":"Prefer not to say"}]},{"id":"field_blood_type","label":"Blood Type","type":"radio","required":false,"order":5,"options":[{"value":"A_POS","label":"A+"},{"value":"A_NEG","label":"A-"},{"value":"B_POS","label":"B+"},{"value":"B_NEG","label":"B-"},{"value":"O_POS","label":"O+"},{"value":"O_NEG","label":"O-"},{"value":"AB_POS","label":"AB+"},{"value":"AB_NEG","label":"AB-"}]},{"id":"field_consent","required":true,"type":"checkbox","auditTrail":{"reasonRequired":true,"trackChanges":true},"criticalDataPoint":true,"order":6,"label":"Informed Consent Obtained","auditRequired":true},{"id":"field_notes","placeholder":"Enter observations...","width":"full","required":false,"type":"textarea","order":7,"label":"Clinical Notes","helpText":"Document any relevant clinical observations"},{"id":"field_email","placeholder":"patient@email.com","required":false,"isPhiField":true,"type":"email","order":8,"label":"Email Address","validationRules":[{"message":"Invalid email format","type":"email"}]},{"id":"field_phone","label":"Phone Number","type":"phone","required":false,"placeholder":"(555) 123-4567","order":9,"isPhiField":true},{"id":"field_documents","maxFiles":5,"required":false,"maxFileSize":10485760,"type":"file","order":10,"label":"Upload Documents","allowedFileTypes":["pdf","jpg","png"]},{"calculationFormula":"weight / (height * height)","id":"field_bmi","required":false,"readonly":true,"dependsOn":["field_weight","field_height"],"type":"number","order":11,"label":"BMI (Calculated)"},{"id":"field_pregnancy_status","label":"Pregnancy Status","showWhen":[{"operator":"equals","value":"F","fieldId":"field_gender"}],"type":"select","required":false,"order":12,"options":[{"value":"NO","label":"Not Pregnant"},{"value":"YES","label":"Currently Pregnant"},{"value":"UNK","label":"Unknown"}]}],"description":"Complete form with all field types","category":"Patient Intake","status":"draft"}	201	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	63	2025-12-02 07:25:40.72957
88	879f883d-c689-4851-a588-bc4755498981	\N	anonymous	\N	GET	/api/forms/7/metadata	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	30	2025-12-02 07:25:40.751858
89	81fe18e3-94b5-4b17-8137-40a13095fc56	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	27	2025-12-02 07:26:09.139645
90	c9e268be-af86-4286-bfb8-2eb4f15e84ad	\N	anonymous	\N	GET	/api/forms/7%20/metadata	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	16	2025-12-02 07:26:09.327692
91	c853363f-c713-47ad-95bf-c358378a910a	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	34	2025-12-02 07:38:03.097189
92	474121e6-9319-46c9-8cef-03aef4c7f458	\N	anonymous	\N	POST	/api/auth/logout	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	2	2025-12-02 07:38:03.362738
93	55824edd-44ad-4079-ba38-54143e460780	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	23	2025-12-02 07:38:04.513408
94	347909b1-e9e8-4e49-9809-8b067edd6cbb	\N	anonymous	\N	GET	/api/audit/login-history	{"limit":"5"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	16	2025-12-02 07:38:04.528635
95	7e62275a-28de-4ae1-b0b2-80b4f13ae2e2	\N	anonymous	\N	GET	/api/audit/login-stats	{"days":"7"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	4	2025-12-02 07:38:04.564466
96	95141090-62c7-4147-b021-c6ae645632be	\N	anonymous	\N	GET	/api/audit/recent	{"limit":"5"}	{}	500	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	16	2025-12-02 07:38:04.574219
97	986b5ff1-f308-43eb-9fe8-8ea8ea98b968	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	35	2025-12-02 07:40:52.156676
98	7ab00f04-db0b-4fc2-b64b-581b566da454	\N	anonymous	\N	POST	/api/forms	{}	{"status":"draft","description":"Testing audit logging","name":"Audit Test Form 014052","version":"1.0","fields":[{"label":"Test Field","type":"text","required":true}]}	201	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	28	2025-12-02 07:40:52.228077
99	9c35499e-906d-4e36-8610-4760304de71d	\N	anonymous	\N	POST	/api/auth/logout	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-12-02 07:40:52.233392
100	f6b11852-c7d6-4e7a-916c-638c8bad98e8	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	15	2025-12-02 07:40:53.50801
101	d27f5d8f-7e2d-4287-a280-cbbc193522f2	\N	anonymous	\N	GET	/api/audit/login-history	{"limit":"5"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	7	2025-12-02 07:40:53.51443
102	4235fca7-fa09-4b7d-9417-09a97429e70e	\N	anonymous	\N	GET	/api/audit/login-stats	{"days":"7"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	5	2025-12-02 07:40:53.5377
103	561c04ea-37aa-470e-a068-33f3cc2e2460	\N	anonymous	\N	GET	/api/audit/recent	{"limit":"5"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	4	2025-12-02 07:40:53.54688
104	12bc0a94-ae74-44df-8704-4dc1068bab05	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	31	2025-12-02 07:43:20.570521
105	97903f22-e074-4e1b-a311-e007a41b4e1c	\N	anonymous	\N	POST	/api/forms	{}	{"status":"draft","description":"Testing audit logging","name":"Audit Test Form 014320","version":"1.0","fields":[{"label":"Test Field","type":"text","required":true}]}	400	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	16	2025-12-02 07:43:20.61747
106	5f986743-a1a0-4784-ac93-e46115f02565	\N	anonymous	\N	GET	/api/forms//metadata	{}	{}	400	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	3	2025-12-02 07:43:20.69176
107	69439f28-97b0-483a-bb33-25449cad49b9	\N	anonymous	\N	PUT	/api/forms/	{}	{"status":"published"}	404	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	4	2025-12-02 07:43:20.702558
108	844254b6-239b-4147-bab6-84e8fd3b0c77	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	4	2025-12-02 07:43:20.725568
109	b4d50bfb-b34b-484a-9ea1-c63ee37bfca0	\N	anonymous	\N	POST	/api/auth/logout	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	16	2025-12-02 07:43:20.732448
110	ce99b12b-064c-45cc-98e9-be13968ecb36	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	13	2025-12-02 07:43:21.981658
111	c349a5d3-e3ae-4f67-8953-20efeaa5262b	\N	anonymous	\N	GET	/api/audit/login-history	{"limit":"10"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	7	2025-12-02 07:43:21.990983
112	34c0049e-cc2d-4604-a9d6-ff65233a429c	\N	anonymous	\N	GET	/api/audit/login-stats	{"days":"7"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	6	2025-12-02 07:43:22.019239
114	e3fc2e08-cdf3-4e58-a725-a56270d4d51b	\N	anonymous	\N	POST	/api/forms	{}	{"description":"Test form","name":"Audit Form 20251202014400","version":"1.0","fields":[{"type":"text","label":"Field1"}]}	201	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	36	2025-12-02 07:44:00.480338
115	54d9ea11-90d8-4d8f-b94d-454f0ec732e9	\N	anonymous	\N	GET	/api/forms/10/metadata	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	34	2025-12-02 07:44:00.508427
116	a0ac3358-ed4b-4b29-8fab-8ece37d89481	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	429	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-12-02 07:44:00.514651
117	ad6156fe-2ac7-441f-a961-48fae636cd74	\N	anonymous	\N	POST	/api/auth/logout	{}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	0	2025-12-02 07:44:00.521182
118	df2a906b-2780-4b14-800c-b75e20207cf8	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	429	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-12-02 07:44:01.871516
119	40730d5d-7ec2-4805-8e4e-df55c34a4872	\N	anonymous	\N	GET	/api/audit/login-stats	{"days":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	17	2025-12-02 07:44:01.893719
120	99a61fcd-a6f1-4dd2-a18c-4a207535ae5a	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	429	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	0	2025-12-02 07:44:35.467036
121	1d35ed1e-2027-458c-8114-85fdd4831c39	\N	anonymous	\N	POST	/api/forms	{}	{"description":"Debug test","name":"Debug Form 014435","version":"1.0","fields":[{"type":"text","label":"Test"}]}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-12-02 07:44:35.585906
122	fc077fe6-f621-4b6f-8e3c-a998ddbabb16	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	429	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-12-02 07:44:54.886769
123	1886520b-8448-4cbf-9394-ed0ad6932729	\N	anonymous	\N	POST	/api/forms	{}	{"description":"Debug test","name":"Debug Form 014454","version":"1.0","fields":[{"type":"text","label":"Test"}]}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	0	2025-12-02 07:44:54.964585
124	ca7ef445-52b0-41f3-a229-3c6b38ce2c58	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	429	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	0	2025-12-02 07:45:20.580735
125	5111d0df-e5ee-4df1-8a8f-6670989acb83	\N	anonymous	\N	POST	/api/forms	{}	{"description":"Debug test","name":"Debug Form 014520","version":"1.0","fields":[{"type":"text","label":"Test"}]}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-12-02 07:45:20.654051
126	d3e8eb0f-6126-44f4-a006-f924f24b6ad1	\N	anonymous	\N	GET	/api/forms//metadata	{}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-12-02 07:45:20.659529
127	dd0e86a2-2b33-4889-a36f-7ce152934f1f	\N	anonymous	\N	GET	/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	2	2025-12-02 07:53:25.784491
128	7ee43341-e209-4e1f-a5fd-1100d74e7655	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	24	2025-12-02 07:53:25.871353
129	31932993-7205-4650-952d-a9436e69d166	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	20	2025-12-02 07:53:25.898291
130	edb260b8-258a-48ec-b9fe-5b424448ffd1	\N	anonymous	\N	POST	/api/queries	{}	{"detailedNotes":"Created from frontend test","description":"Test Query 01:53:25","entityType":"studySubject","studyId":1,"entityId":1,"typeId":3}	400	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	10	2025-12-02 07:53:25.93544
131	8e07dd32-56c1-430b-a57f-018ce30d04a6	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	16	2025-12-02 07:53:40.982488
132	73ca327b-d000-4fc7-9e30-f31b5e7b702e	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	11	2025-12-02 07:53:41.022012
133	965a2b6f-4223-4c13-ad93-22a1f05584b4	\N	anonymous	\N	POST	/api/queries	{}	{"detailedNotes":"Created from frontend test","description":"Test Query 01:53:41","entityType":"studySubject","studyId":1,"entityId":1,"typeId":3}	400	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	4	2025-12-02 07:53:41.03663
134	2b3283a8-5796-4d43-9a15-58450afad73d	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	26	2025-12-02 07:55:02.461695
135	9b71b95c-2202-4276-8c84-a7d1a7b43d45	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	17	2025-12-02 07:55:02.505783
136	e6132ed2-e6b1-40f3-940a-5813646b7319	\N	anonymous	\N	POST	/api/queries	{}	{"detailedNotes":"This query was created to test the frontend integration","description":"Test Query from Frontend - 01:55:02","entityType":"studySubject","studyId":1,"entityId":1,"subjectId":1,"queryType":"Query"}	400	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	20	2025-12-02 07:55:02.538028
137	e96d0fd6-e8c1-4e8c-92fc-2726a4f583d5	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	25	2025-12-02 07:55:59.76447
138	1bf6451f-5ec3-4035-a42d-6e6d0d5199cf	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	14	2025-12-02 07:55:59.805432
139	cbb135c0-810e-43af-b7d9-b51b383d8dd1	\N	anonymous	\N	POST	/api/queries	{}	{"detailedNotes":"Created to verify query system works end-to-end","description":"Test Query from Frontend - 01:55:59","entityType":"studySubject","studyId":1,"entityId":1,"queryType":"Query"}	201	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	17	2025-12-02 07:55:59.832667
140	deeef709-7ee2-44e9-99bc-798a6d469c96	\N	anonymous	\N	GET	/api/queries/2	{}	{}	500	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	12	2025-12-02 07:55:59.85024
141	2d986d48-1a5b-41d8-9c8b-349088fc73e5	\N	anonymous	\N	GET	/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-12-02 09:10:39.131799
142	3ea8f26a-7b69-48dd-8584-aab69ab8bef7	\N	anonymous	\N	GET	/api/sdv	{}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	3	2025-12-02 09:10:43.791786
143	cfe47157-e01c-4819-8fdc-de0fd5572266	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	28	2025-12-02 09:10:49.117708
144	dfb16084-946b-4b62-84fd-b2bf96bc3504	\N	anonymous	\N	GET	/api/sdv	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	29	2025-12-02 09:10:58.302223
145	cc3cb728-d5f7-46dd-a092-abbce452481c	\N	anonymous	\N	GET	/api/sdv	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	7	2025-12-02 09:11:07.363847
146	5b0caf96-f1cb-4b1f-97b1-1f03faa1c1fe	\N	anonymous	\N	GET	/api/sdv	{}	{}	200	127.0.0.1	curl/8.13.0	6	2025-12-02 09:11:17.454143
147	8f9f92ed-2991-4fa3-be1f-7f43b4f312cd	\N	anonymous	\N	GET	/api/sdv	{}	{}	200	127.0.0.1	curl/8.13.0	6	2025-12-02 09:11:26.288819
148	98536640-109a-465d-abcb-d188a4b3944b	\N	anonymous	\N	GET	/api/data-locks	{}	{}	200	127.0.0.1	curl/8.13.0	9	2025-12-02 09:11:43.138208
149	2eb6d0dc-74e3-472c-a635-908b3c18e15e	\N	anonymous	\N	GET	/api/sdv	{}	{}	401	127.0.0.1	curl/8.13.0	2	2025-12-02 09:44:46.860026
150	094db9aa-0246-444f-9ce1-ac18dadd4eeb	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	24	2025-12-02 09:44:58.055413
151	3108c713-df9e-4373-b21a-5031ee710b14	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	curl/8.13.0	27	2025-12-02 09:51:28.370282
152	33cace0e-e95c-4ffb-bd40-7b2b5fc3c8da	\N	anonymous	\N	GET	/api/sdv	{}	{}	200	127.0.0.1	curl/8.13.0	13	2025-12-02 09:51:40.79841
153	cc09fff2-39e3-497e-add9-6560ba473670	\N	anonymous	\N	GET	/api/data-locks	{}	{}	200	127.0.0.1	curl/8.13.0	21	2025-12-02 09:51:56.578639
154	b420a6f3-3435-492d-a7f4-b994884fd10f	\N	anonymous	\N	GET	/api/data-locks	{}	{}	200	127.0.0.1	curl/8.13.0	25	2025-12-02 10:05:44.413226
155	11fb4a40-f36d-4a61-b79c-f61f88abfb3e	\N	anonymous	\N	PUT	/api/sdv/1/verify	{}	{}	200	127.0.0.1	curl/8.13.0	17	2025-12-02 10:06:00.866768
156	6ab799ed-458f-415d-9b52-00cf33720609	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	curl/8.13.0	25	2025-12-02 10:09:18.317423
157	d451e0df-ba80-47e2-86e1-f811ca00cd77	\N	anonymous	\N	GET	/api/users	{}	{}	200	127.0.0.1	curl/8.13.0	9	2025-12-02 10:09:31.835985
158	e94ec1eb-a566-4cba-b8b4-ab45d0d5746a	\N	anonymous	\N	POST	/api/users	{}	{"username":"testuser1","firstName":"Test","lastName":"User","email":"test@example.com","password":"***REDACTED***"}	400	127.0.0.1	curl/8.13.0	22	2025-12-02 10:12:09.424642
159	de07cfe5-5848-46ef-b93d-eca660e9d337	\N	anonymous	\N	GET	/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	4	2025-12-03 04:38:21.875107
160	ddb2dfe6-25e9-4148-bbfa-64d69ed4a076	\N	anonymous	\N	GET	/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-12-03 04:38:25.709868
161	bc30a822-866a-4173-bce4-b82d134585c4	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	16	2025-12-03 04:38:31.475192
162	3a6d318b-c85d-449b-be88-612d77f6762f	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	22	2025-12-03 04:38:45.76012
163	ea79ccff-9961-49f2-a11f-51cc00d14c07	\N	anonymous	\N	POST	/api/forms	{}	{"description":"A test form created via API","name":"Test Form From PowerShell","fields":[{"label":"Patient Name","type":"text","required":true},{"label":"Age","type":"number","required":true},{"label":"Gender","options":[{"value":"male","label":"Male"},{"value":"female","label":"Female"}],"type":"select"}]}	201	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	89	2025-12-03 04:38:57.252366
164	38796cc2-088c-4a4f-9335-9fe537a4fc6b	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	8	2025-12-03 04:39:05.346588
165	b82d1f7c-025c-4b7d-8372-b7d11e94318d	\N	anonymous	\N	GET	/api/forms/11/metadata	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	23	2025-12-03 04:39:20.628617
166	2c1ebfc8-8aec-4133-8270-bc9d63b19b16	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	27	2025-12-03 04:40:41.564108
167	30dc7448-952c-44ed-848d-01636e134043	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	31	2025-12-03 04:40:41.603172
168	12e9d362-a4d3-433b-ab66-0de3a25cccb8	\N	anonymous	\N	POST	/api/forms	{}	{"description":"Created by diagnostic script","name":"Diagnostic Test Form 20251202224041","fields":[{"label":"Patient Name","type":"text","required":true},{"label":"Age","min":0,"max":120,"type":"number","required":true},{"label":"Gender","options":[{"value":"male","label":"Male"},{"value":"female","label":"Female"},{"value":"other","label":"Other"}],"type":"select"},{"label":"Date of Visit","type":"date","required":true},{"label":"Notes","type":"textarea","required":false}]}	201	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	44	2025-12-03 04:40:41.693913
169	692fbb98-db69-4fd7-be20-18cad03e4c05	\N	anonymous	\N	GET	/api/forms/12	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	21	2025-12-03 04:40:41.703481
170	48cd62e2-1e50-49e4-852f-5277dcb50516	\N	anonymous	\N	GET	/api/forms/12/metadata	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	19	2025-12-03 04:40:41.727539
171	3eda07d2-646c-4b59-a02b-46cf6e369032	\N	anonymous	\N	PUT	/api/forms/12	{}	{"name":"Diagnostic Test Form 20251202224041 (Updated)","description":"Updated by diagnostic script"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	26	2025-12-03 04:40:41.799596
172	123cfcbb-27f7-4232-9f8d-6f4490487ca6	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	18	2025-12-03 04:40:41.808871
173	43b90676-1e28-4b13-9cda-d6f7447cf5ca	\N	anonymous	\N	GET	/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	2	2025-12-03 05:01:14.833084
174	2c14ddd8-b2cf-4479-a00d-05d7a5834688	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	unknown	21	2025-12-03 05:01:24.183625
222	c7f3f513-9fb5-472c-bacc-6dc17c6199ea	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	325	2025-12-04 14:09:01.539684
223	c69a46fa-be6b-45fd-a82c-cd3485f943f8	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	29	2025-12-04 14:09:01.784782
175	36ab0c51-851f-415f-b1df-9fe70f087767	\N	anonymous	\N	POST	/api/forms	{}	{"name":"Real API Test 1764738084185","description":"Created by test-template-api.js - Real E2E test","category":"demographics","version":"1.0","fields":[{"label":"Patient Name","type":"text","name":"patient_name","required":true},{"label":"Age","type":"number","name":"age","required":true,"min":0,"max":150},{"label":"Date of Birth","type":"date","name":"dob","required":true,"isPhiField":true},{"label":"Gender","type":"select","name":"gender","options":[{"label":"Male","value":"M"},{"label":"Female","value":"F"},{"label":"Other","value":"O"}]},{"label":"Height","type":"number","name":"height","unit":"cm","min":50,"max":250},{"label":"Weight","type":"number","name":"weight","unit":"kg","min":1,"max":500},{"label":"Blood Pressure","type":"text","name":"bp","unit":"mmHg","placeholder":"120/80"},{"label":"Smoking Status","type":"radio","name":"smoking","options":[{"label":"Never","value":"never"},{"label":"Former","value":"former"},{"label":"Current","value":"current"}]},{"label":"Notes","type":"textarea","name":"notes"},{"label":"SSN","type":"text","name":"ssn","isPhiField":true,"auditRequired":true}]}	201	127.0.0.1	unknown	67	2025-12-03 05:01:24.270327
176	bcb9146e-a15f-423d-9183-64ced303de4e	\N	anonymous	\N	GET	/api/forms/13	{}	{}	200	127.0.0.1	unknown	20	2025-12-03 05:01:24.283019
177	bfd1dc0d-36af-47ac-927e-55771507e46d	\N	anonymous	\N	GET	/api/forms/13/metadata	{}	{}	200	127.0.0.1	unknown	21	2025-12-03 05:01:24.303902
178	abbd9b14-bd19-4866-8b29-4c5847bf64ac	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	unknown	18	2025-12-03 05:01:24.329663
179	67bffe89-c34b-453b-9f75-f0f2b97d8148	\N	anonymous	\N	PUT	/api/forms/13	{}	{"name":"Real API Test 1764738084185 - UPDATED","description":"Updated by test script"}	200	127.0.0.1	unknown	17	2025-12-03 05:01:24.360859
180	b438b20a-d6e5-47b3-9788-302366439ee9	\N	anonymous	\N	GET	/api/forms/13	{}	{}	200	127.0.0.1	unknown	20	2025-12-03 05:01:24.370497
181	ee5a548d-4e58-49f3-a03d-e5dd168ba829	\N	anonymous	\N	DELETE	/api/forms/13	{}	{}	200	127.0.0.1	unknown	21	2025-12-03 05:01:24.392406
182	6861a043-00a0-440c-b20f-b5ca539b727a	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	unknown	30	2025-12-03 05:03:21.413167
183	843f0c68-a652-4421-914d-85de157a66dd	\N	anonymous	\N	POST	/api/forms	{}	{"name":"Data Verification Test 1764738201358","description":"Testing that exact data is preserved through the system","category":"vitals","version":"2.0","fields":[{"label":"Patient Full Name","type":"text","name":"patient_full_name","required":true,"placeholder":"Enter your full legal name","helpText":"As it appears on your ID"},{"label":"Age in Years","type":"number","name":"age_years","required":true,"min":0,"max":120,"unit":"years"},{"label":"Date of Birth","type":"date","name":"date_of_birth","required":true,"isPhiField":true,"auditRequired":true},{"label":"Biological Sex","type":"select","name":"biological_sex","required":true,"options":[{"label":"Male","value":"male"},{"label":"Female","value":"female"},{"label":"Intersex","value":"intersex"}]},{"label":"Height","type":"number","name":"height_cm","required":false,"unit":"cm","min":30,"max":280},{"label":"Weight","type":"number","name":"weight_kg","required":false,"unit":"kg","min":0.5,"max":700},{"label":"Blood Pressure","type":"text","name":"blood_pressure","required":false,"unit":"mmHg","placeholder":"e.g., 120/80"},{"label":"Smoking History","type":"radio","name":"smoking_history","required":true,"options":[{"label":"Never Smoked","value":"never"},{"label":"Former Smoker","value":"former"},{"label":"Current Smoker","value":"current"}]},{"label":"Medical Notes","type":"textarea","name":"medical_notes","required":false,"placeholder":"Enter any relevant medical history"},{"label":"Social Security Number","type":"text","name":"ssn","required":false,"isPhiField":true,"auditRequired":true}]}	201	127.0.0.1	unknown	68	2025-12-03 05:03:21.500576
184	9c928a27-9392-4f96-91f3-b980a0d7063d	\N	anonymous	\N	GET	/api/forms/14/metadata	{}	{}	200	127.0.0.1	unknown	33	2025-12-03 05:03:21.522224
185	e7d06a6c-e03d-4d0d-a427-0564099e01fd	\N	anonymous	\N	DELETE	/api/forms/14	{}	{}	200	127.0.0.1	unknown	20	2025-12-03 05:03:21.559172
186	29b9c944-78e6-4715-b0b2-10aaf9405a7d	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	unknown	26	2025-12-03 05:06:22.875776
187	90e11f1c-67e7-4804-9ae8-96ee3dbd8e08	\N	anonymous	\N	POST	/api/forms	{}	{"name":"Data Verification Test 1764738382826","description":"Testing that exact data is preserved through the system","category":"vitals","version":"2.0","fields":[{"label":"Patient Full Name","type":"text","name":"patient_full_name","required":true,"placeholder":"Enter your full legal name","helpText":"As it appears on your ID"},{"label":"Age in Years","type":"number","name":"age_years","required":true,"min":0,"max":120,"unit":"years"},{"label":"Date of Birth","type":"date","name":"date_of_birth","required":true,"isPhiField":true,"auditRequired":true},{"label":"Biological Sex","type":"select","name":"biological_sex","required":true,"options":[{"label":"Male","value":"male"},{"label":"Female","value":"female"},{"label":"Intersex","value":"intersex"}]},{"label":"Height","type":"number","name":"height_cm","required":false,"unit":"cm","min":30,"max":280},{"label":"Weight","type":"number","name":"weight_kg","required":false,"unit":"kg","min":0.5,"max":700},{"label":"Blood Pressure","type":"text","name":"blood_pressure","required":false,"unit":"mmHg","placeholder":"e.g., 120/80"},{"label":"Smoking History","type":"radio","name":"smoking_history","required":true,"options":[{"label":"Never Smoked","value":"never"},{"label":"Former Smoker","value":"former"},{"label":"Current Smoker","value":"current"}]},{"label":"Medical Notes","type":"textarea","name":"medical_notes","required":false,"placeholder":"Enter any relevant medical history"},{"label":"Social Security Number","type":"text","name":"ssn","required":false,"isPhiField":true,"auditRequired":true}]}	400	127.0.0.1	unknown	16	2025-12-03 05:06:22.897794
188	911d0813-e8ee-4037-829b-06d5c25da09f	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	unknown	29	2025-12-03 05:07:10.473208
224	57562b49-1dc5-4532-9bcb-e5edc2a14e94	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"1000"}	{}	400	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	4	2025-12-04 14:09:01.808621
225	373e1be1-5f21-426a-87a6-dc72a2973756	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"1000"}	{}	400	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	3	2025-12-04 14:09:01.808786
227	dd8c1a8a-9250-48df-af74-e4464a38e484	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	39	2025-12-04 14:09:01.851246
228	3e80b26e-30b2-473f-a4de-7ef49db12445	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	25	2025-12-04 14:09:01.85213
230	40ad91d6-707e-449d-8bb7-966fe52bed23	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	12	2025-12-04 14:09:01.902192
189	9d964199-73b2-46cb-910b-be25078f6d6f	\N	anonymous	\N	POST	/api/forms	{}	{"name":"Data Verification Test 1764738430406","description":"Testing that exact data is preserved through the system","category":"vitals","version":"2.0","fields":[{"label":"Patient Full Name","type":"text","name":"patient_full_name","required":true,"placeholder":"Enter your full legal name","helpText":"As it appears on your ID"},{"label":"Age in Years","type":"number","name":"age_years","required":true,"min":0,"max":120,"unit":"years"},{"label":"Date of Birth","type":"date","name":"date_of_birth","required":true,"isPhiField":true,"auditRequired":true},{"label":"Biological Sex","type":"select","name":"biological_sex","required":true,"options":[{"label":"Male","value":"male"},{"label":"Female","value":"female"},{"label":"Intersex","value":"intersex"}]},{"label":"Height","type":"number","name":"height_cm","required":false,"unit":"cm","min":30,"max":280},{"label":"Weight","type":"number","name":"weight_kg","required":false,"unit":"kg","min":0.5,"max":700},{"label":"Blood Pressure","type":"text","name":"blood_pressure","required":false,"unit":"mmHg","placeholder":"e.g., 120/80"},{"label":"Smoking History","type":"radio","name":"smoking_history","required":true,"options":[{"label":"Never Smoked","value":"never"},{"label":"Former Smoker","value":"former"},{"label":"Current Smoker","value":"current"}]},{"label":"Medical Notes","type":"textarea","name":"medical_notes","required":false,"placeholder":"Enter any relevant medical history"},{"label":"Social Security Number","type":"text","name":"ssn","required":false,"isPhiField":true,"auditRequired":true}]}	400	127.0.0.1	unknown	25	2025-12-03 05:07:10.505124
190	d4ae8c79-1ed6-49a7-b5e5-9d5f97bd9b3c	\N	anonymous	\N	GET	/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	4	2025-12-03 05:07:36.761825
191	bad3ba44-1657-448e-82d6-1437c6893a1c	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	unknown	23	2025-12-03 05:07:40.980978
192	dbe8dc7a-88af-40fb-b1fd-b22bc3344596	\N	anonymous	\N	POST	/api/forms	{}	{"name":"Data Verification Test 1764738460924","description":"Testing that exact data is preserved through the system","category":"vitals","version":"2.0","fields":[{"label":"Patient Full Name","type":"text","name":"patient_full_name","required":true,"placeholder":"Enter your full legal name","helpText":"As it appears on your ID"},{"label":"Age in Years","type":"number","name":"age_years","required":true,"min":0,"max":120,"unit":"years"},{"label":"Date of Birth","type":"date","name":"date_of_birth","required":true,"isPhiField":true,"auditRequired":true},{"label":"Biological Sex","type":"select","name":"biological_sex","required":true,"options":[{"label":"Male","value":"male"},{"label":"Female","value":"female"},{"label":"Intersex","value":"intersex"}]},{"label":"Height","type":"number","name":"height_cm","required":false,"unit":"cm","min":30,"max":280},{"label":"Weight","type":"number","name":"weight_kg","required":false,"unit":"kg","min":0.5,"max":700},{"label":"Blood Pressure","type":"text","name":"blood_pressure","required":false,"unit":"mmHg","placeholder":"e.g., 120/80"},{"label":"Smoking History","type":"radio","name":"smoking_history","required":true,"options":[{"label":"Never Smoked","value":"never"},{"label":"Former Smoker","value":"former"},{"label":"Current Smoker","value":"current"}]},{"label":"Medical Notes","type":"textarea","name":"medical_notes","required":false,"placeholder":"Enter any relevant medical history"},{"label":"Social Security Number","type":"text","name":"ssn","required":false,"isPhiField":true,"auditRequired":true}]}	400	127.0.0.1	unknown	19	2025-12-03 05:07:41.00628
193	22a44f17-ea4b-4f55-bfee-1fad7efa184e	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	unknown	25	2025-12-03 05:14:36.130871
194	6e9e8c92-4f14-4c2b-959e-b08ae408cd9d	\N	anonymous	\N	POST	/api/forms	{}	{"name":"Data Verification Test 1764738876070","description":"Testing that exact data is preserved through the system","category":"vitals","version":"2.0","fields":[{"label":"Patient Full Name","type":"text","name":"patient_full_name","required":true,"placeholder":"Enter your full legal name","helpText":"As it appears on your ID"},{"label":"Age in Years","type":"number","name":"age_years","required":true,"min":0,"max":120,"unit":"years"},{"label":"Date of Birth","type":"date","name":"date_of_birth","required":true,"isPhiField":true,"auditRequired":true},{"label":"Biological Sex","type":"select","name":"biological_sex","required":true,"options":[{"label":"Male","value":"male"},{"label":"Female","value":"female"},{"label":"Intersex","value":"intersex"}]},{"label":"Height","type":"number","name":"height_cm","required":false,"unit":"cm","min":30,"max":280},{"label":"Weight","type":"number","name":"weight_kg","required":false,"unit":"kg","min":0.5,"max":700},{"label":"Blood Pressure","type":"text","name":"blood_pressure","required":false,"unit":"mmHg","placeholder":"e.g., 120/80"},{"label":"Smoking History","type":"radio","name":"smoking_history","required":true,"options":[{"label":"Never Smoked","value":"never"},{"label":"Former Smoker","value":"former"},{"label":"Current Smoker","value":"current"}]},{"label":"Medical Notes","type":"textarea","name":"medical_notes","required":false,"placeholder":"Enter any relevant medical history"},{"label":"Social Security Number","type":"text","name":"ssn","required":false,"isPhiField":true,"auditRequired":true}]}	400	127.0.0.1	unknown	23	2025-12-03 05:14:36.1615
195	4e985646-8dfd-45d6-b011-b763ff16b3ac	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	unknown	26	2025-12-03 05:15:12.482075
196	4e41a493-5a88-42a0-9738-5c7acc065fa4	\N	anonymous	\N	POST	/api/forms	{}	{"name":"Data Verification Test 1764738912421","description":"Testing that exact data is preserved through the system","category":"vitals","version":"2.0","fields":[{"label":"Patient Full Name","type":"text","name":"patient_full_name","required":true,"placeholder":"Enter your full legal name","helpText":"As it appears on your ID"},{"label":"Age in Years","type":"number","name":"age_years","required":true,"min":0,"max":120,"unit":"years"},{"label":"Date of Birth","type":"date","name":"date_of_birth","required":true,"isPhiField":true,"auditRequired":true},{"label":"Biological Sex","type":"select","name":"biological_sex","required":true,"options":[{"label":"Male","value":"male"},{"label":"Female","value":"female"},{"label":"Intersex","value":"intersex"}]},{"label":"Height","type":"number","name":"height_cm","required":false,"unit":"cm","min":30,"max":280},{"label":"Weight","type":"number","name":"weight_kg","required":false,"unit":"kg","min":0.5,"max":700},{"label":"Blood Pressure","type":"text","name":"blood_pressure","required":false,"unit":"mmHg","placeholder":"e.g., 120/80"},{"label":"Smoking History","type":"radio","name":"smoking_history","required":true,"options":[{"label":"Never Smoked","value":"never"},{"label":"Former Smoker","value":"former"},{"label":"Current Smoker","value":"current"}]},{"label":"Medical Notes","type":"textarea","name":"medical_notes","required":false,"placeholder":"Enter any relevant medical history"},{"label":"Social Security Number","type":"text","name":"ssn","required":false,"isPhiField":true,"auditRequired":true}]}	400	127.0.0.1	unknown	22	2025-12-03 05:15:12.511128
197	1191a46c-95d0-41e3-8805-d580d4ae47c7	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	unknown	22	2025-12-03 05:16:29.693782
226	b1961e7a-19f7-4470-90a6-611e652fc658	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:09:01.850931
198	b817863b-0f01-462d-9a75-e1993798c60e	\N	anonymous	\N	POST	/api/forms	{}	{"name":"Data Verification Test 1764738989631","description":"Testing that exact data is preserved through the system","category":"vitals","version":"2.0","fields":[{"label":"Patient Full Name","type":"text","name":"patient_full_name","required":true,"placeholder":"Enter your full legal name","helpText":"As it appears on your ID"},{"label":"Age in Years","type":"number","name":"age_years","required":true,"min":0,"max":120,"unit":"years"},{"label":"Date of Birth","type":"date","name":"date_of_birth","required":true,"isPhiField":true,"auditRequired":true},{"label":"Biological Sex","type":"select","name":"biological_sex","required":true,"options":[{"label":"Male","value":"male"},{"label":"Female","value":"female"},{"label":"Intersex","value":"intersex"}]},{"label":"Height","type":"number","name":"height_cm","required":false,"unit":"cm","min":30,"max":280},{"label":"Weight","type":"number","name":"weight_kg","required":false,"unit":"kg","min":0.5,"max":700},{"label":"Blood Pressure","type":"text","name":"blood_pressure","required":false,"unit":"mmHg","placeholder":"e.g., 120/80"},{"label":"Smoking History","type":"radio","name":"smoking_history","required":true,"options":[{"label":"Never Smoked","value":"never"},{"label":"Former Smoker","value":"former"},{"label":"Current Smoker","value":"current"}]},{"label":"Medical Notes","type":"textarea","name":"medical_notes","required":false,"placeholder":"Enter any relevant medical history"},{"label":"Social Security Number","type":"text","name":"ssn","required":false,"isPhiField":true,"auditRequired":true}]}	201	127.0.0.1	unknown	62	2025-12-03 05:16:29.778996
199	cfe3f61c-5623-48eb-804b-f69ba0fcb658	\N	anonymous	\N	GET	/api/forms/20/metadata	{}	{}	200	127.0.0.1	unknown	35	2025-12-03 05:16:29.799581
200	df04e5e0-df6c-43bb-be03-5d78ede6a02e	\N	anonymous	\N	DELETE	/api/forms/20	{}	{}	200	127.0.0.1	unknown	19	2025-12-03 05:16:29.838938
201	8aeba233-2165-4fb0-a6ca-36cfe5fed82e	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	unknown	16	2025-12-03 05:16:35.18226
202	2244bea8-0c25-4f24-8688-1d74f52a90aa	\N	anonymous	\N	POST	/api/forms	{}	{"name":"Data Verification Test 1764738995138","description":"Testing that exact data is preserved through the system","category":"vitals","version":"2.0","fields":[{"label":"Patient Full Name","type":"text","name":"patient_full_name","required":true,"placeholder":"Enter your full legal name","helpText":"As it appears on your ID"},{"label":"Age in Years","type":"number","name":"age_years","required":true,"min":0,"max":120,"unit":"years"},{"label":"Date of Birth","type":"date","name":"date_of_birth","required":true,"isPhiField":true,"auditRequired":true},{"label":"Biological Sex","type":"select","name":"biological_sex","required":true,"options":[{"label":"Male","value":"male"},{"label":"Female","value":"female"},{"label":"Intersex","value":"intersex"}]},{"label":"Height","type":"number","name":"height_cm","required":false,"unit":"cm","min":30,"max":280},{"label":"Weight","type":"number","name":"weight_kg","required":false,"unit":"kg","min":0.5,"max":700},{"label":"Blood Pressure","type":"text","name":"blood_pressure","required":false,"unit":"mmHg","placeholder":"e.g., 120/80"},{"label":"Smoking History","type":"radio","name":"smoking_history","required":true,"options":[{"label":"Never Smoked","value":"never"},{"label":"Former Smoker","value":"former"},{"label":"Current Smoker","value":"current"}]},{"label":"Medical Notes","type":"textarea","name":"medical_notes","required":false,"placeholder":"Enter any relevant medical history"},{"label":"Social Security Number","type":"text","name":"ssn","required":false,"isPhiField":true,"auditRequired":true}]}	201	127.0.0.1	unknown	73	2025-12-03 05:16:35.273087
203	4b71e4f0-6a2d-4136-9460-4569d8764327	\N	anonymous	\N	GET	/api/forms/21/metadata	{}	{}	200	127.0.0.1	unknown	32	2025-12-03 05:16:35.29563
204	640702ab-f594-496d-835d-8412e7c7ec91	\N	anonymous	\N	DELETE	/api/forms/21	{}	{}	200	127.0.0.1	unknown	17	2025-12-03 05:16:35.330095
205	a7ff8771-5d8e-44fd-a72f-acc7e1f92413	\N	anonymous	\N	GET	/api/users	{}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	2	2025-12-03 06:11:06.073047
206	1b8174be-697d-4cf7-a7b3-7b85042bd785	\N	anonymous	\N	GET	/api/users	{"limit":"5"}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	2	2025-12-03 06:11:12.86793
207	6a210566-9ca9-49c3-a15f-a2ed808febf4	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	15	2025-12-03 06:11:22.111953
208	380d98f1-34c5-4c66-bafb-0a00a5667789	\N	anonymous	\N	GET	/api/users	{"limit":"5"}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-12-03 06:11:22.138641
209	f441cd72-bdd7-465c-809d-d9bb92fb8c2e	\N	anonymous	\N	GET	/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	4	2025-12-03 06:48:20.767282
210	a55dfeba-7455-40c7-8beb-a8c31e4ca8c8	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	14	2025-12-03 06:48:35.456993
211	2c600fbe-98f2-420a-88f8-2bf312116167	\N	anonymous	\N	POST	/api/subjects	{}	{"dateOfBirth":"1990-01-15","studyId":1,"gender":"m","studySubjectId":"TEST-PATIENT-838468298","secondaryId":"MRN12345","enrollmentDate":"2025-01-01"}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	3	2025-12-03 06:48:35.855445
212	f72a1381-9fdc-4f3c-baaf-2ff68e451ee4	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	9	2025-12-03 06:48:40.423174
213	d77d747f-dff6-43a6-8e07-445853c5f52f	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	28	2025-12-03 06:49:39.28229
214	6d16efb3-d6ae-4d90-80c1-153a035b1e80	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	unknown	27	2025-12-03 06:52:38.594657
215	577c072f-02a8-4426-95a9-f5889792ec5e	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1"}	{}	200	127.0.0.1	unknown	36	2025-12-03 06:52:38.654185
216	b4ac70cd-114c-4b80-9c0e-233e9aea04c6	\N	anonymous	\N	POST	/api/subjects	{}	{"studyId":1,"studySubjectId":"TEST-1764744758640","secondaryId":"MRN-TEST-123","dateOfBirth":"1990-05-15","gender":"m","enrollmentDate":"2025-01-01"}	201	127.0.0.1	unknown	403	2025-12-03 06:52:39.048216
217	c7dc6be9-68ff-4b41-93bc-f78eb0d92c59	\N	anonymous	\N	GET	/api/subjects/1	{}	{}	200	127.0.0.1	unknown	50	2025-12-03 06:52:39.102061
218	8d5ad3a4-fe3f-4768-95af-27231dffa4d7	\N	anonymous	\N	GET	/api/subjects/1/progress	{}	{}	200	127.0.0.1	unknown	91	2025-12-03 06:52:39.198345
219	9343487b-a624-45a2-9278-192c6d74c506	\N	anonymous	\N	GET	/api/subjects/1/events	{}	{}	200	127.0.0.1	unknown	11	2025-12-03 06:52:39.212596
220	78b01ecf-6e96-497c-b013-1aafa78b9ea9	\N	anonymous	\N	GET	/api/subjects/1/forms	{}	{}	200	127.0.0.1	unknown	10	2025-12-03 06:52:39.224931
221	34a4e230-58a5-4de2-ba95-a1f942de5040	\N	anonymous	\N	GET	/api/subjects	{}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	3	2025-12-04 14:02:49.075072
231	1860c0e4-c60b-47d8-b477-60a69fef3e12	\N	anonymous	\N	GET	/api/workflows/user/root/summary	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	12	2025-12-04 14:09:01.907282
232	a217cf10-75b0-491c-b40c-bf3308a6caba	\N	anonymous	\N	GET	/api/workflows/user/root	{}	{}	500	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	10	2025-12-04 14:09:01.922871
233	b56800fa-0466-45f2-b2f3-256057cff563	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	21	2025-12-04 14:12:46.832598
234	89a76551-5d9b-432a-af3a-ba731ae278a1	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	38	2025-12-04 14:12:46.844262
235	a1a895c7-2a2b-4fa2-b588-68667e7b1a34	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	36	2025-12-04 14:12:46.849037
236	1d223580-149e-44bf-83ae-326f2822c981	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	12	2025-12-04 14:12:46.859236
237	d130151b-064c-48b6-884f-dd45817279f7	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	57	2025-12-04 14:12:46.867004
238	7071f7ea-0c1c-4173-b752-9842f878e18f	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	36	2025-12-04 14:12:46.876772
239	653a3f1e-a3f9-4c47-8887-9079b74b0e67	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	15	2025-12-04 14:12:46.880886
240	86729cac-f99f-49a2-99e1-f7ed20bebff3	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	10	2025-12-04 14:12:46.898549
241	ef4ed498-7bbc-4952-824f-b9a9d7f630bb	\N	anonymous	\N	GET	/api/workflows/user/root/summary	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:12:46.899361
242	808ca282-5562-49ff-a915-d4d43c0be322	\N	anonymous	\N	GET	/api/workflows/user/root	{}	{}	500	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:12:46.91213
243	bd5ab59f-a50e-440a-ac41-f1b6a7ca8bcb	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 14:12:56.420545
244	5d380c0d-7cc3-4bb3-aec4-d09a3f250e25	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	18	2025-12-04 14:12:56.448738
245	4cd30605-37c4-4199-960b-5e6b9355bf4a	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	20	2025-12-04 14:12:56.459644
246	98299ae0-bd0c-4c16-b838-4eaa7f1c5ab2	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	27	2025-12-04 14:12:56.478773
247	bb760f0a-9897-4ffa-b638-e659b4377c85	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	44	2025-12-04 14:12:56.487981
248	8be41898-4830-4cdb-8edd-61c35b4de916	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	22	2025-12-04 14:12:56.502604
249	ca0b8869-b043-48d7-9fda-5e3c01f58638	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	17	2025-12-04 14:12:56.50285
250	ed638fcc-3213-49b5-9c62-0b6011204055	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 14:12:56.525305
251	e94d6a1c-bd87-4a6a-bf2a-b28998e36b6e	\N	anonymous	\N	GET	/api/workflows/user/root/summary	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:12:56.525702
252	68cb101a-0f9a-4bfe-a2d8-c0091908eeca	\N	anonymous	\N	GET	/api/workflows/user/root	{}	{}	500	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	10	2025-12-04 14:12:56.541856
253	381a2d7a-1306-49ca-b4d0-c4fb2553bef0	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	13	2025-12-04 14:12:57.501708
254	13d5e507-8e31-4353-8c7a-40af53245b02	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	25	2025-12-04 14:12:57.513058
255	fa3a8d67-2402-43f1-8981-d36d79aac430	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	35	2025-12-04 14:12:57.532437
256	53aaeefc-8caf-4846-8a70-d62f1d20d358	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	49	2025-12-04 14:12:57.538742
258	0085b080-66dc-4133-ba96-8c9b4fbb7efe	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	34	2025-12-04 14:12:57.546104
259	bd1ca067-c06a-4959-a157-3086a07a5c80	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	9	2025-12-04 14:12:57.546439
257	8af7bbb9-58c5-4f3c-89ec-d8f39356bbc0	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	43	2025-12-04 14:12:57.545642
260	aee9f359-b997-496e-9931-6204a15a55b4	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 14:12:57.557769
261	5a4bcbb4-fe88-4d0c-bc81-56b5606bc360	\N	anonymous	\N	GET	/api/workflows/user/root/summary	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	5	2025-12-04 14:12:57.558327
262	c1cd6541-753d-4c8b-bd0e-a473da791d32	\N	anonymous	\N	GET	/api/workflows/user/root	{}	{}	500	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:12:57.570259
263	1c18ec1f-fec6-4d8f-b88e-044120d4c102	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	23	2025-12-04 14:17:36.919564
264	ed0766ad-cc2a-43c6-9537-5c67e74e25a4	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	73	2025-12-04 14:17:37.043553
265	92f600ec-c2a9-4f79-be30-abee9dc43839	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	28	2025-12-04 14:19:16.614189
266	2ef5e5f6-a308-44c6-8c9f-ff0ddcf4752c	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	36	2025-12-04 14:19:16.622592
267	68b9a728-6140-4b7e-9839-9eaf429c1fba	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	45	2025-12-04 14:19:16.627442
269	cf83df76-6734-4cd3-bb8d-04e29f7f257a	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	14	2025-12-04 14:19:16.645236
268	61654d86-e58f-4d71-a2e0-96a7dd20d778	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	59	2025-12-04 14:19:16.644632
270	6b2deddf-3756-4d59-a3aa-c40dec619a92	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	44	2025-12-04 14:19:16.665828
271	e708d1ac-4553-4924-8ffe-b2066368493e	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	30	2025-12-04 14:19:16.671749
272	aaab7a12-b7a2-41cd-ba0a-4bb3c5218717	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:19:16.683965
274	9a6ad49b-5efa-46ca-8374-2ccd625d54cc	\N	anonymous	\N	GET	/api/subjects/NaN	{}	{}	400	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	3	2025-12-04 14:19:19.206125
273	e92bb63a-ea51-40c1-bd6d-ed585dbdab82	\N	anonymous	\N	GET	/api/subjects//progress	{}	{}	400	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 14:19:19.20636
275	b30df0d3-631b-4650-81b7-d6e95129f4d4	\N	anonymous	\N	GET	/api/subjects//events	{}	{}	400	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 14:19:19.206941
276	6a34d0ad-f40a-4c10-9749-b4da4fcea06a	\N	anonymous	\N	GET	/api/subjects//forms	{}	{}	400	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 14:19:19.207238
277	72b92b73-64d5-4044-af26-0f779394cf07	\N	anonymous	\N	GET	/api/workflows/user/root/summary	{}	{}	500	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	12	2025-12-04 14:19:35.593325
278	02c14135-85b0-43bd-92e1-cf8deb502dcf	\N	anonymous	\N	GET	/api/workflows/user/root	{}	{}	500	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 14:19:35.606131
279	7bf810b9-4258-4761-a87c-696aa2dc8835	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	13	2025-12-04 14:19:36.261395
280	3a22e06d-7bc4-4bc9-a51c-85d309b67cc5	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	30	2025-12-04 14:19:36.275432
281	183ebc22-77ae-4b03-9273-46b35d2f1745	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 14:19:36.900981
282	42260917-9695-4f9c-9d0d-5a12d5a56254	\N	anonymous	\N	GET	/api/dashboard/enrollment	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	13	2025-12-04 14:19:38.945408
283	5f27bd4b-c78e-4f63-a0f6-3d4f9a3b08d9	\N	anonymous	\N	GET	/api/dashboard/completion	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	16	2025-12-04 14:19:38.954319
284	fd3d6002-fa28-4914-95af-09d31c73eb92	\N	anonymous	\N	GET	/api/dashboard/queries	{"studyId":"1","timeframe":"month"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	17	2025-12-04 14:19:38.965359
285	5eefddf1-a90a-469d-bc39-d067a50d4e94	\N	anonymous	\N	GET	/api/dashboard/activity	{"studyId":"1","days":"30"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	13	2025-12-04 14:19:38.966169
286	513ed601-89bd-45bc-8297-672ebd573a0a	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 14:19:38.97949
287	6536c101-3c90-4fe1-9588-9b67f01c9ad6	\N	anonymous	\N	GET	/api/dashboard/enrollment	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:19:38.989672
288	a16c3740-8be7-49b9-8bb9-7ce4b469a000	\N	anonymous	\N	GET	/api/dashboard/enrollment-trend	{"studyId":"1","days":"30"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	5	2025-12-04 14:19:38.999903
289	46b5b378-2e7b-4680-829b-ff05cc34a726	\N	anonymous	\N	GET	/api/dashboard/enrollment	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	12	2025-12-04 14:19:40.939933
290	23c8a791-08b2-4e08-b23a-85d6605929d1	\N	anonymous	\N	GET	/api/dashboard/completion	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	15	2025-12-04 14:19:40.944745
291	3644bb21-9fdf-4e96-91e2-5934a48e3824	\N	anonymous	\N	GET	/api/dashboard/queries	{"studyId":"1","timeframe":"month"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	15	2025-12-04 14:19:40.947882
292	2ac44198-7e9a-4afa-93c6-e8e475a13650	\N	anonymous	\N	GET	/api/dashboard/activity	{"studyId":"1","days":"30"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	30	2025-12-04 14:19:40.964725
294	452de1ab-d579-4290-bae6-9e7276160b11	\N	anonymous	\N	GET	/api/dashboard/enrollment	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	9	2025-12-04 14:19:40.988724
295	77afb0f6-185e-4cec-9a5a-1ca38f7a2881	\N	anonymous	\N	GET	/api/dashboard/enrollment-trend	{"studyId":"1","days":"30"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	4	2025-12-04 14:19:40.998542
293	d6589414-17c4-44cf-ade3-9a66a48c9b95	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	9	2025-12-04 14:19:40.976608
296	ae4cdd28-da00-4e9b-8a30-9473953a0af4	\N	anonymous	\N	GET	/api/workflows/user/root/summary	{}	{}	500	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	12	2025-12-04 14:19:42.322849
297	0552c61f-9d34-42f1-a4d3-2788b01e106b	\N	anonymous	\N	GET	/api/workflows/user/root	{}	{}	500	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:19:42.337024
299	981ef85e-edfa-4b5d-8d4b-14a463310b0a	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	24	2025-12-04 14:19:42.867984
300	3cb850e6-cb34-47d0-a0c0-8febe8c97263	\N	anonymous	\N	GET	/api/subjects/NaN	{}	{}	400	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	3	2025-12-04 14:19:53.255967
298	b4a033ca-617e-4339-915d-39c2e89098ad	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	10	2025-12-04 14:19:42.856696
301	7b852d6e-6545-4431-a8b7-397525f1f2a3	\N	anonymous	\N	GET	/api/subjects//progress	{}	{}	400	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	3	2025-12-04 14:19:53.262749
302	8c908ae4-fec1-40fd-8a1d-5ac32da5ba9a	\N	anonymous	\N	GET	/api/subjects//events	{}	{}	400	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	4	2025-12-04 14:19:53.282877
303	ca9ff670-4409-4bdb-9325-2990d0de7817	\N	anonymous	\N	GET	/api/subjects//forms	{}	{}	400	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	3	2025-12-04 14:19:53.28334
304	9d739471-aaf4-4cfc-846a-e9c5de65c4a9	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	16	2025-12-04 14:20:00.887568
305	f68be745-ca07-445c-a403-962a8151ef0d	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"5"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	30	2025-12-04 14:20:00.916405
306	fe5ad1b4-e311-4aa2-ad3f-a347e4141f37	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	39	2025-12-04 14:23:57.541777
307	63ac0089-e5ea-48f3-b1b8-501c5128fbe7	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	29	2025-12-04 14:23:57.863045
308	fb2ec293-d0eb-4e27-8e3a-eddb24bae932	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	48	2025-12-04 14:23:57.863242
309	ff09e103-f95f-4446-bd9e-6dff5f44a662	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	36	2025-12-04 14:23:57.863437
310	ce0155eb-654c-444b-bd5c-2229f0629b10	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	32	2025-12-04 14:23:57.863634
311	633493fe-6b31-4059-b488-74c492fb82a5	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	572	2025-12-04 14:23:58.281583
312	b8fa2174-352e-4730-956a-35e22af08ae7	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:23:58.731936
313	7e3c6055-4cc9-4853-b374-b86a4f67e072	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	430	2025-12-04 14:23:58.732151
314	22b5a00e-3cbc-445b-b967-d7428d48b18f	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	13	2025-12-04 14:24:04.659048
315	d757316d-5ac7-4278-b3d5-fd27d88a18f4	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	13	2025-12-04 14:24:04.671126
316	fff9b9ba-d5b8-4fae-bfd9-9049ae11d993	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	41	2025-12-04 14:24:04.690976
317	6cae6455-fbc2-43a5-9928-e9f12f4e817c	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	18	2025-12-04 14:24:04.697627
318	25a94b7e-56fa-4444-ab19-939e866eb449	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	10	2025-12-04 14:24:04.716148
319	c45c9663-6842-44c8-86f5-5911ce913b39	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 14:24:04.723671
320	eb503283-2428-4349-a528-ba306f03716a	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	35	2025-12-04 14:24:04.724387
321	dfd466b4-0b40-4189-a048-59cb07fc57cc	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 14:24:04.766269
322	4ef1127f-e93d-42fd-b7f3-27f7b2d5f699	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	15	2025-12-04 14:24:14.509886
323	d7b01c45-2905-4ca7-b166-42e8377c76ce	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	22	2025-12-04 14:24:14.533088
324	8533cdd8-7d1e-483f-b0ae-6ff637e1aac9	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	23	2025-12-04 14:24:14.533787
325	46256906-9222-4012-896f-afe81cea99e4	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	13	2025-12-04 14:24:14.536964
326	99884211-fd84-4548-92a4-8ef99ae5a2ec	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	52	2025-12-04 14:24:14.540625
327	e01692bf-0780-4a1a-a69b-a4d94199ba84	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	17	2025-12-04 14:24:14.549729
328	51cdefe1-4734-4c9d-8db9-f3267d8f9e4b	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	51	2025-12-04 14:24:14.593194
329	975b38fa-e1bd-4a29-a8b8-658bf5f5028c	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 14:24:14.621512
330	cab5f0db-1dc9-41d9-b684-17a2c58b6938	\N	anonymous	\N	GET	/api/subjects/1/events	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 14:24:17.213109
336	64c3b743-167d-40ee-8610-17203130de53	\N	anonymous	\N	GET	/api/subjects/1/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 14:24:18.749245
338	6a9c0d5e-b5ec-4be8-a90d-a84cce164400	\N	anonymous	\N	GET	/api/api/events/study/1	{}	{}	404	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	4	2025-12-04 14:24:18.76979
342	ffd07ef2-4ce2-4765-a8d9-14bfa38ef49e	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	12	2025-12-04 14:24:22.642962
350	6fccc1e0-286a-4cb7-a409-e5aae310f104	\N	anonymous	\N	GET	/api/subjects/2/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 14:24:24.213617
353	0e061590-0d56-47d4-84ac-440fba0d7dec	\N	anonymous	\N	GET	/api/workflows/user/root	{}	{}	500	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:24:30.241689
354	4867567e-a772-49aa-839e-581ea846c452	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	18	2025-12-04 14:24:31.589724
356	20d09433-35ac-4512-91b3-7ef3ae907eb7	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 14:24:40.696918
357	9861207a-7bef-4037-a08c-af72d5582e78	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	23	2025-12-04 14:24:40.708307
361	d1155be1-703f-4ce2-956c-6f537eff7107	\N	anonymous	\N	GET	/api/introspection/table/discrepancy_note	{}	{}	404	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	3	2025-12-04 14:24:53.028199
331	ec2a7113-6c9d-4312-aa36-a9a918888c02	\N	anonymous	\N	GET	/api/subjects/1/progress	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	10	2025-12-04 14:24:17.215481
334	0208922d-6fda-47a0-b3ec-639fbd61e320	\N	anonymous	\N	GET	/api/subjects/1/events	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	5	2025-12-04 14:24:18.744206
341	08958f71-72d7-4e69-b009-a6608a94ebab	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	20	2025-12-04 14:24:22.642741
332	eb3fceb5-a416-4f4c-83a9-e5c981302586	\N	anonymous	\N	GET	/api/subjects/1/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:24:17.217401
335	69f420a0-0e7b-407c-a48a-1b5cfc7d53fd	\N	anonymous	\N	GET	/api/subjects/1/progress	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 14:24:18.744562
343	be9168db-08c1-4389-9d9f-330ebb619b80	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	21	2025-12-04 14:24:22.649701
348	cd8b0eb8-5f26-4325-89d6-0b2db662332e	\N	anonymous	\N	GET	/api/subjects/2/events	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	5	2025-12-04 14:24:24.21042
355	18b89001-f68c-4603-94ea-a9adf0db1c92	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 14:24:31.596473
358	e3b97a08-695b-4602-aa86-6e9adff53a53	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 14:24:40.974302
359	39d71958-6817-4668-9e13-9ca2c78a8d86	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	37	2025-12-04 14:24:41.002169
360	5602fb80-9d83-4f92-b1e0-909eb69ff332	\N	anonymous	\N	POST	/api/auth/login	{}	{"username":"root","password":"***REDACTED***"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	15	2025-12-04 14:24:53.027117
333	604dd018-48a0-4559-b748-a07d5fa76761	\N	anonymous	\N	GET	/api/subjects/1	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	17	2025-12-04 14:24:17.218091
337	a18921f1-9221-4506-9d35-bc1050445310	\N	anonymous	\N	GET	/api/subjects/1	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	17	2025-12-04 14:24:18.749901
339	6766115e-5da7-429c-98f4-d77b676fb24d	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 14:24:18.770431
340	9277278f-a374-4ea5-a6ad-8d04392ddb72	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	16	2025-12-04 14:24:22.632835
344	f851a052-fa9c-43c4-88d3-9d589a253072	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	42	2025-12-04 14:24:22.660455
349	cb003814-061c-4f84-abcf-f97ba1ed7a65	\N	anonymous	\N	GET	/api/subjects/2/progress	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 14:24:24.213157
352	f1ff22a2-30ad-4a83-afbf-98bf198c653b	\N	anonymous	\N	GET	/api/workflows/user/root/summary	{}	{}	500	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 14:24:30.23046
345	c844d9f3-aabc-4c7b-930a-7776411e9c3b	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	15	2025-12-04 14:24:22.660726
346	f191efdc-65f1-4464-ac42-7cb1a1799d7a	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	25	2025-12-04 14:24:22.684478
347	f37a441f-cedd-4caa-adb9-b72893e8a222	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	5	2025-12-04 14:24:22.695417
351	25c019c6-de0d-4189-b58f-724a60b629ec	\N	anonymous	\N	GET	/api/subjects/2	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	16	2025-12-04 14:24:24.21661
362	ffa682b0-d980-4fe5-8201-7507b9e7d205	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	26	2025-12-04 14:38:34.357038
363	929af972-f380-46cc-8a33-70bdae936f54	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	54	2025-12-04 14:38:34.370917
364	d3a4bf95-482a-4116-bd92-e819feae7c7e	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	43	2025-12-04 14:38:34.375574
365	f16d523d-5416-4954-aab3-a465b80d591e	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	17	2025-12-04 14:38:34.385328
366	75107d93-f481-46b3-bb37-9d7a70007a0e	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	18	2025-12-04 14:38:34.392637
367	7d511726-5928-42b7-839c-afe06b96466d	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	101	2025-12-04 14:38:34.42255
368	17ad800c-b2bf-479f-9ed9-110952d3ab3b	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	21	2025-12-04 14:38:34.441938
369	387f015d-0cb7-4e25-b6ea-87a18849a727	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:38:34.458522
370	01797629-7a7a-4f56-8de3-f0a95a945d59	\N	anonymous	\N	GET	/api/workflows/user/root/summary	{}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	3	2025-12-04 14:40:01.703313
371	8b503a27-0a8f-434b-bec7-6aad936ca267	\N	anonymous	\N	POST	/api/auth/refresh	{}	{"refreshToken":"***REDACTED***"}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	24	2025-12-04 14:40:01.719844
372	6d2cc753-0789-477d-b71e-b6320dcecfb7	\N	anonymous	\N	GET	/api/workflows/user/root/summary	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	18	2025-12-04 14:40:01.740679
373	faa4f436-aa41-4c7c-b7f5-28962ab105f2	\N	anonymous	\N	GET	/api/workflows/user/root	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	5	2025-12-04 14:40:01.75022
374	68701543-87a4-4c77-9b3a-154c64510351	\N	anonymous	\N	GET	/api/users	{"page":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 14:40:07.047244
375	f9f4f868-00a6-4b8d-aa0a-f72903ee12c1	\N	anonymous	\N	GET	/api/workflows	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	10	2025-12-04 14:40:07.065703
376	8711ba89-0121-400e-ad4e-7e31ab596288	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:40:10.176295
377	49b28cda-0c2c-4b8c-b542-eef456f92324	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	29	2025-12-04 14:41:24.945447
378	89c15961-41ac-4822-a3d2-1ad623e742b0	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	47	2025-12-04 14:41:24.951828
379	701dd9ed-b007-4830-b8b9-84ff135d3434	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	47	2025-12-04 14:41:24.959332
380	fcaf5e84-bd0c-496a-bfe0-aa03f4203c5f	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	16	2025-12-04 14:41:24.973943
381	2a944ba8-e517-4105-a09b-aec41aa4f5e6	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	29	2025-12-04 14:41:24.979142
382	035f63e9-7007-47b3-bb12-261331921b1c	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	115	2025-12-04 14:41:25.022316
383	a756f0b3-8dfb-4d12-93bc-4ed568f83f9f	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	23	2025-12-04 14:41:25.043902
384	607d4e61-03db-464b-8e10-f21e172de8e0	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 14:41:25.059274
385	baa62dd5-8d13-44a1-af36-1cbe6f76a1ad	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	14	2025-12-04 14:41:36.894127
386	40a9503e-d084-43bc-ba90-df8cb9919d15	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	14	2025-12-04 14:41:36.909026
387	d2fc3e70-6d28-4748-95fc-bee4a677e5cd	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	15	2025-12-04 14:41:36.92112
388	6c1f903d-5b12-45c1-8145-07d8a33412da	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	13	2025-12-04 14:41:36.943058
395	a866025b-a194-41bf-ad66-48d43e4283fd	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	13	2025-12-04 14:41:42.622855
389	8f0ce71e-286c-4a39-be32-4cbac96bb31f	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	9	2025-12-04 14:41:36.950718
390	feaeacc8-e00c-4d1b-ac96-c4acbd77e24a	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	98	2025-12-04 14:41:36.983452
391	3b9ec2a6-1f14-4f41-a3b6-275e13bcfff3	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	29	2025-12-04 14:41:37.009465
392	bc085eea-e163-428b-a6a1-fbf6910a6972	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:41:37.022413
393	31731405-e8b1-4d13-b52c-9acef0c8158f	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	22	2025-12-04 14:41:42.610756
397	d924e21f-2fab-43b2-bda8-9f64b271c660	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	20	2025-12-04 14:41:42.640679
398	f12ef1a4-e327-4cbc-b341-1ebeadaf3afb	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	92	2025-12-04 14:41:42.68187
399	5ebef8d6-2501-4854-9595-44a2dbe7c155	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	27	2025-12-04 14:41:42.707077
400	3b8db99a-87dd-4b32-be5a-5097c9cbf3b1	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 14:41:42.720961
401	d90c96e6-b888-4d69-ba66-e8fdfd720152	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	15	2025-12-04 14:41:53.531986
403	6efd6783-15b9-4283-a0bb-a6bd7003ca1b	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	13	2025-12-04 14:41:53.564141
405	f5aaa280-ce38-4617-99c5-143779a75d7d	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	5	2025-12-04 14:41:53.580931
406	0607498f-b66d-4b33-a0de-8b4f4736a547	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	93	2025-12-04 14:41:53.616474
407	4d08800c-5dbb-4f4c-86f9-5881b6344183	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	27	2025-12-04 14:41:53.641574
408	ed41c6db-4f0f-4107-b55b-340f0795e802	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:41:53.653844
394	daeb0d7c-6a16-4bd4-8b88-d54207fba079	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	24	2025-12-04 14:41:42.622407
396	d5518c3d-e6a3-49dc-aa70-e919d0d886c4	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	22	2025-12-04 14:41:42.630183
402	16a81546-1556-4584-b277-f46ef9c8f462	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	14	2025-12-04 14:41:53.543186
404	55855a66-b62f-403e-a7df-cb05b8ec6b49	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	13	2025-12-04 14:41:53.577465
409	84961c01-d50a-476b-987d-26dc56c17298	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	24	2025-12-04 14:47:12.001045
410	82e35099-3db9-4482-82e4-03e4789fe03d	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	37	2025-12-04 14:47:12.01385
411	ed88449f-492b-4a2b-a902-452e1dcb5654	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	47	2025-12-04 14:47:12.017204
412	c1cd2ec5-865e-445b-a4b8-34e54342bcf0	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	16	2025-12-04 14:47:12.028408
413	7c302ddc-7e82-4840-bf97-7727b7a1ab7b	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	17	2025-12-04 14:47:12.03387
414	0e36295c-0a85-4302-90bf-ab07cbcdec09	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	95	2025-12-04 14:47:12.066952
415	a131d1de-daec-4f6f-8ea0-7f325fe21c32	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	26	2025-12-04 14:47:12.092934
416	61e10c24-efd0-4b2b-8398-a4b0fbe29b28	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 14:47:12.103567
417	898936ab-034f-4fb2-9be8-d7c6b6e13200	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	31	2025-12-04 14:48:48.328378
418	737c6428-4785-4397-b22b-b4b1cfca5711	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	85	2025-12-04 14:48:48.378889
419	a0be62c8-cfdd-4ac8-8fb1-11b941541ee1	\N	anonymous	\N	GET	/api/subjects/2	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	29	2025-12-04 14:49:39.580378
420	e35d1fc0-793f-4ed1-b73c-c6de8218f479	\N	anonymous	\N	GET	/api/subjects/2/progress	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	23	2025-12-04 14:49:39.604129
421	234f0820-beff-45cc-91d9-ebef8745e4d6	\N	anonymous	\N	GET	/api/subjects/2/events	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	5	2025-12-04 14:49:39.611091
422	991333cc-c1ad-43b7-8962-5d948152cf25	\N	anonymous	\N	GET	/api/subjects/2/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	21	2025-12-04 14:49:39.631124
423	6c1f7cf0-1390-44e1-a457-5c03c1b304ae	\N	anonymous	\N	GET	/api/subjects/1/progress	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	9	2025-12-04 14:49:40.606191
424	beee8ddf-8161-4897-90ea-63b144247dfd	\N	anonymous	\N	GET	/api/subjects/1/events	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 14:49:40.606681
425	a46b8abf-8010-4ba2-bd99-eac2a633fad8	\N	anonymous	\N	GET	/api/subjects/1	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	20	2025-12-04 14:49:40.613121
426	94759771-ed84-4242-be77-8d05147b5403	\N	anonymous	\N	GET	/api/subjects/1/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	32	2025-12-04 14:49:40.633689
427	ff9e9128-7350-4a06-a550-fe2bc1b20301	\N	anonymous	\N	GET	/api/workflows/user/root/summary	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	25	2025-12-04 14:50:15.375608
428	529b223b-e076-49f0-9212-6b8a8dc476b0	\N	anonymous	\N	GET	/api/workflows/user/root	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	4	2025-12-04 14:50:15.384314
429	bebd1af6-bc55-4efc-8528-569b2a595ba0	\N	anonymous	\N	GET	/api/users	{"page":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:50:15.942167
430	4bea647b-324f-4cf2-a026-bfd98067d695	\N	anonymous	\N	GET	/api/workflows	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 14:50:15.954912
431	eba356fa-1d76-47ef-b5d4-60dad26db219	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 14:50:16.555094
432	06318a94-7120-4bdd-a222-ec811dd7a3d2	\N	anonymous	\N	GET	/api/dashboard/enrollment	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	32	2025-12-04 14:55:48.627983
433	a9f0dc5d-3963-4c70-ac85-56084b9ec2f0	\N	anonymous	\N	GET	/api/dashboard/activity	{"studyId":"1","days":"30"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	27	2025-12-04 14:55:48.632949
434	afa26ef5-04a6-4807-8392-ac5664f41366	\N	anonymous	\N	GET	/api/dashboard/queries	{"studyId":"1","timeframe":"month"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	32	2025-12-04 14:55:48.634908
435	0e074a65-300d-4e31-805f-9d9b57ee2327	\N	anonymous	\N	GET	/api/dashboard/completion	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	37	2025-12-04 14:55:48.638503
436	3bb744a8-3b87-4e14-8675-876fbd1fcad2	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 14:55:48.653081
441	0df07cce-50b2-459a-b8fb-bd3ff5c23f69	\N	anonymous	\N	GET	/api/dashboard/completion	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	17	2025-12-04 14:55:52.823448
443	0e435af7-0952-40bc-9d71-44c3c3e75dd4	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	9	2025-12-04 14:55:52.839841
445	aefde7aa-e00a-4e25-be3f-c5baa91a2e7c	\N	anonymous	\N	GET	/api/dashboard/enrollment-trend	{"studyId":"1","days":"30"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	4	2025-12-04 14:55:52.85494
437	9c204ec5-5789-4f11-ad31-22bd13bad1aa	\N	anonymous	\N	GET	/api/dashboard/enrollment	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:55:48.662949
438	ed7fa074-768c-4334-8252-3817f99a8ca6	\N	anonymous	\N	GET	/api/dashboard/enrollment-trend	{"studyId":"1","days":"30"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	4	2025-12-04 14:55:48.672506
439	743220bf-c3f4-4fe3-8999-b64272d05d4d	\N	anonymous	\N	GET	/api/dashboard/enrollment	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	13	2025-12-04 14:55:52.817542
440	157d16f2-b6d7-4cc5-9669-88cec03bbfc2	\N	anonymous	\N	GET	/api/dashboard/queries	{"studyId":"1","timeframe":"month"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	12	2025-12-04 14:55:52.822954
442	baa6692d-12a6-4ec9-9320-9073481f6d00	\N	anonymous	\N	GET	/api/dashboard/activity	{"studyId":"1","days":"30"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	16	2025-12-04 14:55:52.827167
444	1e8d67ee-d334-42c3-aa19-13e35c5bb1ef	\N	anonymous	\N	GET	/api/dashboard/enrollment	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	5	2025-12-04 14:55:52.847835
446	88ca4f1c-d0ab-444a-a391-bc5d3ec24292	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	23	2025-12-04 14:57:22.375378
447	0d858fb7-641a-466d-949d-ce44764567a4	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	38	2025-12-04 14:57:22.385883
448	ca6d5d1f-43e9-4eec-9169-a50bdf34b8de	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	34	2025-12-04 14:57:22.389794
449	a13e4b0f-98d8-4df8-8521-c1948730c88b	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	16	2025-12-04 14:57:22.399238
450	50068601-14d2-43e9-a4dd-458f5a4c12bd	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	20	2025-12-04 14:57:22.408655
451	c922215e-2293-4fd7-bbb1-d74fcc7ad2ee	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	108	2025-12-04 14:57:22.455656
452	4cc2425a-13e3-4eb2-9c78-da997f7114e4	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	21	2025-12-04 14:57:22.476247
453	68100652-b264-47da-801e-eff07c58ee02	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:57:22.48896
454	5b792373-7837-477a-aae3-8e33e20fb639	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	37	2025-12-04 14:58:45.33315
455	f9bffbc2-ac7e-4929-a715-6b4d9e61c748	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	25	2025-12-04 14:58:45.370293
456	2c62eddf-8c74-4c88-9348-444d233a457e	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	14	2025-12-04 14:58:45.374986
457	7e755867-2f10-4d4d-a566-8242cab763cb	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	24	2025-12-04 14:58:45.394137
458	1d9e6127-7df3-4799-9ce1-c98869616c49	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	31	2025-12-04 14:58:45.405655
459	0180f40a-e123-4054-8ea0-81e1cdd8b8d7	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	107	2025-12-04 14:58:45.410467
460	adbdc484-a299-4c34-84d3-3c3e129fac2f	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	27	2025-12-04 14:58:45.435798
461	d0117196-2189-4942-88b0-1fdb27b893e9	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 14:58:45.449303
462	eccf0ebd-a869-461e-8fef-4db3156a36f6	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	5	2025-12-04 14:58:52.014878
463	9f5c56b2-f7f1-4fe4-852c-87c3ab08de89	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	23	2025-12-04 15:00:29.832084
464	ee141709-94ba-41f4-82eb-13c759c1b608	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	37	2025-12-04 15:00:29.846424
465	51eae54d-1a94-4bef-aed4-74e6bd225418	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	45	2025-12-04 15:00:29.850482
466	cc3bda44-fb33-4550-97ab-b2cf2e8382b6	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	17	2025-12-04 15:00:29.861087
467	8ba9bb29-4fd9-47de-8541-c043482db054	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	22	2025-12-04 15:00:29.871996
468	88497f68-f30e-4854-a9a8-66cdc957da53	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	100	2025-12-04 15:00:29.902376
469	23e8e704-ce14-4ccb-91a5-575c2f59cf57	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	25	2025-12-04 15:00:29.925965
470	3296c953-5037-4d2f-9b89-03c8f1e9fbea	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 15:00:29.937256
471	71c6f544-0373-42fe-b793-a341a634b74a	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 15:00:31.116221
472	f95420f4-39d7-4c6d-bc03-957a2c700d12	\N	anonymous	\N	GET	/api/forms/10	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	18	2025-12-04 15:01:46.291936
473	6b341aa7-e2ea-4124-ab41-da1e0811b8f0	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	14	2025-12-04 15:01:54.183816
474	6badb76d-21b4-4403-b002-9f36b47bcd72	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	96	2025-12-04 15:01:54.281423
476	cf1aebd6-3d81-4d0c-8ec5-466cb4a5e1a6	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	13	2025-12-04 15:01:54.303949
477	0cb2d676-5634-49d2-9ae6-2e3730932a2c	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	23	2025-12-04 15:01:54.329826
479	61610d57-427b-41ef-901e-f2757d2df76d	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	5	2025-12-04 15:01:54.34366
480	f6715a54-994f-4894-95be-54d859822c22	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	5	2025-12-04 15:01:54.357554
481	224cf396-f6f7-4aea-b4fc-913f7a83f64f	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	4	2025-12-04 15:02:03.68837
475	089cf9ce-bfbd-4724-b036-8633f244a93a	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 15:01:54.287065
478	ead2fdfe-1aef-4f0a-be21-55d430c735e7	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 15:01:54.337806
482	542d3674-faf2-4b90-8616-3a3e78bf2d0a	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	27	2025-12-04 15:06:45.985184
483	97050434-573a-4c24-b634-94d5aeefc760	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	48	2025-12-04 15:06:45.999983
484	507c4ed3-a773-4057-81a2-421c81c8dd41	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	42	2025-12-04 15:06:46.003887
485	fe5cc1e6-f333-46a9-84a9-8d3f33f029d1	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	19	2025-12-04 15:06:46.015289
486	c678ee46-c906-47c9-afe1-633bd5a5826a	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	19	2025-12-04 15:06:46.021767
487	bc2cb2aa-a413-421c-b565-d7d52bafc5cf	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	111	2025-12-04 15:06:46.063755
488	c52410b3-7508-47b6-a685-2214ab113337	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	23	2025-12-04 15:06:46.084319
489	2d6e2bef-704b-460e-a800-2003a99af675	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 15:06:46.097171
490	b1ecd2c1-8f33-4619-b9fd-77a3c29c0960	\N	anonymous	\N	GET	/api/studies	{}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	3	2025-12-04 15:10:57.951627
491	fef7a3e5-71a1-4191-a37f-f14fd13da694	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	3	2025-12-04 15:10:57.951941
492	d20d37eb-f935-4ce9-b707-f6151651f735	\N	anonymous	\N	GET	/api/studies	{}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:10:57.954581
493	4dc980ea-6a84-446d-8327-d1f6bc9a0519	\N	anonymous	\N	GET	/api/forms	{}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:10:57.95483
494	6bd929e1-b24b-4a57-83da-6ba55e52be83	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:10:57.955273
495	56b864a9-8d8a-4ae0-b297-9e798040dd27	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:10:57.962504
496	6de90774-4b88-4492-bd42-7f130747606c	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:10:57.962674
498	82e62026-10b3-49cd-99b7-7cc0a735e191	\N	anonymous	\N	POST	/api/auth/refresh	{}	{"refreshToken":"***REDACTED***"}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:10:57.973686
497	868d50af-b015-4af6-9e38-5a2ce3c0ba93	\N	anonymous	\N	POST	/api/auth/refresh	{}	{"refreshToken":"***REDACTED***"}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:10:57.976976
500	f2b0b21c-79d8-4e54-959c-1be26cae9540	\N	anonymous	\N	POST	/api/auth/refresh	{}	{"refreshToken":"***REDACTED***"}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	58	2025-12-04 15:10:57.984688
499	3376a1e4-b62d-4289-a395-716a78da18fe	\N	anonymous	\N	POST	/api/auth/refresh	{}	{"refreshToken":"***REDACTED***"}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	56	2025-12-04 15:10:57.984538
501	b1c876cc-e219-4053-9ece-69d19d185ee1	\N	anonymous	\N	POST	/api/auth/logout	{}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:10:57.98518
502	f04baffd-458c-46d4-9b42-0c03ac89a3e0	\N	anonymous	\N	POST	/api/auth/refresh	{}	{"refreshToken":"***REDACTED***"}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	63	2025-12-04 15:10:57.990249
503	26d7286b-9823-4c0c-a461-ef9d789ddc49	\N	anonymous	\N	POST	/api/auth/refresh	{}	{"refreshToken":"***REDACTED***"}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	64	2025-12-04 15:10:57.99042
504	68338cb3-a59f-4a12-aca4-5c3c3398b214	\N	anonymous	\N	POST	/api/auth/refresh	{}	{"refreshToken":"***REDACTED***"}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	68	2025-12-04 15:10:57.997335
505	92958fd9-a151-49f3-8932-8e9dbe65b511	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	26	2025-12-04 15:10:58.001855
506	348d6b60-a9c8-4f1e-89b9-7210d95a7f17	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	18	2025-12-04 15:10:58.014405
507	d956a87f-a12d-4796-9b00-2bf1ddf09ab4	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	91	2025-12-04 15:10:58.08404
508	45711b68-5109-4150-9a87-d19f0ca5946f	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 15:10:58.09824
509	e4daba19-5ed2-4398-9316-5c6fb65fc0a8	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	18	2025-12-04 15:11:16.603001
510	ed4693cb-17dc-4b66-b099-bc4589b75c23	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 15:11:16.603284
511	b91c8ad0-1bff-4d8c-9493-17eab67c208f	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	20	2025-12-04 15:11:16.610198
512	3708f95c-92c4-4b75-b781-346e7f128918	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 15:11:16.61649
518	feeda9ad-f0c4-4fbf-8ebe-57e9ceb325cd	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 15:11:37.205034
520	f5bd446f-0931-48c6-89bc-ee5bb244c6b8	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 15:11:37.22938
513	48d1a62b-da2b-46d1-8497-d461ebd48a20	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	20	2025-12-04 15:11:16.619612
514	55abcaa9-a5c1-4f10-9935-a9463948d67c	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	105	2025-12-04 15:11:16.689753
515	3ece79ca-6ad6-4d26-aab2-19a02da24ff0	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	21	2025-12-04 15:11:16.709842
516	c19d0af1-5463-4d4a-9ddd-e5c3a708bcf7	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 15:11:16.721915
517	646deffc-0cf5-42b3-853c-57e1c6370b91	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	12	2025-12-04 15:11:37.191801
519	0d26bc5b-794c-43f7-a061-e7ab5e2b3879	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 15:11:37.212816
521	3829345f-f9df-4fe1-987c-b1b0100da8fe	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 15:11:37.235636
522	d62fed90-a003-4332-ba12-90805bb77c28	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	98	2025-12-04 15:11:37.281842
523	debcacc8-4325-4282-b95f-f741b6adc8eb	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	22	2025-12-04 15:11:37.30331
524	2941695b-db54-4811-998d-ac1f15be7953	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	5	2025-12-04 15:11:37.312686
525	9408d8a9-bb1b-4e9a-a9d6-c7d4bf056f7c	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	24	2025-12-04 15:16:28.604279
526	f873918b-56f6-4e35-be52-aca886dffc9b	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	35	2025-12-04 15:16:28.615143
527	abefb9ee-f501-43b2-bd35-85dc5e06bec5	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	29	2025-12-04 15:16:28.618741
528	b855735c-d12d-4ecb-811c-d3beaa61b218	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	16	2025-12-04 15:16:28.629617
529	494501d3-1cfa-4d41-8bbb-675f3d952891	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	17	2025-12-04 15:16:28.635224
530	37e81fce-8350-4f80-bf26-5fb31851336c	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	102	2025-12-04 15:16:28.685049
531	73ab0b08-e3cc-44d6-a006-b2cb6da4122d	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	21	2025-12-04 15:16:28.704886
532	3e28b471-a752-4560-8160-2794bffa4718	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 15:16:28.716631
533	4cc9dca7-5c52-44c1-9eba-3b8bc42353e4	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	22	2025-12-04 15:30:12.151781
534	42089060-e682-4298-b654-f6d601be624d	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	35	2025-12-04 15:30:12.161685
535	13680296-78ba-41f1-9758-0e52fffa7a36	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	35	2025-12-04 15:30:12.161764
536	35c31edc-5e34-46d7-8a17-6192563aa78d	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	21	2025-12-04 15:30:12.17583
537	880fd273-915d-4bb4-8085-8128cca008bd	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	32	2025-12-04 15:30:12.192939
538	e4c0dd3a-c988-4e27-b21c-3b55ddb23959	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	107	2025-12-04 15:30:12.229622
539	3cd211b9-66f1-4184-bf79-02910202cb03	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	20	2025-12-04 15:30:12.248425
540	6509ee97-f54e-4acf-b0d7-42f0389f08f5	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 15:30:12.263648
541	acc10b67-fe0c-4d10-aff7-01b07d1b1bac	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 15:30:16.080209
542	736909b1-24e2-402d-b5da-22d6f9600c83	\N	anonymous	\N	GET	/api/queries	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	14	2025-12-04 15:30:16.962517
543	5cf132b9-9369-4786-b299-842665d073aa	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	9	2025-12-04 15:30:18.77259
544	0c053d8c-a12d-4296-909a-b082827a4a7c	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	32	2025-12-04 15:30:18.79187
545	381d11e3-9967-4373-9074-a9e74f468054	\N	anonymous	\N	GET	/api/workflows/user/root/summary	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 15:30:20.306892
547	055107c5-fe08-4891-99bc-eaca399d997c	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	9	2025-12-04 15:30:21.102958
548	d3c092af-c136-4a5e-96de-ae6330f3bd55	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	26	2025-12-04 15:30:21.117012
549	77f84d7a-50a4-4a74-950b-22dce117c443	\N	anonymous	\N	GET	/api/sdv	{"studyId":"1","limit":"1000"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 15:30:23.768149
546	932a69d2-d2c7-447d-bec5-6d8fa7549fb3	\N	anonymous	\N	GET	/api/workflows/user/root	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	5	2025-12-04 15:30:20.316472
550	b6504171-151b-4cb3-b0dd-44d0172d1932	\N	anonymous	\N	GET	/api/sdv	{"studyId":"1","limit":"1000"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 15:30:23.779195
551	99beb790-f07f-49f9-b495-3528719060f3	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 15:30:26.102098
552	80657b5d-32b3-43c9-b1b2-b8c9e20628b1	\N	anonymous	\N	GET	/api/studies/1/sites	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	4	2025-12-04 15:30:26.113221
553	03722b33-b590-424c-aa8d-69d9c33ff76c	\N	anonymous	\N	GET	/api/monitoring/stats	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	3	2025-12-04 15:30:26.120672
554	013a9939-1484-4f80-a468-5d6958b6c634	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	79	2025-12-04 15:30:26.205894
555	01e9045b-69bc-47bd-9d9c-3a08444ed409	\N	anonymous	\N	GET	/api/forms/3	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	16	2025-12-04 15:31:04.325664
556	8ff70a39-754d-4916-be30-54652e0f4a66	\N	anonymous	\N	GET	/api/dashboard/enrollment	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	10	2025-12-04 15:31:30.295706
557	c394c311-1732-4040-8bbc-ed6b72254f89	\N	anonymous	\N	GET	/api/dashboard/completion	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	26	2025-12-04 15:31:30.32312
558	f9f5974a-27b4-42ac-ac64-8219ced291b2	\N	anonymous	\N	GET	/api/dashboard/queries	{"studyId":"1","timeframe":"month"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 15:31:30.334205
559	b8b79f27-5f73-4a54-b74c-39a9d3179028	\N	anonymous	\N	GET	/api/dashboard/activity	{"studyId":"1","days":"30"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 15:31:30.344255
560	1f3259ca-8a95-4fff-8c17-2dd691be84e9	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 15:31:30.359719
561	2ee92538-445d-4a76-9de0-cbf5ef3109c8	\N	anonymous	\N	GET	/api/dashboard/enrollment	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	5	2025-12-04 15:31:30.367307
562	ce4dbd16-6367-413d-93c6-026d1c1a26e3	\N	anonymous	\N	GET	/api/dashboard/enrollment-trend	{"studyId":"1","days":"30"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	4	2025-12-04 15:31:30.376191
563	d00df9cf-80eb-473e-87a6-8167bb7d641e	\N	anonymous	\N	GET	/api/dashboard/data-quality	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 15:31:30.388746
564	23079d3f-caa7-4435-814b-2b81ba5b6fff	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	29	2025-12-04 15:32:07.693794
565	244e97f5-4521-432e-b0f7-5f90d9d53667	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	168	2025-12-04 15:32:07.828619
566	fdb2f7e6-76d4-4851-b86e-ba1212ae8320	\N	anonymous	\N	GET	/api/workflows/user/root/summary	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 15:32:08.622103
567	9a3a6cba-dd42-4a8d-8d31-adc8eb956f3f	\N	anonymous	\N	GET	/api/workflows/user/root	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	4	2025-12-04 15:32:08.631217
568	4bc656c6-96bc-493a-b9de-4b55ed35582c	\N	anonymous	\N	GET	/api/queries	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 15:32:09.35755
569	e58ea00c-a204-4d86-b9e2-ee736b86676a	\N	anonymous	\N	GET	/api/workflows/user/root/summary	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	9	2025-12-04 15:32:09.867651
570	cd077fc5-af22-46d2-8297-5d93f6ca35e1	\N	anonymous	\N	GET	/api/workflows/user/root	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	12	2025-12-04 15:32:09.88412
571	fa29881b-0bec-4f49-89a6-cdf2568fa59c	\N	anonymous	\N	PUT	/api/workflows/2/status	{}	{"status":"in_progress"}	500	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	10	2025-12-04 15:32:11.048141
572	a2f7bed5-9de9-4ae8-9854-12b5870b2353	\N	anonymous	\N	GET	/api/workflows/user/root/summary	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 15:32:11.060235
573	7ebdc247-3b9e-444e-a133-542139515397	\N	anonymous	\N	GET	/api/workflows/user/root	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	22	2025-12-04 15:32:11.085691
574	2a555cc4-0a12-4641-a073-2ed03b264a9d	\N	anonymous	\N	GET	/api/sdv	{"studyId":"1","limit":"1000"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	24	2025-12-04 15:33:00.843883
575	5c03198b-94d0-42f3-8643-236512bffa8e	\N	anonymous	\N	GET	/api/studies/1/sites	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	16	2025-12-04 15:33:01.40456
576	08f1116e-3e2f-456d-879c-c6592ed7020b	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	26	2025-12-04 15:33:01.404761
577	8a83f9ef-5d97-4b5a-abff-c0af8128b438	\N	anonymous	\N	GET	/api/sdv	{"studyId":"1","limit":"1000"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	23	2025-12-04 15:33:01.405193
578	4f7c151a-7995-443a-81a6-1e12df81aa2b	\N	anonymous	\N	GET	/api/monitoring/stats	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	14	2025-12-04 15:33:01.405315
579	2a32a1ce-8ec8-4150-829c-f3748ff98170	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1007	2025-12-04 15:33:02.348019
580	5b80a590-5e61-400b-8c84-60b110aad21d	\N	anonymous	\N	GET	/api/users	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 15:33:08.70467
583	f6fa4a6b-5861-47e3-b040-934959c06ba9	\N	anonymous	\N	GET	/api/dashboard/completion	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	12	2025-12-04 15:33:22.456142
585	136edc1f-233e-4161-86d1-5add5a62cb38	\N	anonymous	\N	GET	/api/dashboard/activity	{"studyId":"1","days":"30"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 15:33:22.475771
586	f44d6ae6-4c0b-42b6-bec5-876e9dd17ae5	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 15:33:22.488176
593	3db82f8c-60cb-42e2-8940-45b6b076908e	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 15:33:28.986205
596	57c12f90-929d-4ee0-860c-b3b0e2af7709	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	21	2025-12-04 15:33:29.008417
599	f063b708-05ed-4386-bda7-be6d3921449f	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	16	2025-12-04 15:33:29.043666
600	dcd8cb90-b9f4-40af-a582-475a05dc7c4a	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	13	2025-12-04 15:33:29.044783
604	526a51e3-9ac0-4f86-a8d9-c2204eea4230	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 15:33:29.115051
605	2929b74e-4b02-4a11-ba42-a2f6570cb741	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	29	2025-12-04 15:33:29.135064
606	2676ed81-fccd-4be6-a5b5-2330c4d3b3e2	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	21	2025-12-04 15:33:29.155122
607	3990b9f3-cf1c-4e1c-a0ba-669dd16fe056	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	5	2025-12-04 15:33:29.164727
608	65ffa31d-f16c-4884-82b6-5f54576dadfc	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 15:33:50.193288
610	ea987269-f135-4c11-af08-b88b3b50e5be	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 15:33:50.22267
612	1b6b1d33-6f2d-4a28-9f91-9deeace3678e	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	4	2025-12-04 15:33:50.238124
613	a6132c5e-3a57-4909-b3b5-9035f806392c	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	103	2025-12-04 15:33:50.29022
614	fe0f5b9d-6597-44c7-b383-a3107574a57b	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	25	2025-12-04 15:33:50.314711
615	a3a6365a-b8ca-45dd-8133-74dc3a6f7f88	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 15:33:50.330464
616	9a898864-4ef0-4cf5-ac25-565216174bff	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 15:33:50.434388
618	9ea49a7e-3d12-4486-9b76-34a4e92fee50	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 15:33:50.455914
619	327526e4-0775-48f3-aa5d-a582993c2b5a	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	30	2025-12-04 15:33:50.459735
628	2064405b-85b9-4333-959d-c640935fe583	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	17	2025-12-04 15:34:03.593221
631	9e3a3327-962f-4db9-9356-de215d0e7463	\N	anonymous	\N	GET	/api/studies	{}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:34:03.611266
632	1cd4812a-6378-46ec-81fb-14dac35d2000	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	23	2025-12-04 15:34:03.622443
633	082a7553-9210-4afe-a7ad-96e7036da991	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:34:03.627614
581	0ee1bc9f-1590-44df-97f5-aa542b12dd32	\N	anonymous	\N	GET	/api/users	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 15:33:08.712999
582	9a8a0f3f-9e00-4ff0-8b37-1b6a324f9267	\N	anonymous	\N	GET	/api/dashboard/enrollment	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 15:33:22.443755
584	8f3c2f1d-6c4a-412c-b26b-b818a275a115	\N	anonymous	\N	GET	/api/dashboard/queries	{"studyId":"1","timeframe":"month"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 15:33:22.468095
587	45da07d2-6304-400c-95d7-97fcd4641405	\N	anonymous	\N	GET	/api/dashboard/enrollment	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	6	2025-12-04 15:33:22.497187
588	324332b7-2396-47b4-a699-578fa44243dd	\N	anonymous	\N	GET	/api/dashboard/enrollment-trend	{"studyId":"1","days":"30"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	4	2025-12-04 15:33:22.505293
589	449d29fe-d995-424c-b54a-62df10c7ee50	\N	anonymous	\N	GET	/api/dashboard/data-quality	{"studyId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 15:33:22.51797
590	c768b94e-f721-4219-87dc-6be64a64934f	\N	anonymous	\N	GET	/api/studies	{"limit":"100","statusId":"1"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	8	2025-12-04 15:33:24.170939
591	5c207d13-9b98-496e-8e05-6ac7549da7f3	\N	anonymous	\N	GET	/api/validation-rules/study/1	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	14	2025-12-04 15:33:24.189531
592	1857ab57-1600-4723-a02d-ceb37e3bd9fd	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	21	2025-12-04 15:33:28.985969
595	4e084f06-f337-41f0-9614-4f230aed7ad6	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 15:33:29.001465
597	3250c46a-30b1-41c6-9349-00c5248402fd	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	15	2025-12-04 15:33:29.026386
594	d1581363-d986-4b62-91c9-bbf419845896	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	21	2025-12-04 15:33:28.994034
598	cc6f1068-4555-4a1d-a1db-7a8cdadf2506	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	12	2025-12-04 15:33:29.03074
621	f0a23c78-a725-459c-a81d-69d85f7681ff	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 15:33:50.47095
622	475b5e22-0125-4905-b76d-b98bb2ce7150	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	30	2025-12-04 15:33:50.500274
623	31d31a74-5262-4e95-a05f-2f93605920ab	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	7	2025-12-04 15:33:50.515962
624	401ecc79-2d55-42b7-b6b5-17fd9b6ba625	\N	anonymous	\N	GET	/api/workflows/user/root/summary	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	9	2025-12-04 15:33:59.057626
625	06cc87a9-eeec-4272-9bd0-c9713f1213da	\N	anonymous	\N	GET	/api/workflows/user/root	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	5	2025-12-04 15:33:59.068762
626	db369fd1-bea5-42bd-8e68-168d3d6d3027	\N	anonymous	\N	GET	/api/queries	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	12	2025-12-04 15:33:59.831523
627	5b8563ff-d7fa-4856-8b38-db33a3092dfa	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	16	2025-12-04 15:34:03.581762
630	012a6a87-dd0f-414a-9c38-d7fcbe61ccb4	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	12	2025-12-04 15:34:03.609791
634	5a62fd95-1660-476b-912b-96cd9bf08d6f	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:34:03.628493
639	248a091e-7b99-4ae4-b4a9-df6d0628b6bc	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:34:03.692471
641	06167269-1e49-4803-8465-4e1235c6066e	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:34:03.70001
644	e590980f-c59c-4ab3-a07d-5c0879b13214	\N	anonymous	\N	GET	/api/studies	{}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:34:13.608452
645	28fcdd38-1ff3-4d45-ac7b-caacd218ff80	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:34:13.61807
601	5e6cc839-489d-47ed-b206-15017066a84b	\N	anonymous	\N	GET	/api/forms	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 15:33:29.045009
602	e48e4435-9b5d-4938-869c-83f293a90678	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	116	2025-12-04 15:33:29.082054
603	d70ea0e6-ef56-4d15-a855-6f7afb5f390a	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	21	2025-12-04 15:33:29.104482
609	200a9867-da51-4f45-8458-a8c5670108d0	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	13	2025-12-04 15:33:50.204114
611	f0471d1b-e3b6-41bd-b55c-3bdefea4773f	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	11	2025-12-04 15:33:50.234553
617	bcd07c4e-12c2-48d3-983f-f0d9d4fceba9	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	9	2025-12-04 15:33:50.445767
620	3d5ec93e-a6dd-4b64-8d7e-b036322a0803	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	13	2025-12-04 15:33:50.470718
629	4012dd24-9525-4b4f-a17b-c3d8b58f3c7c	\N	anonymous	\N	GET	/api/studies	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	21	2025-12-04 15:34:03.605816
635	ae355ab4-748a-452c-a959-67425828b9f9	\N	anonymous	\N	GET	/api/forms	{}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:34:03.6366
636	f5340c1a-c806-43c8-8e52-3bd0ea7055fe	\N	anonymous	\N	GET	/api/studies	{}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:34:03.639367
637	ddd11f8c-d16c-4fec-bc90-0ce4641c38c4	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	116	2025-12-04 15:34:03.686326
638	5f6c818f-278a-4dcb-b2f2-abface10c60e	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:34:03.689365
640	6eff1884-5f74-4d8b-85d9-ce18a841a229	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:34:03.693425
642	12850357-9b7d-422c-9e02-5d2c466cd677	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:34:03.700676
643	5d2d3e2f-8ed7-4822-a2ce-26e9328d7dd1	\N	anonymous	\N	GET	/api/studies	{}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:34:13.603697
646	a7155ec7-d593-46be-96b7-a71cdf32a130	\N	anonymous	\N	GET	/api/studies	{}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:34:13.619283
647	b2e45267-54e7-44e7-8a60-9da4b8bc4bd1	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:34:13.624501
648	f52035bd-ec49-45ca-b285-3e20d3c2fed5	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:34:13.631691
649	f6e96c17-26a8-4484-9a11-f1e2dc0c2a29	\N	anonymous	\N	GET	/api/studies	{}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:34:13.636716
650	640bd789-db59-4f1a-ab17-adf8f4bf2307	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:34:13.646346
651	0b4843d1-6734-4bbf-b9f9-91c30071ad70	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:34:13.65082
652	d5b045f4-753b-4445-ac15-fcbc88f6e09e	\N	anonymous	\N	GET	/api/forms	{}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:34:13.655145
653	00aeeb96-fb1c-470d-83a9-2f64de3e1949	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:34:13.661156
654	9bd7bf0a-e639-4495-9dd4-83af091f112b	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:34:13.665493
655	2f13fbb4-c035-41b3-aef5-f68c4ec416b5	\N	anonymous	\N	GET	/api/forms	{}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:34:13.669778
656	0d290d1a-3108-42f5-8184-415b24b36690	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:34:13.675419
657	8b6f593d-54c4-4fe3-83d0-e6c1426cf3e8	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:34:13.683505
658	012ed96e-af81-4426-928f-52b9523637d5	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:34:13.687465
659	2489f8c8-3657-4c20-b2cf-4ae0ae78ac9a	\N	anonymous	\N	GET	/api/studies	{}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:40:07.065849
660	99a6fde4-e282-4e5c-800e-173f05f2ba8d	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:40:07.071337
661	bb35062f-d7e5-4606-b040-c3dd2ea72591	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:40:07.071602
662	aa0fad36-9d10-4a6c-a78b-f3328b978575	\N	anonymous	\N	GET	/api/studies	{}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:40:07.071532
663	042901af-11d6-42a4-bbf7-ca8f8b030458	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	3	2025-12-04 15:40:07.075523
664	bd1c306c-06ae-47ac-8d45-0164bd451799	\N	anonymous	\N	GET	/api/studies	{}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:40:07.07562
665	8bcf7bf2-c1cc-485c-8ee7-e56e6b43f441	\N	anonymous	\N	GET	/api/forms	{}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:40:07.076551
666	8d6a6e24-6ec2-46e2-90e0-bac09bc7cfc2	\N	anonymous	\N	GET	/api/forms	{}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:40:07.076676
669	feab0855-b09f-4789-8543-5d1058813bf3	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:40:07.086835
667	a47a4747-bfe1-4166-97bf-e50780eb417c	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:40:07.080282
670	02e92a61-c1c5-4464-9bc8-e81e50512b10	\N	anonymous	\N	GET	/api/studies	{}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:40:07.08669
668	2888cd1f-659b-45ba-865e-a5c3d55e890b	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:40:07.077034
672	7a57cf90-9ad0-4c50-adfb-36a05e42e5c9	\N	anonymous	\N	GET	/api/studies	{"limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	1	2025-12-04 15:40:07.091278
671	5e22e9e6-733d-400e-9903-26a7119330bd	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:40:07.09567
673	4e98bbf6-f1b4-409d-b67b-e3878b4269dc	\N	anonymous	\N	GET	/api/subjects	{"studyId":"1","limit":"100"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:40:07.076808
674	3b905e1e-f34e-4b81-aced-35d2d79f2c8c	\N	anonymous	\N	GET	/api/audit	{"page":"1","limit":"50"}	{}	429	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2	2025-12-04 15:40:07.102128
675	dd8e94e1-d26e-4294-bb29-eff602000896	\N	anonymous	\N	GET	/api/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	3880	2025-12-04 15:55:53.326004
676	f7085dbb-2e30-41a2-adb1-fcf3cbaa0b17	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	17	2025-12-04 15:55:59.428579
677	073192f9-b55e-443b-aea2-ff02d3df88ae	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	11	2025-12-04 15:56:04.878947
678	3876f2ea-5dd8-4561-a89e-957c35ccfe76	\N	anonymous	\N	GET	/api/study-parameters/available	{}	{}	404	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	3	2025-12-04 15:56:13.517927
679	d1ba9511-2c65-47b5-be12-2f26e358a804	\N	anonymous	\N	GET	/api/health	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	3034	2025-12-04 15:57:02.293627
680	c0795cbd-2e73-464e-9bb8-805e527be851	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	20	2025-12-04 15:57:08.249833
681	ec5852ad-4c21-4ec9-b623-39bbb2d2207a	\N	anonymous	\N	GET	/api/study-parameters/available	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	7	2025-12-04 15:57:08.26065
682	83e7eb90-11ec-4efc-80b3-8e03e5694d95	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	23	2025-12-04 15:57:14.766386
683	f7768509-8240-43db-9111-91bde3631904	\N	anonymous	\N	GET	/api/study-parameters/available	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	3	2025-12-04 15:57:14.77034
684	7982a28e-1b96-44de-a3a6-133f8f25565b	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	11	2025-12-04 15:57:22.008946
685	1c1fb0e6-0fe8-4d8d-8de5-4478be99f4e6	\N	anonymous	\N	GET	/api/study-parameters/1	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	9	2025-12-04 15:57:22.016193
686	27f7072a-aac2-4b7f-9ef6-e557f9e89d82	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	11	2025-12-04 15:57:31.615696
687	216a0c67-2fdc-42f0-90f8-a613785881b9	\N	anonymous	\N	GET	/api/study-groups/study/1	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	8	2025-12-04 15:57:31.622791
688	ae67269a-4467-4b56-bad5-1c3bdd0b2d80	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	12	2025-12-04 15:57:39.077485
689	e0d951b6-ec76-4f7e-971f-4829f17075a9	\N	anonymous	\N	GET	/api/subjects/enrollment-config/1	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	23	2025-12-04 15:57:39.099254
690	1142b2fc-9025-4522-8b8e-50f863fdc767	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	429	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	2	2025-12-04 15:57:55.825554
691	20ccd934-4401-42af-aa21-e28e1f4bf2b9	\N	anonymous	\N	GET	/api/study-groups/class-types	{}	{}	200	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	3	2025-12-04 15:57:55.838509
692	01a5894a-5038-4ec3-b402-cd5a0ad5f11a	\N	anonymous	\N	POST	/api/auth/login	{}	{"password":"***REDACTED***","username":"root"}	429	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	1	2025-12-04 16:06:26.773004
693	b3eec705-76cb-44e4-ae4b-bc9e3d2b980d	\N	anonymous	\N	POST	/api/forms	{}	{"description":"Testing form creation","name":"Test Form","fields":[{"label":"Test Field","name":"test_field","type":"text","required":true}]}	201	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	75	2025-12-04 16:06:26.848565
694	20dbf179-2d51-459d-82a8-b2f5240b12e0	\N	anonymous	\N	GET	/api/forms/22/metadata	{}	{}	401	127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.19041.6456	3	2025-12-04 16:09:14.607285
\.


--
-- Data for Name: audit_user_login; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.audit_user_login (id, user_name, user_account_id, login_attempt_date, login_status_code, version, details) FROM stdin;
3	root	1	2025-12-02 07:43:20.557514	1	1	Login from 127.0.0.1
4	root	1	2025-12-02 07:43:20.725061	2	1	Logout from 127.0.0.1
5	root	1	2025-12-02 07:43:21.972009	1	1	Login from 127.0.0.1
6	root	1	2025-12-02 07:44:00.390755	1	1	Login from 127.0.0.1
7	root	1	2025-12-02 07:53:25.857298	1	1	Login from 127.0.0.1
8	root	1	2025-12-02 07:53:40.971962	1	1	Login from 127.0.0.1
9	root	1	2025-12-02 07:55:02.444619	1	1	Login from 127.0.0.1
10	root	1	2025-12-02 07:55:59.747293	1	1	Login from 127.0.0.1
11	root	1	2025-12-02 09:10:49.102295	1	1	Login from 127.0.0.1
12	root	1	2025-12-02 09:44:58.0468	1	1	Login from 127.0.0.1
13	root	1	2025-12-02 09:51:28.359735	1	1	Login from 127.0.0.1
14	root	1	2025-12-02 10:09:18.307361	1	1	Login from 127.0.0.1
15	root	1	2025-12-03 04:38:45.747425	1	1	Login from 127.0.0.1
16	root	1	2025-12-03 04:40:41.554483	1	1	Login from 127.0.0.1
17	root	1	2025-12-03 05:01:24.17082	1	1	Login from 127.0.0.1
18	root	1	2025-12-03 05:03:21.401547	1	1	Login from 127.0.0.1
19	root	1	2025-12-03 05:06:22.865795	1	1	Login from 127.0.0.1
20	root	1	2025-12-03 05:07:10.454755	1	1	Login from 127.0.0.1
21	root	1	2025-12-03 05:07:40.966825	1	1	Login from 127.0.0.1
22	root	1	2025-12-03 05:14:36.115137	1	1	Login from 127.0.0.1
23	root	1	2025-12-03 05:15:12.466306	1	1	Login from 127.0.0.1
24	root	1	2025-12-03 05:16:29.677965	1	1	Login from 127.0.0.1
25	root	1	2025-12-03 05:16:35.17258	1	1	Login from 127.0.0.1
26	root	1	2025-12-03 06:11:22.103938	1	1	Login from 127.0.0.1
27	root	1	2025-12-03 06:49:39.26889	1	1	Login from 127.0.0.1
28	root	1	2025-12-03 06:52:38.584263	1	1	Login from 127.0.0.1
29	root	1	2025-12-04 14:09:01.444725	1	1	Login from 127.0.0.1
30	root	1	2025-12-04 14:17:36.905093	1	1	Login from 127.0.0.1
31	root	1	2025-12-04 14:20:00.875774	1	1	Login from 127.0.0.1
32	root	1	2025-12-04 14:24:53.013269	1	1	Login from 127.0.0.1
33	root	1	2025-12-04 15:55:59.41907	1	1	Login from 127.0.0.1
34	root	1	2025-12-04 15:56:04.871324	1	1	Login from 127.0.0.1
35	root	1	2025-12-04 15:57:08.237624	1	1	Login from 127.0.0.1
36	root	1	2025-12-04 15:57:14.753069	1	1	Login from 127.0.0.1
37	root	1	2025-12-04 15:57:21.997581	1	1	Login from 127.0.0.1
38	root	1	2025-12-04 15:57:31.605267	1	1	Login from 127.0.0.1
39	root	1	2025-12-04 15:57:39.065886	1	1	Login from 127.0.0.1
\.


--
-- Data for Name: authorities; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.authorities (id, username, authority, version) FROM stdin;
1	root	ROLE_USER	1
\.


--
-- Data for Name: completion_status; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.completion_status (completion_status_id, status_id, name, description) FROM stdin;
1	1	completion status	place filler for completion status
\.


--
-- Data for Name: configuration; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.configuration (id, key, value, description, version) FROM stdin;
1	user.lock.switch	FALSE	You can enable/disable the User Locking functionality by setting the value to TRUE/FALSE	0
2	user.lock.allowedFailedConsecutiveLoginAttempts	3	You can configure the number of allowed Failed Consecutive Login Attempts before Locking the system	0
3	pwd.chars.min	8	Password minimum length	0
4	pwd.chars.max	-1	Password maximum length	0
5	pwd.chars.case.lower	false	Whether the password must contain lowercase letters	0
6	pwd.chars.case.upper	false	Whether the password must contain upper case letters	0
7	pwd.chars.digits	false	Whether the password must contain digits	0
8	pwd.chars.specials	false	Whether the password must special character	0
9	pwd.expiration.days	360	Number of days after a password expires	0
10	pwd.change.required	1	If the user is required to change their password after the first login	0
\.


--
-- Data for Name: crf; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.crf (crf_id, status_id, name, description, owner_id, date_created, date_updated, update_id, oc_oid, source_study_id) FROM stdin;
1	1	Integration Test Template 20251202_002306	Updated - Published!	1	2025-12-02	2025-12-02	1	F_INTEGRATION_TEST_TEMPLATE_2025	\N
2	5	Angular E2E Test 20251202_005032	Created from Angular UI	1	2025-12-02	2025-12-02	1	F_ANGULAR_E2E_TEST_20251202_0050	\N
3	1	Template With Fields Test 005830	Testing field sync	1	2025-12-02	\N	\N	F_TEMPLATE_WITH_FIELDS_TEST_0058	\N
4	1	Fields Test 010017	Testing field storage	1	2025-12-02	\N	\N	F_FIELDS_TEST_010017_817277	\N
5	1	Complete Form Test 010137	Testing all field types	1	2025-12-02	\N	\N	F_COMPLETE_FORM_TEST_01013_897129	\N
6	1	Full Field Test 011526	Testing ALL field properties	1	2025-12-02	\N	\N	F_FULL_FIELD_TEST_011526_726160	\N
7	1	Frontend Test Form 012540	Complete form with all field types	1	2025-12-02	\N	\N	F_FRONTEND_TEST_FORM_01254_340656	\N
8	1	Audit Test Form 014052	Testing audit logging	1	2025-12-02	\N	\N	F_AUDIT_TEST_FORM_014052_252191	\N
10	1	Audit Form 20251202014400	Test form	1	2025-12-02	\N	\N	F_AUDIT_FORM_2025120201440_440431	\N
11	1	Test Form From PowerShell	A test form created via API	1	2025-12-03	\N	\N	F_TEST_FORM_FROM_POWERSHEL_737156	\N
12	1	Diagnostic Test Form 20251202224041 (Updated)	Updated by diagnostic script	1	2025-12-03	2025-12-03	1	F_DIAGNOSTIC_TEST_FORM_202_841639	\N
13	5	Real API Test 1764738084185 - UPDATED	Updated by test script	1	2025-12-03	2025-12-03	1	F_REAL_API_TEST_1764738084_084195	\N
14	5	Data Verification Test 1764738201358	Testing that exact data is preserved through the system	1	2025-12-03	2025-12-03	1	F_DATA_VERIFICATION_TEST_1_201423	\N
20	5	Data Verification Test 1764738989631	Testing that exact data is preserved through the system	1	2025-12-03	2025-12-03	1	F_DATA_VERIFICATION_TEST_1_989708	\N
21	5	Data Verification Test 1764738995138	Testing that exact data is preserved through the system	1	2025-12-03	2025-12-03	1	F_DATA_VERIFICATION_TEST_1_995196	\N
22	1	Test Form	Testing form creation	1	2025-12-04	\N	\N	F_TEST_FORM_386787	\N
\.


--
-- Data for Name: crf_version; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.crf_version (crf_version_id, crf_id, name, description, revision_notes, status_id, date_created, date_updated, owner_id, update_id, oc_oid, xform, xform_name) FROM stdin;
1	1	v1.0	Test from PowerShell integration test	\N	1	2025-12-02	\N	1	\N	F_INTEGRATION_TEST_TEMPLATE_2025_V1	\N	\N
2	2	v1.0	Created from Angular UI	\N	1	2025-12-02	\N	1	\N	F_ANGULAR_E2E_TEST_20251202_0050_V1	\N	\N
3	3	v1.0	Testing field sync	\N	1	2025-12-02	\N	1	\N	F_TEMPLATE_WITH_FIELDS_TEST_0058_V1	\N	\N
4	4	v1.0	Testing field storage	\N	1	2025-12-02	\N	1	\N	F_FIELDS_TEST_010017_817277_V1	\N	\N
5	5	v1.0	Testing all field types	\N	1	2025-12-02	\N	1	\N	F_COMPLETE_FORM_TEST_01013_897129_V1	\N	\N
6	6	v1.0	Testing ALL field properties	\N	1	2025-12-02	\N	1	\N	F_FULL_FIELD_TEST_011526_726160_V1	\N	\N
7	7	1.0	Complete form with all field types	\N	1	2025-12-02	\N	1	\N	F_FRONTEND_TEST_FORM_01254_340656_V1	\N	\N
8	8	1.0	Testing audit logging	\N	1	2025-12-02	\N	1	\N	F_AUDIT_TEST_FORM_014052_252191_V1	\N	\N
10	10	1.0	Test form	\N	1	2025-12-02	\N	1	\N	F_AUDIT_FORM_2025120201440_440431_V1	\N	\N
11	11	v1.0	A test form created via API	\N	1	2025-12-03	\N	1	\N	F_TEST_FORM_FROM_POWERSHEL_737156_V1	\N	\N
12	12	v1.0	Created by diagnostic script	\N	1	2025-12-03	\N	1	\N	F_DIAGNOSTIC_TEST_FORM_202_841639_V1	\N	\N
13	13	1.0	Created by test-template-api.js - Real E2E test	\N	1	2025-12-03	\N	1	\N	F_REAL_API_TEST_1764738084_084195_V1	\N	\N
14	14	2.0	Testing that exact data is preserved through the system	\N	1	2025-12-03	\N	1	\N	F_DATA_VERIFICATION_TEST_1_201423_V1	\N	\N
20	20	2.0	Testing that exact data is preserved through the system	\N	1	2025-12-03	\N	1	\N	F_DATA_VERIFICATION_TEST_1_989708_V1	\N	\N
21	21	2.0	Testing that exact data is preserved through the system	\N	1	2025-12-03	\N	1	\N	F_DATA_VERIFICATION_TEST_1_995196_V1	\N	\N
22	22	v1.0	Testing form creation	\N	1	2025-12-04	\N	1	\N	F_TEST_FORM_386787_V1	\N	\N
\.


--
-- Data for Name: crf_version_media; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.crf_version_media (crf_version_media_id, crf_version_id, name, path) FROM stdin;
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
1235684743487-0	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.152683	1	MARK_RAN	8:ab25015b9763c27a512455fd43e39225	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-1	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.169135	2	EXECUTED	8:75a39ee2d45f42b135de71a20df62f99	createTable tableName=archived_dataset_file		\N	3.6.3	\N	\N	4489977887
1235684743487-2	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.18256	3	EXECUTED	8:49b4819aff026a99d7b0548b35a63029	createTable tableName=audit_event		\N	3.6.3	\N	\N	4489977887
1235684743487-3	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.188333	4	EXECUTED	8:e6ca531ef9cf0d8470e3c3522188681e	createTable tableName=audit_event_context		\N	3.6.3	\N	\N	4489977887
1235684743487-4	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.196435	5	EXECUTED	8:9c124592d17e2b5323b66d8f57fce7bb	createTable tableName=audit_event_values		\N	3.6.3	\N	\N	4489977887
1235684743487-5	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.209718	6	EXECUTED	8:9f2b8689687ef7713897c1e1a70d2ebb	createTable tableName=audit_log_event		\N	3.6.3	\N	\N	4489977887
235684743487-5-1	kkrumlian	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.212203	7	EXECUTED	8:d41d8cd98f00b204e9800998ecf8427e	empty		\N	3.6.3	\N	\N	4489977887
235684743487-5-2	kkrumlian	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.214393	8	EXECUTED	8:d41d8cd98f00b204e9800998ecf8427e	empty		\N	3.6.3	\N	\N	4489977887
1235684743487-6	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.223433	9	EXECUTED	8:c8aaae0e324a03884b11808d0a3cde5a	createTable tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-7	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.243753	10	EXECUTED	8:a18936418bedba4bd41ea351b1b708ae	createTable tableName=completion_status		\N	3.6.3	\N	\N	4489977887
1235684743487-8	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.254916	11	EXECUTED	8:5752fe8b7dd5e1783bb76bd76c490802	createTable tableName=crf		\N	3.6.3	\N	\N	4489977887
1235684743487-9	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.26669	12	EXECUTED	8:b41359e661d830286a984c2f679a5eff	createTable tableName=crf_version		\N	3.6.3	\N	\N	4489977887
1235684743487-10	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.282115	13	EXECUTED	8:7b916bf555eb847232bf3efaa86fa8b9	createTable tableName=dataset		\N	3.6.3	\N	\N	4489977887
235684743487-10-1	kkrumlian	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.285544	14	MARK_RAN	8:d8766ca6237d3decdca44ccf02bdef1c	dropTable tableName=dataset		\N	3.6.3	\N	\N	4489977887
1235684743487-10-2	kkrumlian	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.287778	15	MARK_RAN	8:1b54ec543794fafb7ff7964387119446	createTable tableName=dataset		\N	3.6.3	\N	\N	4489977887
235684743487-10-3	kkrumlian	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.289626	16	EXECUTED	8:d41d8cd98f00b204e9800998ecf8427e	empty		\N	3.6.3	\N	\N	4489977887
1235684743487-11	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.294125	17	EXECUTED	8:716041754b974828255bda16ea669d11	createTable tableName=dataset_crf_version_map		\N	3.6.3	\N	\N	4489977887
1235684743487-12	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.298693	18	EXECUTED	8:d6bee076c68d62eb732673ddbc79dd7f	createTable tableName=dataset_filter_map		\N	3.6.3	\N	\N	4489977887
1235684743487-13	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.310624	19	EXECUTED	8:892e0f42c612ab48a5206fa037a2bb91	createTable tableName=dataset_study_group_class_map		\N	3.6.3	\N	\N	4489977887
1235684743487-14	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.318737	20	EXECUTED	8:4a35282487e39f3a325524434811c046	createTable tableName=dc_computed_event		\N	3.6.3	\N	\N	4489977887
1235684743487-15	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.335268	21	EXECUTED	8:a8fd5ee2012102fd3234847b83641e7c	createTable tableName=dc_event		\N	3.6.3	\N	\N	4489977887
1235684743487-16	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.348041	22	EXECUTED	8:1990e4185c7f9cec46537630326be9a5	createTable tableName=dc_primitive		\N	3.6.3	\N	\N	4489977887
1235684743487-17	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.356889	23	EXECUTED	8:9a8bebb42e0debb2fc1b2de24200d6da	createTable tableName=dc_section_event		\N	3.6.3	\N	\N	4489977887
1235684743487-18	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.369224	24	EXECUTED	8:8c969997fa8e40d4542098613ff67a49	createTable tableName=dc_send_email_event		\N	3.6.3	\N	\N	4489977887
1235684743487-19	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.379941	25	EXECUTED	8:8bbc5d421ecd3dd45ab8d0488f7a485a	createTable tableName=dc_substitution_event		\N	3.6.3	\N	\N	4489977887
1235684743487-20	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.386441	26	EXECUTED	8:e807da47d9cc06a2a9c816aac801f92c	createTable tableName=dc_summary_item_map		\N	3.6.3	\N	\N	4489977887
1235684743487-21	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.398417	27	EXECUTED	8:4bbb389a038a945cb3142d4b3671ba6f	createTable tableName=decision_condition		\N	3.6.3	\N	\N	4489977887
1235684743487-22	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.409987	28	EXECUTED	8:0aaecfd2fd709f91f68591fa83fc74c2	createTable tableName=discrepancy_note		\N	3.6.3	\N	\N	4489977887
1235684743487-23	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.41893	29	EXECUTED	8:31310632aa0deef8374e1cd8d7e73a3c	createTable tableName=discrepancy_note_type		\N	3.6.3	\N	\N	4489977887
1235684743487-24	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.423917	30	EXECUTED	8:6be4537297bbe3747a7e98a51fade90e	createTable tableName=dn_event_crf_map		\N	3.6.3	\N	\N	4489977887
1235684743487-25	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.428058	31	EXECUTED	8:48159a10319361e1e90e129f0f52ce79	createTable tableName=dn_item_data_map		\N	3.6.3	\N	\N	4489977887
1235684743487-26	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.432	32	EXECUTED	8:035750d8678ba7939eee438990f32d4e	createTable tableName=dn_study_event_map		\N	3.6.3	\N	\N	4489977887
1235684743487-27	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.439539	33	EXECUTED	8:e6f36347e7556c0199ebcffba5beddba	createTable tableName=dn_study_subject_map		\N	3.6.3	\N	\N	4489977887
1235684743487-28	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.446489	34	EXECUTED	8:267b1a7b9b07b3270a8804a1dd614c41	createTable tableName=dn_subject_map		\N	3.6.3	\N	\N	4489977887
1235684743487-29	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.463216	35	EXECUTED	8:2d84bebb30d70d421d1197bdc1705387	createTable tableName=event_crf		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-9	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.44174	649	EXECUTED	8:4927977153d185a78f84ba1a1693eded	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-30	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.475048	36	EXECUTED	8:2be7d7e16cf465e30b846e2bf74aa7eb	createTable tableName=event_definition_crf		\N	3.6.3	\N	\N	4489977887
1235684743487-31	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.489744	37	EXECUTED	8:1e2af57ca0f9ced0278d26e2790b431c	createTable tableName=export_format		\N	3.6.3	\N	\N	4489977887
1235684743487-32	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.502646	38	EXECUTED	8:55d1a0d13871f0676c9a5c4448fdaa40	createTable tableName=filter		\N	3.6.3	\N	\N	4489977887
235684743487-32-1	kkrumlian	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.504799	39	MARK_RAN	8:87c8e9f28f945994770a175f3b8e0013	dropTable tableName=filter		\N	3.6.3	\N	\N	4489977887
1235684743487-32-2	kkrumlian	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.506747	40	MARK_RAN	8:8eefa9b88de32fd8e47025a96639e581	createTable tableName=filter		\N	3.6.3	\N	\N	4489977887
235684743487-32-3	kkrumlian	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.508726	41	EXECUTED	8:d41d8cd98f00b204e9800998ecf8427e	empty		\N	3.6.3	\N	\N	4489977887
1235684743487-33	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.512799	42	EXECUTED	8:018ea6822999ec08141725648cfea144	createTable tableName=filter_crf_version_map		\N	3.6.3	\N	\N	4489977887
1235684743487-34	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.527195	43	EXECUTED	8:04da53a11a50fbe807fa49a1f0ffd8ad	createTable tableName=group_class_types		\N	3.6.3	\N	\N	4489977887
1235684743487-35	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.54576	44	EXECUTED	8:6d31529ee3e474eb66d78a31b811016e	createTable tableName=item		\N	3.6.3	\N	\N	4489977887
1235684743487-36	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.563413	45	EXECUTED	8:0e9e3ba564cde91d75a7f20a092ee8c8	createTable tableName=item_data		\N	3.6.3	\N	\N	4489977887
1235684743487-37	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.579905	46	EXECUTED	8:ebe81e192653b298f701edc92367aa6b	createTable tableName=item_data_type		\N	3.6.3	\N	\N	4489977887
1235684743487-38	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.593357	47	EXECUTED	8:1c5c5fdff357490dc09aa9ad1fc30568	createTable tableName=item_form_metadata		\N	3.6.3	\N	\N	4489977887
1235684743487-39	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.602468	48	EXECUTED	8:84dd9d291ae82748723d7fd844087b49	createTable tableName=item_group		\N	3.6.3	\N	\N	4489977887
1235684743487-40	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.61335	49	EXECUTED	8:e936a01433322af590ebb00e0e0fc303	createTable tableName=item_group_metadata		\N	3.6.3	\N	\N	4489977887
1235684743487-41	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.624721	50	EXECUTED	8:4ef33c18136abe6ddcd3591af18ee37b	createTable tableName=item_reference_type		\N	3.6.3	\N	\N	4489977887
1235684743487-42	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.63932	51	EXECUTED	8:fd8ea095a7baae4d540dd2081d065fa6	createTable tableName=null_value_type		\N	3.6.3	\N	\N	4489977887
1235684743487-43	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.646899	52	EXECUTED	8:72de38d0e7169c4267e753a20dcccf93	createTable tableName=openclinica_version		\N	3.6.3	\N	\N	4489977887
1235684743487-43-1	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.654079	53	EXECUTED	8:8847950fab7e2d659fc66dcf92cefd90	dropTable tableName=openclinica_version		\N	3.6.3	\N	\N	4489977887
1235684743487-43-2	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.67936	54	EXECUTED	8:833753787ac14466b353f539ce90238f	createTable tableName=openclinica_version		\N	3.6.3	\N	\N	4489977887
1235684743487-44	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.697088	55	EXECUTED	8:745c69632162820f47500b11c05288cf	createTable tableName=privilege		\N	3.6.3	\N	\N	4489977887
1235684743487-45	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.707326	56	EXECUTED	8:eb07c228ab5b72825d03cae934b41950	createTable tableName=resolution_status		\N	3.6.3	\N	\N	4489977887
1235684743487-46	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.721764	57	EXECUTED	8:b9a79994580cd4422d6022fecb518241	createTable tableName=response_set		\N	3.6.3	\N	\N	4489977887
1235684743487-47	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.735122	58	EXECUTED	8:69e4ab85f9ba73ce29e52204101b8767	createTable tableName=response_type		\N	3.6.3	\N	\N	4489977887
1235684743487-48	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.741219	59	EXECUTED	8:02349b735c8bd4315f5f70e486b57669	createTable tableName=role_privilege_map		\N	3.6.3	\N	\N	4489977887
1235684743487-49	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.753422	60	EXECUTED	8:e94661e26f8f4e232c902bf412491665	createTable tableName=rule		\N	3.6.3	\N	\N	4489977887
1235684743487-50	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.764209	61	EXECUTED	8:4d43f401f214e8dbdc71b21ff641ce66	createTable tableName=rule_action		\N	3.6.3	\N	\N	4489977887
1235684743487-51	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.77511	62	EXECUTED	8:a75751c1a5d9e2b4dc21e540a37ba02b	createTable tableName=rule_expression		\N	3.6.3	\N	\N	4489977887
1235684743487-52	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.782614	63	EXECUTED	8:6bb306d331ebc9747a96d1aa098d243e	createTable tableName=rule_set		\N	3.6.3	\N	\N	4489977887
1235684743487-53	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.790301	64	EXECUTED	8:e2183a822e74b12f6069ac8398b9563f	createTable tableName=rule_set_audit		\N	3.6.3	\N	\N	4489977887
1235684743487-54	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.797936	65	EXECUTED	8:ba4f18774b25e7c98660e99487298807	createTable tableName=rule_set_rule		\N	3.6.3	\N	\N	4489977887
1235684743487-55	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.806245	66	EXECUTED	8:99a91a5e5707b2d5977481754fe18e40	createTable tableName=rule_set_rule_audit		\N	3.6.3	\N	\N	4489977887
1235684743487-56	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.817804	67	EXECUTED	8:28477b753c6af013056e638153ba9cfa	createTable tableName=section		\N	3.6.3	\N	\N	4489977887
1235684743487-57	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.828746	68	EXECUTED	8:c632c95c12844ce9810157ca9d794013	createTable tableName=status		\N	3.6.3	\N	\N	4489977887
1235684743487-58	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.843443	69	EXECUTED	8:01a9d4c2532042b4d1ca9512c0995ff2	createTable tableName=study		\N	3.6.3	\N	\N	4489977887
1235684743487-59	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.85502	70	EXECUTED	8:e3d52deaeba5943a11b26aaa79f9f2d3	createTable tableName=study_event		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-10	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.447741	650	EXECUTED	8:a8c26dc25a1a70477230778778cf7e29	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-60	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.866205	71	EXECUTED	8:42ce85748e6cdddf8c081ec010a2c7b4	createTable tableName=study_event_definition		\N	3.6.3	\N	\N	4489977887
1235684743487-61	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.875929	72	EXECUTED	8:cea6d977d3b25f4950ebbb645e5f8573	createTable tableName=study_group		\N	3.6.3	\N	\N	4489977887
1235684743487-62	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.883354	73	EXECUTED	8:f47b05c54b386104a4cc6f81cb935bb7	createTable tableName=study_group_class		\N	3.6.3	\N	\N	4489977887
1235684743487-63	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.890807	74	EXECUTED	8:9e9b1efe1656d50b5c850c104d3ff3c2	createTable tableName=study_parameter		\N	3.6.3	\N	\N	4489977887
1235684743487-64	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.895431	75	EXECUTED	8:fe55faffdce6be6e45efb3672b44e946	createTable tableName=study_parameter_value		\N	3.6.3	\N	\N	4489977887
1235684743487-65	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.903108	76	EXECUTED	8:ebcf3983b1a57b1d46093611ebfa6513	createTable tableName=study_subject		\N	3.6.3	\N	\N	4489977887
1235684743487-66	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.912975	77	EXECUTED	8:fdab9fa2cf68b2da6a36e7d66edb2c49	createTable tableName=study_type		\N	3.6.3	\N	\N	4489977887
1235684743487-67	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.917391	78	EXECUTED	8:8b27f270993dcbcc4094c8d411c6166c	createTable tableName=study_user_role		\N	3.6.3	\N	\N	4489977887
1235684743487-68	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.926058	79	EXECUTED	8:b0d42edba5a604eeb32ba5da9880f078	createTable tableName=subject		\N	3.6.3	\N	\N	4489977887
1235684743487-69	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.936684	80	EXECUTED	8:72c7fe9c277ebb3defb253e170de147a	createTable tableName=subject_event_status		\N	3.6.3	\N	\N	4489977887
1235684743487-70	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.944152	81	EXECUTED	8:628b4b8e306ce2564b6dea49d49132ec	createTable tableName=subject_group_map		\N	3.6.3	\N	\N	4489977887
1235684743487-71	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.955106	82	EXECUTED	8:f4b01066342a49a8be7a3e2f95f72106	createTable tableName=user_account		\N	3.6.3	\N	\N	4489977887
1235684743487-72	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.96495	83	EXECUTED	8:4291a7048736ea6723c12f628dfe1d39	createTable tableName=user_role		\N	3.6.3	\N	\N	4489977887
1235684743487-73	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.972226	84	EXECUTED	8:d92d0f26fc468dacc64359201c20eb6e	createTable tableName=user_type		\N	3.6.3	\N	\N	4489977887
1235684743487-74	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.975857	85	EXECUTED	8:2e6ca64cd8aa2b00c6098d8559e909a5	createTable tableName=versioning_map		\N	3.6.3	\N	\N	4489977887
1236014212860-75	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.984343	86	EXECUTED	8:4ab35ba894e54fb7148c2ee7ec6f832d	addUniqueConstraint constraintName=uniq_crf_oc_oid, tableName=crf		\N	3.6.3	\N	\N	4489977887
1236014212860-76	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.99026	87	EXECUTED	8:783a5821fb76be57e88002f66823ffb4	addUniqueConstraint constraintName=uniq_crf_version_oc_oid, tableName=crf_version		\N	3.6.3	\N	\N	4489977887
1236014212860-77	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:18.997352	88	EXECUTED	8:9f2a1e391446c400213d0d8acac17b4c	addUniqueConstraint constraintName=uniq_item_oc_oid, tableName=item		\N	3.6.3	\N	\N	4489977887
1236014212860-78	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.00412	89	EXECUTED	8:40944b0affe1fd427daaf881d093f3fd	addUniqueConstraint constraintName=uniq_item_group_oc_oid, tableName=item_group		\N	3.6.3	\N	\N	4489977887
1236014212860-79	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.010888	90	EXECUTED	8:f11877e6e1e49a3bfadc9ff6317861e6	addUniqueConstraint constraintName=uniq_study_oid, tableName=study		\N	3.6.3	\N	\N	4489977887
1236014212860-80	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.017074	91	EXECUTED	8:3302762b35aef789a3e545fa1c9ed1bc	addUniqueConstraint constraintName=uniq_study_event_def_oid, tableName=study_event_definition		\N	3.6.3	\N	\N	4489977887
1236014212860-81	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.023361	92	EXECUTED	8:2cb89cd4186ac5900cb4c77d6b2e4c66	addUniqueConstraint constraintName=study_parameter_handle_key, tableName=study_parameter		\N	3.6.3	\N	\N	4489977887
1236014212860-82	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.028982	93	EXECUTED	8:9185d3a333e95f3e1e23749b7e8f6091	addUniqueConstraint constraintName=uniq_study_subject_oid, tableName=study_subject		\N	3.6.3	\N	\N	4489977887
1235684743487-83	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.035247	94	EXECUTED	8:3c6808fef162c99c4ee14d189894c160	createIndex indexName=i_audit_event_audit_table, tableName=audit_event		\N	3.6.3	\N	\N	4489977887
1235684743487-84	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.040631	95	EXECUTED	8:ba4302cf79ecccad8e75c3f44bdc5707	createIndex indexName=i_audit_event_entity_id, tableName=audit_event		\N	3.6.3	\N	\N	4489977887
1235684743487-85	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.045668	96	EXECUTED	8:48e0f7ab89b7ad305384814debdd0353	createIndex indexName=i_audit_event_user_id, tableName=audit_event		\N	3.6.3	\N	\N	4489977887
1235684743487-86	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.051869	97	EXECUTED	8:c895f39d0f76c1f237753e8832c7c7f5	createIndex indexName=i_audit_event_context_study_id, tableName=audit_event_context		\N	3.6.3	\N	\N	4489977887
1235684743487-87	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.058675	98	EXECUTED	8:c0a6cedf52e0a75e4e6af69b53ca3ed9	createIndex indexName=i_item_name, tableName=item		\N	3.6.3	\N	\N	4489977887
1235684743487-88	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.064614	99	EXECUTED	8:11a1057cca90d2825f51464a96d05c9f	createIndex indexName=i_itm_form_metadata_crf_ver_id, tableName=item_form_metadata		\N	3.6.3	\N	\N	4489977887
1235684743487-89	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.070857	100	EXECUTED	8:0f7e7aeeda60ad7f973aa8a0aa502084	createIndex indexName=i_section_ordinal, tableName=section		\N	3.6.3	\N	\N	4489977887
1235684743487-90	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.076752	101	EXECUTED	8:b56eaf9079785a7eaec8a2081eebd3d5	createIndex indexName=i_section_parent_id, tableName=section		\N	3.6.3	\N	\N	4489977887
1235684743487-91	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.083231	102	EXECUTED	8:7f61eccf7e49507bf0d51d3ef5f007b0	createIndex indexName=i_study_user_role_user_name, tableName=study_user_role		\N	3.6.3	\N	\N	4489977887
1235684743487-92	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.089226	103	EXECUTED	8:02055e8e8fa822ea0ef8464316fba5b5	createIndex indexName=i_user_account_user_name, tableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-93	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.095275	104	EXECUTED	8:5a145d60e11ca5662d15a117de10da15	addForeignKeyConstraint baseTableName=archived_dataset_file, constraintName=fk_archived_reference_dataset, referencedTableName=dataset		\N	3.6.3	\N	\N	4489977887
1236014212860-94	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.100348	105	EXECUTED	8:b5f86b242cad93583fd6b362279d2068	addForeignKeyConstraint baseTableName=archived_dataset_file, constraintName=fk_archived_reference_export_f, referencedTableName=export_format		\N	3.6.3	\N	\N	4489977887
1236014212860-95	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.105984	106	EXECUTED	8:82c4abeb6e25ca6728ab834b9368dfc3	addForeignKeyConstraint baseTableName=audit_event_context, constraintName=fk_audit_ev_reference_audit_ev, referencedTableName=audit_event		\N	3.6.3	\N	\N	4489977887
1236014212860-96	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.110783	107	EXECUTED	8:a8dfd8c64577d36fe846aeede9fa9458	addForeignKeyConstraint baseTableName=audit_event_values, constraintName=fk_audit_lo_ref_audit_lo, referencedTableName=audit_event		\N	3.6.3	\N	\N	4489977887
1236014212860-97	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.115652	108	EXECUTED	8:784d7819df2f9e6fcea9911ebe283d45	addForeignKeyConstraint baseTableName=completion_status, constraintName=fk_completi_fk_comple_status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-98	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.121416	109	EXECUTED	8:2cf3e9e321dae21d9f78b335b9f491dc	addForeignKeyConstraint baseTableName=crf, constraintName=fk_crf_crf_user_user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-99	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.125907	110	EXECUTED	8:04c1af1eb42ff752ab61795c0e13b4c9	addForeignKeyConstraint baseTableName=crf, constraintName=fk_crf_fk_crf_fk_status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-100	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.13047	111	EXECUTED	8:17b3dc3f2f1d2538eb9f8467b2b5b3af	addForeignKeyConstraint baseTableName=crf_version, constraintName=fk_versioni_reference_instrume, referencedTableName=crf		\N	3.6.3	\N	\N	4489977887
1236014212860-101	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.135115	112	EXECUTED	8:2b2a7dd1be174b5c352feedd8c5a7503	addForeignKeyConstraint baseTableName=crf_version, constraintName=fk_crf_vers_crf_versi_user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-102	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.139572	113	EXECUTED	8:5ead911e261260224ee47acc5f71e2f1	addForeignKeyConstraint baseTableName=crf_version, constraintName=fk_crf_vers_fk_crf_ve_status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-103	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.14377	114	EXECUTED	8:694029fd735da7a447331470dc56e85e	addForeignKeyConstraint baseTableName=dataset, constraintName=fk_dataset_fk_datase_user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-104	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.148012	115	EXECUTED	8:a6214b160a99ba3eb9a53631a4289f42	addForeignKeyConstraint baseTableName=dataset, constraintName=fk_dataset_fk_datase_status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-105	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.153355	116	EXECUTED	8:484f5148d76803addac6a31237e38b78	addForeignKeyConstraint baseTableName=dataset, constraintName=fk_dataset_fk_datase_study, referencedTableName=study		\N	3.6.3	\N	\N	4489977887
1236014212860-106	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.158013	117	EXECUTED	8:422792896040cc10697e6ac344c9607d	addForeignKeyConstraint baseTableName=dataset_crf_version_map, constraintName=fk_dataset_crf_ref_dataset, referencedTableName=dataset		\N	3.6.3	\N	\N	4489977887
1236014212860-107	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.162751	118	EXECUTED	8:33c9842f4c7133a1d757a77ef34ee4a6	addForeignKeyConstraint baseTableName=dataset_crf_version_map, constraintName=fk_dataset__ref_event_event_de, referencedTableName=event_definition_crf		\N	3.6.3	\N	\N	4489977887
1236014212860-108	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.167257	119	EXECUTED	8:c42e81434e0fed5ba3dcee85d604fcab	addForeignKeyConstraint baseTableName=dataset_filter_map, constraintName=fk_dataset_reference_dataset, referencedTableName=dataset		\N	3.6.3	\N	\N	4489977887
1236014212860-109	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.171966	120	EXECUTED	8:72a8561a4743867ec8e9d1650d05f90e	addForeignKeyConstraint baseTableName=dataset_filter_map, constraintName=fk_dataset_reference_filter, referencedTableName=filter		\N	3.6.3	\N	\N	4489977887
1236014212860-110	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.176062	121	EXECUTED	8:0d91bae01ba8d23c57145e268fc3e7e5	addForeignKeyConstraint baseTableName=dataset_study_group_class_map, constraintName=fk_dataset_study_ref_dataset, referencedTableName=dataset		\N	3.6.3	\N	\N	4489977887
1236014212860-111	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.180741	122	EXECUTED	8:c2ab431561bbd588ad05a01a1120b001	addForeignKeyConstraint baseTableName=dataset_study_group_class_map, constraintName=fk_dataset_ref_study_grp_class, referencedTableName=study_group_class		\N	3.6.3	\N	\N	4489977887
1236014212860-112	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.186543	123	EXECUTED	8:6bec0f5e3b4a1a748b4b99907f3f4b09	addForeignKeyConstraint baseTableName=dc_computed_event, constraintName=fk_dc_compu_fk_dc_com_dc_event, referencedTableName=dc_event		\N	3.6.3	\N	\N	4489977887
1236014212860-113	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.191639	124	EXECUTED	8:e0c5684bc4c492532cc5c80c378190f0	addForeignKeyConstraint baseTableName=dc_event, constraintName=fk_dc_event_fk_dc_eve_decision, referencedTableName=decision_condition		\N	3.6.3	\N	\N	4489977887
1236014212860-114	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.196063	125	EXECUTED	8:e5df907a87c0a2c471e386f798ab5f0c	addForeignKeyConstraint baseTableName=dc_primitive, constraintName=fk_dc_primi_fk_dc_pri_decision, referencedTableName=decision_condition		\N	3.6.3	\N	\N	4489977887
1236014212860-115	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.201752	126	EXECUTED	8:6d3e2ee63fe4e3782c04b0209da8ee3d	addForeignKeyConstraint baseTableName=dc_primitive, constraintName=fk_dc_primi_fk_dc_pri_item, referencedTableName=item		\N	3.6.3	\N	\N	4489977887
1236014212860-116	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.2066	127	EXECUTED	8:ad93c0a42a057e6af75bdbc1246ad543	addForeignKeyConstraint baseTableName=dc_primitive, constraintName=fk_dc_primi_fk_item_i_item, referencedTableName=item		\N	3.6.3	\N	\N	4489977887
1236014212860-117	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.211649	128	EXECUTED	8:108c87221c029437cc89bdb6ba088df9	addForeignKeyConstraint baseTableName=dc_section_event, constraintName=fk_dc_secti_fk_dc_sec_dc_event, referencedTableName=dc_event		\N	3.6.3	\N	\N	4489977887
1236014212860-118	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.21723	129	EXECUTED	8:da8faf0f2dd00016b538c10a781e1202	addForeignKeyConstraint baseTableName=dc_send_email_event, constraintName=fk_dc_send__dc_send_e_dc_event, referencedTableName=dc_event		\N	3.6.3	\N	\N	4489977887
1236014212860-119	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.222499	130	EXECUTED	8:117084b2919e8b2dfd55e7a433e1c171	addForeignKeyConstraint baseTableName=dc_substitution_event, constraintName=fk_dc_subst_fk_dc_sub_dc_event, referencedTableName=dc_event		\N	3.6.3	\N	\N	4489977887
1236014212860-120	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.227579	131	EXECUTED	8:7cd87e39f571ebb40515e24d186afcb5	addForeignKeyConstraint baseTableName=dc_substitution_event, constraintName=fk_dc_subst_fk_dc_sub_item, referencedTableName=item		\N	3.6.3	\N	\N	4489977887
1236014212860-121	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.233411	132	EXECUTED	8:7a837085d8d722840cd2e81ad995913e	addForeignKeyConstraint baseTableName=dc_summary_item_map, constraintName=fk_dc_summa_fk_dc_sum_dc_compu, referencedTableName=dc_computed_event		\N	3.6.3	\N	\N	4489977887
1236014212860-122	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.238249	133	EXECUTED	8:ccf0c6dd73dd7dea0d8584a950e1612d	addForeignKeyConstraint baseTableName=dc_summary_item_map, constraintName=fk_dc_summa_fk_dc_sum_item, referencedTableName=item		\N	3.6.3	\N	\N	4489977887
1236014212860-123	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.24307	134	EXECUTED	8:f5ef89e27a8fd3489cd19bb3323869f6	addForeignKeyConstraint baseTableName=decision_condition, constraintName=fk_decision_fk_decisi_crf_vers, referencedTableName=crf_version		\N	3.6.3	\N	\N	4489977887
1236014212860-124	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.248104	135	EXECUTED	8:033e7d8806cff79e26978f9e46663fb9	addForeignKeyConstraint baseTableName=decision_condition, constraintName=fk_decision_fk_decisi_user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-125	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.253402	136	EXECUTED	8:fbec8420757bd6febf7b891591385fad	addForeignKeyConstraint baseTableName=decision_condition, constraintName=fk_decision_fk_decisi_status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-126	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.258639	137	EXECUTED	8:fa3804dbde9a11cbacd5944b5a734ece	addForeignKeyConstraint baseTableName=discrepancy_note, constraintName=dn_discrepancy_note_type_id_fk, referencedTableName=discrepancy_note_type		\N	3.6.3	\N	\N	4489977887
1236014212860-127	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.263332	138	EXECUTED	8:55673da64417f38ab8b610b94648c66f	addForeignKeyConstraint baseTableName=discrepancy_note, constraintName=discrepancy_note_owner_id_fkey, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-128	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.268455	139	EXECUTED	8:54f7b2226f1eeb82d86fa2222d55deb4	addForeignKeyConstraint baseTableName=discrepancy_note, constraintName=dn_resolution_status_id_fkey, referencedTableName=resolution_status		\N	3.6.3	\N	\N	4489977887
1236014212860-129	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.273253	140	EXECUTED	8:beeaa6ccf41466caf49907830aef8fe4	addForeignKeyConstraint baseTableName=discrepancy_note, constraintName=discrepancy_note_study_id_fkey, referencedTableName=study		\N	3.6.3	\N	\N	4489977887
1236014212860-130	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.27787	141	EXECUTED	8:b3f322258d3e85fa30c0a796efbe459c	addForeignKeyConstraint baseTableName=dn_event_crf_map, constraintName=dn_event_crf_map_dn_id_fkey, referencedTableName=discrepancy_note		\N	3.6.3	\N	\N	4489977887
1236014212860-131	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.282505	142	EXECUTED	8:5886303880158c7f2a89457fdbb90814	addForeignKeyConstraint baseTableName=dn_event_crf_map, constraintName=dn_evnt_crf_map_evnt_crf_id_fk, referencedTableName=event_crf		\N	3.6.3	\N	\N	4489977887
1236014212860-132	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.287385	143	EXECUTED	8:8716b7587d36ee9bec873a558eb461aa	addForeignKeyConstraint baseTableName=dn_item_data_map, constraintName=dn_item_data_map_dn_id_fkey, referencedTableName=discrepancy_note		\N	3.6.3	\N	\N	4489977887
1236014212860-133	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.292695	144	EXECUTED	8:1a63ed8be239f846d65b860cd92709d5	addForeignKeyConstraint baseTableName=dn_item_data_map, constraintName=dn_itm_data_map_itm_data_id_fk, referencedTableName=item_data		\N	3.6.3	\N	\N	4489977887
1236014212860-134	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.296677	145	EXECUTED	8:758b09cd1c0a94e87010214d6c7d4f3b	addForeignKeyConstraint baseTableName=dn_study_event_map, constraintName=dn_study_event_map_dn_id_fkey, referencedTableName=discrepancy_note		\N	3.6.3	\N	\N	4489977887
1236014212860-135	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.302875	146	EXECUTED	8:a3ce6f519bc224196a0a2c3345b66c20	addForeignKeyConstraint baseTableName=dn_study_event_map, constraintName=dn_sem_study_event_id_fkey, referencedTableName=study_event		\N	3.6.3	\N	\N	4489977887
1236014212860-136	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.307864	147	EXECUTED	8:b7717ef377c43720c3966af36d256228	addForeignKeyConstraint baseTableName=dn_study_subject_map, constraintName=dn_study_subject_map_dn_id_fk, referencedTableName=discrepancy_note		\N	3.6.3	\N	\N	4489977887
1236014212860-137	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.312566	148	EXECUTED	8:6cc6e4bd76416ebfc33951427c38127c	addForeignKeyConstraint baseTableName=dn_study_subject_map, constraintName=dn_ssm_study_subject_id_fkey, referencedTableName=study_subject		\N	3.6.3	\N	\N	4489977887
1236014212860-138	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.318681	149	EXECUTED	8:abe22b5d100781a8c52ff8bd788758b5	addForeignKeyConstraint baseTableName=dn_subject_map, constraintName=dn_subject_map_dn_id_fkey, referencedTableName=discrepancy_note		\N	3.6.3	\N	\N	4489977887
1236014212860-139	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.323979	150	EXECUTED	8:5aff82860bcfc18039b2b6d92f90feaa	addForeignKeyConstraint baseTableName=dn_subject_map, constraintName=dn_subject_map_subject_id_fkey, referencedTableName=subject		\N	3.6.3	\N	\N	4489977887
1236014212860-140	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.328824	151	EXECUTED	8:db489a71831699a5021ab34b53d58c2f	addForeignKeyConstraint baseTableName=event_crf, constraintName=fk_event_cr_fk_event__completi, referencedTableName=completion_status		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-11	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.454025	651	EXECUTED	8:29f51fb38b19723cf40131acd6d60611	sql		\N	3.6.3	\N	\N	4489977887
1236014212860-141	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.333589	152	EXECUTED	8:708fc4cc3ab8c497c81e8042db324e40	addForeignKeyConstraint baseTableName=event_crf, constraintName=fk_subject_referenc_instrument, referencedTableName=crf_version		\N	3.6.3	\N	\N	4489977887
1236014212860-142	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.338543	153	EXECUTED	8:eff93ffb371dfd3875b78f46bd3e32ed	addForeignKeyConstraint baseTableName=event_crf, constraintName=fk_event_cr_fk_event__user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-143	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.343042	154	EXECUTED	8:3ba8c51488856a55c85213d4061c84c2	addForeignKeyConstraint baseTableName=event_crf, constraintName=fk_event_cr_fk_event__status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-144	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.347478	155	EXECUTED	8:71e2e06369e952fd52005a36be6ffeb7	addForeignKeyConstraint baseTableName=event_crf, constraintName=fk_event_cr_fk_event__study_ev, referencedTableName=study_event		\N	3.6.3	\N	\N	4489977887
1236014212860-145	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.353008	156	EXECUTED	8:586e39df8fb012f72b98e0836983a7a4	addForeignKeyConstraint baseTableName=event_crf, constraintName=fk_event_cr_reference_study_su, referencedTableName=study_subject		\N	3.6.3	\N	\N	4489977887
1236014212860-146	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.357826	157	EXECUTED	8:b737a81c6355360025707405fd3dcac2	addForeignKeyConstraint baseTableName=event_definition_crf, constraintName=fk_study_inst_reference, referencedTableName=crf		\N	3.6.3	\N	\N	4489977887
1236014212860-147	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.362324	158	EXECUTED	8:9c71a0de20af02fef329d5287b901ba4	addForeignKeyConstraint baseTableName=event_definition_crf, constraintName=fk_versioning_study_inst, referencedTableName=crf_version		\N	3.6.3	\N	\N	4489977887
1236014212860-148	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.370312	159	EXECUTED	8:14ceb6fe4cb45b90fbe76520a89ccc02	addForeignKeyConstraint baseTableName=event_definition_crf, constraintName=fk_event_de_study_crf_user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-149	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.37478	160	EXECUTED	8:127e91df58164417384bbf7ff8746bf1	addForeignKeyConstraint baseTableName=event_definition_crf, constraintName=fk_event_de_fk_study__status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-150	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.379126	161	EXECUTED	8:ed672069caab041c0c31f5c931c8441a	addForeignKeyConstraint baseTableName=event_definition_crf, constraintName=fk_event_de_reference_study_ev, referencedTableName=study_event_definition		\N	3.6.3	\N	\N	4489977887
1236014212860-151	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.383638	162	EXECUTED	8:02ce5e1e247373da2db3dd81845e5f71	addForeignKeyConstraint baseTableName=event_definition_crf, constraintName=fk_study_reference_instrument, referencedTableName=study		\N	3.6.3	\N	\N	4489977887
1236014212860-152	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.388664	163	EXECUTED	8:d2a67fe9543a3a16f9b17766efc35356	addForeignKeyConstraint baseTableName=filter, constraintName=fk_filter_fk_query__user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-153	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.393295	164	EXECUTED	8:c0fd1fd8b9af591af681b77e51b0632b	addForeignKeyConstraint baseTableName=filter, constraintName=fk_filter_fk_query__status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-154	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.398287	165	EXECUTED	8:b962255cfd5c5f2309ffb5b2316360c1	addForeignKeyConstraint baseTableName=filter_crf_version_map, constraintName=fk_filter_c_reference_crf_vers, referencedTableName=crf_version		\N	3.6.3	\N	\N	4489977887
1236014212860-155	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.406406	166	EXECUTED	8:270af0a70dbbff1dfb4eaa71c3400308	addForeignKeyConstraint baseTableName=filter_crf_version_map, constraintName=fk_filter_c_reference_filter, referencedTableName=filter		\N	3.6.3	\N	\N	4489977887
1236014212860-156	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.41261	167	EXECUTED	8:4ad2b50832012ba7f7fc24bd18dc11ef	addForeignKeyConstraint baseTableName=item, constraintName=fk_item_fk_item_i_item_dat, referencedTableName=item_data_type		\N	3.6.3	\N	\N	4489977887
1236014212860-157	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.418234	168	EXECUTED	8:7f42e9a4d91aeadcfbbc6863dce306d3	addForeignKeyConstraint baseTableName=item, constraintName=fk_item_fk_item_f_item_ref, referencedTableName=item_reference_type		\N	3.6.3	\N	\N	4489977887
1236014212860-158	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.423581	169	EXECUTED	8:e46042a5f6e62591a2d0e5d64b6eb6f9	addForeignKeyConstraint baseTableName=item, constraintName=fk_item_fk_item_u_user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-159	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.428279	170	EXECUTED	8:aaad7f001ba309a386f68f02deaa781e	addForeignKeyConstraint baseTableName=item, constraintName=fk_item_fk_item_s_status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-160	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.43321	171	EXECUTED	8:2434665aa599a819cb6915aa78778562	addForeignKeyConstraint baseTableName=item_data, constraintName=fk_item_reference_subject, referencedTableName=event_crf		\N	3.6.3	\N	\N	4489977887
1236014212860-161	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.438208	172	EXECUTED	8:acbc118b8dcb46b241ddd76b6bc3ce48	addForeignKeyConstraint baseTableName=item_data, constraintName=fk_answer_reference_item, referencedTableName=item		\N	3.6.3	\N	\N	4489977887
1236014212860-162	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.442728	173	EXECUTED	8:2758521afabdc918a6db68e681b4cdd7	addForeignKeyConstraint baseTableName=item_data, constraintName=fk_item_dat_fk_item_d_user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-163	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.447385	174	EXECUTED	8:a3e53d1177d299765bda5423bf27fd79	addForeignKeyConstraint baseTableName=item_data, constraintName=fk_item_dat_fk_item_d_status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-164	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.453723	175	EXECUTED	8:93357942e32539f39e92a7ce1430d76b	addForeignKeyConstraint baseTableName=item_form_metadata, constraintName=fk_item_id, referencedTableName=item		\N	3.6.3	\N	\N	4489977887
1236014212860-165	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.459707	176	EXECUTED	8:f4d83e1c13de54eee4ea263e1f4804d8	addForeignKeyConstraint baseTableName=item_form_metadata, constraintName=fk_rs_id, referencedTableName=response_set		\N	3.6.3	\N	\N	4489977887
1236014212860-166	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.465497	177	EXECUTED	8:5239a0205a65d65df485f6656e86b362	addForeignKeyConstraint baseTableName=item_form_metadata, constraintName=fk_sec_id, referencedTableName=section		\N	3.6.3	\N	\N	4489977887
1236014212860-167	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.471934	178	EXECUTED	8:416e1853b6d2db27a844d88ac9b6410f	addForeignKeyConstraint baseTableName=item_group, constraintName=fk_item_group_crf, referencedTableName=crf		\N	3.6.3	\N	\N	4489977887
1236014212860-168	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.477389	179	EXECUTED	8:14e51438b573b62b7cdb6c06497f52c4	addForeignKeyConstraint baseTableName=item_group, constraintName=fk_item_gro_fk_item_g_user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-169	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.483267	180	EXECUTED	8:5e1d6d162faa991093126c25c6372753	addForeignKeyConstraint baseTableName=item_group, constraintName=fk_item_gro_fk_item_g_status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-170	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.48967	181	EXECUTED	8:bb780d7900ecce72c99c0f739f62a6f3	addForeignKeyConstraint baseTableName=item_group_metadata, constraintName=fk_crf_metadata, referencedTableName=crf_version		\N	3.6.3	\N	\N	4489977887
1236014212860-171	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.495491	182	EXECUTED	8:50cdb140076c819efd86fed58248024e	addForeignKeyConstraint baseTableName=item_group_metadata, constraintName=fk_item_group, referencedTableName=item_group		\N	3.6.3	\N	\N	4489977887
1236014212860-172	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.50059	183	EXECUTED	8:0d6e32d61569810923d3aaad5252d0b6	addForeignKeyConstraint baseTableName=item_group_metadata, constraintName=fk_item, referencedTableName=item		\N	3.6.3	\N	\N	4489977887
1236014212860-173	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.505988	184	EXECUTED	8:7196bafac32a9de08ecc5737aead0c9e	addForeignKeyConstraint baseTableName=response_set, constraintName=fk_response_fk_respon_response, referencedTableName=response_type		\N	3.6.3	\N	\N	4489977887
1236014212860-174	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.510869	185	EXECUTED	8:67b67df0bf7ccf00b923aaf14cb471cc	addForeignKeyConstraint baseTableName=role_privilege_map, constraintName=fk_priv_id, referencedTableName=privilege		\N	3.6.3	\N	\N	4489977887
1236014212860-175	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.515489	186	EXECUTED	8:b5961da7020d64c5e931affd118db504	addForeignKeyConstraint baseTableName=role_privilege_map, constraintName=fk_role_id, referencedTableName=user_role		\N	3.6.3	\N	\N	4489977887
1236014212860-176	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.521333	187	EXECUTED	8:95ac34cbaff8c35abdcd76fff87645bf	addForeignKeyConstraint baseTableName=section, constraintName=fk_section_version, referencedTableName=crf_version		\N	3.6.3	\N	\N	4489977887
1236014212860-177	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.526692	188	EXECUTED	8:763024d732b00c0bf587dac5b4522c60	addForeignKeyConstraint baseTableName=section, constraintName=fk_section_fk_sectio_user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-178	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.531779	189	EXECUTED	8:fa0533582aa989548754d26cfe9ab79f	addForeignKeyConstraint baseTableName=section, constraintName=fk_section_fk_sectio_status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-179	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.537268	190	EXECUTED	8:658584378cf05f956fabf3251b6d2030	addForeignKeyConstraint baseTableName=study, constraintName=fk_study_fk_study__user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-180	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.542681	191	EXECUTED	8:b026736c60bd4a8061e6b87f74d5c5d5	addForeignKeyConstraint baseTableName=study, constraintName=PROJECT_IS_CONTAINED_WITHIN_PA, referencedTableName=study		\N	3.6.3	\N	\N	4489977887
1236014212860-181	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.547599	192	EXECUTED	8:40c509d963ba8550383cb96e8a51ed71	addForeignKeyConstraint baseTableName=study, constraintName=fk_study_fk_study__status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-182	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.553163	193	EXECUTED	8:b225e2b2c8a493540da1c6e8a55e0180	addForeignKeyConstraint baseTableName=study, constraintName=fk_study_type, referencedTableName=study_type		\N	3.6.3	\N	\N	4489977887
1236014212860-183	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.558515	194	EXECUTED	8:a547c33f2a87cfda82ba69e2b0880c3c	addForeignKeyConstraint baseTableName=study_event, constraintName=fk_study_ev_fk_study__user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-184	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.563081	195	EXECUTED	8:fba528a262b0ad6f688fff651b7c806e	addForeignKeyConstraint baseTableName=study_event, constraintName=fk_study_ev_fk_study__status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-185	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.567954	196	EXECUTED	8:37d2af747ca09dbc4896c8d9baf905ab	addForeignKeyConstraint baseTableName=study_event, constraintName=fk_study_ev_fk_study__study_ev, referencedTableName=study_event_definition		\N	3.6.3	\N	\N	4489977887
1236014212860-186	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.572733	197	EXECUTED	8:8a268e6d14026d111d531680dcabcb01	addForeignKeyConstraint baseTableName=study_event, constraintName=fk_study_ev_reference_study_su, referencedTableName=study_subject		\N	3.6.3	\N	\N	4489977887
1236014212860-187	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.577362	198	EXECUTED	8:daa94b0109ec79110712f8cabddeb5e8	addForeignKeyConstraint baseTableName=study_event_definition, constraintName=fk_study_ev_fk_studye_user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-188	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.582058	199	EXECUTED	8:d319fba9e1c911f3b44d698101780001	addForeignKeyConstraint baseTableName=study_event_definition, constraintName=fk_study_ev_fk_studye_status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-189	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.587684	200	EXECUTED	8:ffb58bfdba7a2a915364641868ced2bc	addForeignKeyConstraint baseTableName=study_event_definition, constraintName=FK_STUDY_EV_FK_STUDY__STUDY, referencedTableName=study		\N	3.6.3	\N	\N	4489977887
1236014212860-190	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.592494	201	EXECUTED	8:5e397541082c45334d23b2522663380b	addForeignKeyConstraint baseTableName=study_group, constraintName=fk_group_class_study_group, referencedTableName=study_group_class		\N	3.6.3	\N	\N	4489977887
1235684743487-115	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.843368	266	MARK_RAN	8:a75887dad929337403ff840c552fff79	sql		\N	3.6.3	\N	\N	4489977887
1236014212860-191	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.597722	202	EXECUTED	8:ba5fc8c611acf6cab75249a869685adc	addForeignKeyConstraint baseTableName=study_group_class, constraintName=fk_study_gr_fk_study__group_ty, referencedTableName=group_class_types		\N	3.6.3	\N	\N	4489977887
1236014212860-192	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.603253	203	EXECUTED	8:e0e5474a511c4bc3283bbf9eae8f3278	addForeignKeyConstraint baseTableName=study_group_class, constraintName=fk_study_gr_fk_study__user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-193	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.608109	204	EXECUTED	8:76a9959a7f912c02fe495059d374bedd	addForeignKeyConstraint baseTableName=study_group_class, constraintName=fk_study_gr_fk_study__status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-194	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.613182	205	EXECUTED	8:5b1a123b41b42294fb7c49590a965f62	addForeignKeyConstraint baseTableName=study_parameter_value, constraintName=study_param_value_param_fkey, referencedTableName=study_parameter		\N	3.6.3	\N	\N	4489977887
1236014212860-195	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.6186	206	EXECUTED	8:90d2cd232a5877273732af59eeb5724a	addForeignKeyConstraint baseTableName=study_parameter_value, constraintName=study_param_value_study_id_fk, referencedTableName=study		\N	3.6.3	\N	\N	4489977887
1236014212860-196	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.623568	207	EXECUTED	8:0f4bb01382b2693f900c2b12f5642ed5	addForeignKeyConstraint baseTableName=study_subject, constraintName=fk_study_su_fk_study__user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-197	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.628473	208	EXECUTED	8:d950507bf627a6cd6df4cda151da915f	addForeignKeyConstraint baseTableName=study_subject, constraintName=fk_study_su_fk_study__status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-198	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.633739	209	EXECUTED	8:5faf573679909033c358825fb1221686	addForeignKeyConstraint baseTableName=study_subject, constraintName=fk_project__reference_study2, referencedTableName=study		\N	3.6.3	\N	\N	4489977887
1236014212860-199	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.638927	210	EXECUTED	8:0c6146baee4bf1ab070c6c2274d9b53e	addForeignKeyConstraint baseTableName=study_subject, constraintName=fk_study_reference_subject, referencedTableName=subject		\N	3.6.3	\N	\N	4489977887
1236014212860-200	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.643916	211	EXECUTED	8:bc8f4605f0be91009762750f7e2de0ec	addForeignKeyConstraint baseTableName=study_user_role, constraintName=fk_study_us_study_use_user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-201	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.64882	212	EXECUTED	8:5300222041ea79d3c20f7d34be7810c5	addForeignKeyConstraint baseTableName=study_user_role, constraintName=fk_study_us_fk_study__status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-202	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.654631	213	EXECUTED	8:a8c1c485c719e872e90a19a7fc9c8249	addForeignKeyConstraint baseTableName=study_user_role, constraintName=fk_person_role_study_id, referencedTableName=study		\N	3.6.3	\N	\N	4489977887
1236014212860-203	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.663914	214	EXECUTED	8:cc245ff4851d9bda30393dfaf70a45a8	addForeignKeyConstraint baseTableName=subject, constraintName=HAS_FATHER, referencedTableName=subject		\N	3.6.3	\N	\N	4489977887
1236014212860-204	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.669276	215	EXECUTED	8:c65aa2c1c0e5b399cc91416e9320bff3	addForeignKeyConstraint baseTableName=subject, constraintName=HAS_MOTHER, referencedTableName=subject		\N	3.6.3	\N	\N	4489977887
1236014212860-205	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.675104	216	EXECUTED	8:c19643b8fee32b180fd3e17a2098a54f	addForeignKeyConstraint baseTableName=subject, constraintName=fk_subject_fk_subjec_user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-206	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.68024	217	EXECUTED	8:7cb70adc9fb9eb3646e97085a76b5c70	addForeignKeyConstraint baseTableName=subject, constraintName=fk_subject_fk_subjec_status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-207	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.685608	218	EXECUTED	8:c4327ab0cf4dba9394fa8d769485b56c	addForeignKeyConstraint baseTableName=subject_group_map, constraintName=fk_subject__fk_sub_gr_user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-208	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.691197	219	EXECUTED	8:4675a4ed5a4494748cb6c96cc4620b73	addForeignKeyConstraint baseTableName=subject_group_map, constraintName=fk_subject__fk_subjec_status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-209	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.696208	220	EXECUTED	8:dcd61b3af42dd54b5005db1ac3817b2c	addForeignKeyConstraint baseTableName=subject_group_map, constraintName=fk_subject__fk_subjec_study_gr, referencedTableName=study_group_class		\N	3.6.3	\N	\N	4489977887
1236014212860-210	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.70134	221	EXECUTED	8:26b87f20cabf9d776441cae4541b3c85	addForeignKeyConstraint baseTableName=subject_group_map, constraintName=fk_subject__fk_subjec_group_ro, referencedTableName=study_group		\N	3.6.3	\N	\N	4489977887
1236014212860-211	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.706702	222	EXECUTED	8:e00b9266b75630dcda467bfa0e38f29b	addForeignKeyConstraint baseTableName=subject_group_map, constraintName=fk_subject__subject_g_study_su, referencedTableName=study_subject		\N	3.6.3	\N	\N	4489977887
1236014212860-212	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.711402	223	EXECUTED	8:b4ea0f0888616c020449a7f668275866	addForeignKeyConstraint baseTableName=user_account, constraintName=fk_user_acc_fk_user_f_user_acc, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1236014212860-213	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.716426	224	EXECUTED	8:5670df208d3f80311b55312381fcdcf5	addForeignKeyConstraint baseTableName=user_account, constraintName=fk_user_acc_status_re_status, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
1236014212860-214	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.72165	225	EXECUTED	8:e443b38ca43d7f66603caad35f73aef6	addForeignKeyConstraint baseTableName=user_account, constraintName=fk_user_acc_ref_user__user_typ, referencedTableName=user_type		\N	3.6.3	\N	\N	4489977887
1236014212860-215	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.72669	226	EXECUTED	8:a8c0325992bf1c8c5203d6935e9b1a23	addForeignKeyConstraint baseTableName=versioning_map, constraintName=fk_versioni_fk_versio_crf_vers, referencedTableName=crf_version		\N	3.6.3	\N	\N	4489977887
1236014212860-216	pgawade (generated)	migration/2.5/changeLogCreateTables.xml	2025-11-30 08:06:19.731409	227	EXECUTED	8:8fcbdd127ad819b84f765818ce66cbc3	addForeignKeyConstraint baseTableName=versioning_map, constraintName=fk_versioni_fk_versio_item, referencedTableName=item		\N	3.6.3	\N	\N	4489977887
1235684743487-358	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.738892	228	EXECUTED	8:b8e68de4d2d9162edf55c108fc2f92fd	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-359	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.743604	229	EXECUTED	8:e492bba351691f46cf5d3b4ca3541535	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-360	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.747443	230	EXECUTED	8:e20b2c3a817a2fa7e2876994f84c8fa0	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-361	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.751748	231	EXECUTED	8:546d7f5229badfc53a98861303be6164	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-362	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.75738	232	EXECUTED	8:6f1b401f214247a8ab064702a71e47c9	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-363	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.761923	233	EXECUTED	8:f2738be0a0b626c2505c5ea830c10077	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-364	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.765898	234	EXECUTED	8:f7de76bd05378289d1ba8efe5be6390e	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-365	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.769862	235	EXECUTED	8:1aa66d188d2fea929ea6d2a36798d514	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-366	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.773919	236	EXECUTED	8:fe141d6b17e807e11aebef61816ce663	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-367	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.778653	237	EXECUTED	8:f902670329ff6dbeb67fbe094f5a4140	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-368	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.782954	238	EXECUTED	8:19ddc561cc9b4b06bdc8e67bce13b383	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-369	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.7868	239	EXECUTED	8:a0670abc6cc8b73f07b78c70e3c7a1a0	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-370	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.790836	240	EXECUTED	8:95a771dbd88b01b8537376a041a9e474	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-371	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.795857	241	EXECUTED	8:6593180872df00c572effc89a3c1e092	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-93	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.797582	242	MARK_RAN	8:6ed7e18af5415d38f0aaea6fd814a8e9	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-94	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.799469	243	MARK_RAN	8:7079d556d3e42461500fb1cd0720fc50	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-95	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.80157	244	MARK_RAN	8:274be231b79fe6546b438180b1f4a517	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-96	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.803542	245	MARK_RAN	8:34eb9f3bb37b5fb4de0765f73a32d397	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-97	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.805312	246	MARK_RAN	8:ac345c5e9effa5e3bdfc7c0e8ad488f6	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-155	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.807087	247	MARK_RAN	8:c52952721682d0b710565dbc9e8a3bed	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-98	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.809122	248	MARK_RAN	8:eb1286ec8b7387d61e57176b31338450	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-99	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.810771	249	MARK_RAN	8:c46b27579042ffbd8081dacef97ce7d9	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-100	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.812341	250	MARK_RAN	8:10fc09edcc2097dd2e21624a7f443a49	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-101	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.813925	251	MARK_RAN	8:1a4a683639c966868cc4462133f5f4bd	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-102	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.815602	252	MARK_RAN	8:d88b2dfb38699046bbe01d2c36e0bd74	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-103	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.817886	253	MARK_RAN	8:da3e02bd109d2eba7a3478b8ddcd8f35	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-104	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.820337	254	MARK_RAN	8:3e3db750b9e3f1c7732f21beeab2075e	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-105	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.822348	255	MARK_RAN	8:aa740982a69b037d71a14abf86309c9e	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-106	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.82459	256	MARK_RAN	8:7474ffca613a9b8bf866e9fefba51a9d	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-107	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.826761	257	MARK_RAN	8:17e93919e8c6775504b3fce227d7167e	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-108	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.828521	258	MARK_RAN	8:3cc11789d6bd4f8a62f55ca7d96eedbd	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-109	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.830256	259	MARK_RAN	8:b19884d5119e575cdd05aa8912ed703d	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-110	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.832206	260	MARK_RAN	8:9b73bd57d023dc187a14704a81217960	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-111	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.834379	261	MARK_RAN	8:a869d6ebacc872a45b63d9b8f31b3e94	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-112	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.836418	262	MARK_RAN	8:ccdb56856b01f716423f899b7640621c	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-113	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.838246	263	MARK_RAN	8:a8d67d2d4865df30a749b045698babdf	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-380	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.839971	264	MARK_RAN	8:68c0bba17f8a8d7f15ebbbba4df1b16a	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-114	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.841772	265	MARK_RAN	8:6d5839d126b6b8077664ac915a2e2ffe	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-116	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.844968	267	MARK_RAN	8:a9a25772fc0cac4ffb62649e33ef596b	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-117	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.846532	268	MARK_RAN	8:26a826cac4bd650f87fc29b96f260b73	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-118	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.84832	269	MARK_RAN	8:f44d995a17b91ffa608dd0696cb29dee	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-119	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.85039	270	MARK_RAN	8:0e5a1f7decad7c9bd02b9a2e727d2134	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-120	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.85253	271	MARK_RAN	8:9adc90e9a658bd23dd07c27fd6abec7c	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-388	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.854471	272	MARK_RAN	8:50c0d4e159dd41dec4a54e68b7946575	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-121	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.856226	273	MARK_RAN	8:65fc4e704d667f5ec1b2f51b723dcd7a	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-122	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.857947	274	MARK_RAN	8:59dafac03ddf130c67ca3a58c628ca15	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-123	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.859626	275	MARK_RAN	8:8cb55c0265c69074f04edc3cbcbf630b	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-124	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.861214	276	MARK_RAN	8:0250fecbdb17b84ecf4f051c4dbd6d86	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-125	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.862812	277	MARK_RAN	8:7a1a26da141cf35b38013a4afc23ec76	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-126	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.864395	278	MARK_RAN	8:49129a7a3458d7e2fd210d764898d8a6	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-127	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.866058	279	MARK_RAN	8:49a644cd4014584605ba9e487902ade9	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-128	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.86801	280	MARK_RAN	8:81bfe156bd8738bc76a26e616a3cd0fa	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-129	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.869877	281	MARK_RAN	8:94e6cffb6db80079b8597174e0acec81	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-130	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.871617	282	MARK_RAN	8:71e6286fa0f831b7f64225ed5ff64e09	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-131	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.873415	283	MARK_RAN	8:5e88ad64f206b6ea1f322d827b865da7	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-132	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.875102	284	MARK_RAN	8:5e292e6216ba161ca20928d62a6abf9d	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-133	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.876732	285	MARK_RAN	8:baca8fceba5b0b6107ace237dc70f846	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-134	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.878263	286	MARK_RAN	8:8cc148883c2c59822f39b8646e6a5237	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-135	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.879836	287	MARK_RAN	8:881151f70f9a6bef716f65de23446105	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-136	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.881407	288	MARK_RAN	8:da691c1f251c8dad3eab02afcc637055	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-137	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.883396	289	MARK_RAN	8:4a51efd714a3413ece8aa17a68567280	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-138	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.885277	290	MARK_RAN	8:ef04b4a2e298c2d80ebfbab8cfa48a05	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-139	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.887001	291	MARK_RAN	8:d718966d59bf951ede52c3f1e9861c48	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-140	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.888697	292	MARK_RAN	8:e8f54d473f28d89ae92923aeff63e233	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-141	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.890312	293	MARK_RAN	8:68b1e195994272784aae1fc0b89350c7	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-142	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.891848	294	MARK_RAN	8:b952246da098df2b91f2b6914a543165	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-143	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.893458	295	MARK_RAN	8:0ba81ba39c9f9b329ec0fde7d01d6af5	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-144	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.895018	296	MARK_RAN	8:3328f6be87fb7e248a03945c855ba584	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-145	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.896587	297	MARK_RAN	8:41d82d3e97b2be939ae80e45320f7687	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-146	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.898324	298	MARK_RAN	8:a2d57cc7a9498b013e6771fd4755586d	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-147	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.900295	299	MARK_RAN	8:8182bcefe02ef55616c0e6ecfa96d007	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-148	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.902607	300	MARK_RAN	8:1258d24ffa5e818b12ec9cad771ae351	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-149	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.904534	301	MARK_RAN	8:99ae1825232d2c13150be1cc07cad917	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-150	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.906329	302	MARK_RAN	8:9d4df8e91729916cdd091cf112bc82ed	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-151	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.908129	303	MARK_RAN	8:a1e88d711b3deff36e0708ffc5d9a506	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-152	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.909808	304	MARK_RAN	8:b4044b08328e755b92db5332f17d76c0	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-373	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.91154	305	MARK_RAN	8:fa63a466def347227491c42729ac1a68	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-374	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.913164	306	MARK_RAN	8:f6bd4a186f2281ca7124f0660fcfa1b6	sql		\N	3.6.3	\N	\N	4489977887
1236096695424-291	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.91481	307	MARK_RAN	8:f450dc954965c2c457bbf16ff2a4a169	createSequence sequenceName=ARCHIVED_DATASET_FILE_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-292	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.916738	308	MARK_RAN	8:46051e8fd8efd31769a4cdd9d6b37963	createSequence sequenceName=AUDIT_EVENT_VAL_AUDIT_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-293	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.918705	309	MARK_RAN	8:751580644ff46893101c672a1cce8e58	createSequence sequenceName=AUDIT_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-294	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.92056	310	MARK_RAN	8:fec67954d4b0df0cc8790349bb65946a	createSequence sequenceName=AUDIT_LOG_EVENT_AUDIT_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-295	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.922263	311	MARK_RAN	8:5bc1df8a708533fa7fc056f72e0c9adc	createSequence sequenceName=AUDIT_LOG_EVENT_TYPE_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-296	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.923911	312	MARK_RAN	8:5a8032c49d578adb14d1b977149274a4	createSequence sequenceName=COMPLETION_STATUS_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-297	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.925772	313	MARK_RAN	8:0453004e649f53534d26040306ce0d46	createSequence sequenceName=CRF_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-298	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.927697	314	MARK_RAN	8:6cc9397f759d53261f3446c9200fbd2e	createSequence sequenceName=CRF_VERSION_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-299	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.929336	315	MARK_RAN	8:3e0c57739e7748ad7011ac40536f0712	createSequence sequenceName=DATASET_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-300	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.930829	316	MARK_RAN	8:cb55b07359d980f0e95ad53154b29afc	createSequence sequenceName=DC_EVENT_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-301	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.932306	317	MARK_RAN	8:50b1a3171db1d5b09dbdfa84b10be3d0	createSequence sequenceName=DC_PRIMITIVE_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-302	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.933978	318	MARK_RAN	8:0743ea4ca2a0ac8529a272a4dd63d427	createSequence sequenceName=DC_SECTION_EVENT_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-303	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.935649	319	MARK_RAN	8:4218c5c80c433bc0eb09c07fccbe42b5	createSequence sequenceName=DC_SEND_EMAIL_EVENT_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-304	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.937243	320	MARK_RAN	8:1327eb1eb1bc141e67eabfccb7ee1d13	createSequence sequenceName=DC_SUBSTITUTION_EVENT_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-305	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.938736	321	MARK_RAN	8:ace13022fb6d87acb02e51e7980c1e13	createSequence sequenceName=DC_SUMMARY_EVENT_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-306	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.940237	322	MARK_RAN	8:29ce5f97186e2761f4326ba274142a80	createSequence sequenceName=DECISION_CONDITION_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-307	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.941737	323	MARK_RAN	8:21b2863b40865e7c309223a4f00ce0b6	createSequence sequenceName=DISCREPANCY_NOTE_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-308	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.94318	324	MARK_RAN	8:c9075bb86d85f84b4bdcf45a52a8eee8	createSequence sequenceName=DISCREPANCY_NOTE_TYPE_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-309	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.944681	325	MARK_RAN	8:53e3bfa37d009c91267c553cb95c9920	createSequence sequenceName=EVENT_CRF_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-310	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.946121	326	MARK_RAN	8:a8b80c54bfd747a79784f83e70791f61	createSequence sequenceName=EVENT_DEFINITION_CRF_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-311	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.947565	327	MARK_RAN	8:099c378b2925fea90f45845fd53e4a78	createSequence sequenceName=EXPORT_FORMAT_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-312	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.949001	328	MARK_RAN	8:2c26eeea393c6b8d86d17526f2d1cbdd	createSequence sequenceName=FILTER_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-313	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.951492	329	MARK_RAN	8:f21ab24ca9730ba5c52e0d9ab29cc282	createSequence sequenceName=GROUP_CLASS_TYPE_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-314	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.953129	330	MARK_RAN	8:fcb6d90c25a6cc5f306ebe26307cc5fa	createSequence sequenceName=ITEM_DATA_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-315	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.954755	331	MARK_RAN	8:2db69a3e1d6ef2bf80deca40af4174f2	createSequence sequenceName=ITEM_DATA_TYPE_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-316	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.9566	332	MARK_RAN	8:fb011b418ffcfd38f745959bd9ab56c6	createSequence sequenceName=ITEM_FORM_METADATA_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-317	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.958271	333	MARK_RAN	8:6d0e86d957a101ed0bd035193299ef39	createSequence sequenceName=ITEM_GROUP_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-318	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.960049	334	MARK_RAN	8:c13a33eb69c73df25833ec2be8ee82c7	createSequence sequenceName=ITEM_GROUP_METADATA_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-319	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.961778	335	MARK_RAN	8:6de055922443a3c12ab5dbe970627f5d	createSequence sequenceName=ITEM_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-320	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.963873	336	MARK_RAN	8:b2e8fba8a593e996ac24224590ce5578	createSequence sequenceName=ITEM_REFERENCE_TYPE_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-321	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.965489	337	MARK_RAN	8:7437f48c5b56544b8b0d2374f37b7572	createSequence sequenceName=NULL_VALUE_TYPE_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-322	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.967307	338	MARK_RAN	8:9860e704669fec84d7a088738a6de9ce	createSequence sequenceName=PRIV_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-323	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.969255	339	MARK_RAN	8:3c70fa00c20743c4041a8ed17b7019d6	createSequence sequenceName=RESOLUTION_STATUS_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-324	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.971264	340	MARK_RAN	8:87f6621ee901dadd85c450cd346468fc	createSequence sequenceName=RESPONSE_SET_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-325	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.973081	341	MARK_RAN	8:f4f691bae3d0276abca4b8d2fc0281c2	createSequence sequenceName=RESPONSE_TYPE_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-326	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.974803	342	MARK_RAN	8:24235070e4bfc01d9ef42df7edbe71ea	createSequence sequenceName=ROLE_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-327	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.976472	343	MARK_RAN	8:cce95af06dcf0bc3ac0859e4175c4c23	createSequence sequenceName=RULE_ACTION_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-328	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.97818	344	MARK_RAN	8:735a7c365758a1d922c40600f6ddc78c	createSequence sequenceName=RULE_EXPRESSION_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-329	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.979829	345	MARK_RAN	8:19ab601b1ccf43ec62316608ebf28e33	createSequence sequenceName=RULE_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-330	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.981435	346	MARK_RAN	8:a124b8e229866cc7db2abb9b31428c50	createSequence sequenceName=RULE_SET_AUDIT_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-331	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.983425	347	MARK_RAN	8:301f109c6b899a751e7ec566fe86326b	createSequence sequenceName=RULE_SET_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-332	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.985478	348	MARK_RAN	8:e377deeb9c7cb140a9c9890d9b165247	createSequence sequenceName=RULE_SET_RULE_AUDIT_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-333	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.987499	349	MARK_RAN	8:ffaaafe304ba9f7bb7a532e12ae0ead3	createSequence sequenceName=RULE_SET_RULE_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-334	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.989286	350	MARK_RAN	8:aaad01bccc4359f30f1195c430dfb3cc	createSequence sequenceName=SECTION_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-335	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.990936	351	MARK_RAN	8:ab40618e2313804a2847ce0290bd9583	createSequence sequenceName=STATUS_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-336	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.992541	352	MARK_RAN	8:6d2953e5129dd8e252719d3acfe6b99e	createSequence sequenceName=STUDY_EVENT_DEFINITION_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-337	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.994303	353	MARK_RAN	8:1e23ba7713289c1599df1311cedb9b57	createSequence sequenceName=STUDY_EVENT_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-338	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.996093	354	MARK_RAN	8:086eb6fdfe2f22a3ab519cf9df0e819e	createSequence sequenceName=STUDY_GROUP_CLASS_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-339	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.99788	355	MARK_RAN	8:a44ea87deb51446da07ce738fa51c475	createSequence sequenceName=STUDY_GROUP_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-340	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:19.999959	356	MARK_RAN	8:74bbed9512633ea6e641c4a643b52fdd	createSequence sequenceName=STUDY_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-341	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:20.002041	357	MARK_RAN	8:a4a733f72269890feb6230e4188b8e9a	createSequence sequenceName=STUDY_PARAMETER_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-342	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:20.003961	358	MARK_RAN	8:c138043618eaab923c8d0b28c0ca95a3	createSequence sequenceName=STUDY_PARAMETER_VALUE_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-343	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:20.00583	359	MARK_RAN	8:2d21a92a2dd3dc6e0520f08dbaa321d8	createSequence sequenceName=STUDY_SUBJECT_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-344	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:20.007521	360	MARK_RAN	8:6e150d9d34650119793c939fb7711f55	createSequence sequenceName=STUDY_TYPE_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-345	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:20.009047	361	MARK_RAN	8:54019e54403cea853e8c5dda29e824d6	createSequence sequenceName=SUBJECT_EVENT_STATUS_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-346	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:20.010644	362	MARK_RAN	8:50056459f6c199fe020f519c219bbe22	createSequence sequenceName=SUBJECT_GROUP_MAP_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-347	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:20.012236	363	MARK_RAN	8:11852c0910e095f9a2f386907d15a008	createSequence sequenceName=SUBJECT_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-348	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:20.013802	364	MARK_RAN	8:9def6fcc2b62b90fb5084cfc512d6ac4	createSequence sequenceName=USER_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-349	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:20.015295	365	MARK_RAN	8:c5787b151c94a84a6a24123e3c4af1b7	createSequence sequenceName=USER_TYPE_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-350	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:20.016904	366	MARK_RAN	8:9648255423283ac79ea119d74dfefcbe	createSequence sequenceName=USAGE_STATISTICS_DATA_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1236096695424-351	pgawade (generated)	migration/2.5/changeLogCreateFunctions.xml	2025-11-30 08:06:20.018644	367	MARK_RAN	8:a1ff029fb778ce1a43907168c3c1ef97	createSequence sequenceName=OPENCLINICA_VERSION_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1235684743487-217	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.021985	368	EXECUTED	8:f9bcc0a9e34cd3a7bc8574452ebb2084	insert tableName=status		\N	3.6.3	\N	\N	4489977887
1235684743487-218	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.024545	369	EXECUTED	8:4a4dcbaf3df122c20637633cdd60302e	insert tableName=status		\N	3.6.3	\N	\N	4489977887
1235684743487-219	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.02713	370	EXECUTED	8:53188602c5fe66d9090d7963a7d5a29e	insert tableName=status		\N	3.6.3	\N	\N	4489977887
1235684743487-220	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.029696	371	EXECUTED	8:e114aa055dd251c2330f360afa08f9ad	insert tableName=status		\N	3.6.3	\N	\N	4489977887
1235684743487-221	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.032428	372	EXECUTED	8:5d7203fa1daef39eaefe7b504033fde3	insert tableName=status		\N	3.6.3	\N	\N	4489977887
1235684743487-222	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.035478	373	EXECUTED	8:71a95dc36e0b2d86ebd563d8f8202631	insert tableName=status		\N	3.6.3	\N	\N	4489977887
1235684743487-223	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.03819	374	EXECUTED	8:453867bd02ebe3aab16692ac13ca631d	insert tableName=status		\N	3.6.3	\N	\N	4489977887
1235684743487-224	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.040764	375	EXECUTED	8:56e944d178da8633366e2171ea9fb2d3	insert tableName=status		\N	3.6.3	\N	\N	4489977887
1235684743487-225	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.043627	376	EXECUTED	8:a7afda9833f2bbb6e7f335f9aad7520f	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-226	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.046143	377	EXECUTED	8:f7849dda0c0131d521c544d21f5e78d5	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-227	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.048826	378	EXECUTED	8:c9e2f82b22766f03288e0a1285aeb992	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-228	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.053557	379	EXECUTED	8:e9262fc73f6197d8a5e0456b4c6666c2	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-229	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.05659	380	EXECUTED	8:1544ffd2c832fbad4c652a9f6e29c0e5	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-230	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.059542	381	EXECUTED	8:d465c89f1aaf8070873913d792eeb7ea	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-231	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.062101	382	EXECUTED	8:ef1bd6ffad08208290e07ad2a9eb4cb5	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-232	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.064866	383	EXECUTED	8:0ad7754f6394e20eff685b5dc68ade42	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-233	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.068242	384	EXECUTED	8:cbb911df6407e26140509dfb789dafbc	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-234	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.072208	385	EXECUTED	8:298c81244a8401c3c16f7d493a55b8af	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-235	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.076067	386	EXECUTED	8:ad119a1c53c2e5bfc5dab73d9470fc55	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-237	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.078869	387	EXECUTED	8:86116daa91eb038f13d1e2ed26c73ffd	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-238	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.081893	388	EXECUTED	8:bcafddbcd00e606beaf6209691d42ae4	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-239	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.084981	389	EXECUTED	8:9b8b442f9baccb1b1bfb68f8cb99582d	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-240	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.087948	390	EXECUTED	8:5d61f82c6e01bbdd2fed3991d08c5afe	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-241	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.091438	391	EXECUTED	8:af04c6bbcbada633adfd8b37a168ff46	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-242	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.094695	392	EXECUTED	8:ece323c835e27d9f6e4357328db560fa	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-243	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.097727	393	EXECUTED	8:37887199bcda62329b58a359ef9bd030	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-244	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.100988	394	EXECUTED	8:40f23046cd2a4fbb367df3945ce9fe3e	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-245	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.104139	395	EXECUTED	8:85a4040883337100cbaee0ef5a9b9da9	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-246	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.107195	396	EXECUTED	8:8765ea2e549f82e1af0ebe489b3cbc6d	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-247	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.110169	397	EXECUTED	8:9f4114e0513bf879cf88e8b2e1f3b3d0	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-248	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.113302	398	EXECUTED	8:60e4322ed5300c22802f50f2f8692dc2	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-249	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.116498	399	EXECUTED	8:7afd71c14b14bd96bb929ad2c4bda03f	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-250	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.120175	400	EXECUTED	8:3110a3a4da9b95ea0e6055d9ea50c992	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-251	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.123138	401	EXECUTED	8:22bac96fac58913b28a2fcb2593fc272	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-252	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.125965	402	EXECUTED	8:0443bdebc29725c327ff14b2ef58ff5d	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-253	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.129168	403	EXECUTED	8:bd2ccca635527d870f9cbef1d83624be	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-254	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.13251	404	EXECUTED	8:1a203659a9d1b9d5b3a2c6dd7d5b3c16	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-255	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.136144	405	EXECUTED	8:9c9a507a6a17d10796918b4e90a176f2	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
1235684743487-256	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.139151	406	EXECUTED	8:7d5de7c41a8abe493b1cb703bb573b26	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-7	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.428976	647	EXECUTED	8:332540fbc218622298ae9a66170ad084	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-257	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.14247	407	EXECUTED	8:ea020a68aa2dc2e5a91040a042f494af	insert tableName=subject_event_status		\N	3.6.3	\N	\N	4489977887
1235684743487-258	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.145165	408	EXECUTED	8:40a0e3e1429f0974919583a70383a558	insert tableName=subject_event_status		\N	3.6.3	\N	\N	4489977887
1235684743487-259	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.147689	409	EXECUTED	8:7f3b4df912792f2c6a064e954a5a4c27	insert tableName=subject_event_status		\N	3.6.3	\N	\N	4489977887
1235684743487-260	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.151178	410	EXECUTED	8:587de459368e957e1d26ea52d2a4efc9	insert tableName=subject_event_status		\N	3.6.3	\N	\N	4489977887
1235684743487-261	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.154306	411	EXECUTED	8:c4280f9be3ae0a1325ff222d04f3b869	insert tableName=subject_event_status		\N	3.6.3	\N	\N	4489977887
1235684743487-262	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.157259	412	EXECUTED	8:6bcfb3988b8a742f36ae1ac34664ec5c	insert tableName=subject_event_status		\N	3.6.3	\N	\N	4489977887
1235684743487-263	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.160363	413	EXECUTED	8:ba0f1ffa4b518dd35a760066c124090a	insert tableName=subject_event_status		\N	3.6.3	\N	\N	4489977887
1235684743487-264	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.163196	414	EXECUTED	8:52daed60dd6e08bea8771f0e05f989fa	insert tableName=subject_event_status		\N	3.6.3	\N	\N	4489977887
1235684743487-265	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.166429	415	EXECUTED	8:a74d90c0de4199e192ad0abe82744c6f	insert tableName=response_type		\N	3.6.3	\N	\N	4489977887
1235684743487-266	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.169828	416	EXECUTED	8:816daeb98044de9d75843f281be36f0c	insert tableName=response_type		\N	3.6.3	\N	\N	4489977887
1235684743487-267	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.172815	417	EXECUTED	8:9ca78dc1d4f210a6a39292528755eb9c	insert tableName=response_type		\N	3.6.3	\N	\N	4489977887
1235684743487-268	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.17568	418	EXECUTED	8:d5262bb385867b8d77621a36167f8c49	insert tableName=response_type		\N	3.6.3	\N	\N	4489977887
1235684743487-269	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.178387	419	EXECUTED	8:d03b46e2090bd53de739e0ba62c7f242	insert tableName=response_type		\N	3.6.3	\N	\N	4489977887
1235684743487-270	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.181282	420	EXECUTED	8:4b2262e5985684a44344599800689b6b	insert tableName=response_type		\N	3.6.3	\N	\N	4489977887
1235684743487-271	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.184773	421	EXECUTED	8:cb6069e67980874b9fb0d6a023da5e34	insert tableName=response_type		\N	3.6.3	\N	\N	4489977887
1235684743487-272	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.187807	422	EXECUTED	8:ea8a07ca02148056a5a5b429b78c0544	insert tableName=response_type		\N	3.6.3	\N	\N	4489977887
1235684743487-273	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.190429	423	EXECUTED	8:0b62ba6956395d6c24e5c409b5c8ecd5	insert tableName=response_type		\N	3.6.3	\N	\N	4489977887
1235684743487-274	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.193433	424	EXECUTED	8:27274b9bb65ff8c60fa89656dbe73a4e	insert tableName=user_type		\N	3.6.3	\N	\N	4489977887
1235684743487-275	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.196201	425	EXECUTED	8:c89e895eb241cf188089bc58795b19a1	insert tableName=user_type		\N	3.6.3	\N	\N	4489977887
1235684743487-276	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.198663	426	EXECUTED	8:3df9aa9f27c7f3317e6b23fb9d2df245	insert tableName=user_type		\N	3.6.3	\N	\N	4489977887
1235684743487-277	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.201897	427	EXECUTED	8:4b3252e9c7dd5f4fa56c3e722b91f34e	insert tableName=study_type		\N	3.6.3	\N	\N	4489977887
1235684743487-278	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.204755	428	EXECUTED	8:fa34ea59d1a40dc0dc8701a8b1aede39	insert tableName=study_type		\N	3.6.3	\N	\N	4489977887
1235684743487-279	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.208636	429	EXECUTED	8:c21473f9e55dce6ef9d0417bcc7a1740	insert tableName=user_account		\N	3.6.3	\N	\N	4489977887
1235684743487-279-1	kkrumlian	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.211741	430	EXECUTED	8:48f3d2a02d2b5b3f07fe64d06e64fdcf	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-279-2	kkrumlian	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.213287	431	MARK_RAN	8:88de093f5891a1813e52b65084df72e9	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-280	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.217962	432	EXECUTED	8:44df87de223658603bb4be7e2173fa15	insert tableName=study		\N	3.6.3	\N	\N	4489977887
1235684743487-280-1	kkrumlian	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.221957	433	EXECUTED	8:c150fe84c2d3d64d9c805cfbfdf5cd59	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-280-2	kkrumlian	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.223695	434	MARK_RAN	8:f836eaaae87e9d012c7e0c26373ef1c5	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-281	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.226722	435	EXECUTED	8:209cb9e2f3838a6cafdebb5f8cc75d3b	insert tableName=study_parameter		\N	3.6.3	\N	\N	4489977887
1235684743487-282	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.229319	436	EXECUTED	8:dd2aac5294454e87b5119c8264ab11da	insert tableName=study_parameter		\N	3.6.3	\N	\N	4489977887
1235684743487-283	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.232023	437	EXECUTED	8:be8a8191cf707054c37942395b430206	insert tableName=study_parameter		\N	3.6.3	\N	\N	4489977887
1235684743487-284	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.235559	438	EXECUTED	8:1f01ac820d92dea074a9d54911c915c4	insert tableName=study_parameter		\N	3.6.3	\N	\N	4489977887
1235684743487-285	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.23866	439	EXECUTED	8:bfc7e4dd92eae4bd3a54165bf491fbff	insert tableName=study_parameter		\N	3.6.3	\N	\N	4489977887
1235684743487-286	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.24134	440	EXECUTED	8:04534d44d0d0bc855a16c433f5e93596	insert tableName=study_parameter		\N	3.6.3	\N	\N	4489977887
1235684743487-287	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.243998	441	EXECUTED	8:14c9d8a0b8d654dbd745b431e4e68c1f	insert tableName=study_parameter		\N	3.6.3	\N	\N	4489977887
1235684743487-288	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.25496	442	EXECUTED	8:acdeccfe1af4771933592bcf1f2db01e	insert tableName=study_parameter		\N	3.6.3	\N	\N	4489977887
1235684743487-289	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.258752	443	EXECUTED	8:5f5a5af81e6d2086e73ab186f9ff3aa7	insert tableName=study_parameter		\N	3.6.3	\N	\N	4489977887
1235684743487-290	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.26161	444	EXECUTED	8:7dcabcfd81d7cce2e99a1d550d071458	insert tableName=study_parameter		\N	3.6.3	\N	\N	4489977887
1235684743487-291	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.264356	445	EXECUTED	8:ac17bb73f550c2920571c0bc8d28c15b	insert tableName=study_parameter		\N	3.6.3	\N	\N	4489977887
1235684743487-292	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.267983	446	EXECUTED	8:d80a11010c3fd7bffd0d539a894b89ef	insert tableName=study_parameter		\N	3.6.3	\N	\N	4489977887
1235684743487-293	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.2713	447	EXECUTED	8:66308d0128564cf7c6adbad33f7daf78	insert tableName=study_parameter		\N	3.6.3	\N	\N	4489977887
1235684743487-294	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.274161	448	EXECUTED	8:4958b28daec50f3726595dec04b3081d	insert tableName=discrepancy_note_type		\N	3.6.3	\N	\N	4489977887
1235684743487-295	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.276936	449	EXECUTED	8:24b43e5d5989e458bace23071fef40b2	insert tableName=discrepancy_note_type		\N	3.6.3	\N	\N	4489977887
1235684743487-296	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.280018	450	EXECUTED	8:ae9827de2cce13de7122577f73d910df	insert tableName=discrepancy_note_type		\N	3.6.3	\N	\N	4489977887
1235684743487-297	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.283731	451	EXECUTED	8:2550843464638524e285f88106a7ab9f	insert tableName=discrepancy_note_type		\N	3.6.3	\N	\N	4489977887
1235684743487-298	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.287058	452	EXECUTED	8:ca1bc001b4b432e39f0842bb4be33c12	insert tableName=discrepancy_note_type		\N	3.6.3	\N	\N	4489977887
1235684743487-299	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.289923	453	EXECUTED	8:7be1a79ebeef5c84dcc396849379db95	insert tableName=discrepancy_note_type		\N	3.6.3	\N	\N	4489977887
1235684743487-300	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.292918	454	EXECUTED	8:a45621f0ea2c8e58565ac2ba04f816cb	insert tableName=discrepancy_note_type		\N	3.6.3	\N	\N	4489977887
1235684743487-301	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.296219	455	EXECUTED	8:2ba4be175630b68d80676f8b5a03badf	insert tableName=resolution_status		\N	3.6.3	\N	\N	4489977887
1235684743487-302	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.299165	456	EXECUTED	8:e3642b771f5f0c08c52425402b169723	insert tableName=resolution_status		\N	3.6.3	\N	\N	4489977887
1235684743487-303	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.302526	457	EXECUTED	8:d1fdc06622fe218893f22aab9e59ab4d	insert tableName=resolution_status		\N	3.6.3	\N	\N	4489977887
1235684743487-304	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.305736	458	EXECUTED	8:ee5740298004fc993e0affb4a323d0c8	insert tableName=resolution_status		\N	3.6.3	\N	\N	4489977887
1235684743487-305	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.308815	459	EXECUTED	8:60f7d80b097daeaea3365799dd932fd5	insert tableName=resolution_status		\N	3.6.3	\N	\N	4489977887
1235684743487-306	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.312184	460	EXECUTED	8:7c76d4a70bc31210b1ba197aa8b9ae46	insert tableName=completion_status		\N	3.6.3	\N	\N	4489977887
1235684743487-307	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.31545	461	EXECUTED	8:64bd952f99e585b5c4be5e80a884366e	insert tableName=user_role		\N	3.6.3	\N	\N	4489977887
1235684743487-308	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.318678	462	EXECUTED	8:8e7842ed8f5f9560c4497ef74cc9b5c9	insert tableName=user_role		\N	3.6.3	\N	\N	4489977887
1235684743487-309	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.32182	463	EXECUTED	8:17336df7826bbeda20aea050b1da1042	insert tableName=user_role		\N	3.6.3	\N	\N	4489977887
1235684743487-310	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.324559	464	EXECUTED	8:128d3b27a6fe0810bf40531a7ea6973e	insert tableName=user_role		\N	3.6.3	\N	\N	4489977887
1235684743487-311	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.327192	465	EXECUTED	8:7e9a14b07ef61e8da75d7fddc62b941b	insert tableName=user_role		\N	3.6.3	\N	\N	4489977887
1235684743487-312	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.330167	466	EXECUTED	8:9224207bba3b1a1e109e6791b0757d8e	insert tableName=user_role		\N	3.6.3	\N	\N	4489977887
1235684743487-313	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.333738	467	EXECUTED	8:c5e611840c41d66270556b5338a387cf	insert tableName=export_format		\N	3.6.3	\N	\N	4489977887
1235684743487-314	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.337198	468	EXECUTED	8:45ead64d624b09a680dca9813a150f81	insert tableName=export_format		\N	3.6.3	\N	\N	4489977887
1235684743487-315	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.340222	469	EXECUTED	8:1f23c8ca6c86cf49c5a4cbe588f17618	insert tableName=export_format		\N	3.6.3	\N	\N	4489977887
1235684743487-316	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.343269	470	EXECUTED	8:7f1c6ccf25609442ae0ddc60f10f4128	insert tableName=export_format		\N	3.6.3	\N	\N	4489977887
1235684743487-317	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.346427	471	EXECUTED	8:65f313b47dda8be52016b8f3812b8456	insert tableName=export_format		\N	3.6.3	\N	\N	4489977887
1235684743487-318	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.350506	472	EXECUTED	8:a546e09fec2ee9db2a10eaa5ebf82fc5	insert tableName=study_parameter_value		\N	3.6.3	\N	\N	4489977887
1235684743487-319	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.354067	473	EXECUTED	8:262a84d747f238c3f1acdf0105ae8c7f	insert tableName=study_parameter_value		\N	3.6.3	\N	\N	4489977887
1235684743487-320	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.357257	474	EXECUTED	8:0ff146a7c75fc9f0d3d4fd340cfb4205	insert tableName=study_parameter_value		\N	3.6.3	\N	\N	4489977887
1235684743487-321	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.360457	475	EXECUTED	8:4b12ec962a1e8356e4704420b70ed6dc	insert tableName=study_parameter_value		\N	3.6.3	\N	\N	4489977887
1235684743487-322	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.363573	476	EXECUTED	8:f2d184ef9d8fa814f005d5fa77b1297e	insert tableName=study_parameter_value		\N	3.6.3	\N	\N	4489977887
1235684743487-323	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.366801	477	EXECUTED	8:169146d8d330f594874b539f48737a60	insert tableName=study_parameter_value		\N	3.6.3	\N	\N	4489977887
1235684743487-324	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.370413	478	EXECUTED	8:8d0ed8a2fb1a0f34d7a52e03b12ff7ac	insert tableName=study_parameter_value		\N	3.6.3	\N	\N	4489977887
1235684743487-325	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.374951	479	EXECUTED	8:daaafa4f843a4d8a0145e8a0a915c480	insert tableName=study_parameter_value		\N	3.6.3	\N	\N	4489977887
1235684743487-326	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.378389	480	EXECUTED	8:9b6c20024ef03b4a0ba4d4d2b0b368e7	insert tableName=study_parameter_value		\N	3.6.3	\N	\N	4489977887
1235684743487-327	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.381363	481	EXECUTED	8:481815ce36a11a8f8532a40a75f651ad	insert tableName=study_parameter_value		\N	3.6.3	\N	\N	4489977887
1235684743487-328	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.384812	482	EXECUTED	8:e9c2b892d4bb0b59a9bb149ba59568a3	insert tableName=study_parameter_value		\N	3.6.3	\N	\N	4489977887
1235684743487-329	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.388364	483	EXECUTED	8:c29742bd6913484ba63d8ff921600da7	insert tableName=study_parameter_value		\N	3.6.3	\N	\N	4489977887
1235684743487-330	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.391816	484	EXECUTED	8:da945939879094848ea4532e8ee77fe8	insert tableName=study_parameter_value		\N	3.6.3	\N	\N	4489977887
1235684743487-331	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.3952	485	EXECUTED	8:f9a58bbee8e985803d0493d1ae797b22	insert tableName=item_reference_type		\N	3.6.3	\N	\N	4489977887
1235684743487-332	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.399179	486	EXECUTED	8:d041ede137a3c6685b187928abe0cc26	insert tableName=study_user_role		\N	3.6.3	\N	\N	4489977887
1235684743487-333	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.403246	487	EXECUTED	8:1a142bd1a10b07307e9f541181892700	insert tableName=study_user_role		\N	3.6.3	\N	\N	4489977887
1235684743487-334	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.406758	488	EXECUTED	8:bc35387c9c6437f767189180820624de	insert tableName=item_data_type		\N	3.6.3	\N	\N	4489977887
1235684743487-335	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.409742	489	EXECUTED	8:21dd8d7859ead96dba6f98636dad20f5	insert tableName=item_data_type		\N	3.6.3	\N	\N	4489977887
1235684743487-336	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.412631	490	EXECUTED	8:676b91e5ceb913f92989f9868f462011	insert tableName=item_data_type		\N	3.6.3	\N	\N	4489977887
1235684743487-337	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.415478	491	EXECUTED	8:28541c93f01a506e86e6a79154337a61	insert tableName=item_data_type		\N	3.6.3	\N	\N	4489977887
1235684743487-338	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.4189	492	EXECUTED	8:b6f46255e2aa21d060e81e21afd5a906	insert tableName=item_data_type		\N	3.6.3	\N	\N	4489977887
1235684743487-339	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.42253	493	EXECUTED	8:3032dfe9ccfc01c717ce23b66d4313b5	insert tableName=item_data_type		\N	3.6.3	\N	\N	4489977887
1235684743487-340	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.425477	494	EXECUTED	8:b2fb167d5eaad51925f102308fc28548	insert tableName=item_data_type		\N	3.6.3	\N	\N	4489977887
1235684743487-341	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.428411	495	EXECUTED	8:47297b04b1485681eb1e2c8a1c9fcab6	insert tableName=item_data_type		\N	3.6.3	\N	\N	4489977887
1235684743487-342	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.431343	496	EXECUTED	8:714e6ddb19db41d35d99ab86a62a857a	insert tableName=item_data_type		\N	3.6.3	\N	\N	4489977887
1235684743487-343	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.435226	497	EXECUTED	8:e87422aacb8444c38b1e41b611b8c297	insert tableName=group_class_types		\N	3.6.3	\N	\N	4489977887
1235684743487-344	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.438711	498	EXECUTED	8:387308eb9df30cfc42878d853135c535	insert tableName=group_class_types		\N	3.6.3	\N	\N	4489977887
1235684743487-345	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.441666	499	EXECUTED	8:be2ebb8042ae1f2f2ae286962fb8f0d0	insert tableName=group_class_types		\N	3.6.3	\N	\N	4489977887
1235684743487-346	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.444624	500	EXECUTED	8:c274f69e37db9f85d71319af244f2f65	insert tableName=group_class_types		\N	3.6.3	\N	\N	4489977887
1235684743487-347	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.448138	501	EXECUTED	8:cdde31d50985e3abdbe973772fd0030e	insert tableName=null_value_type		\N	3.6.3	\N	\N	4489977887
1235684743487-348	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.451897	502	EXECUTED	8:503a68ed687c91558f902190b560e080	insert tableName=null_value_type		\N	3.6.3	\N	\N	4489977887
1235684743487-349	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.455323	503	EXECUTED	8:6a7a30fed44f1f376be2f9be5581630a	insert tableName=null_value_type		\N	3.6.3	\N	\N	4489977887
1235684743487-350	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.45834	504	EXECUTED	8:ecd80b30b46ba049fb8a9eabe742c482	insert tableName=null_value_type		\N	3.6.3	\N	\N	4489977887
1235684743487-351	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.461272	505	EXECUTED	8:bcc787a5029ef66b5fdd2ff517a12dd3	insert tableName=null_value_type		\N	3.6.3	\N	\N	4489977887
1235684743487-352	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.464206	506	EXECUTED	8:5dc067b7456bc80358231f2c5ff4a51b	insert tableName=null_value_type		\N	3.6.3	\N	\N	4489977887
1235684743487-353	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.46786	507	EXECUTED	8:d4eb9505388fe331f2fba5805ce3fce8	insert tableName=null_value_type		\N	3.6.3	\N	\N	4489977887
1235684743487-354	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.471155	508	EXECUTED	8:b20ae90a3f670e0a84f80fe266f238fc	insert tableName=null_value_type		\N	3.6.3	\N	\N	4489977887
1235684743487-355	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.474759	509	EXECUTED	8:7a59105e934791e6bc9bb918e2bc4635	insert tableName=null_value_type		\N	3.6.3	\N	\N	4489977887
1235684743487-356	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.477933	510	EXECUTED	8:bd624454d257dc9712b93f6e30a78d85	insert tableName=null_value_type		\N	3.6.3	\N	\N	4489977887
1235684743487-357	pgawade (generated)	migration/2.5/changeLogDataInsert.xml	2025-11-30 08:06:20.481144	511	EXECUTED	8:56aeaa227a30d58b679d90d8d3c403a5	insert tableName=null_value_type		\N	3.6.3	\N	\N	4489977887
1235684743487-372	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.485175	512	EXECUTED	8:15d6aa224e65fc7e5a878df7f4f87e46	renameColumn newColumnName=id, oldColumnName=rule_id, tableName=rule		\N	3.6.3	\N	\N	4489977887
1235684743487-373	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.488798	513	EXECUTED	8:9a6f25bae89abc11a8eaadda3222deb4	renameTable newTableName=rule_id_seq, oldTableName=rule_rule_id_seq		\N	3.6.3	\N	\N	4489977887
1235684743487-374	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.492982	514	EXECUTED	8:060efc355f68da3bcbb971fc3642bd91	addColumn tableName=rule		\N	3.6.3	\N	\N	4489977887
1235684743487-375	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.495847	515	EXECUTED	8:5ceaedf2b00dcce16a266833a4afb07e	update tableName=rule		\N	3.6.3	\N	\N	4489977887
1235684743487-376	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.49915	516	EXECUTED	8:a0bf6b0e2887df2c10a1d6c6167a00f0	renameColumn newColumnName=id, oldColumnName=rule_action_id, tableName=rule_action		\N	3.6.3	\N	\N	4489977887
1235684743487-377	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.502615	517	EXECUTED	8:e870e4ec39cb550ebb78722e5a6778cd	renameTable newTableName=rule_action_id_seq, oldTableName=rule_action_rule_action_id_seq		\N	3.6.3	\N	\N	4489977887
1235684743487-378	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.505997	518	EXECUTED	8:41d24bd0d56a9b9bfbd31b2de0de5c41	addColumn tableName=rule_action		\N	3.6.3	\N	\N	4489977887
1235684743487-379	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.508401	519	EXECUTED	8:9d7cb58a79b2e769bbcfc8929bfbab6f	update tableName=rule_action		\N	3.6.3	\N	\N	4489977887
1235684743487-380	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.511121	520	EXECUTED	8:2ef080b1a3c199ee038d6d00f07f7a24	renameColumn newColumnName=id, oldColumnName=rule_expression_id, tableName=rule_expression		\N	3.6.3	\N	\N	4489977887
1235684743487-381	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.513943	521	EXECUTED	8:fcff51463679b46efd5d2b6fac05b747	renameTable newTableName=rule_expression_id_seq, oldTableName=rule_expression_rule_expression_id_seq		\N	3.6.3	\N	\N	4489977887
1235684743487-382	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.516922	522	EXECUTED	8:cdadaccb8a79fdb37f76512d693c6c92	addColumn tableName=rule_expression		\N	3.6.3	\N	\N	4489977887
1235684743487-383	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.519427	523	EXECUTED	8:5a260b32bd274d36e7d04d580f0d68ae	update tableName=rule_expression		\N	3.6.3	\N	\N	4489977887
1235684743487-384	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.522327	524	EXECUTED	8:d2bbfdb59bc4c8b3a157fc2c39eb82a3	renameColumn newColumnName=id, oldColumnName=rule_set_id, tableName=rule_set		\N	3.6.3	\N	\N	4489977887
1235684743487-385	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.525284	525	EXECUTED	8:39ddecde39b3a9a8a702721dd9036e84	renameTable newTableName=rule_set_id_seq, oldTableName=rule_set_rule_set_id_seq		\N	3.6.3	\N	\N	4489977887
1235684743487-386	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.528096	526	EXECUTED	8:5dfae0caa8945dfc8c0f47013a0eb574	addColumn tableName=rule_set		\N	3.6.3	\N	\N	4489977887
1235684743487-387	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.530325	527	EXECUTED	8:18e8ff06bf73cab5966d0ba21bcb1716	update tableName=rule_set		\N	3.6.3	\N	\N	4489977887
1235684743487-388	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.533189	528	EXECUTED	8:43ab339face85d20073efdb8cf58a47e	renameColumn newColumnName=id, oldColumnName=rule_set_audit_id, tableName=rule_set_audit		\N	3.6.3	\N	\N	4489977887
1235684743487-389	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.536256	529	EXECUTED	8:f82061ca8544950b56a462759324f451	renameTable newTableName=rule_set_audit_id_seq, oldTableName=rule_set_audit_rule_set_audit_id_seq		\N	3.6.3	\N	\N	4489977887
1235684743487-390	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.539173	530	EXECUTED	8:2d809343230c93e5edf12fe6e1694422	addColumn tableName=rule_set_audit		\N	3.6.3	\N	\N	4489977887
1235684743487-391	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.541529	531	EXECUTED	8:236b0a6385304c4d403b2dedc074e307	update tableName=rule_set_audit		\N	3.6.3	\N	\N	4489977887
1235684743487-392	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.54467	532	EXECUTED	8:e24e894246e3d161e365be7db292364e	renameColumn newColumnName=id, oldColumnName=rule_set_rule_id, tableName=rule_set_rule		\N	3.6.3	\N	\N	4489977887
1235684743487-393	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.548399	533	EXECUTED	8:132ca549755f6fcccc7f42bb89557186	renameTable newTableName=rule_set_rule_id_seq, oldTableName=rule_set_rule_rule_set_rule_id_seq		\N	3.6.3	\N	\N	4489977887
1235684743487-394	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.553412	534	EXECUTED	8:d5c85db0710271b7d2eb076623ef1577	addColumn tableName=rule_set_rule		\N	3.6.3	\N	\N	4489977887
1235684743487-395	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.556802	535	EXECUTED	8:984fd070b3da227a08fd549aa7bf1797	update tableName=rule_set_rule		\N	3.6.3	\N	\N	4489977887
1235684743487-396	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.560278	536	EXECUTED	8:8a7342fb18d8a638761e0a1c55a766e0	renameColumn newColumnName=id, oldColumnName=rule_set_rule_audit_id, tableName=rule_set_rule_audit		\N	3.6.3	\N	\N	4489977887
1235684743487-397	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.564053	537	EXECUTED	8:2f5f89455561282eddc5c9e9adab3ad5	renameTable newTableName=rule_set_rule_audit_id_seq, oldTableName=rule_set_rule_audit_rule_set_rule_audit_id_seq		\N	3.6.3	\N	\N	4489977887
1235684743487-398	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.568118	538	EXECUTED	8:46677b1eab898b7fafafaac8587fca48	addColumn tableName=rule_set_rule_audit		\N	3.6.3	\N	\N	4489977887
1235684743487-399	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.571395	539	EXECUTED	8:63ca8031fe697a1f8bae1519bc99c781	update tableName=rule_set_rule_audit		\N	3.6.3	\N	\N	4489977887
1235684743487-400	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.575263	540	EXECUTED	8:10e4ba5a7fc2e2fe46f1f49d4862412c	insert tableName=item_data_type		\N	3.6.3	\N	\N	4489977887
1235684743487-401	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.578818	541	EXECUTED	8:a555f96d8b1b480484035325fa37affe	insert tableName=item_data_type		\N	3.6.3	\N	\N	4489977887
1235684743487-402	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.584795	542	EXECUTED	8:7b9b1e57a5991cf462767ffe105ada62	createTable tableName=authorities		\N	3.6.3	\N	\N	4489977887
1235684743487-433	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.587819	543	MARK_RAN	8:8c8e59b23bba4362960c50b31a3fa4b0	createSequence sequenceName=AUTHORITIES_ID_SEQ		\N	3.6.3	\N	\N	4489977887
1235684743487-434	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.590349	544	MARK_RAN	8:49f3196750f8b171c0d35c761f948831	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-403	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.60134	545	EXECUTED	8:a8d8fd46e32199a4ab926a3f30a15e8e	createTable tableName=oc_qrtz_blob_triggers		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-8	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.435547	648	EXECUTED	8:4a7f0bf31361f93c0ea0899cb8255aca	sql		\N	3.6.3	\N	\N	4489977887
1235684743487-404	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.610548	546	EXECUTED	8:ca8829339b8a65109fea4981e6266ce5	createTable tableName=oc_qrtz_calendars		\N	3.6.3	\N	\N	4489977887
1235684743487-405	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.622523	547	EXECUTED	8:f4b408683ca4b0a4ead9465672cade7c	createTable tableName=oc_qrtz_cron_triggers		\N	3.6.3	\N	\N	4489977887
1235684743487-406	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.633706	548	EXECUTED	8:3eb59d9d8926555ec47349f096ec8b39	createTable tableName=oc_qrtz_fired_triggers		\N	3.6.3	\N	\N	4489977887
1235684743487-407	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.646746	549	EXECUTED	8:e74c826041bc046dc8b99a584744975e	createTable tableName=oc_qrtz_job_details		\N	3.6.3	\N	\N	4489977887
1235684743487-408	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.680223	550	EXECUTED	8:53dfbc04592790b73f91e1d92bfd36a3	createTable tableName=oc_qrtz_job_listeners		\N	3.6.3	\N	\N	4489977887
1235684743487-409	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.687532	551	EXECUTED	8:9d0af7d72eaa9dd4438e7b530180b3cd	createTable tableName=oc_qrtz_locks		\N	3.6.3	\N	\N	4489977887
1235684743487-410	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.693976	552	EXECUTED	8:69be035b176235db7fe02618f94f6377	createTable tableName=oc_qrtz_paused_trigger_grps		\N	3.6.3	\N	\N	4489977887
1235684743487-411	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.701372	553	EXECUTED	8:24b48571395d1ab4f1aab440af86c59e	createTable tableName=oc_qrtz_scheduler_state		\N	3.6.3	\N	\N	4489977887
1235684743487-412	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.710746	554	EXECUTED	8:587e5baff5ae59e742ccb1359f4585e0	createTable tableName=oc_qrtz_simple_triggers		\N	3.6.3	\N	\N	4489977887
1235684743487-413	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.735503	555	EXECUTED	8:b9f45483b4ef95bcbc246fd15feb84fe	createTable tableName=oc_qrtz_trigger_listeners		\N	3.6.3	\N	\N	4489977887
1235684743487-414	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.747029	556	EXECUTED	8:4387cd4795d644ef3aa2fe8b762c035d	createTable tableName=oc_qrtz_triggers		\N	3.6.3	\N	\N	4489977887
1235684743487-415	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.751393	557	EXECUTED	8:76427fae1b94796a0cc03f403e482125	insert tableName=authorities		\N	3.6.3	\N	\N	4489977887
1235684743487-416	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.755578	558	EXECUTED	8:d2bd6e738c3640030f207389a4532cc8	insert tableName=oc_qrtz_locks		\N	3.6.3	\N	\N	4489977887
1235684743487-417	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.759612	559	EXECUTED	8:3fbd01f16e6cda42664658f1ff9d35dd	insert tableName=oc_qrtz_locks		\N	3.6.3	\N	\N	4489977887
1235684743487-418	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.76318	560	EXECUTED	8:d4cd6f9c322890bcd736d039ef599769	insert tableName=oc_qrtz_locks		\N	3.6.3	\N	\N	4489977887
1235684743487-419	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.76636	561	EXECUTED	8:80ed0dd9fcf5e833c720518974b464aa	insert tableName=oc_qrtz_locks		\N	3.6.3	\N	\N	4489977887
1235684743487-420	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.769924	562	EXECUTED	8:e7ed12ba832b8c70441cc9616f1ed6b5	insert tableName=oc_qrtz_locks		\N	3.6.3	\N	\N	4489977887
1236021533243-421	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.775996	563	EXECUTED	8:34e5601b66f9e7002ae2776b9f4e9c13	addForeignKeyConstraint baseTableName=oc_qrtz_blob_triggers, constraintName=oc_qrtz_blob_triggers_trg_fkey, referencedTableName=oc_qrtz_triggers		\N	3.6.3	\N	\N	4489977887
1236021533243-422	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.781266	564	EXECUTED	8:bab305ff414461d3f4e17ebdbfb41dc0	addForeignKeyConstraint baseTableName=oc_qrtz_cron_triggers, constraintName=oc_qrtz_cron_triggers_trg_fkey, referencedTableName=oc_qrtz_triggers		\N	3.6.3	\N	\N	4489977887
1236021533243-423	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.787219	565	EXECUTED	8:3f58e0a1de1f7418ae06f843a1a61d08	addForeignKeyConstraint baseTableName=oc_qrtz_job_listeners, constraintName=oc_qrtz_job_listeners_job_fkey, referencedTableName=oc_qrtz_job_details		\N	3.6.3	\N	\N	4489977887
1236021533243-424	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.792499	566	EXECUTED	8:1329e905ba0a765db06a4a79bafca7a8	addForeignKeyConstraint baseTableName=oc_qrtz_simple_triggers, constraintName=oc_qrtz_simple_trigs_trg_fkey, referencedTableName=oc_qrtz_triggers		\N	3.6.3	\N	\N	4489977887
1236021533243-425	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.79763	567	EXECUTED	8:e561a445f4ceb104aab5146a8fdd256d	addForeignKeyConstraint baseTableName=oc_qrtz_trigger_listeners, constraintName=oc_qrtz_trigger_lsnrs_trg_fkey, referencedTableName=oc_qrtz_triggers		\N	3.6.3	\N	\N	4489977887
1236021533243-426	pgawade (generated)	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.803021	568	EXECUTED	8:373f2f3b9c350423285b9335ccb92573	addForeignKeyConstraint baseTableName=oc_qrtz_triggers, constraintName=oc_qrtz_triggers_job_name_fkey, referencedTableName=oc_qrtz_job_details		\N	3.6.3	\N	\N	4489977887
1235684743487-427	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.807205	569	EXECUTED	8:97bbe82a6a49c7fa003a526a5ba7e475	addColumn tableName=event_definition_crf		\N	3.6.3	\N	\N	4489977887
1235684743487-428	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.810791	570	EXECUTED	8:c3394d99fc31c45e31e65e8e243611fc	addColumn tableName=discrepancy_note		\N	3.6.3	\N	\N	4489977887
1235684743487-429	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.815977	571	EXECUTED	8:f3db3f0e4bc71fab1edeff7f9ac7750d	addForeignKeyConstraint baseTableName=discrepancy_note, constraintName=discrepancy_note_asn_u_id_fkey, referencedTableName=user_account		\N	3.6.3	\N	\N	4489977887
1235684743487-430	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.819821	572	EXECUTED	8:bc041580b76a81d2e4ac3dca45d28bbd	insert tableName=study_parameter		\N	3.6.3	\N	\N	4489977887
1235684743487-431	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.823435	573	EXECUTED	8:f66fe500e724db0823af6382a2ffa1ef	insert tableName=study_parameter_value		\N	3.6.3	\N	\N	4489977887
1235684743487-432	pgawade	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.826845	574	EXECUTED	8:64dcb26e8aa2d660cfaa2457279d9ea4	addColumn tableName=item_form_metadata		\N	3.6.3	\N	\N	4489977887
1235684743487-433	kkrumlian	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.830291	575	EXECUTED	8:e36306d501fdc6c80afca4739bc4dd9d	addColumn tableName=crf		\N	3.6.3	\N	\N	4489977887
1235684743487-434	kkrumlian	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.833995	576	EXECUTED	8:06b264dfd1b7f6775664163262271bb4	insert tableName=status		\N	3.6.3	\N	\N	4489977887
1235684743487-435	kkrumlian	migration/3.0/schema_patch_2.5_to_3.0.xml	2025-11-30 08:06:20.840637	577	EXECUTED	8:982029be93be2fa533ad1be53b7bb789	sql		\N	3.6.3	\N	\N	4489977887
2009-03-16-2914-1	ywang	migration/3.0/2009-03-16-2914.xml	2025-11-30 08:06:20.848692	578	EXECUTED	8:30ddd3132cd96bf8fa348b434622fb14	createTable tableName=dataset_item_status		\N	3.6.3	\N	\N	4489977887
2009-03-16-2914-2	ywang	migration/3.0/2009-03-16-2914.xml	2025-11-30 08:06:20.853192	579	EXECUTED	8:39d50b8d748e6c8823033208db8aff3b	insert tableName=dataset_item_status		\N	3.6.3	\N	\N	4489977887
2009-03-16-2914-3	ywang	migration/3.0/2009-03-16-2914.xml	2025-11-30 08:06:20.856386	580	EXECUTED	8:cafa63ee6f8e78c9eb54e0ea829ff3d8	insert tableName=dataset_item_status		\N	3.6.3	\N	\N	4489977887
2009-03-16-2914-4	ywang	migration/3.0/2009-03-16-2914.xml	2025-11-30 08:06:20.859235	581	EXECUTED	8:be8afadfb4f40fef29664f0962fa5b74	insert tableName=dataset_item_status		\N	3.6.3	\N	\N	4489977887
2009-03-16-2914-5	ywang	migration/3.0/2009-03-16-2914.xml	2025-11-30 08:06:20.862291	582	EXECUTED	8:a6d3b864142876e6f0f59eec5d7d8040	addColumn tableName=dataset		\N	3.6.3	\N	\N	4489977887
2009-03-16-2914-6	ywang	migration/3.0/2009-03-16-2914.xml	2025-11-30 08:06:20.867411	583	EXECUTED	8:02358c7a63d25d0db88bbda8ad14cb91	addForeignKeyConstraint baseTableName=dataset, constraintName=dataset_fk_dataset_item_status, referencedTableName=dataset_item_status		\N	3.6.3	\N	\N	4489977887
2009-03-30-NA01-1	kkrumlian	migration/3.0/2009-03-30-NA01.xml	2025-11-30 08:06:20.871244	584	EXECUTED	8:ac755c630059fa59f27ea2c975dd059c	renameColumn newColumnName=source_study_id, oldColumnName=study_id, tableName=crf	Rename Column Name	\N	3.6.3	\N	\N	4489977887
2009-03-30-NA01-2	kkrumlian	migration/3.0/2009-03-30-NA01.xml	2025-11-30 08:06:20.876499	585	EXECUTED	8:a1820970ea7d06729d7587ea075ad360	addForeignKeyConstraint baseTableName=crf, constraintName=fk_source_study_id, referencedTableName=study	Add foreign Key for the source_study_id	\N	3.6.3	\N	\N	4489977887
2009-03-30-3348-1	ywang	migration/3.0/2009-03-30-3348.xml	2025-11-30 08:06:20.880081	586	EXECUTED	8:51786ab81b450276ec05c3647989c29f	addColumn tableName=event_definition_crf	event_definition_crf (source_data_verification_code)	\N	3.6.3	\N	\N	4489977887
2009-03-30-3348-2	ywang	migration/3.0/2009-03-30-3348.xml	2025-11-30 08:06:20.883816	587	EXECUTED	8:daa1dc5cf258afcc00c71c7defa70c71	addColumn tableName=event_definition_crf	event_definition_crf (selected_version_ids)	\N	3.6.3	\N	\N	4489977887
2009-03-30-3348-3	ywang	migration/3.0/2009-03-30-3348.xml	2025-11-30 08:06:20.887696	588	EXECUTED	8:79bbd6043c64056d49cf148181e70bb7	addColumn tableName=event_definition_crf	event_definition_crf (parent_id)	\N	3.6.3	\N	\N	4489977887
2009-03-31-1	ywang	migration/3.0/2009-03-31-3382.xml	2025-11-30 08:06:20.89108	589	EXECUTED	8:dc9523c33f6ffd4312644323add769e4	update tableName=dataset_item_status		\N	3.6.3	\N	\N	4489977887
2009-03-31-2	ywang	migration/3.0/2009-03-31-3382.xml	2025-11-30 08:06:20.89426	590	EXECUTED	8:4110b2ec52ce0d8448f8b59dd80709e5	update tableName=dataset_item_status		\N	3.6.3	\N	\N	4489977887
2009-03-31-3	ywang	migration/3.0/2009-03-31-3382.xml	2025-11-30 08:06:20.897631	591	EXECUTED	8:bd25dfeaba2f76ff8d4ce561eb8954b4	update tableName=dataset_item_status		\N	3.6.3	\N	\N	4489977887
2009-04-02-3397-1	kkrumlian	migration/3.0/2009-04-02-3397.xml	2025-11-30 08:06:20.906278	592	EXECUTED	8:e60bff81e87f6260d2f335851868d712	createTable tableName=audit_user_login	Create a table named audit_user_login	\N	3.6.3	\N	\N	4489977887
2009-04-02-3397-3	kkrumlian	migration/3.0/2009-04-02-3397.xml	2025-11-30 08:06:20.91092	593	EXECUTED	8:c06df55d220be762b82bf23e64296548	addForeignKeyConstraint baseTableName=audit_user_login, constraintName=fk_audit_user_login_id, referencedTableName=user_account	Add foreign Key for user_account_id	\N	3.6.3	\N	\N	4489977887
2009-04-02-3397-4	kkrumlian	migration/3.0/2009-04-02-3397.xml	2025-11-30 08:06:20.915086	594	EXECUTED	8:ddcaed314dcd68a764f1147166a9ab16	addColumn tableName=user_account	Add enabled property to user_account table	\N	3.6.3	\N	\N	4489977887
2009-04-02-3397-5	kkrumlian	migration/3.0/2009-04-02-3397.xml	2025-11-30 08:06:20.918955	595	EXECUTED	8:32b5eaae0fdc3babaa46d4f458ffa383	addColumn tableName=user_account	Add account_non_locked property to user_account table	\N	3.6.3	\N	\N	4489977887
2009-04-02-3397-6	kkrumlian	migration/3.0/2009-04-02-3397.xml	2025-11-30 08:06:20.92271	596	EXECUTED	8:015d2f8abef98a2babbb67b1b002e9fe	addColumn tableName=user_account	Add lock_counter property to user_account table	\N	3.6.3	\N	\N	4489977887
2009-04-02-3397-7	kkrumlian	migration/3.0/2009-04-02-3397.xml	2025-11-30 08:06:20.936568	597	EXECUTED	8:d967e573e74fbe2600f32b5892e9bcd1	createTable tableName=configuration	Create a table named configuration	\N	3.6.3	\N	\N	4489977887
2009-04-02-3397-8	kkrumlian	migration/3.0/2009-04-02-3397.xml	2025-11-30 08:06:20.942643	598	EXECUTED	8:b3914e4541bffd89600146a5605e0b66	createIndex indexName=i_key_index, tableName=configuration	Create an index on table named configuration	\N	3.6.3	\N	\N	4489977887
2009-04-02-3397-10	kkrumlian	migration/3.0/2009-04-02-3397.xml	2025-11-30 08:06:20.946905	599	EXECUTED	8:1f8a960cef55784377ec948612246321	insert tableName=configuration		\N	3.6.3	\N	\N	4489977887
2009-04-02-3397-11	kkrumlian	migration/3.0/2009-04-02-3397.xml	2025-11-30 08:06:20.950689	600	EXECUTED	8:fcab58cc8cc38419e2e3d15267cfc081	insert tableName=configuration		\N	3.6.3	\N	\N	4489977887
2009-04-10-3120-1	sshamim	migration/3.0/2009-04-10-3120.xml	2025-11-30 08:06:20.959859	601	EXECUTED	8:0fd84cfdae98c29dabee1ea347242a23	createTable tableName=study_module_status	Create a table named study_module_status	\N	3.6.3	\N	\N	4489977887
2009-04-10-3120-2	sshamim	migration/3.0/2009-04-10-3120.xml	2025-11-30 08:06:20.964889	602	EXECUTED	8:f07e656cd9c33ac1d2c39ebfbd8c6627	addForeignKeyConstraint baseTableName=study_module_status, constraintName=fk_study_module_study_id, referencedTableName=study	Add foreign Key for study_id column	\N	3.6.3	\N	\N	4489977887
2009-04-29-3349-1	bwperry	migration/3.0/2009-04-29-3349.xml	2025-11-30 08:06:20.969032	603	EXECUTED	8:59bdb5da15a8e2560b53a7baa2c80efe	addColumn tableName=event_crf	Add sdv_status property to event_crf table	\N	3.6.3	\N	\N	4489977887
2009-05-15-3624-1	ywang	migration/3.0/2009-05-15-3624.xml	2025-11-30 08:06:20.981789	604	EXECUTED	8:f1a8420ee77020302c6b1e8b59831ecb	createTable tableName=measurement_unit	create measurement_unit	\N	3.6.3	\N	\N	4489977887
2009-05-15-3624-3	ywang	migration/3.0/2009-05-15-3624.xml	2025-11-30 08:06:20.987757	605	EXECUTED	8:a18c3450fbfe9cd9f2232e94fb30a105	sql	mapping item.units to measurement_unit.name and oc_oid	\N	3.6.3	\N	\N	4489977887
2009-05-28-3481-1	sshamim	migration/3.0/2009-05-28-3481.xml	2025-11-30 08:06:20.992761	606	EXECUTED	8:7dd65dc75ef12df657cf5032686624b7	insert tableName=status	Insert a record in Status table	\N	3.6.3	\N	\N	4489977887
2009-06-04-3684-1	thickerson	migration/3.0/2009-06-04-3684.xml	2025-11-30 08:06:21.237672	607	EXECUTED	8:89fa12135c4ec50180fa2b62d17b11f5	insert tableName=study_parameter	Insert a new record in the studyParameter table	\N	3.6.3	\N	\N	4489977887
2009-06-08-3628-1	ywang	migration/3.0/2009-06-08-3628.xml	2025-11-30 08:06:21.24131	608	EXECUTED	8:5099b26dd89bf997e999d30f8b051a3e	insert tableName=null_value_type	insert a new record to null_value_type: NPE(not performed)	\N	3.6.3	\N	\N	4489977887
2009-06-10-3260-1	kkrumlian	migration/3.0/2009-06-10-3260.xml	2025-11-30 08:06:21.244518	609	EXECUTED	8:279236a00b2511c104a85c8ef4ba5916	update tableName=discrepancy_note	update discrepancy_note set entity_type='itemData' where entity_type='ItemData'	\N	3.6.3	\N	\N	4489977887
2009-07-23-3930-1	ywang	migration/3.0/2009-07-23-3930.xml	2025-11-30 08:06:21.249369	610	EXECUTED	8:c327f00db54ec79573e2ce6eac1fa5b8	sql	create or replace event_crf_trigger for event crf sdv status	\N	3.6.3	\N	\N	4489977887
2009-07-23-3930-2	ywang	migration/3.0/2009-07-23-3930.xml	2025-11-30 08:06:21.253454	611	EXECUTED	8:382a966af0df8ef570c928327f4e7906	insert tableName=audit_log_event_type	Insert event crf sdv into audit_log_event_type  table	\N	3.6.3	\N	\N	4489977887
2009-07-24-3648-1	shamim	migration/3.0/2009-07-24-3648.xml	2025-11-30 08:06:21.25765	612	EXECUTED	8:a9ac48925b2c621a63e291b018dc2c05	addColumn tableName=event_crf	Add a column in event_crf table	\N	3.6.3	\N	\N	4489977887
2009-09-10-3599-1	ywang	migration/3.0/2009-09-10-3599.xml	2025-11-30 08:06:21.261627	613	EXECUTED	8:ac7763ad8570d09e65d72aac5ab0ea45	sql	update resolution_status_id for parent note	\N	3.6.3	\N	\N	4489977887
2009-12-01-4439-1	kkrumlian	migration/3.0/2009-12-01-4439.xml	2025-11-30 08:06:21.265099	614	EXECUTED	8:2d23f143be450ec3c4407b6fb2e14c7a	sql	update study protocol_type	\N	3.6.3	\N	\N	4489977887
2009-12-01-4439-2	kkrumlian	migration/3.0/2009-12-01-4439.xml	2025-11-30 08:06:21.268965	615	EXECUTED	8:226444fdc137f3862b1bbf2ee5ef850c	sql	update study protocol_type	\N	3.6.3	\N	\N	4489977887
2009-12-01-4439-3	kkrumlian	migration/3.0/2009-12-01-4439.xml	2025-11-30 08:06:21.272221	616	EXECUTED	8:e425b0198d75274eede7566826e7ef41	sql	update study protocol_type	\N	3.6.3	\N	\N	4489977887
2009-12-11-4502-1	kkrumlian	migration/3.0/2009-12-11-4502.xml	2025-11-30 08:06:21.274892	617	EXECUTED	8:2fe8f14ea68c02df1d0201e845731012	update tableName=study_user_role	update study protocol_type	\N	3.6.3	\N	\N	4489977887
2010-02-16-NA01-1	kkrumlian	migration/3.0/2010-02-16-NA01.xml	2025-11-30 08:06:21.293837	618	EXECUTED	8:c19f3980f3e13d0d8c96223b7b414341	sql	update data in item_data table	\N	3.6.3	\N	\N	4489977887
2010-03-01-4772-2	kkrumlian	migration/3.0/2010-03-01-4772.xml	2025-11-30 08:06:21.298658	619	EXECUTED	8:e1680fefd70639257716f11a35bea6a1	sql	ALTER TABLE dataset ALTER sql_statement TYPE text	\N	3.6.3	\N	\N	4489977887
2010-03-02-4776-1	kkrumlian	migration/3.0/2010-03-02-4776.xml	2025-11-30 08:06:21.302178	620	EXECUTED	8:40c0abda332e3a1cb0bc0127527b9606	update tableName=event_definition_crf	update event_definition_crf	\N	3.6.3	\N	\N	4489977887
2009-03-03-4768-1	sshamim	migration/3.0/2010-03-03-4768.xml	2025-11-30 08:06:21.306218	621	EXECUTED	8:65740d994efcf9661be7b3af14ccaf90	sql	create or replace event_definition_crf_trigger	\N	3.6.3	\N	\N	4489977887
2009-03-03-4768-2	sshamim	migration/3.0/2010-03-03-4768.xml	2025-11-30 08:06:21.309935	622	EXECUTED	8:d9f786242b9f448ed8edb2f2e1c6cdb4	sql		\N	3.6.3	\N	\N	4489977887
2010-03-03-NA01-1	kkrumlian	migration/3.0/2010-03-03-NA01.xml	2025-11-30 08:06:21.314741	623	EXECUTED	8:ea097807f6d63dd22325e92f4244d306	addColumn tableName=dn_item_data_map	Add Study Subject Id column to	\N	3.6.3	\N	\N	4489977887
2010-03-03-NA01-2	kkrumlian	migration/3.0/2010-03-03-NA01.xml	2025-11-30 08:06:21.319244	624	EXECUTED	8:efa0d2816f82c9043e332b2627cc768e	sql	Update Study Subject Id column	\N	3.6.3	\N	\N	4489977887
2010-03-03-NA01-3	kkrumlian	migration/3.0/2010-03-03-NA01.xml	2025-11-30 08:06:21.322992	625	EXECUTED	8:1f980ac52ddd692ed024a49c0e7b1876	sql		\N	3.6.3	\N	\N	4489977887
2010-03-03-NA01-4	kkrumlian	migration/3.0/2010-03-03-NA01.xml	2025-11-30 08:06:21.326677	626	EXECUTED	8:c7e28458175698b65c75c4b0b7f86231	sql		\N	3.6.3	\N	\N	4489977887
2010-03-03-NA01-5	kkrumlian	migration/3.0/2010-03-03-NA01.xml	2025-11-30 08:06:21.328818	627	MARK_RAN	8:337b08aff4b4cd4d229f2fb840587da5	sql		\N	3.6.3	\N	\N	4489977887
2010-03-03-NA01-6	kkrumlian	migration/3.0/2010-03-03-NA01.xml	2025-11-30 08:06:21.332437	628	EXECUTED	8:b51f2a8e72b0a5edb46cec3f1f4649af	update tableName=discrepancy_note	update discrepancy_note table	\N	3.6.3	\N	\N	4489977887
2010-05-31-5009-1	ahamid	migration/3.0/2010-05-31-5009.xml	2025-11-30 08:06:21.336925	629	EXECUTED	8:2ab3fbfcded4e6c9071eae53d6a9ea09	addColumn tableName=study	study (old_status)	\N	3.6.3	\N	\N	4489977887
2010-05-31-5009-3	ahamid	migration/3.0/2010-05-31-5009.xml	2025-11-30 08:06:21.341997	630	EXECUTED	8:9ff1f2d21c30111af68a6aedc3a5d65a	addForeignKeyConstraint baseTableName=study, constraintName=fk_old_status_id, referencedTableName=status		\N	3.6.3	\N	\N	4489977887
2010-05-31-5009-4	ahamid	migration/3.0/2010-05-31-5009.xml	2025-11-30 08:06:21.345483	631	EXECUTED	8:e8701c70ac501a3dc3badcc6e5f0f919	sql		\N	3.6.3	\N	\N	4489977887
2010-05-27-5095-2	kkrumlian	migration/3.0/2010-05-27-5095.xml	2025-11-30 08:06:21.34847	632	EXECUTED	8:a3d4f6a134686de2a380db28dd1bcef4	addColumn tableName=rule_set	Add item_id column to rule_set	\N	3.6.3	\N	\N	4489977887
2010-05-27-5095-3	kkrumlian	migration/3.0/2010-05-27-5095.xml	2025-11-30 08:06:21.351626	633	EXECUTED	8:1512a6a2c8e8bdbd772e11f709a30f9a	sql	Populate item_id with values	\N	3.6.3	\N	\N	4489977887
2010-05-27-5095-5	kkrumlian	migration/3.0/2010-05-27-5095.xml	2025-11-30 08:06:21.354961	634	EXECUTED	8:c8e36211c33c0cbaeed0f1ee077d614e	addColumn tableName=rule_set	Add item_group_id column to rule_set	\N	3.6.3	\N	\N	4489977887
2010-05-27-5095-6	kkrumlian	migration/3.0/2010-05-27-5095.xml	2025-11-30 08:06:21.357884	635	EXECUTED	8:7de250a859bc8cea3e599103d07d7ea8	sql	Populate item_group_id with values	\N	3.6.3	\N	\N	4489977887
2010-07-16-NA01-1	kkrumlian	migration/3.0/2010-07-16-NA01.xml	2025-11-30 08:06:21.360923	636	EXECUTED	8:54f5f2705f14bd70841643699e43c6e4	addColumn tableName=rule	add study_id to rule table	\N	3.6.3	\N	\N	4489977887
2010-07-16-NA01-2	kkrumlian	migration/3.0/2010-07-16-NA01.xml	2025-11-30 08:06:21.363854	637	EXECUTED	8:b903b5bc904bfe9bfca564311ea5c54a	sql	update study_id to rule table	\N	3.6.3	\N	\N	4489977887
2010-07-16-NA01-3	kkrumlian	migration/3.0/2010-07-16-NA01.xml	2025-11-30 08:06:21.367968	638	EXECUTED	8:ebf8cbc988af2ad4f132b5d3af1caf9e	sql	update study_id to rule table	\N	3.6.3	\N	\N	4489977887
2010-07-30-5255-1	thickerson	migration/3.0/2010-07-30-5255.xml	2025-11-30 08:06:21.371851	639	EXECUTED	8:407fcbfaf45fc1141998e36145f3757a	sql	updating ordinals in study event definition table to remove duplicates	\N	3.6.3	\N	\N	4489977887
2010-09-22-5926-1	kkrumlian	migration/3.0/2010-09-22-5926.xml	2025-11-30 08:06:21.381121	640	EXECUTED	8:15e7e80263ea19988d215669e6d8ee12	sql	fix a bug introduced in 3.0.4 that allowed Pdate to store dd-MMM-yyyy instead of mm/dd/yyyy	\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-1	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.389518	641	EXECUTED	8:391d742797292a39ff1cbfd7cfaf0712	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-2	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.39586	642	EXECUTED	8:2dbecf83f6fd1f1469a88b587e14a6cc	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-3	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.402165	643	EXECUTED	8:cbaa5492222d19e505acd32299ed3786	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-4	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.408336	644	EXECUTED	8:93e6f2efe24f7a1d3d4879aaf37ab7ce	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-5	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.415956	645	EXECUTED	8:1613cf2cfe6c637b34cbdc7a4cb131be	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-6	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.423145	646	EXECUTED	8:1b98514ad6862389e2f8e363e365a96d	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-12	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.460613	652	EXECUTED	8:21fea4c9f2cbc980ec7d3ba89f45532d	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-13	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.468649	653	EXECUTED	8:c25ba30ef717e6feb17f1baf3c26cf6d	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-14	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.475107	654	EXECUTED	8:0459dcd96354b26de67811d093edbb4a	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-15	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.480935	655	EXECUTED	8:4c4c480b702eb47143a3c00834a5a8f4	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-16	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.488125	656	EXECUTED	8:6129ff38db913d62b24c97b0e15fa7e4	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-17	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.494532	657	EXECUTED	8:f59222784494d6816daa8a7132bdff67	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-18	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.501316	658	EXECUTED	8:3438c9439f31a41d71d910594825833c	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-19	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.508509	659	EXECUTED	8:c6c6acaf5692fc453a379addb7db6c54	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-20	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.515443	660	EXECUTED	8:ff1effb995283254ae88cfa391dcabaf	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-21	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.521741	661	EXECUTED	8:b8116b6ca3924c71356269774723e11e	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-22	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.527745	662	EXECUTED	8:dfad2fe53ab0a77e9c82beda8f574951	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-23	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.533336	663	EXECUTED	8:e556f8cfeea22ef1a1773f3d695dcd17	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-24	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.540375	664	EXECUTED	8:1e9ad302e79bbbf8056f98c0d4127e6f	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-25	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.545816	665	EXECUTED	8:098dfa90593cad83b8998f06400da527	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-26	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.552934	666	EXECUTED	8:7d86594c7d33a5988910642b4cf5325d	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-27	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.559926	667	EXECUTED	8:c15afac03bf05da47a4d825aacafbe4e	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-28	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.566124	668	EXECUTED	8:ace731973bf0ae7675ad767ea8b891d9	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-29	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.572705	669	EXECUTED	8:a0702cbbd1b76133b57cc00bb49598ed	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-30	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.578774	670	EXECUTED	8:f013aa05f4fcfbe47cc22f09283335f6	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-31	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.58583	671	EXECUTED	8:1e1e59d22efc79063c4279ace74e5402	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-32	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.592546	672	EXECUTED	8:9654279247f97ab258db59b7dc5883d3	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-33	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.598727	673	EXECUTED	8:da961cb9b7ae24b6e0ef3bd823e6c76c	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-34	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.605588	674	EXECUTED	8:43390bfe73c799215cbeed50ff5b8691	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-35	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.612652	675	EXECUTED	8:935f8eb613513c83d9fc044047171823	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-36	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.624976	676	EXECUTED	8:489e78684c403d0673e94b150b5fbcd7	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-37	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.631413	677	EXECUTED	8:5204339ff1c50ccd232a78f8a677630d	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-38	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.638529	678	EXECUTED	8:554c03f28847ea00a82327b1c4aad295	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-39	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.649989	679	EXECUTED	8:d5e6cf3508429d08eeb59747fed382a8	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-40	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.656484	680	EXECUTED	8:a53be88eaf596490867cd65cdf352dad	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-41	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.662919	681	EXECUTED	8:8975e9305c667755d2462eb87467bbcc	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-42	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.67054	682	EXECUTED	8:3dcd43322b172b40ae8080a5e0fceafa	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-43	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.678779	683	EXECUTED	8:0c32f3e54e9bb7e563ddd695a9796e16	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-44	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.690401	684	EXECUTED	8:d09678ff87dee6155c542acc175f816d	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-45	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.697343	685	EXECUTED	8:260343bcd9957a8e8c711e516e79da7e	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-46	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.7052	686	EXECUTED	8:39e43aefefdf151a62786502de8011b7	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-47	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.715558	687	EXECUTED	8:7740869808d9f1c9de73ebd49f21d8cc	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-48	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.725834	688	EXECUTED	8:3c16e0ebbac544ae09113fddbc2093bd	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-49	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.732045	689	EXECUTED	8:03175ca79220dc138ef8e0f9cff290f1	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-50	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.739562	690	EXECUTED	8:1b2d0ea1fdfcd841d572422ce63462db	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-51	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.748777	691	EXECUTED	8:6f47269429f2afe48f91416789f26ed8	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-52	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.756224	692	EXECUTED	8:7b7572bf601bcdb526338c99af874095	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-53	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.762641	693	EXECUTED	8:70155bb5383f102baf189e2b08c0cfa2	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-54	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.76921	694	EXECUTED	8:0d1417c99ae5646d8ce6489a47a1a5a4	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-55	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.775732	695	EXECUTED	8:78ed417d9499da090bd45b89080b2613	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-56	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.78171	696	EXECUTED	8:f7b6f637b3aad7a37353b1d8ad55052c	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-57	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.788303	697	EXECUTED	8:c7d7dc22c5113fef489cb8affdfaa8ad	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-58	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.794277	698	EXECUTED	8:2e21521fee06b91ebf0060e2bf672202	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-59	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.801394	699	EXECUTED	8:38ff087bfbd8aa6b855cfae339d3f6dc	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-60	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.808185	700	EXECUTED	8:67e0b88da9bd8bb0bb9373cd51e8d5c7	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-61	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.814718	701	EXECUTED	8:076ed5317b33d7d8c9d9901d3dafc9a0	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-62	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.821251	702	EXECUTED	8:34063462d1138e22890c06a90898808e	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-63	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.827256	703	EXECUTED	8:63861e05eb5c415288dc9cf89894e3cc	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-64	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.833259	704	EXECUTED	8:6e64695401ce316f78901c936776e675	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-65	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.839637	705	EXECUTED	8:115273b21ff0a9d4bbd67cc778ebd7c4	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-66	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.845967	706	EXECUTED	8:9cfff0870912bac946ff8cff4c077743	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-67	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.853555	707	EXECUTED	8:e8e7551fa69f413ac38489cb55188b22	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-68	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.860941	708	EXECUTED	8:518cbefeedb43eeda5d63bc2204fd1f3	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-69	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.869352	709	EXECUTED	8:61792dd2117bbe3ecec6fde43fa97333	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-70	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.879907	710	EXECUTED	8:d9d9e71c681c3ba8c8701562be4b6753	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-71	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.886894	711	EXECUTED	8:5de3797a9cd3d40eb619588ec56ba4ca	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-72	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.893469	712	EXECUTED	8:57ec4c5a46866ed1801486951e3565e1	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-73	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.90019	713	EXECUTED	8:f67821de396521cdd31960927c902623	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-74	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.906649	714	EXECUTED	8:521d56e3f52fab9fa28f7cc87a7ba627	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-75	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.912798	715	EXECUTED	8:41f411d1ac10ca81799ca5fa6d5beb71	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-76	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.919758	716	EXECUTED	8:0c47a53b4005cba8c2b7b3171aa9426a	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-77	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.927159	717	EXECUTED	8:faa5733acf5179e764f925b8f5ee22bf	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-78	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.934478	718	EXECUTED	8:771f03a58331eebfdf769b26c03dad42	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-79	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.943861	719	EXECUTED	8:6fb97905429026716fd154a659dc767b	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-80	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.951465	720	EXECUTED	8:a069270a68b8203e126af13a58b18586	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-81	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.958203	721	EXECUTED	8:0ab76468f6ef1133b00aaebcae032fca	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-82	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.963982	722	EXECUTED	8:9a4f966bfc4f405fa52960516ae1796e	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-83	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.970458	723	EXECUTED	8:6ec9ec82cda84c2de814e22c7baab0b4	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-84	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.976476	724	EXECUTED	8:c54bdaca065bd569f5327e39a4d25ea1	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-85	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.982661	725	EXECUTED	8:b831adc99dc761a39d5c1e18eec87d81	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-86	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.992419	726	EXECUTED	8:08f84ab05085dd66dd5e911ee6dcbf9d	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-87	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:21.9988	727	EXECUTED	8:000f64bb0e2e3189a933f80cdecf3daa	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-88	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.005506	728	EXECUTED	8:0dc6b3e50f70c1239992c790d9bbb7c9	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-89	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.011651	729	EXECUTED	8:2fd6e5b0b13681ed5062bd865d420fb9	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-90	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.022558	730	EXECUTED	8:12c302f09808699b1be4ced45982c009	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-91	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.029251	731	EXECUTED	8:62268d2d077be6f47474d8e71d387d0d	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-92	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.03606	732	EXECUTED	8:977b19ba3e0169ff05b7216cb0733e33	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-93	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.042242	733	EXECUTED	8:b15de58fb326a575412cef5e3e31d283	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-94	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.04843	734	EXECUTED	8:2567cf17d5ee043f32c294e3b1d7385b	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-95	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.054523	735	EXECUTED	8:984b476d448d79b63f2516f10e617cd6	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-96	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.061084	736	EXECUTED	8:55d517421bf6dfb5f41e2440e61713c1	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-97	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.067575	737	EXECUTED	8:ef2e184f3b95a345cc56b65aa73f865a	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-98	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.073878	738	EXECUTED	8:e583bc3b365788de565a0d9b70ed8182	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-99	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.079508	739	EXECUTED	8:9119ae960a43acf5b525edfa6b632fac	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-100	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.085294	740	EXECUTED	8:7bca9a36d155f48b5d67908e0a196466	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-101	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.091031	741	EXECUTED	8:6f36a6effb2688623d7cfcbd80b0b374	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-102	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.096784	742	EXECUTED	8:204715bf32f32d3b1376a16671a20fae	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-103	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.102898	743	EXECUTED	8:0f3d219bacbba95044661298ed83cbb8	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-104	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.109002	744	EXECUTED	8:6d0530e4ceff6ae31a6ea5f2f7c22140	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-105	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.115381	745	EXECUTED	8:a1db2ba5c65e34538891ffb4d5182015	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-106	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.122338	746	EXECUTED	8:def599481f052728275ec812d179144f	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-107	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.128468	747	EXECUTED	8:9564c0653d640dce49c33f6ff38836ac	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-108	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.134617	748	EXECUTED	8:53fda929e412a5e821fd2c12722a668f	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-109	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.140566	749	EXECUTED	8:a675f733ebf6832f4ea5f1c46a3c402d	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-110	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.146077	750	EXECUTED	8:cf6bdb177d1f8004c0e63dbb5f2634d0	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-111	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.151926	751	EXECUTED	8:0589153753e71c5a0f6503e7bf68ce15	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-112	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.159726	752	EXECUTED	8:0ac1ceef78b325b015ba2f1bcc68794f	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-113	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.166477	753	EXECUTED	8:bbd27c99905c9ac2b8cbaaea7c42c9c6	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-114	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.172573	754	EXECUTED	8:771212fe645da757bbb9ee0281df8922	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-115	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.178668	755	EXECUTED	8:733669f0d4a5585dbe9f8b24079f345b	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-116	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.184763	756	EXECUTED	8:15b491c641d0bb2a1448f0192063c193	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-117	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.192085	757	EXECUTED	8:ca5672d3309b96c6ec8294f60d7d04e7	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-118	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.198274	758	EXECUTED	8:91daa79df2875e1e451c26f517da6fa7	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-119	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.204688	759	EXECUTED	8:0da82a88bf6c804eb3e2785e59038e6a	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-120	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.210435	760	EXECUTED	8:45ef604a7f99eb43c22a045298d0c122	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-121	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.216702	761	EXECUTED	8:559cc22bd4d277d76d26eb4fde44e225	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-122	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.223174	762	EXECUTED	8:d6124a89eabfd54eb6682115a3e6b5b2	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-123	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.229435	763	EXECUTED	8:8dca45d1df1561a99191eccd8be4e9ce	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-124	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.235572	764	EXECUTED	8:5f8fb3ff2b3e7958b86dec0df47fe859	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-125	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.242399	765	EXECUTED	8:2b4990651f4a44d0eca83a0606f40632	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-126	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.248198	766	EXECUTED	8:f5bf4e8f65d41bb14cf8111e2308c177	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-127	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.254243	767	EXECUTED	8:511605968ca65c239e263e14c73c1a2b	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-128	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.260485	768	EXECUTED	8:b21dc8755dd9d3fbcb118fbccfb5aeaa	sql		\N	3.6.3	\N	\N	4489977887
2011-04-08-8840-129	pgawade	migration/amethyst/changeLogCreateIndexes.xml	2025-11-30 08:06:22.266381	769	EXECUTED	8:d842cd6166490fd7cf3f25cb922409c3	sql		\N	3.6.3	\N	\N	4489977887
2010-01-13-4575-1	kkrumlian	migration/amethyst/2010-01-13-4575.xml	2025-11-30 08:06:22.269873	770	EXECUTED	8:bf6db3a5e7ee638bbe3d38b3601fe5d9	addColumn tableName=rule_action	update rule_action add oids column	\N	3.6.3	\N	\N	4489977887
2010-01-13-4575-2	kkrumlian	migration/amethyst/2010-01-13-4575.xml	2025-11-30 08:06:22.277551	771	EXECUTED	8:1b7be94ab5d19d990d614867f0ec3240	createTable tableName=rule_action_run	Create a table named audit_user_login	\N	3.6.3	\N	\N	4489977887
2010-01-13-4575-4	kkrumlian	migration/amethyst/2010-01-13-4575.xml	2025-11-30 08:06:22.28106	772	EXECUTED	8:68b6d746b435bf3672936aeb8aff9981	addColumn tableName=rule_action	update rule_action add rule_action_run_id column	\N	3.6.3	\N	\N	4489977887
2010-01-13-4575-5	kkrumlian	migration/amethyst/2010-01-13-4575.xml	2025-11-30 08:06:22.291749	773	EXECUTED	8:ec1800950c1a002efee3527d308cd0d6	createTable tableName=rule_action_property	Create a table named rule_action_property	\N	3.6.3	\N	\N	4489977887
2010-01-13-4575-7	kkrumlian	migration/amethyst/2010-01-13-4575.xml	2025-11-30 08:06:22.295686	774	EXECUTED	8:9d63bfa0d1c7a0bf75ff34d0023c128e	dropColumn columnName=oids, tableName=rule_action	update rule_action drop oids column	\N	3.6.3	\N	\N	4489977887
2010-01-13-4575-8	kkrumlian	migration/amethyst/2010-01-13-4575.xml	2025-11-30 08:06:22.306725	775	EXECUTED	8:52d4dcace836b74204899c9432b9399c	createTable tableName=rule_action_run_log	Create a table named rule_action_run_log	\N	3.6.3	\N	\N	4489977887
2010-01-13-4575-10	kkrumlian	migration/amethyst/2010-01-13-4575.xml	2025-11-30 08:06:22.311369	776	EXECUTED	8:3a220d5cdb8dc10bc8f09b1ad07eff37	dropColumn columnName=reference, tableName=rule_action_property; addColumn tableName=rule_action_property	Drop/Add Column	\N	3.6.3	\N	\N	4489977887
2011-03-01-4575-1	kkrumlian	migration/amethyst/2011-03-01-4575.xml	2025-11-30 08:06:22.316605	777	EXECUTED	8:3fa5b88359381fea10a35c96c3655260	sql	Add a row to rule_action_run and update rule_action row	\N	3.6.3	\N	\N	4489977887
2010-02-03-4593-1	thickerson	migration/amethyst/2010-02-03-4593.xml	2025-11-30 08:06:22.321042	778	EXECUTED	8:f3edf6cc2da435479910210f50a0344f	addColumn tableName=item_form_metadata	Add a column to item_form_metadata	\N	3.6.3	\N	\N	4489977887
2010-02-03-4593-2	thickerson	migration/amethyst/2010-02-03-4593.xml	2025-11-30 08:06:22.324681	779	EXECUTED	8:cad2a7e0fa14447c0d235c805e576da0	addColumn tableName=item_group_metadata	Add a column to item_group_metadata	\N	3.6.3	\N	\N	4489977887
2010-03-03-4618-1	thickerson	migration/amethyst/2010-03-03-4618.xml	2025-11-30 08:06:22.331945	780	EXECUTED	8:a7f0d32efe351d66a4e640f8ae1dd19a	createTable tableName=dyn_item_form_metadata	Create a table named dynamics_item_form_metadata	\N	3.6.3	\N	\N	4489977887
2010-03-03-4618-2	thickerson	migration/amethyst/2010-03-03-4618.xml	2025-11-30 08:06:22.340018	781	EXECUTED	8:d406591fb92b52dc8141c3d3c1a147a2	createTable tableName=dyn_item_group_metadata	Create a table named dynamics_item_group_metadata	\N	3.6.3	\N	\N	4489977887
2010-03-30-4618-1	thickerson	migration/amethyst/2010-03-30-4618.xml	2025-11-30 08:06:22.343596	782	EXECUTED	8:73ebe6713ee8b9703f7ecef684adbcc0	addColumn tableName=dyn_item_form_metadata	Add a column to dyn_item_form_metadata	\N	3.6.3	\N	\N	4489977887
2010-03-30-4618-2	thickerson	migration/amethyst/2010-03-30-4618.xml	2025-11-30 08:06:22.347066	783	EXECUTED	8:6ad86a5de9928572cced7a6fad04ae4b	addColumn tableName=dyn_item_form_metadata	Add a column to dyn_item_form_metadata: PASSED DDE	\N	3.6.3	\N	\N	4489977887
2010-03-30-4618-3	thickerson	migration/amethyst/2010-03-30-4618.xml	2025-11-30 08:06:22.350858	784	EXECUTED	8:5e864ec6f87ad75cae9046835597fd03	addColumn tableName=dyn_item_group_metadata	Add a column to dyn_item_group_metadata: PASSED DDE	\N	3.6.3	\N	\N	4489977887
2010-05-27-5095-1	kkrumlian	migration/amethyst/2010-05-27-5095.xml	2025-11-30 08:06:22.354415	785	EXECUTED	8:75e81d01081a127ab2d39af601b46040	sql	Change RuleSet so study event definition id can be null	\N	3.6.3	\N	\N	4489977887
2010-07-01-5245-1	ahamid	migration/amethyst/2010-07-01-5245.xml	2025-11-30 08:06:22.360775	786	EXECUTED	8:92432dac7a0b2b8f977709645f95a7b0	sql	CREATE A VIEW	\N	3.6.3	\N	\N	4489977887
2010-07-01-5245-3	ahamid	migration/amethyst/2010-07-01-5245.xml	2025-11-30 08:06:22.366717	787	EXECUTED	8:69643d61a5144e62973df7ab129bc8b3	sql	RECREATE THE VIEW WITH SOME NEW CONDITION	\N	3.6.3	\N	\N	4489977887
2011-05-9305-1	ahamid	migration/amethyst/2011-05-28-9305.xml	2025-11-30 08:06:22.373325	788	MARK_RAN	8:e74c826041bc046dc8b99a584744975e	createTable tableName=oc_qrtz_job_details		\N	3.6.3	\N	\N	4489977887
2011-05-9305-2	ahamid	migration/amethyst/2011-05-28-9305.xml	2025-11-30 08:06:22.37787	789	MARK_RAN	8:4387cd4795d644ef3aa2fe8b762c035d	createTable tableName=oc_qrtz_triggers		\N	3.6.3	\N	\N	4489977887
2010-07-07-5429-1	thickerson	migration/amethyst/2010-07-07-5429.xml	2025-11-30 08:06:22.381096	790	EXECUTED	8:b0277c2725cbdf81f8acf4402fb79df8	sql	Change oc_qrtz_job_details class names for EXPORT DATA JOBS	\N	3.6.3	\N	\N	4489977887
2010-07-07-5429-2	thickerson	migration/amethyst/2010-07-07-5429.xml	2025-11-30 08:06:22.384245	791	EXECUTED	8:88fa2b3c9572939125a5b3cab0493ef2	sql	Change oc_qrtz_job_details class names for IMPORT DATA JOBS	\N	3.6.3	\N	\N	4489977887
2010-07-14-5265-1	ahamid	migration/amethyst/2010-07-14-5265.xml	2025-11-30 08:06:22.388785	792	EXECUTED	8:11abfba952ade539a3e6c6455d4dc922	addColumn tableName=item_group_metadata	item_group_metadata (repeating_group)	\N	3.6.3	\N	\N	4489977887
2010-08-19-NA01-1	kkrumlian	migration/amethyst/2010-08-19-NA01.xml	2025-11-30 08:06:22.393247	793	EXECUTED	8:617ba684c33ecbe9a19a02b12a151991	addColumn tableName=user_account	add run webservices column to user_account table	\N	3.6.3	\N	\N	4489977887
2010-05-27-5724	jamuna	migration/amethyst/2010-08-24-5724.xml	2025-11-30 08:06:22.399032	794	EXECUTED	8:30ac2cd4b3a51815929cd01c955e6ca0	dropView viewName=dn_age_days	Dropping the view before changing the  date type	\N	3.6.3	\N	\N	4489977887
2010-05-27-5724-0	jamuna	migration/amethyst/2010-08-24-5724.xml	2025-11-30 08:06:22.427459	795	EXECUTED	8:ed396587a64de457aed01bb8e55d2351	sql	Change data type of created_date to timestamp	\N	3.6.3	\N	\N	4489977887
2010-05-27-5724-2	jamuna	migration/amethyst/2010-08-24-5724.xml	2025-11-30 08:06:22.431523	796	EXECUTED	8:ed396587a64de457aed01bb8e55d2351	sql	Change data type of created_date to timestamp	\N	3.6.3	\N	\N	4489977887
2010-05-27-5724-1	jamuna	migration/amethyst/2010-08-24-5724.xml	2025-11-30 08:06:22.438313	797	EXECUTED	8:c63e2de857b8c94466b6e26a910d41a4	createView viewName=dn_age_days	recreating the view back	\N	3.6.3	\N	\N	4489977887
2010-05-27-5724-3	jamuna	migration/amethyst/2010-08-24-5724.xml	2025-11-30 08:06:22.443048	798	EXECUTED	8:30ac2cd4b3a51815929cd01c955e6ca0	dropView viewName=dn_age_days	Dropping the view before changing the  date type	\N	3.6.3	\N	\N	4489977887
2010-05-27-5724-4	jamuna	migration/amethyst/2010-08-24-5724.xml	2025-11-30 08:06:22.448524	799	EXECUTED	8:c63e2de857b8c94466b6e26a910d41a4	createView viewName=dn_age_days	recreating the view back	\N	3.6.3	\N	\N	4489977887
2010-08-26-5724	jamuna	migration/amethyst/2010-08-26-5724.xml	2025-11-30 08:06:22.453419	800	EXECUTED	8:30ac2cd4b3a51815929cd01c955e6ca0	dropView viewName=dn_age_days	Dropping the view before changing the  date type	\N	3.6.3	\N	\N	4489977887
2010-08-26-5724-2	jamuna	migration/amethyst/2010-08-26-5724.xml	2025-11-30 08:06:22.480466	801	EXECUTED	8:52da625ac87ad262752a02dc867ac92a	sql	Change data type of created_date back to date	\N	3.6.3	\N	\N	4489977887
2010-08-26-5724-1	jamuna	migration/amethyst/2010-08-26-5724.xml	2025-11-30 08:06:22.487351	802	EXECUTED	8:c63e2de857b8c94466b6e26a910d41a4	createView viewName=dn_age_days	recreating the view back	\N	3.6.3	\N	\N	4489977887
2010-08-26-5724-3	jamuna	migration/amethyst/2010-08-26-5724.xml	2025-11-30 08:06:22.493041	803	EXECUTED	8:30ac2cd4b3a51815929cd01c955e6ca0	dropView viewName=dn_age_days	Dropping the view again to create the view without owner name	\N	3.6.3	\N	\N	4489977887
2010-08-26-5724-4	jamuna	migration/amethyst/2010-08-26-5724.xml	2025-11-30 08:06:22.498675	804	EXECUTED	8:c63e2de857b8c94466b6e26a910d41a4	createView viewName=dn_age_days	recreating the view back	\N	3.6.3	\N	\N	4489977887
2010-08-26-5237-1	ahamid	migration/amethyst/2010-08-26-5732.xml	2025-11-30 08:06:22.502517	805	EXECUTED	8:0a6e507cacc04cc4cf77b53a6a1faf4c	insert tableName=study_parameter	Insert a new record in the studyParameter table	\N	3.6.3	\N	\N	4489977887
2010-08-26-5237-2	ahamid	migration/amethyst/2010-08-26-5732.xml	2025-11-30 08:06:22.50717	806	EXECUTED	8:73c971ce18d6b20029ebb0f92ea64e24	sql	Change study_parameter values	\N	3.6.3	\N	\N	4489977887
2010-08-26-5237-3	ahamid	migration/amethyst/2010-08-26-5732.xml	2025-11-30 08:06:22.510099	807	EXECUTED	8:d45e75f2af8a957716dc1ea4ccf6a110	sql	Change study_parameter values	\N	3.6.3	\N	\N	4489977887
2010-10-05-5556-1	thickerson	migration/amethyst/2010-10-05-5556.xml	2025-11-30 08:06:22.524525	808	EXECUTED	8:8ee7e73daaecd12bec656734d496274f	sql	Change data type of created_date to timestamp	\N	3.6.3	\N	\N	4489977887
2010-10-11-5962-1	ywang	migration/amethyst/2010-10-11-5962.xml	2025-11-30 08:06:22.528723	809	EXECUTED	8:dfbadd97abfee9158a8cfb28a14ded6a	sql	Update Resolution Status Ids of Parent DNs As Their Last Child	\N	3.6.3	\N	\N	4489977887
2010-10-11-5962-3	ywang	migration/amethyst/2010-10-11-5962.xml	2025-11-30 08:06:22.534079	810	EXECUTED	8:828196c835b142c5c2fd8b61f9d80b8c	sql	Create or Replace a View DN_DAYS	\N	3.6.3	\N	\N	4489977887
2010-11-24-6084-1-1	kkrumlian	migration/amethyst/2010-11-24-6084.xml	2025-11-30 08:06:22.539595	811	EXECUTED	8:e28ffbac82cdc68287eeaf4456429a7c	sql	Disable item_data triggers	\N	3.6.3	\N	\N	4489977887
2010-11-24-6084-1	kkrumlian	migration/amethyst/2010-11-24-6084.xml	2025-11-30 08:06:22.544701	812	EXECUTED	8:6abad164692d0898f4330db346841446	sql	Change date format for dataype date,pdate (MM/dd/YYYY) to ISO-8601	\N	3.6.3	\N	\N	4489977887
2010-11-24-6084-3	kkrumlian	migration/amethyst/2010-11-24-6084.xml	2025-11-30 08:06:22.555457	813	EXECUTED	8:57da8fa1e8163c0e2735d1f01429450b	sql	Change date format for dataype pdate (MMM-YYYY) to ISO-8601	\N	3.6.3	\N	\N	4489977887
2010-11-24-6084-5	kkrumlian	migration/amethyst/2010-11-24-6084.xml	2025-11-30 08:06:22.559634	814	EXECUTED	8:35fa92cfaedb984b44aa3141ccaad9ef	sql	Disable item_data triggers	\N	3.6.3	\N	\N	4489977887
2010-12-02-6421-1	ahamid	migration/amethyst/2010-12-02-6421.xml	2025-11-30 08:06:22.562993	815	EXECUTED	8:59d1b78348ab866633c676948cd8c9d9	renameColumn newColumnName=old_status_id, oldColumnName=prev_status, tableName=event_crf	Rename Column Name	\N	3.6.3	\N	\N	4489977887
2010-12-02-6421-3	ahamid	migration/amethyst/2010-12-02-6421.xml	2025-11-30 08:06:22.56735	816	EXECUTED	8:84e4ca26f553e64b91812cd77267d66b	sql	Update null values	\N	3.6.3	\N	\N	4489977887
2010-12-02-6421-5	ahamid	migration/amethyst/2010-12-02-6421.xml	2025-11-30 08:06:22.571649	817	EXECUTED	8:939a659fc7bd6b733a2e930ee371ed26	sql	Update null values	\N	3.6.3	\N	\N	4489977887
2010-12-17-NA01-1	kkrumlian	migration/amethyst/2010-12-17-NA01.xml	2025-11-30 08:06:22.575987	818	EXECUTED	8:6f1b401f214247a8ab064702a71e47c9	sql		\N	3.6.3	\N	\N	4489977887
2010-12-17-NA01-2	pgawade (generated)	migration/amethyst/2010-12-17-NA01.xml	2025-11-30 08:06:22.578045	819	MARK_RAN	8:677dba04d819ab8d6157434fed35e35a	sql		\N	3.6.3	\N	\N	4489977887
2010-12-17-NA01-3	pgawade (generated)	migration/amethyst/2010-12-17-NA01.xml	2025-11-30 08:06:22.582012	820	EXECUTED	8:130797b7819393087e39243ea9cabf80	sql		\N	3.6.3	\N	\N	4489977887
2011-02-07-7181-1	ywang	migration/amethyst/2011-02-07-7181.xml	2025-11-30 08:06:22.593602	821	EXECUTED	8:ba229ef7b83a78763994b46d8329914f	createTable tableName=scd_item_metadata	Create table scd_item_metadata	\N	3.6.3	\N	\N	4489977887
2011-02-07-7181-4	ywang	migration/amethyst/2011-02-07-7181.xml	2025-11-30 08:06:22.599508	822	EXECUTED	8:012608ed4f086e90f11d7ac6ef0496f9	addForeignKeyConstraint baseTableName=scd_item_metadata, constraintName=scd_meta_fk_scd_form_meta_id, referencedTableName=item_form_metadata	Add foreign key for scd_item_metadata	\N	3.6.3	\N	\N	4489977887
2011-02-07-7181-5	ywang	migration/amethyst/2011-02-07-7181.xml	2025-11-30 08:06:22.605235	823	EXECUTED	8:24d3cef8f63967ce9fffce32e76ae9f9	addForeignKeyConstraint baseTableName=scd_item_metadata, constraintName=scd_meta_fk_control_meta_id, referencedTableName=item_form_metadata	Add foreign key for scd_item_metadata	\N	3.6.3	\N	\N	4489977887
2011-03-01-6567-1	ywang	migration/amethyst/2011-03-01-6567.xml	2025-11-30 08:06:22.612046	824	EXECUTED	8:cfb03f1f229b7fe824feda948b0e483e	createView viewName=view_item_unit	create temporary view	\N	3.6.3	\N	\N	4489977887
2011-03-01-6567-3	ywang	migration/amethyst/2011-03-01-6567.xml	2025-11-30 08:06:22.61623	825	EXECUTED	8:32149aecbe69fe5b0931107860df9360	sql	insert into measurement_unit.name and oc_oid	\N	3.6.3	\N	\N	4489977887
2011-03-01-6567-5	ywang	migration/amethyst/2011-03-01-6567.xml	2025-11-30 08:06:22.621268	826	EXECUTED	8:b0eb9ad7e51e692a1604e0ffe177af0c	sql	insert into measurement_unit.name and oc_oid	\N	3.6.3	\N	\N	4489977887
2011-03-01-6567-7	ywang	migration/amethyst/2011-03-01-6567.xml	2025-11-30 08:06:22.625012	827	EXECUTED	8:3eb2f063553396a87874ee7cb256ccae	sql	update measurement_unit.oc_oid	\N	3.6.3	\N	\N	4489977887
2011-03-01-6567-9	ywang	migration/amethyst/2011-03-01-6567.xml	2025-11-30 08:06:22.629418	828	EXECUTED	8:08caa4295640b5ed869fd4bca06541b7	dropView viewName=view_item_unit	drop temporary view	\N	3.6.3	\N	\N	4489977887
2011-03-01-7700-1	ahamid	migration/amethyst/2011-03-01-7700.xml	2025-11-30 08:06:22.633728	829	EXECUTED	8:b966f9f4e00f81550600b9ff48d1102d	addColumn tableName=event_crf	update event_crf add sdv_update_id column	\N	3.6.3	\N	\N	4489977887
2011-03-01-7700-2	ahamid	migration/amethyst/2011-03-01-7700.xml	2025-11-30 08:06:22.639233	830	EXECUTED	8:b881d4f8c5d5e15c0c44a5742b43462a	sql	create or replace event_crf_trigger for event crf sdv status	\N	3.6.3	\N	\N	4489977887
2011-03-16-5930-1	ahamid	migration/amethyst/2011-03-16-5930.xml	2025-11-30 08:06:22.643287	831	EXECUTED	8:facaaf6c8674b85522caa002c630b64e	addColumn tableName=item_data	Item_Data (old_status)	\N	3.6.3	\N	\N	4489977887
2011-03-22-8248-1	pgawade	migration/amethyst/2011-03-22-8248.xml	2025-11-30 08:06:22.654476	832	EXECUTED	8:87eeec90e825ade893d965132ebe92b4	createTable tableName=usage_statistics_data		\N	3.6.3	\N	\N	4489977887
2011-04-05-7475-1	jnyayapathi	migration/amethyst/2011-04-05-7475.xml	2025-11-30 08:06:22.657493	833	EXECUTED	8:3a4ab5a073e324acaa159caf40e62176	sql	Change export data jobs trigger status to complete	\N	3.6.3	\N	\N	4489977887
2011-05-03-9430-3	jnyayapathi	migration/amethyst/2011-05-03-9430.xml	2025-11-30 08:06:22.664224	834	EXECUTED	8:2f7ab9a8c08b51899f101b95a91a294b	sql	Add a constraint when no item data rows are present	\N	3.6.3	\N	\N	4489977887
2011-05-20-9703-1	pgawade (generated)	migration/amethyst/2011-05-20-9703.xml	2025-11-30 08:06:22.666103	835	MARK_RAN	8:138782ab24f59f2699316718da2bd39f	sql		\N	3.6.3	\N	\N	4489977887
2011-05-20-9703-2	jnyayapathi	migration/amethyst/2011-05-20-9703.xml	2025-11-30 08:06:22.66808	836	MARK_RAN	8:2c802e760d41bf25e4af3359c6a4fe6c	sql		\N	3.6.3	\N	\N	4489977887
2010-12-17-NA01-3	pgawade (generated)	migration/amethyst/2011-05-20-9703.xml	2025-11-30 08:06:22.672172	837	EXECUTED	8:130797b7819393087e39243ea9cabf80	sql		\N	3.6.3	\N	\N	4489977887
2011-07-27-8874-1	ywang	migration/amethyst/2011-07-27-8874.xml	2025-11-30 08:06:22.6757	838	EXECUTED	8:f3c1cb91f8596e0f514c2dac8fbf62b7	sql	create item_data_initial_trigger()	\N	3.6.3	\N	\N	4489977887
2011-07-27-8874-2	ywang	migration/amethyst/2011-07-27-8874.xml	2025-11-30 08:06:22.67941	839	EXECUTED	8:59d9c4242d7ec5f2da311ae52e9d06de	sql	create trigger item_data_initial	\N	3.6.3	\N	\N	4489977887
2011-07-27-8874-3	ywang	migration/amethyst/2011-07-27-8874.xml	2025-11-30 08:06:22.681447	840	MARK_RAN	8:b2de51574502b3af7e1b2ac919c89edf	sql	create trigger item_data_initial	\N	3.6.3	\N	\N	4489977887
2011-07-27-8874-4	ywang	migration/amethyst/2011-07-27-8874.xml	2025-11-30 08:06:22.683678	841	MARK_RAN	8:d0dbf71a4311f73bde32b3837b4b3706	sql	add procedure item_data_initial_trigger	\N	3.6.3	\N	\N	4489977887
2011-07-27-8874-5	ywang	migration/amethyst/2011-07-27-8874.xml	2025-11-30 08:06:22.685633	842	MARK_RAN	8:dd6b96388e705859095f4f5c9f59eb04	sql	create item_data_initial_trigger	\N	3.6.3	\N	\N	4489977887
2011-08-03-10666-1	ywang	migration/amethyst/2011-08-03-10666.xml	2025-11-30 08:06:22.689222	843	EXECUTED	8:f85a6b03f07e430c4cdcffa7430f822a	insert tableName=response_type	insert new response type	\N	3.6.3	\N	\N	4489977887
2011-09-06-10813-2	pgawade	migration/amethyst/2011-09-06-10813.xml	2025-11-30 08:06:22.694882	844	EXECUTED	8:8775aefa650bbf929a6ec5a05f4be153	sql	update repeating_group column of item_group_metadata for 3.0 to 3.1 migrations on postgres database	\N	3.6.3	\N	\N	4489977887
2011-11-16-11950-1	htaycher (generated)	migration/amethyst/2011-11-16-11950.xml	2025-11-30 08:06:22.698213	845	EXECUTED	8:3c110feb2a634abe59fb200afc9286fc	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
2011-11-16-11950-3	htaycher 	migration/amethyst/2011-11-16-11950.xml	2025-11-30 08:06:22.701842	846	EXECUTED	8:56765057db461a39fffc73707b95700c	sql		\N	3.6.3	\N	\N	4489977887
2011-11-16-11950-4	htaycher 	migration/amethyst/2011-11-16-11950.xml	2025-11-30 08:06:22.706969	847	EXECUTED	8:bc8e1f4e059abc7ae681d52bbfb71394	sql		\N	3.6.3	\N	\N	4489977887
2011-11-16-11950-5	htaycher 	migration/amethyst/2011-11-16-11950.xml	2025-11-30 08:06:22.71126	848	EXECUTED	8:b5380b7c2e916077db6f4aa4121c0880	sql		\N	3.6.3	\N	\N	4489977887
2011-11-16-11950-12	htaycher	migration/amethyst/2011-11-16-11950.xml	2025-11-30 08:06:22.713312	849	MARK_RAN	8:744e52cd3a06dfe5ab0ac13874c1ff67	sql		\N	3.6.3	\N	\N	4489977887
2012-07-01-14506-11	htaycher	migration/amethyst/2012-07-01-14506.xml	2025-11-30 08:06:22.716665	850	EXECUTED	8:75273b46ee39f57c806426577ae92acf	insert tableName=configuration		\N	3.6.3	\N	\N	4489977887
2012-07-01-14506-12	htaycher	migration/amethyst/2012-07-01-14506.xml	2025-11-30 08:06:22.72036	851	EXECUTED	8:da145151e11a3b128b1415f7685538ef	insert tableName=configuration		\N	3.6.3	\N	\N	4489977887
2012-07-01-14506-13	htaycher	migration/amethyst/2012-07-01-14506.xml	2025-11-30 08:06:22.724461	852	EXECUTED	8:c60340c61e66954b1fb90e5b0245cf71	insert tableName=configuration		\N	3.6.3	\N	\N	4489977887
2012-07-01-14506-14	htaycher	migration/amethyst/2012-07-01-14506.xml	2025-11-30 08:06:22.727943	853	EXECUTED	8:d37801bf5ee5bedada99c373a1f5c239	insert tableName=configuration		\N	3.6.3	\N	\N	4489977887
2012-07-01-14506-19	htaycher	migration/amethyst/2012-07-01-14506.xml	2025-11-30 08:06:22.731129	854	EXECUTED	8:87e6a882c8f18c0827065d94820032ec	insert tableName=configuration		\N	3.6.3	\N	\N	4489977887
2012-07-01-14506-15	htaycher	migration/amethyst/2012-07-01-14506.xml	2025-11-30 08:06:22.734821	855	EXECUTED	8:100cf788c14f4b020c3a4ef59f4b1af3	insert tableName=configuration		\N	3.6.3	\N	\N	4489977887
2012-07-01-14506-18	drodrigues	migration/amethyst/2012-07-01-14506.xml	2025-11-30 08:06:22.739882	856	EXECUTED	8:356656c6bd9c16a44dd29f157a0872bb	insert tableName=configuration; insert tableName=configuration		\N	3.6.3	\N	\N	4489977887
2012-07-16-14454-1	htaycher	migration/amethyst/2012-07-16-14454.xml	2025-11-30 08:06:22.746258	857	EXECUTED	8:73c971ce18d6b20029ebb0f92ea64e24	sql	Change study_parameter values	\N	3.6.3	\N	\N	4489977887
2012-07-16-14454-2	htaycher	migration/amethyst/2012-07-16-14454.xml	2025-11-30 08:06:22.749105	858	EXECUTED	8:d45e75f2af8a957716dc1ea4ccf6a110	sql	Change study_parameter values	\N	3.6.3	\N	\N	4489977887
2012-08-29-14122-01	drodrigues	migration/amethyst/2012-08-29-14122.xml	2025-11-30 08:06:22.755274	859	EXECUTED	8:c2d42bec4963adc8207afcf68281181f	sql	View 'view_dn_stats'.	\N	3.6.3	\N	\N	4489977887
2012-08-29-14122-02	drodrigues	migration/amethyst/2012-08-29-14122.xml	2025-11-30 08:06:22.760752	860	EXECUTED	8:451205dd5fbd5f0a1a8d6788467b1987	sql	View 'view_study_hidden_event_definition_crf'.	\N	3.6.3	\N	\N	4489977887
2012-08-29-14122-03	drodrigues	migration/amethyst/2012-08-29-14122.xml	2025-11-30 08:06:22.76623	861	EXECUTED	8:66be27b053ccba6adb9335e4bd59e9a8	sql	View 'view_site_hidden_event_definition_crf'.	\N	3.6.3	\N	\N	4489977887
2012-08-29-14122-04	drodrigues	migration/amethyst/2012-08-29-14122.xml	2025-11-30 08:06:22.785385	862	EXECUTED	8:b2f11b02ecd2127272fbb4b0251a7589	sql	View 'view_dn_item_data'.	\N	3.6.3	\N	\N	4489977887
2012-08-29-14122-05	drodrigues	migration/amethyst/2012-08-29-14122.xml	2025-11-30 08:06:22.798745	863	EXECUTED	8:e77a09c93e8b96a9dfcf5ef7a2b2feb3	sql	View 'view_dn_event_crf'.	\N	3.6.3	\N	\N	4489977887
2012-08-29-14122-06	drodrigues	migration/amethyst/2012-08-29-14122.xml	2025-11-30 08:06:22.811577	864	EXECUTED	8:102d25d95933bb544daec558d0176cbf	sql	View 'view_dn_study_event'.	\N	3.6.3	\N	\N	4489977887
2012-08-29-14122-07	drodrigues	migration/amethyst/2012-08-29-14122.xml	2025-11-30 08:06:22.821645	865	EXECUTED	8:f12bf763b75e0013bad4fa1616435981	sql	View 'view_dn_study_subject'.	\N	3.6.3	\N	\N	4489977887
2012-08-29-14122-08	drodrigues	migration/amethyst/2012-08-29-14122.xml	2025-11-30 08:06:22.833901	866	EXECUTED	8:41c3ee6d825d44b35abaa9aa91b6a1f0	sql	View 'view_dn_subject'.	\N	3.6.3	\N	\N	4489977887
2012-08-29-14122-09	drodrigues	migration/amethyst/2012-08-29-14122.xml	2025-11-30 08:06:22.849825	867	EXECUTED	8:e5b5ca11f804386758d5df0963c99c65	sql	View 'view_discrepancy_note'.	\N	3.6.3	\N	\N	4489977887
2012-08-29-14122-10	drodrigues	migration/amethyst/2012-08-29-14122.xml	2025-11-30 08:06:22.881998	868	EXECUTED	8:7b5d4e32ab7d2fc4aba3d53606e2d831	sql	Indexes for the tables used in the view_discrepancy_notes query.	\N	3.6.3	\N	\N	4489977887
2012-08-29-14122-10-shared	drodrigues	migration/amethyst/2012-08-29-14122.xml	2025-11-30 08:06:22.885965	869	EXECUTED	8:60265f3f14731733638debb0feae942e	sql	Updating wrong entity names in study event mapping	\N	3.6.3	\N	\N	4489977887
2012-08-3-13347-01	drodrigues	migration/amethyst/2012-08-31-13347.xml	2025-11-30 08:06:22.889049	870	EXECUTED	8:10b932faf5e7019e2b1639d0266bf334	sql	Updating wrong case in DISCREPANCY_NOTE.ENTITY_TYPE	\N	3.6.3	\N	\N	4489977887
2013-04-16-MR330-01	jnyayapathi	migration/amethyst/2013-04-16-MR330.xml	2025-11-30 08:06:22.90294	871	EXECUTED	8:941f0bbff6b5b14e1cba5cb49765cb9c	sql	View 'view_dn_item_data'.	\N	3.6.3	\N	\N	4489977887
2013-04-16-MR330-03	jnyayapathi	migration/amethyst/2013-04-16-MR330.xml	2025-11-30 08:06:22.918588	872	EXECUTED	8:a5509e375e96d632c3367190da3c471e	sql	View 'view_dn_item_data'.	\N	3.6.3	\N	\N	4489977887
2013-04-16-MR330-04	jnyayapathi	migration/amethyst/2013-04-16-MR330.xml	2025-11-30 08:06:22.932215	873	EXECUTED	8:ca200af4e1b23ef6eb8e8984ecb75b23	sql	View 'view_dn_event_crf'.	\N	3.6.3	\N	\N	4489977887
2011-10-03-11376-1	htaycher (generated)	migration/customDevelopment/changeLogTypeInsert.xml	2025-11-30 08:06:22.936874	874	EXECUTED	8:2710f3de3a69a217c86ad1c3bb1f4706	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
2011-10-03-11376-3	htaycher 	migration/customDevelopment/changeLogCreateFunction.xml	2025-11-30 08:06:22.941568	875	EXECUTED	8:35e5a39aef9d84ce4c1e79270d7fc88a	sql		\N	3.6.3	\N	\N	4489977887
2011-10-03-11376-2	htaycher 	migration/customDevelopment/changeLogCreateFunction.xml	2025-11-30 08:06:22.945525	876	EXECUTED	8:6ff85bf725ba86b2fea57c553f3a083d	sql		\N	3.6.3	\N	\N	4489977887
2011-11-03-11376-9	htaycher	migration/customDevelopment/changeLogCreateFunction.xml	2025-11-30 08:06:22.947536	877	MARK_RAN	8:783fe47238344c3028c682554d12dcd0	sql		\N	3.6.3	\N	\N	4489977887
2013-07-31-OC-1403-1	jnyayapathi	migration/3.2/2013-07-31-OC-1403.xml	2025-11-30 08:06:22.951912	878	EXECUTED	8:0f4d5b7d764c4937c4996a6a7990d2e2	delete tableName=oc_qrtz_simple_triggers		\N	3.6.3	\N	\N	4489977887
2013-07-31-OC-1403-2	jnyayapathi	migration/3.2/2013-07-31-OC-1403.xml	2025-11-30 08:06:22.955179	879	EXECUTED	8:6cc6a43daf63e683ab2b5f7a2e88421f	delete tableName=oc_qrtz_triggers		\N	3.6.3	\N	\N	4489977887
2013-10-21-OC-3399-1	jnyayapathi	migration/3.2/2013-10-21-OC-3399.xml	2025-11-30 08:06:22.959002	880	EXECUTED	8:fe0e29973d70741c5eebdda06484d47b	update tableName=discrepancy_note_type		\N	3.6.3	\N	\N	4489977887
2013-10-21-OC-3399-2	jnyayapathi	migration/3.2/2013-10-21-OC-3399.xml	2025-11-30 08:06:22.962297	881	EXECUTED	8:f1643e1d1a7f74deb7412779e0d58d5a	update tableName=discrepancy_note_type		\N	3.6.3	\N	\N	4489977887
2013-10-21-OC-3399-4	jnyayapathi	migration/3.2/2013-10-21-OC-3399.xml	2025-11-30 08:06:22.966201	882	EXECUTED	8:be20cab74896b9eb0466c6b4ea7252a0	update tableName=discrepancy_note_type		\N	3.6.3	\N	\N	4489977887
2013-10-21-OC-3399-5	jnyayapathi	migration/3.2/2013-10-21-OC-3399.xml	2025-11-30 08:06:22.970957	883	EXECUTED	8:8a1f922701e7b320459494895e005941	update tableName=discrepancy_note_type		\N	3.6.3	\N	\N	4489977887
2013-10-21-OC-3399-6	jnyayapathi	migration/3.2/2013-10-21-OC-3399.xml	2025-11-30 08:06:22.975379	884	EXECUTED	8:b525f3654f3469919da407347d841510	update tableName=discrepancy_note_type		\N	3.6.3	\N	\N	4489977887
2013-10-21-OC-3399-7	jnyayapathi	migration/3.2/2013-10-21-OC-3399.xml	2025-11-30 08:06:22.979692	885	EXECUTED	8:87e0fc14c052ed4a146c56c6e5cf0c45	update tableName=discrepancy_note_type		\N	3.6.3	\N	\N	4489977887
2014-01-03-OC-3442-1	jrousseau	migration/3.2/2014-01-03-OC-3442.xml	2025-11-30 08:06:24.617571	886	EXECUTED	8:4e482a556364c9eb4b921506a1f3d6f9	createIndex indexName=i_versioning_map_item_id, tableName=versioning_map		\N	3.6.3	\N	\N	4489977887
2014-01-03-OC-3442-2	jrousseau	migration/3.2/2014-01-03-OC-3442.xml	2025-11-30 08:06:26.230304	887	EXECUTED	8:09ebbdfdebd47456514ff9ce5acd3add	createIndex indexName=i_versioning_map_crf_version_id, tableName=versioning_map		\N	3.6.3	\N	\N	4489977887
2014-01-15-OC-1276-1	kkrumlian	migration/3.2/2014-01-15-OC-1276.xml	2025-11-30 08:06:26.236265	888	EXECUTED	8:7f8533f7c3b5c1c41becb21c2333d454	sql		\N	3.6.3	\N	\N	4489977887
2014-01-30-OC-4168-1	kkrumlian	migration/3.2/2014-01-30-OC-4168.xml	2025-11-30 08:06:26.24126	889	EXECUTED	8:3977c45136c98d42e681693a6db15a4a	sql		\N	3.6.3	\N	\N	4489977887
2014-04-09-OC-5087-1	jrousseau	migration/3.3/2014-04-09-OC-5087.xml	2025-11-30 08:06:27.868023	890	EXECUTED	8:079bdaaadd3080a72f76de28fbdaf42c	createIndex indexName=i_difm_item_id, tableName=dyn_item_form_metadata		\N	3.6.3	\N	\N	4489977887
2014-04-09-OC-5087-2	jrousseau	migration/3.3/2014-04-09-OC-5087.xml	2025-11-30 08:06:29.497978	891	EXECUTED	8:120f7732ce69a6e5591b0d42b28e1157	createIndex indexName=i_difm_item_form_metadata_id, tableName=dyn_item_form_metadata		\N	3.6.3	\N	\N	4489977887
2014-04-09-OC-5087-3	jrousseau	migration/3.3/2014-04-09-OC-5087.xml	2025-11-30 08:06:31.256487	892	EXECUTED	8:3792ba683074d99bfd04844b02057c54	createIndex indexName=i_difm_event_crf_id, tableName=dyn_item_form_metadata		\N	3.6.3	\N	\N	4489977887
2014-04-09-OC-5087-4	jrousseau	migration/3.3/2014-04-09-OC-5087.xml	2025-11-30 08:06:32.844634	893	EXECUTED	8:c4085ec7f001c3e7c5b14a90656a97c7	createIndex indexName=i_difm_item_data_id, tableName=dyn_item_form_metadata		\N	3.6.3	\N	\N	4489977887
2014-04-09-OC-5087-5	jrousseau	migration/3.3/2014-04-09-OC-5087.xml	2025-11-30 08:06:34.527715	894	EXECUTED	8:206a2a191928c43a2d231c82125030df	createIndex indexName=i_difm_show_item, tableName=dyn_item_form_metadata		\N	3.6.3	\N	\N	4489977887
2014-04-09-OC-5087-6	jrousseau	migration/3.3/2014-04-09-OC-5087.xml	2025-11-30 08:06:36.155972	895	EXECUTED	8:c9b93a0f3712e1859a2dfde2575cc564	createIndex indexName=i_event_crf_study_event_id, tableName=event_crf		\N	3.6.3	\N	\N	4489977887
2014-04-09-OC-5087-7	jrousseau	migration/3.3/2014-04-09-OC-5087.xml	2025-11-30 08:06:37.710349	896	EXECUTED	8:484930b2d4e130fc82ed8036acc4b6a9	createIndex indexName=i_ifm_response_set_id, tableName=item_form_metadata		\N	3.6.3	\N	\N	4489977887
2014-04-09-OC-5087-8	jrousseau	migration/3.3/2014-04-09-OC-5087.xml	2025-11-30 08:06:39.325353	897	EXECUTED	8:b8d5db41d080311a155fdaebb934d718	createIndex indexName=i_ifm_section_id, tableName=item_form_metadata		\N	3.6.3	\N	\N	4489977887
2014-04-09-OC-5087-9	jrousseau	migration/3.3/2014-04-09-OC-5087.xml	2025-11-30 08:06:40.962073	898	EXECUTED	8:4d339959f3467d406fb7fb6bd7435669	createIndex indexName=i_ifm_item_id, tableName=item_form_metadata		\N	3.6.3	\N	\N	4489977887
2014-04-09-OC-5087-10	jrousseau	migration/3.3/2014-04-09-OC-5087.xml	2025-11-30 08:06:42.630933	899	EXECUTED	8:3cb4cca2d1a103ee15cba9ef937faa96	createIndex indexName=i_didm_column_name, tableName=dn_item_data_map		\N	3.6.3	\N	\N	4489977887
2010-04-15-OC-4822-1	jnyayapathi	migration/3.3/2014-04-15-OC-4822.xml	2025-11-30 08:06:42.635791	900	EXECUTED	8:a516ee73b926a575ef8f29db5629c37c	addColumn tableName=rule_action_property	Add Column	\N	3.6.3	\N	\N	4489977887
2010-04-15-OC-4822-2	jnyayapathi	migration/3.3/2014-04-15-OC-4822.xml	2025-11-30 08:06:42.640205	901	EXECUTED	8:993ffa483bdb1b15b07b01491ea074d2	addColumn tableName=rule_action	Add Column	\N	3.6.3	\N	\N	4489977887
2010-04-15-OC-4822-3	jnyayapathi	migration/3.3/2014-04-15-OC-4822.xml	2025-11-30 08:06:42.644758	902	EXECUTED	8:ce204584905c91d2f8c2aaa2e21316c4	addColumn tableName=rule_action_run	Add Column	\N	3.6.3	\N	\N	4489977887
2010-04-15-OC-4822-4	jnyayapathi	migration/3.3/2014-04-15-OC-4822.xml	2025-11-30 08:06:42.650269	903	EXECUTED	8:6bf84faf14c5f3b8dce3c7eba7d5444e	addColumn tableName=rule_action_run	Add Column	\N	3.6.3	\N	\N	4489977887
2010-04-15-OC-4822-5	jnyayapathi	migration/3.3/2014-04-15-OC-4822.xml	2025-11-30 08:06:42.65534	904	EXECUTED	8:64779746be191bb9853fab2f362a5091	addColumn tableName=rule_action_run	Add Column	\N	3.6.3	\N	\N	4489977887
2010-04-15-OC-4822-6	jnyayapathi	migration/3.3/2014-04-15-OC-4822.xml	2025-11-30 08:06:42.660392	905	EXECUTED	8:b32e38e5d18fe92816bbce230f874200	addColumn tableName=rule_action_run	Add Column	\N	3.6.3	\N	\N	4489977887
2010-04-15-OC-4822-7	jnyayapathi	migration/3.3/2014-04-15-OC-4822.xml	2025-11-30 08:06:42.664894	906	EXECUTED	8:3133792dd8e5f6447cb78c93014d4433	addColumn tableName=rule_action_run	Add Column	\N	3.6.3	\N	\N	4489977887
2010-04-15-OC-4822-8	jnyayapathi	migration/3.3/2014-04-15-OC-4822.xml	2025-11-30 08:06:42.67106	907	EXECUTED	8:40250431a09f709ea7b0f772f7659dae	addColumn tableName=rule_action_run	Add Column	\N	3.6.3	\N	\N	4489977887
2014-08-5767	jkeremian	migration/3.4/2014-08-15-5767.xml	2025-11-30 08:06:42.67643	908	EXECUTED	8:15615ff9ff55a410bb19787c48b7f68e	insert tableName=study_parameter	Insert a new record in the studyParameter table	\N	3.6.3	\N	\N	4489977887
2014-08-27-4488_1	jkeremian	migration/3.4/2014-08-27-5985.xml	2025-11-30 08:06:42.711101	909	EXECUTED	8:058431db8373d185983130fcaf99a97a	sql	Change data type of created_date to timestamp	\N	3.6.3	\N	\N	4489977887
2014-08-27-4488_2	jkeremian	migration/3.4/2014-08-27-5985.xml	2025-11-30 08:06:42.740776	910	EXECUTED	8:193b4afabdd371ebfd34d7d60ec2a010	sql	Change data type of updated_date to timestamp	\N	3.6.3	\N	\N	4489977887
2014-08-27-5897_1	jkeremian	migration/3.4/2014-08-29-5897.xml	2025-11-30 08:06:42.758973	911	EXECUTED	8:7ffb96a508b898ce43871365a04c73ec	sql	Change data type of created_date to timestamp	\N	3.6.3	\N	\N	4489977887
2014-08-27-5897_2	jkeremian	migration/3.4/2014-08-29-5897.xml	2025-11-30 08:06:42.790612	912	EXECUTED	8:73a8d7f4245220ba996b9c4761fbdea9	sql	Change data type of updated_date to timestamp	\N	3.6.3	\N	\N	4489977887
2014-09-03-5903_1	jkeremian	migration/3.4/2014-09-03-5903.xml	2025-11-30 08:06:42.829046	913	EXECUTED	8:63367f00ff68796fb61474801e86c7bd	sql	Change data type of created_date to timestamp	\N	3.6.3	\N	\N	4489977887
2014-09-03-5903_2	jkeremian	migration/3.4/2014-09-03-5903.xml	2025-11-30 08:06:42.860595	914	EXECUTED	8:512146d64e6d9776788d59dab4793d03	sql	Change data type of updated_date to timestamp	\N	3.6.3	\N	\N	4489977887
2014-09-03-5904_1	jkeremian	migration/3.4/2014-09-03-5904.xml	2025-11-30 08:06:42.880436	915	EXECUTED	8:9cd77e82a262ea0620f93b7276c532a9	sql	Change data type of created_date to timestamp	\N	3.6.3	\N	\N	4489977887
2014-09-03-5904_2	jkeremian	migration/3.4/2014-09-03-5904.xml	2025-11-30 08:06:42.903247	916	EXECUTED	8:66370afba59153b483f53905578f49d8	sql	Change data type of updated_date to timestamp	\N	3.6.3	\N	\N	4489977887
2014-08-28-5896_1	jkeremian	migration/3.4/2014-08-28-5896.xml	2025-11-30 08:06:42.921476	917	EXECUTED	8:7fcfbcd5fa7a96b390950713282a8b6a	sql	Before Changing data type of created_date to timestamp, we need to drop all Views	\N	3.6.3	\N	\N	4489977887
2014-08-28-5896_2	jkeremian	migration/3.4/2014-08-28-5896.xml	2025-11-30 08:06:42.984477	918	EXECUTED	8:9bf82232c0432770c38eef7c4cb6cf98	sql	Change data type of created_date to timestamp	\N	3.6.3	\N	\N	4489977887
2014-08-28-5896_3	jkeremian	migration/3.4/2014-08-28-5896.xml	2025-11-30 08:06:43.05653	919	EXECUTED	8:21522155bbde92734c81dc3067be65bd	sql	Create All Reviews back by updating date data types	\N	3.6.3	\N	\N	4489977887
2015-01-11-OC-6132-1	jkeremian	migration/3.5/2015-01-11-OC-6132.xml	2025-11-30 08:06:43.062357	920	EXECUTED	8:d3ab969e313cdf7283e48ea594a4c235	addColumn tableName=user_account	Add access_code column to user Account table	\N	3.6.3	\N	\N	4489977887
2015-01-23-5802-1	jkeremian	migration/3.5/2015-01-23-OC-5802.xml	2025-11-30 08:06:43.069951	921	EXECUTED	8:057a990b649a90d0e498745e5a38b0ea	addColumn tableName=event_definition_crf	adding a column in event_definition_crf table	\N	3.6.3	\N	\N	4489977887
2015-04-12-OC-6304-1	jkeremian	migration/3.6/2015-04-12-OC-6304.xml	2025-11-30 08:06:43.076745	922	EXECUTED	8:b2539856ffd2fd75d4255e0945ed5e07	addColumn tableName=dn_item_data_map	adding a column in dn_item_data_map table	\N	3.6.3	\N	\N	4489977887
2015-4-15-6008-1	jkeremian	migration/3.6/2015-04-15-OC-6008.xml	2025-11-30 08:06:43.083864	923	EXECUTED	8:e02713f2108a0fad8831bda00110074f	addColumn tableName=audit_log_event	Add Column item_data_repeat_key in audit_log_event table	\N	3.6.3	\N	\N	4489977887
2015-4-15-6008-2	jkeremian	migration/3.6/2015-04-15-OC-6008.xml	2025-11-30 08:06:43.093082	924	EXECUTED	8:f29e6fcbdd8f62e6bc69c1e64ffce58a	sql		\N	3.6.3	\N	\N	4489977887
2015-4-15-6008-3	jkeremian	migration/3.6/2015-04-15-OC-6008.xml	2025-11-30 08:06:43.098077	925	EXECUTED	8:e3a1326828f259b4070e1ea5c4f8a15d	sql	create item_data_initial_trigger()	\N	3.6.3	\N	\N	4489977887
2015-04-15-OC6413-1	jkeremian	migration/3.6/2015-04-15-OC-6413.xml	2025-11-30 08:06:43.105494	926	EXECUTED	8:5b965d66c18a37abc4035a6a5ac62f5f	sql		\N	3.6.3	\N	\N	4489977887
2015-04-15-OC6413-2	jkeremian	migration/3.6/2015-04-15-OC-6413.xml	2025-11-30 08:06:43.110375	927	EXECUTED	8:48967e6075e3843b24b1eb535fa0caee	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
2015-04-15-OC6413-3	jkeremian	migration/3.6/2015-04-15-OC-6413.xml	2025-11-30 08:06:43.115192	928	EXECUTED	8:1a0ba035666fa5952ba8d225789ff5d7	insert tableName=audit_log_event_type		\N	3.6.3	\N	\N	4489977887
2015-04-15-OC6413-4	jkeremian	migration/3.6/2015-04-15-OC-6413.xml	2025-11-30 08:06:43.121147	929	EXECUTED	8:8b861fad96d137b348711a765911aeb9	insert tableName=status		\N	3.6.3	\N	\N	4489977887
2015-04-15-OC6413-5	jkeremian	migration/3.6/2015-04-15-OC-6413.xml	2025-11-30 08:06:43.126021	930	EXECUTED	8:ecd9aa52cc7eb1ce1c4aec04599f4a4b	sql	create event_crf_initial_trigger()	\N	3.6.3	\N	\N	4489977887
2015-04-15-OC6413-6	jkeremian	migration/3.6/2015-04-15-OC-6413.xml	2025-11-30 08:06:43.131261	931	EXECUTED	8:2dbf99cef4517b5c1448d64b1de099a0	sql		\N	3.6.3	\N	\N	4489977887
2015-05-01-OC-6405-01	jkeremian	migration/3.6/2015-05-01-OC-6405.xml	2025-11-30 08:06:43.136804	932	EXECUTED	8:ea20a524f230e7415a99e69009fab2fb	addColumn tableName=rule_action	adding a email_subject column in rule_action table	\N	3.6.3	\N	\N	4489977887
2015-05-21-OC-5994-01	sdibona	migration/3.6/2015-05-21-OC-5994.xml	2025-11-30 08:06:43.140621	933	EXECUTED	8:d41d8cd98f00b204e9800998ecf8427e	empty	increasing size of column user_name in table study_user_role	\N	3.6.3	\N	\N	4489977887
2015-05-21-OC-5994-02	jkeremian	migration/3.6/2015-05-21-OC-5994.xml	2025-11-30 08:06:43.143437	934	EXECUTED	8:d41d8cd98f00b204e9800998ecf8427e	empty	increasing size of column role_name in table user_role	\N	3.6.3	\N	\N	4489977887
2015-05-21-OC-5994-03	jkeremian	migration/3.6/2015-05-21-OC-5994.xml	2025-11-30 08:06:43.146136	935	EXECUTED	8:d41d8cd98f00b204e9800998ecf8427e	empty	increasing size of column user_name in table authorities	\N	3.6.3	\N	\N	4489977887
2015-05-14-OC-6454-1	jkeremian	migration/3.6/2015-05-14-OC-6454.xml	2025-11-30 08:06:43.152875	936	EXECUTED	8:5ffd89ffe7df94b51797673be0aad1a7	addColumn tableName=rule_set	adding a column in dn_item_data_map table	\N	3.6.3	\N	\N	4489977887
2015-05-14-OC-6454-2	jkeremian	migration/3.6/2015-05-14-OC-6454.xml	2025-11-30 08:06:43.16275	937	EXECUTED	8:e2ac4f59f21be877644e6bfa24f8cbc2	addColumn tableName=user_account	adding a column in dn_item_data_map table	\N	3.6.3	\N	\N	4489977887
2015-05-14-OC-6454-3	jkeremian	migration/3.6/2015-05-14-OC-6454.xml	2025-11-30 08:06:43.17144	938	EXECUTED	8:6d6c4b498b1c85b69eb942ffacf68aef	addColumn tableName=study_subject	adding a column in dn_item_data_map table	\N	3.6.3	\N	\N	4489977887
2015-06-26-OC-6467-01	jkeremian	migration/3.6/2015-05-26-OC-6467.xml	2025-11-30 08:06:43.17742	939	EXECUTED	8:45c839be83953b42cb2c37ff08864450	sql		\N	3.6.3	\N	\N	4489977887
2015-07-09-OC-6551-1	sdibona	migration/3.7/2015-07-09-OC-6551.xml	2025-11-30 08:06:43.183079	940	EXECUTED	8:8182786b34849d8e00fbc69d365a86a9	addColumn tableName=crf_version	adding a column in crf_version	\N	3.6.3	\N	\N	4489977887
2015-07-25-OC-6589-1	sdibona	migration/3.7/2015-07-25-OC-6589.xml	2025-11-30 08:06:43.189591	941	EXECUTED	8:1976debd714e817384aa1b9166359eaa	addColumn tableName=crf_version	adding a column in crf_version	\N	3.6.3	\N	\N	4489977887
2015-07-31-OC-6621-1	sdibona	migration/3.7/2015-07-31-OC-6621.xml	2025-11-30 08:06:43.20619	942	EXECUTED	8:b63c171361d8db0e58b0df9d2b4052b4	createTable tableName=crf_version_media	adding a mapping table for CRF associated media	\N	3.6.3	\N	\N	4489977887
2015-07-31-OC-6621-2	sdibona	migration/3.7/2015-07-31-OC-6621.xml	2025-11-30 08:06:43.215754	943	EXECUTED	8:db043a672fd162d4a9d3a31f972cf30f	addForeignKeyConstraint baseTableName=crf_version_media, constraintName=fk_crf_version_id, referencedTableName=crf_version		\N	3.6.3	\N	\N	4489977887
2015-07-15-6582-1	jkeremian	migration/3.7/2015-07-15-OC-6582.xml	2025-11-30 08:06:43.223329	944	EXECUTED	8:502d2a7b4cb0acc0ca9c76d48535f0b8	addColumn tableName=event_definition_crf	adding allow_anonymous_submission column in event_definition_crf table	\N	3.6.3	\N	\N	4489977887
2015-07-15-6582-2	jkeremian	migration/3.7/2015-07-15-OC-6582.xml	2025-11-30 08:06:43.235424	945	EXECUTED	8:4e55490ad53a2d963ffd9c43c37e7878	addColumn tableName=event_definition_crf	adding submission_url column in event_definition_crf table	\N	3.6.3	\N	\N	4489977887
2015-08-11-6636-1	jkeremian	migration/3.7/2015-08-11-OC-6636.xml	2025-11-30 08:06:43.241304	946	EXECUTED	8:5cfddcca287a4986fc21628d5033184b	addColumn tableName=user_account	adding enable_api_key column in user_account table	\N	3.6.3	\N	\N	4489977887
2015-08-11-6636-2	jkeremian	migration/3.7/2015-08-11-OC-6636.xml	2025-11-30 08:06:43.246411	947	EXECUTED	8:8d42db77b48deddf68221ea3dac4b9b1	addColumn tableName=user_account	adding api_key column in user_account table	\N	3.6.3	\N	\N	4489977887
2015-08-18-OC-2886	sidr	migration/3.7/2015-08-18-OC-2886.xml	2025-11-30 08:06:43.251742	948	EXECUTED	8:0c5ad78510bb0a6d5d5af787d68d5e5a	sql		\N	3.6.3	\N	\N	4489977887
2015-11-17-6829-2	kkrumlian	migration/3.8/2015-11-17-OC-6829.xml	2025-11-30 08:06:43.257635	949	EXECUTED	8:e915d059ad526c4fb0046f677292ddcc	sql		\N	3.6.3	\N	\N	4489977887
2015-11-18-OC-6777-1	sdibona	migration/3.9/2015-11-18-OC-6777.xml	2025-11-30 08:06:43.262322	950	EXECUTED	8:fc604a1c3a0082602830f5b11b55fd7e	addColumn tableName=item_data	adding a column in item_data	\N	3.6.3	\N	\N	4489977887
2015-11-12-OC-6820	jkeremian	migration/3.9/2015-11-12-OC-6820.xml	2025-11-30 08:06:43.270906	951	EXECUTED	8:23c2b0e9b86128e1fe50753c488fdc10	sql	Apply Uniqueness Constraint to Study Event Table	\N	3.6.3	\N	\N	4489977887
2015-11-18-6825-02	jkeremian	migration/3.9/2015-11-18-OC-6825.xml	2025-11-30 08:06:43.279797	952	EXECUTED	8:cbb806c364fc10155c5f05b71c9a322b	createTable tableName=rule_action_stratification_factor	Create a new table named rule_action_factor	\N	3.6.3	\N	\N	4489977887
2015-12-07-OC-6483-01	jkeremian	migration/3.9/2015-12-07-OC-6483.xml	2025-11-30 08:06:43.286911	953	EXECUTED	8:4602049b0ca8aa2eb3ccae26f06e723f	sql	Change character width for Message and Email_subject columns of Rule Action Table	\N	3.6.3	\N	\N	4489977887
2015-12-07-OC-1176-01	jkeremian	migration/3.9/2015-12-07-OC-1176.xml	2025-11-30 08:06:43.291254	954	EXECUTED	8:175e84e17952010f572cb11b6cc8b1f7	sql	Change character width for expression column of Rule_Expression Table	\N	3.6.3	\N	\N	4489977887
2015-12-08-OC-6847	jkeremian	migration/3.9/2015-12-08-OC-6847.xml	2025-11-30 08:06:43.295822	955	EXECUTED	8:29e6117fe42094063cede56c4b04c0be	insert tableName=study_parameter	Insert a new record in the studyParameter table	\N	3.6.3	\N	\N	4489977887
2016-02-05-OC-6963-01	jkeremian	migration/3.10/2016-02-05-OC-6963.xml	2025-11-30 08:06:43.315512	956	EXECUTED	8:1536ce0ef6b8a5d504752afd5d4dabfc	sql	Create Table tag	\N	3.6.3	\N	\N	4489977887
2016-02-05-OC-6963-02	jkeremian	migration/3.10/2016-02-05-OC-6963.xml	2025-11-30 08:06:43.326512	957	EXECUTED	8:9481bfb9f1b02d75a5bc9478d8162b03	sql	Create Table event_definition_crf_item_tag	\N	3.6.3	\N	\N	4489977887
2016-02-05-OC-6963-03	jkeremian	migration/3.10/2016-02-05-OC-6963.xml	2025-11-30 08:06:43.340169	958	EXECUTED	8:dacc7e08803e3d2cc881da0f86aa6e93	sql	Create Table event_definition_crf_tag	\N	3.6.3	\N	\N	4489977887
2016-02-05-OC-6963-04	jkeremian	migration/3.10/2016-02-05-OC-6963.xml	2025-11-30 08:06:43.352503	959	EXECUTED	8:7f4c8957ab57b887f446a190c554468f	sql	Create Table item_data_flag	\N	3.6.3	\N	\N	4489977887
2016-02-05-OC-6963-05	jkeremian	migration/3.10/2016-02-05-OC-6963.xml	2025-11-30 08:06:43.364904	960	EXECUTED	8:487e0b5ee0752c4a17c30cf0d41a8f8b	sql	Create Table item_data_flag_workflow	\N	3.6.3	\N	\N	4489977887
2016-02-05-OC-6963-06	jkeremian	migration/3.10/2016-02-05-OC-6963.xml	2025-11-30 08:06:43.375995	961	EXECUTED	8:6310fa0002f951b112875b51f5f3f797	sql	Create Table event_crf_flag	\N	3.6.3	\N	\N	4489977887
2016-02-05-OC-6963-07	jkeremian	migration/3.10/2016-02-05-OC-6963.xml	2025-11-30 08:06:43.388063	962	EXECUTED	8:f975842dad862374c93a530215f8a371	sql	Create Table event_crf_flag_workflow	\N	3.6.3	\N	\N	4489977887
2016-02-05-OC-6963-08	jkeremian	migration/3.10/2016-02-05-OC-6963.xml	2025-11-30 08:06:43.401288	963	EXECUTED	8:080d44c1282b7b48506e0305d0942af1	sql	Create View for Item Data Toolkit	\N	3.6.3	\N	\N	4489977887
2016-02-05-OC-6963-09	jkeremian	migration/3.10/2016-02-05-OC-6963.xml	2025-11-30 08:06:43.412435	964	EXECUTED	8:7b2a6b9fbfb39e80d50193c94265dae2	sql	Create View for Item Data Toolkit Filtered	\N	3.6.3	\N	\N	4489977887
2016-02-05-OC-6963-10	jkeremian	migration/3.10/2016-02-06-OC-6963.xml	2025-11-30 08:06:43.417294	965	EXECUTED	8:45b21f8c3923ce40468e8517671aa8a0	sql	Insert a Row in Tag Table	\N	3.6.3	\N	\N	4489977887
2016-02-05-OC-6963-11	jkeremian	migration/3.10/2016-02-06-OC-6963.xml	2025-11-30 08:06:43.421468	966	EXECUTED	8:61d64efe05945b109010bb2deefadc24	sql	Insert a Row in Tag Table	\N	3.6.3	\N	\N	4489977887
2016-02-05-OC-6963-12	jkeremian	migration/3.10/2016-02-06-OC-6963.xml	2025-11-30 08:06:43.428101	967	EXECUTED	8:93b8cc501f265c835a4a56e46b892987	sql	Apply Uniqueness Constraint to Event_Definition_Crf_Item_Tag	\N	3.6.3	\N	\N	4489977887
2016-02-05-OC-6963-13	jkeremian	migration/3.10/2016-02-06-OC-6963.xml	2025-11-30 08:06:43.434814	968	EXECUTED	8:168a78e471477a7943a7b1df39e64572	sql	Apply Uniqueness Constraint to Event_Definition_Crf_Tag	\N	3.6.3	\N	\N	4489977887
2016-04-07-7118	dewa	migration/3.11/2016-04-07-OC-7118.xml	2025-11-30 08:06:43.441784	969	EXECUTED	8:0f0bc21e86fe0acde38634d139363807	addColumn tableName=audit_user_login	Add new column details on audit_user_login table	\N	3.6.3	\N	\N	4489977887
2016-08-12-OC-5891-01	jkeremian	migration/3.12/2016-08-12-OC-5891.xml	2025-11-30 08:06:43.461978	970	EXECUTED	8:7fcfbcd5fa7a96b390950713282a8b6a	sql	Before Changing data type of description field in discrepancy_note, we need to drop all Views	\N	3.6.3	\N	\N	4489977887
2016-08-12-OC-5891-02	jkeremian	migration/3.12/2016-08-12-OC-5891.xml	2025-11-30 08:06:43.46741	971	EXECUTED	8:8d4abd31985cce0fffc26f20e92898d7	sql	Change character width for Description column of Discrepancy Note Table	\N	3.6.3	\N	\N	4489977887
2016-08-12-OC-5891-03	jkeremian	migration/3.12/2016-08-12-OC-5891.xml	2025-11-30 08:06:43.528005	972	EXECUTED	8:21522155bbde92734c81dc3067be65bd	sql	Create All Reviews back by updating date data types	\N	3.6.3	\N	\N	4489977887
2016-08-24-7399-1	kkrumlian	migration/3.12/2016-08-24-OC-7399.xml	2025-11-30 08:06:43.531221	973	MARK_RAN	8:d41d8cd98f00b204e9800998ecf8427e	empty	Reverting Fix user_id in audit_log_event when SDV	\N	3.6.3	\N	\N	4489977887
2017-05-23-OC-8124-1	sdibona	migration/3.14/2017-05-23-OC-8124.xml	2025-11-30 08:06:45.216312	974	EXECUTED	8:ef6111b181e893cf09add59d048d0ab1	createIndex indexName=i_digm_item_group_metadata_id, tableName=dyn_item_group_metadata		\N	3.6.3	\N	\N	4489977887
2017-05-23-OC-8124-2	sdibona	migration/3.14/2017-05-23-OC-8124.xml	2025-11-30 08:06:46.918348	975	EXECUTED	8:99fc87a71cd0b811da5bf08fd26908d7	createIndex indexName=i_digm_item_group_id, tableName=dyn_item_group_metadata		\N	3.6.3	\N	\N	4489977887
2017-05-23-OC-8124-3	sdibona	migration/3.14/2017-05-23-OC-8124.xml	2025-11-30 08:06:48.565315	976	EXECUTED	8:02e1084b3a11b9899bfabae782d73e6d	createIndex indexName=i_digm_show_group, tableName=dyn_item_group_metadata		\N	3.6.3	\N	\N	4489977887
2017-05-23-OC-8124-4	sdibona	migration/3.14/2017-05-23-OC-8124.xml	2025-11-30 08:06:50.250532	977	EXECUTED	8:4021f86f758810d4cc25e4973fe609f7	createIndex indexName=i_digm_event_crf_id, tableName=dyn_item_group_metadata		\N	3.6.3	\N	\N	4489977887
2017-06-05-7394-1	sdibona	migration/3.14/2017-06-05-OC-7394.xml	2025-11-30 08:06:50.257658	978	EXECUTED	8:a4239a9cfd4e0179739b251c155aaec3	addUniqueConstraint constraintName=uniq_study_event_crf_version_study_subject, tableName=event_crf	Adding unique constraint to prevent duplicate entries in event_crf	\N	3.6.3	\N	\N	4489977887
2017-07-27-7877-1	sdibona	migration/3.14/2017-07-27-OC-7877.xml	2025-11-30 08:06:50.263562	979	EXECUTED	8:0bccded348ec1e688cd1dea4a5e6fe8c	addUniqueConstraint constraintName=uniq_study_event_def_study_crf, tableName=event_definition_crf	Adding unique constraint to prevent duplicate entries in event_definition_crf	\N	3.6.3	\N	\N	4489977887
1555001321719-1	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.271474	980	EXECUTED	8:87dfc69221fa4cbe7d93d12b8e867b8e	addColumn tableName=oc_qrtz_locks		\N	3.6.3	\N	\N	4489977887
1555001321719-2	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.281595	981	EXECUTED	8:218ba9e53f0276b7ba03f72236cbcc09	dropPrimaryKey tableName=oc_qrtz_locks; addPrimaryKey constraintName=oc_qrtz_locks_pkey, tableName=oc_qrtz_locks		\N	3.6.3	\N	\N	4489977887
1555001321719-3	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.286155	982	EXECUTED	8:0e900d1989e95a954b8b7c61288fd5b6	addColumn tableName=oc_qrtz_paused_trigger_grps		\N	3.6.3	\N	\N	4489977887
1555001321719-4	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.29038	983	EXECUTED	8:ef2e5b9fd97f10f1bade3d60fbc176c6	addColumn tableName=oc_qrtz_calendars		\N	3.6.3	\N	\N	4489977887
1555001321719-5	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.294019	984	EXECUTED	8:618749afc707a132a0ece622e30828bb	addColumn tableName=oc_qrtz_scheduler_state		\N	3.6.3	\N	\N	4489977887
1555001321719-6	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.297437	985	EXECUTED	8:397a0df750a41c9bad6d22b5dd48e724	addColumn tableName=oc_qrtz_cron_triggers		\N	3.6.3	\N	\N	4489977887
1555001321719-7	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.30431	986	EXECUTED	8:e6e75e1ec04f98fbbdeb217312f27b9a	addColumn tableName=oc_qrtz_simple_triggers		\N	3.6.3	\N	\N	4489977887
1555001321719-8	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.308447	987	EXECUTED	8:78b3179b27cd8bf96f6976a72cf0d628	addColumn tableName=oc_qrtz_job_details		\N	3.6.3	\N	\N	4489977887
1555001321719-9	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.311842	988	EXECUTED	8:292a7208d7aef5a86eaf116f6796070d	addColumn tableName=oc_qrtz_fired_triggers		\N	3.6.3	\N	\N	4489977887
1555001321719-10	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.315265	989	EXECUTED	8:84b34ec5516463d6453da2ab8f4e1dca	addColumn tableName=oc_qrtz_triggers		\N	3.6.3	\N	\N	4489977887
1555001321719-11	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.31923	990	EXECUTED	8:c5ef242b619939b08baf969d597825b0	addColumn tableName=oc_qrtz_job_details		\N	3.6.3	\N	\N	4489977887
1555001321719-12	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.322923	991	EXECUTED	8:b9de6e17db596ba63b2f25dbf0b21310	addColumn tableName=oc_qrtz_job_details		\N	3.6.3	\N	\N	4489977887
1555001321719-13	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.326188	992	EXECUTED	8:3fd6bee9f77a53bffbd33b0155be3521	addColumn tableName=oc_qrtz_fired_triggers		\N	3.6.3	\N	\N	4489977887
1555001321719-14	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.329396	993	EXECUTED	8:329d87589aee864b560fe11561ee1a9e	addColumn tableName=oc_qrtz_fired_triggers		\N	3.6.3	\N	\N	4489977887
1555001321719-15	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.332504	994	EXECUTED	8:476ce1d6efe729ed2804c69f27ec4000	addColumn tableName=oc_qrtz_fired_triggers		\N	3.6.3	\N	\N	4489977887
1555001321719-16	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.337857	995	EXECUTED	8:092debf8f52f5be486cab64ff8da81df	dropColumn tableName=oc_qrtz_job_details		\N	3.6.3	\N	\N	4489977887
1555001321719-17	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.342211	996	EXECUTED	8:e2260d61b2a55ea9d6ca952623de6c8a	dropColumn tableName=oc_qrtz_job_details		\N	3.6.3	\N	\N	4489977887
1555001321719-18	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.346105	997	EXECUTED	8:720e7a9fae1985b48c7ff9b3f63097a1	dropColumn tableName=oc_qrtz_fired_triggers		\N	3.6.3	\N	\N	4489977887
1555001321719-19	cha	migration/lc-1.0.0/update_to_spring5.xml	2025-11-30 08:06:50.350557	998	EXECUTED	8:9eadcb0f4e036366584fad350006720a	dropColumn tableName=oc_qrtz_triggers		\N	3.6.3	\N	\N	4489977887
2020-01-31-alter_oc_qrtz_blob_triggers_blob_data_type_to_bytea	toskrip	migration/lc-1.0.0/qrtz_blob_to_bytea.xml	2025-11-30 08:06:50.359466	999	EXECUTED	8:1bd6c076330bb11a58cb9ea6490b6d05	dropColumn columnName=blob_data, tableName=oc_qrtz_blob_triggers; addColumn tableName=oc_qrtz_blob_triggers		\N	3.6.3	\N	\N	4489977887
2020-01-31-alter_oc_qrtz_calendars_calendar_type_to_bytea	toskrip	migration/lc-1.0.0/qrtz_blob_to_bytea.xml	2025-11-30 08:06:50.368985	1000	EXECUTED	8:0d2e82c9574987293becb8ac95552ac9	dropColumn columnName=calendar, tableName=oc_qrtz_calendars; addColumn tableName=oc_qrtz_calendars		\N	3.6.3	\N	\N	4489977887
2020-01-31-alter_oc_qrtz_job_details_job_data_type_to_bytea	toskrip	migration/lc-1.0.0/qrtz_blob_to_bytea.xml	2025-11-30 08:06:50.375543	1001	EXECUTED	8:e463a842390a021d92fa333031f6cf33	dropColumn columnName=job_data, tableName=oc_qrtz_job_details; addColumn tableName=oc_qrtz_job_details		\N	3.6.3	\N	\N	4489977887
2020-01-31-alter_oc_qrtz_triggers_job_data_type_to_bytea	toskrip	migration/lc-1.0.0/qrtz_blob_to_bytea.xml	2025-11-30 08:06:50.380263	1002	EXECUTED	8:9dfb39e6066e79001fd197ad23120cee	dropColumn columnName=job_data, tableName=oc_qrtz_triggers; addColumn tableName=oc_qrtz_triggers		\N	3.6.3	\N	\N	4489977887
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
\.


--
-- Data for Name: dataset; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dataset (dataset_id, study_id, status_id, name, description, sql_statement, num_runs, date_start, date_end, date_created, date_updated, date_last_run, owner_id, approver_id, update_id, show_event_location, show_event_start, show_event_end, show_subject_dob, show_subject_gender, show_event_status, show_subject_status, show_subject_unique_id, show_subject_age_at_event, show_crf_status, show_crf_version, show_crf_int_name, show_crf_int_date, show_group_info, show_disc_info, odm_metadataversion_name, odm_metadataversion_oid, odm_prior_study_oid, odm_prior_metadataversion_oid, show_secondary_id, dataset_item_status_id) FROM stdin;
\.


--
-- Data for Name: dataset_crf_version_map; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dataset_crf_version_map (dataset_id, event_definition_crf_id) FROM stdin;
\.


--
-- Data for Name: dataset_filter_map; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dataset_filter_map (dataset_id, filter_id, ordinal) FROM stdin;
\.


--
-- Data for Name: dataset_item_status; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dataset_item_status (dataset_item_status_id, name, description) FROM stdin;
1	completed	Data from CRFs Marked Complete
2	non_completed	Data from CRFs not Marked Complete
3	completed_and_non_completed	Data from all Available CRFs 
\.


--
-- Data for Name: dataset_study_group_class_map; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dataset_study_group_class_map (dataset_id, study_group_class_id) FROM stdin;
\.


--
-- Data for Name: dc_computed_event; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dc_computed_event (dc_summary_event_id, dc_event_id, item_target_id, summary_type) FROM stdin;
\.


--
-- Data for Name: dc_event; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dc_event (dc_event_id, decision_condition_id, ordinal, type) FROM stdin;
\.


--
-- Data for Name: dc_primitive; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dc_primitive (dc_primitive_id, decision_condition_id, item_id, dynamic_value_item_id, comparison, constant_value) FROM stdin;
\.


--
-- Data for Name: dc_section_event; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dc_section_event (dc_event_id, section_id) FROM stdin;
\.


--
-- Data for Name: dc_send_email_event; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dc_send_email_event (dc_event_id, to_address, subject, body) FROM stdin;
\.


--
-- Data for Name: dc_substitution_event; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dc_substitution_event (dc_event_id, item_id, value) FROM stdin;
\.


--
-- Data for Name: dc_summary_item_map; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dc_summary_item_map (dc_summary_event_id, item_id, ordinal) FROM stdin;
\.


--
-- Data for Name: decision_condition; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.decision_condition (decision_condition_id, crf_version_id, status_id, label, comments, quantity, type, owner_id, date_created, date_updated, update_id) FROM stdin;
\.


--
-- Data for Name: discrepancy_note; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.discrepancy_note (discrepancy_note_id, description, discrepancy_note_type_id, resolution_status_id, detailed_notes, date_created, owner_id, parent_dn_id, entity_type, study_id, assigned_user_id) FROM stdin;
2	Test Query from Frontend - 01:55:59	3	1	Created to verify query system works end-to-end	2025-12-02 07:55:59.817292+00	1	\N	studySubject	1	\N
\.


--
-- Data for Name: discrepancy_note_type; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.discrepancy_note_type (discrepancy_note_type_id, name, description) FROM stdin;
1	Failed Validation Check	
2	Annotation	
3	Query	
4	Reason For Change	
5	Not Applicable	
6	Not Applicable	
7	Not Applicable	
\.


--
-- Data for Name: dn_event_crf_map; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dn_event_crf_map (event_crf_id, discrepancy_note_id, column_name) FROM stdin;
\.


--
-- Data for Name: dn_item_data_map; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dn_item_data_map (item_data_id, discrepancy_note_id, column_name, study_subject_id, activated) FROM stdin;
\.


--
-- Data for Name: dn_study_event_map; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dn_study_event_map (study_event_id, discrepancy_note_id, column_name) FROM stdin;
\.


--
-- Data for Name: dn_study_subject_map; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dn_study_subject_map (study_subject_id, discrepancy_note_id, column_name) FROM stdin;
1	2	\N
\.


--
-- Data for Name: dn_subject_map; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dn_subject_map (subject_id, discrepancy_note_id, column_name) FROM stdin;
\.


--
-- Data for Name: dyn_item_form_metadata; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dyn_item_form_metadata (id, item_form_metadata_id, item_id, crf_version_id, show_item, event_crf_id, version, item_data_id, passed_dde) FROM stdin;
\.


--
-- Data for Name: dyn_item_group_metadata; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.dyn_item_group_metadata (id, item_group_metadata_id, item_group_id, show_group, event_crf_id, version, passed_dde) FROM stdin;
\.


--
-- Data for Name: event_crf; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.event_crf (event_crf_id, study_event_id, crf_version_id, date_interviewed, interviewer_name, completion_status_id, status_id, annotations, date_completed, validator_id, date_validate, date_validate_completed, validator_annotations, validate_string, owner_id, date_created, study_subject_id, date_updated, update_id, electronic_signature_status, sdv_status, old_status_id, sdv_update_id) FROM stdin;
2	1	2	2025-12-02	Dr. Smith	\N	2	\N	2025-12-02 00:00:00	\N	\N	\N	\N	\N	1	2025-12-02 00:00:00+00	\N	2025-12-02 00:00:00+00	\N	f	t	1	0
3	2	1	2025-12-02	Dr. Jones	\N	6	\N	2025-12-02 00:00:00	\N	\N	\N	\N	\N	1	2025-12-02 00:00:00+00	\N	2025-12-02 00:00:00+00	\N	f	f	1	0
4	2	2	2025-12-02	Dr. Jones	\N	2	\N	2025-12-02 00:00:00	\N	\N	\N	\N	\N	1	2025-12-02 00:00:00+00	\N	2025-12-02 00:00:00+00	\N	f	f	1	0
1	1	1	2025-12-02	Dr. Smith	\N	2	\N	2025-12-02 00:00:00	\N	\N	\N	\N	\N	1	2025-12-02 00:00:00+00	\N	2025-12-02 10:06:00.854114+00	\N	f	t	1	1
\.


--
-- Data for Name: event_crf_flag; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.event_crf_flag (id, path, tag_id, flag_workflow_id, owner_id, update_id, date_created, date_updated) FROM stdin;
\.


--
-- Data for Name: event_crf_flag_workflow; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.event_crf_flag_workflow (id, workflow_id, workflow_status, owner_id, update_id, date_created, date_updated) FROM stdin;
\.


--
-- Data for Name: event_definition_crf; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.event_definition_crf (event_definition_crf_id, study_event_definition_id, study_id, crf_id, required_crf, double_entry, require_all_text_filled, decision_conditions, null_values, default_version_id, status_id, owner_id, date_created, date_updated, update_id, ordinal, electronic_signature, hide_crf, source_data_verification_code, selected_version_ids, parent_id, participant_form, allow_anonymous_submission, submission_url) FROM stdin;
\.


--
-- Data for Name: event_definition_crf_item_tag; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.event_definition_crf_item_tag (id, path, tag_id, active, owner_id, update_id, date_created, date_updated) FROM stdin;
\.


--
-- Data for Name: event_definition_crf_tag; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.event_definition_crf_tag (id, path, tag_id, active, owner_id, update_id, date_created, date_updated) FROM stdin;
\.


--
-- Data for Name: export_format; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.export_format (export_format_id, name, description, mime_type) FROM stdin;
1	text/plain	Default export format for tab-delimited text	text/plain
2	text/plain	Default export format for comma-delimited text	text/plain
3	application/vnd.ms-excel	Default export format for Excel files	application/vnd.ms-excel
4	text/plain	Default export format for CDISC ODM XML files	text/plain
5	text/plain	Default export format for SAS files	text/plain
\.


--
-- Data for Name: filter; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.filter (filter_id, name, description, sql_statement, status_id, date_created, date_updated, owner_id, update_id) FROM stdin;
\.


--
-- Data for Name: filter_crf_version_map; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.filter_crf_version_map (filter_id, crf_version_id) FROM stdin;
\.


--
-- Data for Name: group_class_types; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.group_class_types (group_class_type_id, name, description) FROM stdin;
1	Arm	\N
2	Family/Pedigree	\N
3	Demographic	\N
4	Other	\N
\.


--
-- Data for Name: item; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.item (item_id, name, description, units, phi_status, item_data_type_id, item_reference_type_id, status_id, owner_id, date_created, date_updated, update_id, oc_oid) FROM stdin;
1	Blood Pressure			f	5	\N	1	1	2025-12-02	\N	\N	I_FIELDS_TEST_0_BP
2	Heart Rate			f	6	\N	1	1	2025-12-02	\N	\N	I_FIELDS_TEST_0_HR
3	Temperature			f	6	\N	1	1	2025-12-02	\N	\N	I_FIELDS_TEST_0_TEMP
4	Patient Name	Enter full name		f	5	\N	1	1	2025-12-02	\N	\N	I_COMPLETE_FORM_NAME
5	Age			f	6	\N	1	1	2025-12-02	\N	\N	I_COMPLETE_FORM_AGE
6	Date of Birth			f	9	\N	1	1	2025-12-02	\N	\N	I_COMPLETE_FORM_DOB
7	Clinical Notes			f	5	\N	1	1	2025-12-02	\N	\N	I_COMPLETE_FORM_NOTES
8	Informed Consent			f	1	\N	1	1	2025-12-02	\N	\N	I_COMPLETE_FORM_CONSENT
9	Patient Name	Patient's legal name\n---EXTENDED_PROPS---\n{"isPhiField":true,"width":"full"}		t	5	\N	1	1	2025-12-02	\N	\N	I_FULL_FIELD_TE_PATIENT_NAME
10	Age	---EXTENDED_PROPS---\n{"unit":"years","min":0,"max":150}	years	f	6	\N	1	1	2025-12-02	\N	\N	I_FULL_FIELD_TE_AGE
11	Blood Type			f	5	\N	1	1	2025-12-02	\N	\N	I_FULL_FIELD_TE_BLOOD_TYPE
12	Informed Consent	---EXTENDED_PROPS---\n{"auditRequired":true,"criticalDataPoint":true}		f	1	\N	1	1	2025-12-02	\N	\N	I_FULL_FIELD_TE_CONSENT
13	Clinical Notes	---EXTENDED_PROPS---\n{"width":"full"}		f	5	\N	1	1	2025-12-02	\N	\N	I_FULL_FIELD_TE_NOTES
14	Patient Full Name	First and last name as on ID\n---EXTENDED_PROPS---\n{"isPhiField":true,"auditRequired":true,"width":"full"}		t	5	\N	1	1	2025-12-02	\N	\N	I_FRONTEND_TEST_FIELD_NAME
15	Age	---EXTENDED_PROPS---\n{"width":"quarter","unit":"years","min":0,"max":150,"criticalDataPoint":false}	years	f	6	\N	1	1	2025-12-02	\N	\N	I_FRONTEND_TEST_FIELD_AGE
16	Date of Birth	---EXTENDED_PROPS---\n{"isPhiField":true,"width":"half","format":"YYYY-MM-DD"}		t	9	\N	1	1	2025-12-02	\N	\N	I_FRONTEND_TEST_FIELD_DOB
17	Gender	---EXTENDED_PROPS---\n{"width":"half"}		f	5	\N	1	1	2025-12-02	\N	\N	I_FRONTEND_TEST_FIELD_GENDER
18	Blood Type			f	5	\N	1	1	2025-12-02	\N	\N	I_FRONTEND_TEST_FIELD_BLOOD_TYP
19	Informed Consent Obtained	---EXTENDED_PROPS---\n{"auditRequired":true,"criticalDataPoint":true,"auditTrail":{"reasonRequired":true,"trackChanges":true}}		f	1	\N	1	1	2025-12-02	\N	\N	I_FRONTEND_TEST_FIELD_CONSENT
20	Clinical Notes	Document any relevant clinical observations\n---EXTENDED_PROPS---\n{"width":"full"}		f	5	\N	1	1	2025-12-02	\N	\N	I_FRONTEND_TEST_FIELD_NOTES
21	Email Address	---EXTENDED_PROPS---\n{"isPhiField":true}		t	5	\N	1	1	2025-12-02	\N	\N	I_FRONTEND_TEST_FIELD_EMAIL
22	Phone Number	---EXTENDED_PROPS---\n{"isPhiField":true}		t	5	\N	1	1	2025-12-02	\N	\N	I_FRONTEND_TEST_FIELD_PHONE
23	Upload Documents	---EXTENDED_PROPS---\n{"allowedFileTypes":["pdf","jpg","png"],"maxFileSize":10485760,"maxFiles":5}		f	11	\N	1	1	2025-12-02	\N	\N	I_FRONTEND_TEST_FIELD_DOCUMENTS
24	BMI (Calculated)	---EXTENDED_PROPS---\n{"calculationFormula":"weight / (height * height)","dependsOn":["field_weight","field_height"],"readonly":true}		f	6	\N	1	1	2025-12-02	\N	\N	I_FRONTEND_TEST_FIELD_BMI
25	Pregnancy Status	---EXTENDED_PROPS---\n{"showWhen":[{"operator":"equals","value":"F","fieldId":"field_gender"}]}		f	5	\N	1	1	2025-12-02	\N	\N	I_FRONTEND_TEST_FIELD_PREGNANCY
26	Test Field			f	5	\N	1	1	2025-12-02	\N	\N	I_AUDIT_TEST_FO_F0
27	Field1			f	5	\N	1	1	2025-12-02	\N	\N	I_AUDIT_FORM_20_F0
28	Patient Name			f	5	\N	1	1	2025-12-03	\N	\N	I_TEST_FORM_FRO_F0
29	Age			f	6	\N	1	1	2025-12-03	\N	\N	I_TEST_FORM_FRO_F1
30	Gender			f	5	\N	1	1	2025-12-03	\N	\N	I_TEST_FORM_FRO_F2
31	Patient Name			f	5	\N	1	1	2025-12-03	\N	\N	I_DIAGNOSTIC_TE_F0
32	Age	---EXTENDED_PROPS---\n{"min":0,"max":120}		f	6	\N	1	1	2025-12-03	\N	\N	I_DIAGNOSTIC_TE_F1
33	Gender			f	5	\N	1	1	2025-12-03	\N	\N	I_DIAGNOSTIC_TE_F2
34	Date of Visit			f	9	\N	1	1	2025-12-03	\N	\N	I_DIAGNOSTIC_TE_F3
35	Notes			f	5	\N	1	1	2025-12-03	\N	\N	I_DIAGNOSTIC_TE_F4
36	Patient Name			f	5	\N	1	1	2025-12-03	\N	\N	I_REAL_API_TEST_F0
37	Age	---EXTENDED_PROPS---\n{"min":0,"max":150}		f	6	\N	1	1	2025-12-03	\N	\N	I_REAL_API_TEST_F1
38	Date of Birth	---EXTENDED_PROPS---\n{"isPhiField":true}		t	9	\N	1	1	2025-12-03	\N	\N	I_REAL_API_TEST_F2
39	Gender			f	5	\N	1	1	2025-12-03	\N	\N	I_REAL_API_TEST_F3
40	Height	---EXTENDED_PROPS---\n{"unit":"cm","min":50,"max":250}	cm	f	6	\N	1	1	2025-12-03	\N	\N	I_REAL_API_TEST_F4
41	Weight	---EXTENDED_PROPS---\n{"unit":"kg","min":1,"max":500}	kg	f	6	\N	1	1	2025-12-03	\N	\N	I_REAL_API_TEST_F5
42	Blood Pressure	---EXTENDED_PROPS---\n{"unit":"mmHg"}	mmHg	f	5	\N	1	1	2025-12-03	\N	\N	I_REAL_API_TEST_F6
43	Smoking Status			f	5	\N	1	1	2025-12-03	\N	\N	I_REAL_API_TEST_F7
44	Notes			f	5	\N	1	1	2025-12-03	\N	\N	I_REAL_API_TEST_F8
45	SSN	---EXTENDED_PROPS---\n{"isPhiField":true,"auditRequired":true}		t	5	\N	1	1	2025-12-03	\N	\N	I_REAL_API_TEST_F9
58	Patient Full Name	As it appears on your ID		f	5	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_0_THD3
59	Age in Years	---EXTENDED_PROPS---\n{"unit":"years","min":0,"max":120}	years	f	6	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_1_X90S
60	Date of Birth	---EXTENDED_PROPS---\n{"isPhiField":true,"auditRequired":true}		t	9	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_2_FT2G
61	Biological Sex			f	5	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_3_FN6H
62	Height	---EXTENDED_PROPS---\n{"unit":"cm","min":30,"max":280}	cm	f	6	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_4_251O
63	Weight	---EXTENDED_PROPS---\n{"unit":"kg","min":0.5,"max":700}	kg	f	6	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_5_B33T
64	Blood Pressure	---EXTENDED_PROPS---\n{"unit":"mmHg"}	mmHg	f	5	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_6_L68Q
65	Smoking History			f	5	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_7_YZWR
66	Medical Notes			f	5	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_8_JSO3
67	Social Security Number	---EXTENDED_PROPS---\n{"isPhiField":true,"auditRequired":true}		t	5	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_9_SROJ
68	Patient Full Name	As it appears on your ID		f	5	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_0_9W1R
69	Age in Years	---EXTENDED_PROPS---\n{"unit":"years","min":0,"max":120}	years	f	6	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_1_EJMQ
70	Date of Birth	---EXTENDED_PROPS---\n{"isPhiField":true,"auditRequired":true}		t	9	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_2_QUV7
71	Biological Sex			f	5	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_3_VQ96
72	Height	---EXTENDED_PROPS---\n{"unit":"cm","min":30,"max":280}	cm	f	6	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_4_NENK
73	Weight	---EXTENDED_PROPS---\n{"unit":"kg","min":0.5,"max":700}	kg	f	6	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_5_8SKX
74	Blood Pressure	---EXTENDED_PROPS---\n{"unit":"mmHg"}	mmHg	f	5	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_6_7TY1
75	Smoking History			f	5	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_7_6IBN
76	Medical Notes			f	5	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_8_CGTQ
77	Social Security Number	---EXTENDED_PROPS---\n{"isPhiField":true,"auditRequired":true}		t	5	\N	1	1	2025-12-03	\N	\N	I_DATA_VERIF_9_QT0H
78	Test Field			f	5	\N	1	1	2025-12-04	\N	\N	I_TEST_FORM__0_PZKS
\.


--
-- Data for Name: item_data; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.item_data (item_data_id, item_id, event_crf_id, status_id, value, date_created, date_updated, owner_id, update_id, ordinal, old_status_id, deleted) FROM stdin;
\.


--
-- Data for Name: item_data_flag; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.item_data_flag (id, path, tag_id, flag_workflow_id, owner_id, update_id, date_created, date_updated) FROM stdin;
\.


--
-- Data for Name: item_data_flag_workflow; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.item_data_flag_workflow (id, workflow_id, workflow_status, owner_id, update_id, date_created, date_updated) FROM stdin;
\.


--
-- Data for Name: item_data_type; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.item_data_type (item_data_type_id, code, name, definition, reference) FROM stdin;
1	BL	Boolean	\N	\N
2	BN	BooleanNonNull	\N	\N
3	ED	Encapsulated Data	\N	\N
4	TEL	A telecommunication address	\N	\N
5	ST	Character String	\N	\N
6	INT	Integer	\N	\N
7	REAL	Floating	\N	\N
8	SET	\N	a value that contains other distinct values	\N
9	DATE	date	date	\N
10	PDATE	partial date	year only or year with month or date	\N
11	FILE	File	File name, extension and path	\N
\.


--
-- Data for Name: item_form_metadata; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.item_form_metadata (item_form_metadata_id, item_id, crf_version_id, header, subheader, parent_id, parent_label, column_number, page_number_label, question_number_label, left_item_text, right_item_text, section_id, decision_condition_id, response_set_id, regexp, regexp_error_msg, ordinal, required, default_value, response_layout, width_decimal, show_item) FROM stdin;
1	9	6	\N	\N	\N	\N	\N	\N	\N	Enter full name	\N	1	\N	1	\N	\N	1	t	\N	\N	\N	t
2	10	6	\N	\N	\N	\N	\N	\N	\N		\N	1	\N	2	\N	\N	2	t	18	\N	0,150	t
3	11	6	\N	\N	\N	\N	\N	\N	\N		\N	1	\N	3	\N	\N	3	t	\N	\N	\N	t
4	12	6	\N	\N	\N	\N	\N	\N	\N		\N	1	\N	4	\N	\N	4	t	\N	\N	\N	t
5	13	6	\N	\N	\N	\N	\N	\N	\N	Enter clinical observations...	\N	1	\N	5	\N	\N	5	f	\N	\N	\N	t
6	14	7	\N	\N	\N	\N	\N	\N	\N	John Doe	\N	2	\N	6	\N	\N	1	t		\N	100	t
7	15	7	\N	\N	\N	\N	\N	\N	\N		\N	2	\N	7	\N	\N	2	t	21	\N	0,150	t
8	16	7	\N	\N	\N	\N	\N	\N	\N		\N	2	\N	8	\N	\N	3	t	\N	\N	\N	t
9	17	7	\N	\N	\N	\N	\N	\N	\N		\N	2	\N	9	\N	\N	4	t		\N	\N	t
10	18	7	\N	\N	\N	\N	\N	\N	\N		\N	2	\N	10	\N	\N	5	f	\N	\N	\N	t
11	19	7	\N	\N	\N	\N	\N	\N	\N		\N	2	\N	11	\N	\N	6	t	\N	\N	\N	t
12	20	7	\N	\N	\N	\N	\N	\N	\N	Enter observations...	\N	2	\N	12	\N	\N	7	f	\N	\N	\N	t
13	21	7	\N	\N	\N	\N	\N	\N	\N	patient@email.com	\N	2	\N	13	\N	\N	8	f	\N	\N	\N	t
14	22	7	\N	\N	\N	\N	\N	\N	\N	(555) 123-4567	\N	2	\N	14	\N	\N	9	f	\N	\N	\N	t
15	23	7	\N	\N	\N	\N	\N	\N	\N		\N	2	\N	15	\N	\N	10	f	\N	\N	\N	t
16	24	7	\N	\N	\N	\N	\N	\N	\N		\N	2	\N	16	\N	\N	11	f	\N	\N	\N	t
17	25	7	\N	\N	\N	\N	\N	\N	\N		\N	2	\N	17	\N	\N	12	f	\N	\N	\N	t
18	26	8	\N	\N	\N	\N	\N	\N	\N		\N	3	\N	18	\N	\N	1	t	\N	\N	\N	t
19	27	10	\N	\N	\N	\N	\N	\N	\N		\N	5	\N	19	\N	\N	1	f	\N	\N	\N	t
20	28	11	\N	\N	\N	\N	\N	\N	\N		\N	6	\N	20	\N	\N	1	t	\N	\N	\N	t
21	29	11	\N	\N	\N	\N	\N	\N	\N		\N	6	\N	21	\N	\N	2	t	\N	\N	\N	t
22	30	11	\N	\N	\N	\N	\N	\N	\N		\N	6	\N	22	\N	\N	3	f	\N	\N	\N	t
23	31	12	\N	\N	\N	\N	\N	\N	\N		\N	7	\N	23	\N	\N	1	t	\N	\N	\N	t
24	32	12	\N	\N	\N	\N	\N	\N	\N		\N	7	\N	24	\N	\N	2	t	\N	\N	0,120	t
25	33	12	\N	\N	\N	\N	\N	\N	\N		\N	7	\N	25	\N	\N	3	f	\N	\N	\N	t
26	34	12	\N	\N	\N	\N	\N	\N	\N		\N	7	\N	26	\N	\N	4	t	\N	\N	\N	t
27	35	12	\N	\N	\N	\N	\N	\N	\N		\N	7	\N	27	\N	\N	5	f	\N	\N	\N	t
48	58	20	\N	\N	\N	\N	\N	\N	\N	Enter your full legal name	\N	15	\N	48	\N	\N	1	t	\N	\N	\N	t
49	59	20	\N	\N	\N	\N	\N	\N	\N		\N	15	\N	49	\N	\N	2	t	\N	\N	0,120	t
50	60	20	\N	\N	\N	\N	\N	\N	\N		\N	15	\N	50	\N	\N	3	t	\N	\N	\N	t
51	61	20	\N	\N	\N	\N	\N	\N	\N		\N	15	\N	51	\N	\N	4	t	\N	\N	\N	t
52	62	20	\N	\N	\N	\N	\N	\N	\N		\N	15	\N	52	\N	\N	5	f	\N	\N	30,280	t
53	63	20	\N	\N	\N	\N	\N	\N	\N		\N	15	\N	53	\N	\N	6	f	\N	\N	0.5,700	t
54	64	20	\N	\N	\N	\N	\N	\N	\N	e.g., 120/80	\N	15	\N	54	\N	\N	7	f	\N	\N	\N	t
55	65	20	\N	\N	\N	\N	\N	\N	\N		\N	15	\N	55	\N	\N	8	t	\N	\N	\N	t
56	66	20	\N	\N	\N	\N	\N	\N	\N	Enter any relevant medical history	\N	15	\N	56	\N	\N	9	f	\N	\N	\N	t
57	67	20	\N	\N	\N	\N	\N	\N	\N		\N	15	\N	57	\N	\N	10	f	\N	\N	\N	t
58	68	21	\N	\N	\N	\N	\N	\N	\N	Enter your full legal name	\N	16	\N	58	\N	\N	1	t	\N	\N	\N	t
59	69	21	\N	\N	\N	\N	\N	\N	\N		\N	16	\N	59	\N	\N	2	t	\N	\N	0,120	t
60	70	21	\N	\N	\N	\N	\N	\N	\N		\N	16	\N	60	\N	\N	3	t	\N	\N	\N	t
61	71	21	\N	\N	\N	\N	\N	\N	\N		\N	16	\N	61	\N	\N	4	t	\N	\N	\N	t
62	72	21	\N	\N	\N	\N	\N	\N	\N		\N	16	\N	62	\N	\N	5	f	\N	\N	30,280	t
63	73	21	\N	\N	\N	\N	\N	\N	\N		\N	16	\N	63	\N	\N	6	f	\N	\N	0.5,700	t
64	74	21	\N	\N	\N	\N	\N	\N	\N	e.g., 120/80	\N	16	\N	64	\N	\N	7	f	\N	\N	\N	t
65	75	21	\N	\N	\N	\N	\N	\N	\N		\N	16	\N	65	\N	\N	8	t	\N	\N	\N	t
66	76	21	\N	\N	\N	\N	\N	\N	\N	Enter any relevant medical history	\N	16	\N	66	\N	\N	9	f	\N	\N	\N	t
67	77	21	\N	\N	\N	\N	\N	\N	\N		\N	16	\N	67	\N	\N	10	f	\N	\N	\N	t
68	78	22	\N	\N	\N	\N	\N	\N	\N		\N	17	\N	68	\N	\N	1	t	\N	\N	\N	t
\.


--
-- Data for Name: item_group; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.item_group (item_group_id, name, crf_id, status_id, date_created, date_updated, owner_id, update_id, oc_oid) FROM stdin;
1	Vital Signs	4	1	2025-12-02	\N	1	\N	IG_FIELDS_TEST_010017_UNGROUPED
2	Patient Assessment	5	1	2025-12-02	\N	1	\N	IG_COMPLETE_FORM_TEST_UNGROUPED
3	Comprehensive Test	6	1	2025-12-02	\N	1	\N	IG_FULL_FIELD_TEST_01_UNGROUPED
4	Patient Intake	7	1	2025-12-02	\N	1	\N	IG_FRONTEND_TEST_FORM_UNGROUPED
5	Form Fields	8	1	2025-12-02	\N	1	\N	IG_AUDIT_TEST_FORM_01_UNGROUPED
7	Form Fields	10	1	2025-12-02	\N	1	\N	IG_AUDIT_FORM_2025120_UNGROUPED
8	Form Fields	11	1	2025-12-03	\N	1	\N	IG_TEST_FORM_FROM_POW_UNGROUPED
9	Form Fields	12	1	2025-12-03	\N	1	\N	IG_DIAGNOSTIC_TEST_FO_UNGROUPED
10	demographics	13	1	2025-12-03	\N	1	\N	IG_REAL_API_TEST_1764_UNGROUPED
17	vitals	20	1	2025-12-03	\N	1	\N	IG_DATA_VERIFICAT_U86LQ0
18	vitals	21	1	2025-12-03	\N	1	\N	IG_DATA_VERIFICAT_TRGWB9
19	Form Fields	22	1	2025-12-04	\N	1	\N	IG_TEST_FORM_3867_YRW8Y5
\.


--
-- Data for Name: item_group_metadata; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.item_group_metadata (item_group_metadata_id, item_group_id, header, subheader, layout, repeat_number, repeat_max, repeat_array, row_start_number, crf_version_id, item_id, ordinal, borders, show_group, repeating_group) FROM stdin;
1	1	\N	\N	\N	\N	\N	\N	\N	4	1	1	\N	t	f
2	1	\N	\N	\N	\N	\N	\N	\N	4	2	2	\N	t	f
3	1	\N	\N	\N	\N	\N	\N	\N	4	3	3	\N	t	f
4	2	\N	\N	\N	\N	\N	\N	\N	5	4	1	\N	t	f
5	2	\N	\N	\N	\N	\N	\N	\N	5	5	2	\N	t	f
6	2	\N	\N	\N	\N	\N	\N	\N	5	6	3	\N	t	f
7	2	\N	\N	\N	\N	\N	\N	\N	5	7	4	\N	t	f
8	2	\N	\N	\N	\N	\N	\N	\N	5	8	5	\N	t	f
9	3	\N	\N	\N	\N	\N	\N	\N	6	9	1	\N	t	f
10	3	\N	\N	\N	\N	\N	\N	\N	6	10	2	\N	t	f
11	3	\N	\N	\N	\N	\N	\N	\N	6	11	3	\N	t	f
12	3	\N	\N	\N	\N	\N	\N	\N	6	12	4	\N	t	f
13	3	\N	\N	\N	\N	\N	\N	\N	6	13	5	\N	t	f
14	4	\N	\N	\N	\N	\N	\N	\N	7	14	1	\N	t	f
15	4	\N	\N	\N	\N	\N	\N	\N	7	15	2	\N	t	f
16	4	\N	\N	\N	\N	\N	\N	\N	7	16	3	\N	t	f
17	4	\N	\N	\N	\N	\N	\N	\N	7	17	4	\N	t	f
18	4	\N	\N	\N	\N	\N	\N	\N	7	18	5	\N	t	f
19	4	\N	\N	\N	\N	\N	\N	\N	7	19	6	\N	t	f
20	4	\N	\N	\N	\N	\N	\N	\N	7	20	7	\N	t	f
21	4	\N	\N	\N	\N	\N	\N	\N	7	21	8	\N	t	f
22	4	\N	\N	\N	\N	\N	\N	\N	7	22	9	\N	t	f
23	4	\N	\N	\N	\N	\N	\N	\N	7	23	10	\N	t	f
24	4	\N	\N	\N	\N	\N	\N	\N	7	24	11	\N	t	f
25	4	\N	\N	\N	\N	\N	\N	\N	7	25	12	\N	t	f
26	5	\N	\N	\N	\N	\N	\N	\N	8	26	1	\N	t	f
27	7	\N	\N	\N	\N	\N	\N	\N	10	27	1	\N	t	f
28	8	\N	\N	\N	\N	\N	\N	\N	11	28	1	\N	t	f
29	8	\N	\N	\N	\N	\N	\N	\N	11	29	2	\N	t	f
30	8	\N	\N	\N	\N	\N	\N	\N	11	30	3	\N	t	f
31	9	\N	\N	\N	\N	\N	\N	\N	12	31	1	\N	t	f
32	9	\N	\N	\N	\N	\N	\N	\N	12	32	2	\N	t	f
33	9	\N	\N	\N	\N	\N	\N	\N	12	33	3	\N	t	f
34	9	\N	\N	\N	\N	\N	\N	\N	12	34	4	\N	t	f
35	9	\N	\N	\N	\N	\N	\N	\N	12	35	5	\N	t	f
36	10	\N	\N	\N	\N	\N	\N	\N	13	36	1	\N	t	f
37	10	\N	\N	\N	\N	\N	\N	\N	13	37	2	\N	t	f
38	10	\N	\N	\N	\N	\N	\N	\N	13	38	3	\N	t	f
39	10	\N	\N	\N	\N	\N	\N	\N	13	39	4	\N	t	f
40	10	\N	\N	\N	\N	\N	\N	\N	13	40	5	\N	t	f
41	10	\N	\N	\N	\N	\N	\N	\N	13	41	6	\N	t	f
42	10	\N	\N	\N	\N	\N	\N	\N	13	42	7	\N	t	f
43	10	\N	\N	\N	\N	\N	\N	\N	13	43	8	\N	t	f
44	10	\N	\N	\N	\N	\N	\N	\N	13	44	9	\N	t	f
45	10	\N	\N	\N	\N	\N	\N	\N	13	45	10	\N	t	f
56	17	\N	\N	\N	\N	\N	\N	\N	20	58	1	\N	t	f
57	17	\N	\N	\N	\N	\N	\N	\N	20	59	2	\N	t	f
58	17	\N	\N	\N	\N	\N	\N	\N	20	60	3	\N	t	f
59	17	\N	\N	\N	\N	\N	\N	\N	20	61	4	\N	t	f
60	17	\N	\N	\N	\N	\N	\N	\N	20	62	5	\N	t	f
61	17	\N	\N	\N	\N	\N	\N	\N	20	63	6	\N	t	f
62	17	\N	\N	\N	\N	\N	\N	\N	20	64	7	\N	t	f
63	17	\N	\N	\N	\N	\N	\N	\N	20	65	8	\N	t	f
64	17	\N	\N	\N	\N	\N	\N	\N	20	66	9	\N	t	f
65	17	\N	\N	\N	\N	\N	\N	\N	20	67	10	\N	t	f
66	18	\N	\N	\N	\N	\N	\N	\N	21	68	1	\N	t	f
67	18	\N	\N	\N	\N	\N	\N	\N	21	69	2	\N	t	f
68	18	\N	\N	\N	\N	\N	\N	\N	21	70	3	\N	t	f
69	18	\N	\N	\N	\N	\N	\N	\N	21	71	4	\N	t	f
70	18	\N	\N	\N	\N	\N	\N	\N	21	72	5	\N	t	f
71	18	\N	\N	\N	\N	\N	\N	\N	21	73	6	\N	t	f
72	18	\N	\N	\N	\N	\N	\N	\N	21	74	7	\N	t	f
73	18	\N	\N	\N	\N	\N	\N	\N	21	75	8	\N	t	f
74	18	\N	\N	\N	\N	\N	\N	\N	21	76	9	\N	t	f
75	18	\N	\N	\N	\N	\N	\N	\N	21	77	10	\N	t	f
76	19	\N	\N	\N	\N	\N	\N	\N	22	78	1	\N	t	f
\.


--
-- Data for Name: item_reference_type; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.item_reference_type (item_reference_type_id, name, description) FROM stdin;
1	literal	\N
\.


--
-- Data for Name: measurement_unit; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.measurement_unit (id, oc_oid, name, description, version) FROM stdin;
\.


--
-- Data for Name: null_value_type; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.null_value_type (null_value_type_id, code, name, definition, reference) FROM stdin;
1	NI	NoInformation	\N	\N
2	NA	not applicable	\N	\N
3	UNK	unknown	\N	\N
4	NASK	not asked	\N	\N
5	ASKU	asked but unknown	\N	\N
6	NAV	temporarily unavailable	\N	\N
7	OTH	other	\N	\N
8	PINF	positive infinity	\N	\N
9	NINF	negative infinity	\N	\N
10	MSK	masked	\N	\N
11	NP	not present	\N	\N
12	NPE	not performed	\N	\N
\.


--
-- Data for Name: oc_qrtz_blob_triggers; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.oc_qrtz_blob_triggers (trigger_name, trigger_group, blob_data) FROM stdin;
\.


--
-- Data for Name: oc_qrtz_calendars; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.oc_qrtz_calendars (calendar_name, sched_name, calendar) FROM stdin;
\.


--
-- Data for Name: oc_qrtz_cron_triggers; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.oc_qrtz_cron_triggers (trigger_name, trigger_group, cron_expression, time_zone_id, sched_name) FROM stdin;
\.


--
-- Data for Name: oc_qrtz_fired_triggers; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.oc_qrtz_fired_triggers (entry_id, trigger_name, trigger_group, instance_name, fired_time, priority, state, job_name, job_group, is_stateful, requests_recovery, sched_name, is_nonconcurrent, is_update_data, sched_time) FROM stdin;
\.


--
-- Data for Name: oc_qrtz_job_details; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.oc_qrtz_job_details (job_name, job_group, description, job_class_name, is_durable, requests_recovery, sched_name, is_nonconcurrent, is_update_data, job_data) FROM stdin;
\.


--
-- Data for Name: oc_qrtz_job_listeners; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.oc_qrtz_job_listeners (job_name, job_group, job_listener) FROM stdin;
\.


--
-- Data for Name: oc_qrtz_locks; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.oc_qrtz_locks (lock_name, sched_name) FROM stdin;
TRIGGER_ACCESS	TestScheduler
JOB_ACCESS	TestScheduler
CALENDAR_ACCESS	TestScheduler
STATE_ACCESS	TestScheduler
MISFIRE_ACCESS	TestScheduler
TRIGGER_ACCESS	public
\.


--
-- Data for Name: oc_qrtz_paused_trigger_grps; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.oc_qrtz_paused_trigger_grps (trigger_group, sched_name) FROM stdin;
\.


--
-- Data for Name: oc_qrtz_scheduler_state; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.oc_qrtz_scheduler_state (instance_name, last_checkin_time, checkin_interval, sched_name) FROM stdin;
\.


--
-- Data for Name: oc_qrtz_simple_triggers; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.oc_qrtz_simple_triggers (trigger_name, trigger_group, repeat_count, repeat_interval, times_triggered, sched_name) FROM stdin;
\.


--
-- Data for Name: oc_qrtz_trigger_listeners; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.oc_qrtz_trigger_listeners (trigger_name, trigger_group, trigger_listener) FROM stdin;
\.


--
-- Data for Name: oc_qrtz_triggers; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.oc_qrtz_triggers (trigger_name, trigger_group, job_name, job_group, description, next_fire_time, prev_fire_time, priority, trigger_state, trigger_type, start_time, end_time, calendar_name, misfire_instr, sched_name, job_data) FROM stdin;
\.


--
-- Data for Name: openclinica_version; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.openclinica_version (id, name, build_number, version, update_timestamp) FROM stdin;
\.


--
-- Data for Name: privilege; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.privilege (priv_id, priv_name, priv_desc) FROM stdin;
\.


--
-- Data for Name: resolution_status; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.resolution_status (resolution_status_id, name, description) FROM stdin;
1	New	
2	Updated	
3	Resolution Proposed	
4	Closed	
5	Not Applicable	
\.


--
-- Data for Name: response_set; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.response_set (response_set_id, response_type_id, label, options_text, options_values, version_id) FROM stdin;
1	1	Patient Name	\N	\N	6
2	1	Age	\N	\N	6
3	6	Blood Type	A+,A-,B+,O+	A_POS,A_NEG,B_POS,O_POS	6
4	3	Informed Consent	\N	\N	6
5	2	Clinical Notes	\N	\N	6
6	1	Patient Full Name	\N	\N	7
7	1	Age	\N	\N	7
8	1	Date of Birth	\N	\N	7
9	6	Gender	Male,Female,Other,Prefer not to say	M,F,O,N	7
10	5	Blood Type	A+,A-,B+,B-,O+,O-,AB+,AB-	A_POS,A_NEG,B_POS,B_NEG,O_POS,O_NEG,AB_POS,AB_NEG	7
11	3	Informed Consent Obtained	\N	\N	7
12	2	Clinical Notes	\N	\N	7
13	1	Email Address	\N	\N	7
14	1	Phone Number	\N	\N	7
15	4	Upload Documents	\N	\N	7
16	1	BMI (Calculated)	\N	\N	7
17	6	Pregnancy Status	Not Pregnant,Currently Pregnant,Unknown	NO,YES,UNK	7
18	1	Test Field	\N	\N	8
19	1	Field1	\N	\N	10
20	1	Patient Name	\N	\N	11
21	1	Age	\N	\N	11
22	6	Gender	Male,Female	male,female	11
23	1	Patient Name	\N	\N	12
24	1	Age	\N	\N	12
25	6	Gender	Male,Female,Other	male,female,other	12
26	1	Date of Visit	\N	\N	12
27	2	Notes	\N	\N	12
28	1	Patient Name	\N	\N	13
29	1	Age	\N	\N	13
30	1	Date of Birth	\N	\N	13
31	6	Gender	Male,Female,Other	M,F,O	13
32	1	Height	\N	\N	13
33	1	Weight	\N	\N	13
34	1	Blood Pressure	\N	\N	13
35	5	Smoking Status	Never,Former,Current	never,former,current	13
36	2	Notes	\N	\N	13
37	1	SSN	\N	\N	13
38	1	Patient Full Name	\N	\N	14
39	1	Age in Years	\N	\N	14
40	1	Date of Birth	\N	\N	14
41	6	Biological Sex	Male,Female,Intersex	male,female,intersex	14
42	1	Height	\N	\N	14
43	1	Weight	\N	\N	14
44	1	Blood Pressure	\N	\N	14
45	5	Smoking History	Never Smoked,Former Smoker,Current Smoker	never,former,current	14
46	2	Medical Notes	\N	\N	14
47	1	Social Security Number	\N	\N	14
48	1	Patient Full Name	\N	\N	20
49	1	Age in Years	\N	\N	20
50	1	Date of Birth	\N	\N	20
51	6	Biological Sex	Male,Female,Intersex	male,female,intersex	20
52	1	Height	\N	\N	20
53	1	Weight	\N	\N	20
54	1	Blood Pressure	\N	\N	20
55	5	Smoking History	Never Smoked,Former Smoker,Current Smoker	never,former,current	20
56	2	Medical Notes	\N	\N	20
57	1	Social Security Number	\N	\N	20
58	1	Patient Full Name	\N	\N	21
59	1	Age in Years	\N	\N	21
60	1	Date of Birth	\N	\N	21
61	6	Biological Sex	Male,Female,Intersex	male,female,intersex	21
62	1	Height	\N	\N	21
63	1	Weight	\N	\N	21
64	1	Blood Pressure	\N	\N	21
65	5	Smoking History	Never Smoked,Former Smoker,Current Smoker	never,former,current	21
66	2	Medical Notes	\N	\N	21
67	1	Social Security Number	\N	\N	21
68	1	Test Field	\N	\N	22
\.


--
-- Data for Name: response_type; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.response_type (response_type_id, name, description) FROM stdin;
1	text	free form text entry limited to one line
2	textarea	free form text area display
3	checkbox	selecting one from many options
4	file	for upload of files
5	radio	selecting one from many options
6	single-select	pick one from a list
7	multi-select	pick many from a list
8	calculation	value calculated automatically
9	group-calculation	value calculated automatically from an entire group of items
10	instant-calculation	for barcode
\.


--
-- Data for Name: role_privilege_map; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.role_privilege_map (role_id, priv_id, priv_value) FROM stdin;
\.


--
-- Data for Name: rule; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.rule (id, name, description, oc_oid, enabled, rule_expression_id, owner_id, date_created, date_updated, update_id, status_id, version, study_id) FROM stdin;
\.


--
-- Data for Name: rule_action; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.rule_action (id, rule_set_rule_id, action_type, expression_evaluates_to, message, email_to, owner_id, date_created, date_updated, update_id, status_id, version, rule_action_run_id, oc_oid_reference, email_subject) FROM stdin;
\.


--
-- Data for Name: rule_action_property; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.rule_action_property (id, rule_action_id, oc_oid, value, version, rule_expression_id, property) FROM stdin;
\.


--
-- Data for Name: rule_action_run; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.rule_action_run (id, administrative_data_entry, initial_data_entry, double_data_entry, import_data_entry, batch, version, not_started, scheduled, data_entry_started, complete, skipped, stopped) FROM stdin;
\.


--
-- Data for Name: rule_action_run_log; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.rule_action_run_log (id, action_type, item_data_id, value, rule_oc_oid, version) FROM stdin;
\.


--
-- Data for Name: rule_action_stratification_factor; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.rule_action_stratification_factor (id, rule_action_id, version, rule_expression_id) FROM stdin;
\.


--
-- Data for Name: rule_expression; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.rule_expression (id, value, context, owner_id, date_created, date_updated, update_id, status_id, version) FROM stdin;
\.


--
-- Data for Name: rule_set; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.rule_set (id, rule_expression_id, study_event_definition_id, crf_id, crf_version_id, study_id, owner_id, date_created, date_updated, update_id, status_id, version, item_id, item_group_id, run_schedule, run_time) FROM stdin;
\.


--
-- Data for Name: rule_set_audit; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.rule_set_audit (id, rule_set_id, date_updated, updater_id, status_id, version) FROM stdin;
\.


--
-- Data for Name: rule_set_rule; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.rule_set_rule (id, rule_set_id, rule_id, owner_id, date_created, date_updated, update_id, status_id, version) FROM stdin;
\.


--
-- Data for Name: rule_set_rule_audit; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.rule_set_rule_audit (id, rule_set_rule_id, date_updated, updater_id, status_id, version) FROM stdin;
\.


--
-- Data for Name: scd_item_metadata; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.scd_item_metadata (id, scd_item_form_metadata_id, control_item_form_metadata_id, control_item_name, option_value, message, version) FROM stdin;
\.


--
-- Data for Name: section; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.section (section_id, crf_version_id, status_id, label, title, subtitle, instructions, page_number_label, ordinal, parent_id, date_created, date_updated, owner_id, update_id, borders) FROM stdin;
1	6	1	Comprehensive Test	Full Field Test 011526	\N	\N	\N	1	\N	2025-12-02	\N	1	\N	\N
2	7	1	Patient Intake	Frontend Test Form 012540	\N	\N	\N	1	\N	2025-12-02	\N	1	\N	\N
3	8	1	Form Fields	Audit Test Form 014052	\N	\N	\N	1	\N	2025-12-02	\N	1	\N	\N
5	10	1	Form Fields	Audit Form 20251202014400	\N	\N	\N	1	\N	2025-12-02	\N	1	\N	\N
6	11	1	Form Fields	Test Form From PowerShell	\N	\N	\N	1	\N	2025-12-03	\N	1	\N	\N
7	12	1	Form Fields	Diagnostic Test Form 20251202224041	\N	\N	\N	1	\N	2025-12-03	\N	1	\N	\N
8	13	1	demographics	Real API Test 1764738084185	\N	\N	\N	1	\N	2025-12-03	\N	1	\N	\N
9	14	1	vitals	Data Verification Test 1764738201358	\N	\N	\N	1	\N	2025-12-03	\N	1	\N	\N
15	20	1	vitals	Data Verification Test 1764738989631	\N	\N	\N	1	\N	2025-12-03	\N	1	\N	\N
16	21	1	vitals	Data Verification Test 1764738995138	\N	\N	\N	1	\N	2025-12-03	\N	1	\N	\N
17	22	1	Form Fields	Test Form	\N	\N	\N	1	\N	2025-12-04	\N	1	\N	\N
\.


--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.status (status_id, name, description) FROM stdin;
1	available	this is the active status
2	unavailable	this is the inactive status
3	private	\N
4	pending	\N
5	removed	this indicates that a record is specifically removed by user
6	locked	\N
7	auto-removed	this indicates that a record is removed due to the removal of its parent record
8	signed	this indicates all StudyEvents has been signed
10	souce_data_verification	indicates the element has undergone SDV
9	frozen	frozen
11	reset	deleting event crf resets status
\.


--
-- Data for Name: study; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.study (study_id, parent_study_id, unique_identifier, secondary_identifier, name, summary, date_planned_start, date_planned_end, date_created, date_updated, owner_id, update_id, type_id, status_id, principal_investigator, facility_name, facility_city, facility_state, facility_zip, facility_country, facility_recruitment_status, facility_contact_name, facility_contact_degree, facility_contact_phone, facility_contact_email, protocol_type, protocol_description, protocol_date_verification, phase, expected_total_enrollment, sponsor, collaborators, medline_identifier, url, url_description, conditions, keywords, eligibility, gender, age_max, age_min, healthy_volunteer_accepted, purpose, allocation, masking, control, assignment, endpoint, interventions, duration, selection, timing, official_title, results_reference, oc_oid, old_status_id) FROM stdin;
1	\N	default-study	default-study	Default Study		2006-10-23	2006-10-23	2006-10-23	2006-10-23	1	\N	1	1	default											observational		2006-10-23	default	0	default								both			f	Natural History							longitudinal	Convenience Sample	Retrospective		f	S_DEFAULTS1	1
\.


--
-- Data for Name: study_event; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.study_event (study_event_id, study_event_definition_id, study_subject_id, location, sample_ordinal, date_start, date_end, owner_id, status_id, date_created, date_updated, update_id, subject_event_status_id, start_time_flag, end_time_flag) FROM stdin;
1	1	1	Site 1	1	2025-12-02 00:00:00	2025-12-02 00:00:00	1	1	2025-12-02 00:00:00+00	\N	\N	1	f	f
2	1	2	Site 1	1	2025-12-02 00:00:00	2025-12-02 00:00:00	1	1	2025-12-02 00:00:00+00	\N	\N	1	f	f
\.


--
-- Data for Name: study_event_definition; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.study_event_definition (study_event_definition_id, study_id, name, description, repeating, type, category, owner_id, status_id, date_created, date_updated, update_id, ordinal, oc_oid) FROM stdin;
1	1	Screening Visit	Initial screening visit	f	scheduled	\N	\N	1	2025-12-02	\N	\N	1	SE_SCREEN
\.


--
-- Data for Name: study_group; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.study_group (study_group_id, name, description, study_group_class_id) FROM stdin;
\.


--
-- Data for Name: study_group_class; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.study_group_class (study_group_class_id, name, study_id, owner_id, date_created, group_class_type_id, status_id, date_updated, update_id, subject_assignment) FROM stdin;
\.


--
-- Data for Name: study_module_status; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.study_module_status (id, study_id, study, crf, event_definition, subject_group, rule, site, users, version, date_created, date_updated, owner_id, update_id, status_id) FROM stdin;
\.


--
-- Data for Name: study_parameter; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.study_parameter (study_parameter_id, handle, name, description, default_value, inheritable, overridable) FROM stdin;
13	personIdShownOnCRF			false	t	f
12	interviewDateEditable		In study creation, CRF Interview Name and Date can be set to editable or not editable	editable	t	f
11	interviewDateDefault		In study or site creation, CRF Interviewer Date can be set to default to blank or to be pre-populated with user's name and the date of the study event	eventDate	t	t
9	interviewerNameEditable		In study creation, CRF Interviewer Name can be set to editable or not editable	editable	t	f
10	interviewDateRequired		In study or site creation, CRF Interviewer Date can be set as optional or required fields	required	t	t
8	interviewerNameDefault		In study or site creation, CRF Interviewer Name can be set to default to blank or to be pre-populated with user's name and the date of the study event	blank	t	t
7	interviewerNameRequired		In study or site creation, CRF Interviewer Name can be set as optional or required fields	required	t	t
6	subjectIdPrefixSuffix		In study and/or site creation, if Study Subject ID is set to Auto-generate, user can optionally specify a prefix and suffix for the format of the ID, using the format [PRETEXT][AUTO#][POSTTEXT]	false	t	f
4	genderRequired		In study creation, Subject Gender can be set to required or not used	required	t	f
5	subjectIdGeneration		In study creation, Study Subject ID can be set to Manual Entry, Auto-generate (editable), Auto-generate (non-editable)	manual	t	f
3	subjectPersonIdRequired		In study creation, Person ID can be set to required, optional, or not used	required	t	f
2	discrepancyManagement			true	t	f
1	collectDob	collect subject's date of birth	In study creation, Subject Birthdate can be set to require collect full birthdate, year of birth, or not used	required	t	f
14	secondaryLabelViewable			not viewable	t	f
15	adminForcedReasonForChange	adminForcedResonForChange	In administrative editing, block changes if event CRF has already been finished.	true	t	f
16	eventLocationRequired	eventLocationRequired	Location Field Required	not_used	t	f
17	participantPortal	participantPortal	Participant Portal Enabled or Diabled option	disabled	t	f
18	randomization	randomization	Randomization Enabled or Diabled option	disabled	t	f
\.


--
-- Data for Name: study_parameter_value; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.study_parameter_value (study_parameter_value_id, study_id, value, parameter) FROM stdin;
1	1	1	collectDob
2	1	true	discrepancyManagement
3	1	true	genderRequired
4	1	required	subjectPersonIdRequired
6	1	blank	interviewerNameDefault
7	1	true	interviewerNameEditable
9	1	blank	interviewDateDefault
10	1	true	interviewDateEditable
11	1	manual	subjectIdGeneration
12	1		subjectIdPrefixSuffix
13	1	true	personIdShownOnCRF
14	1	false	secondaryLabelViewable
5	1	yes	interviewerNameRequired
8	1	yes	interviewDateRequired
\.


--
-- Data for Name: study_subject; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.study_subject (study_subject_id, label, secondary_label, subject_id, study_id, status_id, enrollment_date, date_created, date_updated, owner_id, update_id, oc_oid, time_zone) FROM stdin;
1	SOAP-SUBJ-5934		1	1	1	2025-11-30	2025-11-30 10:26:46.942279+00	\N	1	\N	SS_SOAPSUBJ	
2	FE-7064		2	1	1	2025-11-29	2025-11-30 10:52:20.859416+00	2025-11-30 10:52:20.859416+00	1	\N	SS_FE7064	
3	SOAP-WRITE-6669		3	1	1	2025-11-29	2025-11-30 10:52:37.808187+00	2025-11-30 10:52:37.808187+00	1	\N	SS_SOAPWRITE6669	
4	VERIFY-2008		4	1	1	2025-11-29	2025-11-30 10:53:34.427625+00	2025-11-30 10:53:34.427625+00	1	\N	SS_VERIFY2008	
5	TEST-1764744758640	MRN-TEST-123	5	1	1	2024-12-31	2025-12-03 06:52:39.003578+00	2025-12-03 06:52:39.003578+00	1	\N	SS_TEST1764744758640	
\.


--
-- Data for Name: study_type; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.study_type (study_type_id, name, description) FROM stdin;
1	genetic	\N
2	non-genetic	\N
\.


--
-- Data for Name: study_user_role; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.study_user_role (role_name, study_id, status_id, owner_id, date_created, date_updated, update_id, user_name) FROM stdin;
admin	1	1	1	2006-10-23	\N	\N	root
director	1	1	1	2006-10-23	\N	\N	root
\.


--
-- Data for Name: subject; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.subject (subject_id, father_id, mother_id, status_id, date_of_birth, gender, unique_identifier, date_created, owner_id, date_updated, update_id, dob_collected) FROM stdin;
1	\N	\N	1	1990-01-15	m	PERSON-5934	2025-11-30 10:26:46.916554+00	1	\N	\N	t
2	\N	\N	1	\N	m	FE-7064	2025-11-30 10:52:20.859416+00	1	2025-11-30 10:52:20.859416+00	1	f
3	\N	\N	1	1995-01-14	f	SOAP-WRITE-6669	2025-11-30 10:52:37.808187+00	1	2025-11-30 10:52:37.808187+00	1	t
4	\N	\N	1	\N	m	VERIFY-2008	2025-11-30 10:53:34.427625+00	1	2025-11-30 10:53:34.427625+00	1	f
5	\N	\N	1	1990-05-14	m	TEST-1764744758640	2025-12-03 06:52:39.003578+00	1	2025-12-03 06:52:39.003578+00	1	t
\.


--
-- Data for Name: subject_event_status; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.subject_event_status (subject_event_status_id, name, description) FROM stdin;
1	scheduled	
2	not scheduled	
3	data entry started	
4	completed	
5	stopped	
6	skipped	
7	locked	
8	signed	
\.


--
-- Data for Name: subject_group_map; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.subject_group_map (subject_group_map_id, study_group_class_id, study_subject_id, study_group_id, status_id, owner_id, date_created, date_updated, update_id, notes) FROM stdin;
\.


--
-- Data for Name: tag; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.tag (id, tag_name, workflow, owner_id, update_id, date_created, date_updated) FROM stdin;
1	SDV	Tagging	1	\N	2025-11-30 08:06:43.414677+00	\N
2	OffLine	Tagging	1	\N	2025-11-30 08:06:43.419755+00	\N
\.


--
-- Data for Name: usage_statistics_data; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.usage_statistics_data (id, param_key, param_value, update_timestamp, version) FROM stdin;
\.


--
-- Data for Name: user_account; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.user_account (user_id, user_name, passwd, first_name, last_name, email, active_study, institutional_affiliation, status_id, owner_id, date_created, date_updated, date_lastvisit, passwd_timestamp, passwd_challenge_question, passwd_challenge_answer, phone, user_type_id, update_id, enabled, account_non_locked, lock_counter, run_webservices, access_code, time_zone, enable_api_key, api_key) FROM stdin;
1	root	25d55ad283aa400af464c76d713c07ad	Root	User	openclinica_admin@example.com	1	Akaza Research	1	1	\N	2006-10-23	2025-12-04 15:57:39.062559	2006-10-23	\N	\N	617 621 8585	3	1	t	t	0	t	\N		f	\N
\.


--
-- Data for Name: user_role; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.user_role (role_id, role_name, parent_id, role_desc) FROM stdin;
1	admin	1	\N
2	coordinator	1	\N
3	director	1	\N
4	investigator	1	\N
5	ra	1	\N
6	monitor	1	\N
\.


--
-- Data for Name: user_type; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.user_type (user_type_id, user_type) FROM stdin;
1	admin
2	user
3	tech-admin
\.


--
-- Data for Name: versioning_map; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.versioning_map (crf_version_id, item_id) FROM stdin;
\.


--
-- Name: archived_dataset_file_archived_dataset_file_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.archived_dataset_file_archived_dataset_file_id_seq', 1, false);


--
-- Name: audit_event_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.audit_event_audit_id_seq', 1, false);


--
-- Name: audit_log_event_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.audit_log_event_audit_id_seq', 92, true);


--
-- Name: audit_log_event_type_audit_log_event_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.audit_log_event_type_audit_log_event_type_id_seq', 1, false);


--
-- Name: audit_user_api_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.audit_user_api_log_id_seq', 694, true);


--
-- Name: audit_user_login_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.audit_user_login_id_seq', 39, true);


--
-- Name: authorities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.authorities_id_seq', 1, true);


--
-- Name: completion_status_completion_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.completion_status_completion_status_id_seq', 1, false);


--
-- Name: configuration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.configuration_id_seq', 10, true);


--
-- Name: crf_crf_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.crf_crf_id_seq', 22, true);


--
-- Name: crf_version_crf_version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.crf_version_crf_version_id_seq', 22, true);


--
-- Name: crf_version_media_crf_version_media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.crf_version_media_crf_version_media_id_seq', 1, false);


--
-- Name: dataset_dataset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.dataset_dataset_id_seq', 1, false);


--
-- Name: dataset_item_status_dataset_item_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.dataset_item_status_dataset_item_status_id_seq', 1, false);


--
-- Name: dc_computed_event_dc_summary_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.dc_computed_event_dc_summary_event_id_seq', 1, false);


--
-- Name: dc_event_dc_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.dc_event_dc_event_id_seq', 1, false);


--
-- Name: dc_primitive_dc_primitive_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.dc_primitive_dc_primitive_id_seq', 1, false);


--
-- Name: dc_section_event_dc_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.dc_section_event_dc_event_id_seq', 1, false);


--
-- Name: dc_send_email_event_dc_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.dc_send_email_event_dc_event_id_seq', 1, false);


--
-- Name: dc_substitution_event_dc_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.dc_substitution_event_dc_event_id_seq', 1, false);


--
-- Name: decision_condition_decision_condition_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.decision_condition_decision_condition_id_seq', 1, false);


--
-- Name: discrepancy_note_discrepancy_note_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.discrepancy_note_discrepancy_note_id_seq', 2, true);


--
-- Name: discrepancy_note_type_discrepancy_note_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.discrepancy_note_type_discrepancy_note_type_id_seq', 1, false);


--
-- Name: dyn_item_form_metadata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.dyn_item_form_metadata_id_seq', 1, false);


--
-- Name: dyn_item_group_metadata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.dyn_item_group_metadata_id_seq', 1, false);


--
-- Name: event_crf_event_crf_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.event_crf_event_crf_id_seq', 1, false);


--
-- Name: event_crf_flag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.event_crf_flag_id_seq', 1, false);


--
-- Name: event_crf_flag_workflow_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.event_crf_flag_workflow_id_seq', 1, false);


--
-- Name: event_definition_crf_event_definition_crf_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.event_definition_crf_event_definition_crf_id_seq', 1, false);


--
-- Name: event_definition_crf_item_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.event_definition_crf_item_tag_id_seq', 1, false);


--
-- Name: event_definition_crf_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.event_definition_crf_tag_id_seq', 1, false);


--
-- Name: export_format_export_format_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.export_format_export_format_id_seq', 1, false);


--
-- Name: filter_filter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.filter_filter_id_seq', 1, false);


--
-- Name: group_class_types_group_class_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.group_class_types_group_class_type_id_seq', 1, false);


--
-- Name: item_data_flag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.item_data_flag_id_seq', 1, false);


--
-- Name: item_data_flag_workflow_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.item_data_flag_workflow_id_seq', 1, false);


--
-- Name: item_data_item_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.item_data_item_data_id_seq', 1, false);


--
-- Name: item_data_type_item_data_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.item_data_type_item_data_type_id_seq', 1, false);


--
-- Name: item_form_metadata_item_form_metadata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.item_form_metadata_item_form_metadata_id_seq', 68, true);


--
-- Name: item_group_item_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.item_group_item_group_id_seq', 19, true);


--
-- Name: item_group_metadata_item_group_metadata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.item_group_metadata_item_group_metadata_id_seq', 76, true);


--
-- Name: item_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.item_item_id_seq', 78, true);


--
-- Name: item_reference_type_item_reference_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.item_reference_type_item_reference_type_id_seq', 1, false);


--
-- Name: measurement_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.measurement_unit_id_seq', 1, false);


--
-- Name: null_value_type_null_value_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.null_value_type_null_value_type_id_seq', 1, false);


--
-- Name: openclinica_version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.openclinica_version_id_seq', 1, false);


--
-- Name: privilege_priv_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.privilege_priv_id_seq', 1, false);


--
-- Name: resolution_status_resolution_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.resolution_status_resolution_status_id_seq', 1, false);


--
-- Name: response_set_response_set_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.response_set_response_set_id_seq', 68, true);


--
-- Name: response_type_response_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.response_type_response_type_id_seq', 1, false);


--
-- Name: rule_action_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.rule_action_id_seq', 1, false);


--
-- Name: rule_action_property_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.rule_action_property_id_seq', 1, false);


--
-- Name: rule_action_run_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.rule_action_run_id_seq', 1, false);


--
-- Name: rule_action_run_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.rule_action_run_log_id_seq', 1, false);


--
-- Name: rule_action_stratification_factor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.rule_action_stratification_factor_id_seq', 1, false);


--
-- Name: rule_expression_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.rule_expression_id_seq', 1, false);


--
-- Name: rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.rule_id_seq', 1, false);


--
-- Name: rule_set_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.rule_set_audit_id_seq', 1, false);


--
-- Name: rule_set_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.rule_set_id_seq', 1, false);


--
-- Name: rule_set_rule_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.rule_set_rule_audit_id_seq', 1, false);


--
-- Name: rule_set_rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.rule_set_rule_id_seq', 1, false);


--
-- Name: scd_item_metadata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.scd_item_metadata_id_seq', 1, false);


--
-- Name: section_section_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.section_section_id_seq', 17, true);


--
-- Name: status_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.status_status_id_seq', 1, false);


--
-- Name: study_event_definition_study_event_definition_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.study_event_definition_study_event_definition_id_seq', 1, false);


--
-- Name: study_event_study_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.study_event_study_event_id_seq', 1, false);


--
-- Name: study_group_class_study_group_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.study_group_class_study_group_class_id_seq', 1, false);


--
-- Name: study_group_study_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.study_group_study_group_id_seq', 1, false);


--
-- Name: study_module_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.study_module_status_id_seq', 1, false);


--
-- Name: study_parameter_study_parameter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.study_parameter_study_parameter_id_seq', 1, false);


--
-- Name: study_parameter_value_study_parameter_value_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.study_parameter_value_study_parameter_value_id_seq', 1, false);


--
-- Name: study_study_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.study_study_id_seq', 2, true);


--
-- Name: study_subject_study_subject_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.study_subject_study_subject_id_seq', 5, true);


--
-- Name: study_type_study_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.study_type_study_type_id_seq', 1, false);


--
-- Name: subject_event_status_subject_event_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.subject_event_status_subject_event_status_id_seq', 1, false);


--
-- Name: subject_group_map_subject_group_map_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.subject_group_map_subject_group_map_id_seq', 1, false);


--
-- Name: subject_subject_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.subject_subject_id_seq', 5, true);


--
-- Name: tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.tag_id_seq', 1, false);


--
-- Name: usage_statistics_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.usage_statistics_data_id_seq', 1, false);


--
-- Name: user_account_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.user_account_user_id_seq', 1, true);


--
-- Name: user_role_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.user_role_role_id_seq', 1, false);


--
-- Name: user_type_user_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.user_type_user_type_id_seq', 1, false);


--
-- Name: archived_dataset_file archived_dataset_file_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.archived_dataset_file
    ADD CONSTRAINT archived_dataset_file_pkey PRIMARY KEY (archived_dataset_file_id);


--
-- Name: audit_event audit_event_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.audit_event
    ADD CONSTRAINT audit_event_pkey PRIMARY KEY (audit_id);


--
-- Name: audit_log_event audit_log_event_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.audit_log_event
    ADD CONSTRAINT audit_log_event_pkey PRIMARY KEY (audit_id);


--
-- Name: audit_log_event_type audit_log_event_type_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.audit_log_event_type
    ADD CONSTRAINT audit_log_event_type_pkey PRIMARY KEY (audit_log_event_type_id);


--
-- Name: audit_user_api_log audit_user_api_log_audit_id_key; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.audit_user_api_log
    ADD CONSTRAINT audit_user_api_log_audit_id_key UNIQUE (audit_id);


--
-- Name: audit_user_api_log audit_user_api_log_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.audit_user_api_log
    ADD CONSTRAINT audit_user_api_log_pkey PRIMARY KEY (id);


--
-- Name: audit_user_login audit_user_login_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.audit_user_login
    ADD CONSTRAINT audit_user_login_pkey PRIMARY KEY (id);


--
-- Name: completion_status completion_status_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.completion_status
    ADD CONSTRAINT completion_status_pkey PRIMARY KEY (completion_status_id);


--
-- Name: configuration configuration_key_key; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT configuration_key_key UNIQUE (key);


--
-- Name: configuration configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT configuration_pkey PRIMARY KEY (id);


--
-- Name: crf crf_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.crf
    ADD CONSTRAINT crf_pkey PRIMARY KEY (crf_id);


--
-- Name: crf_version_media crf_version_media_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.crf_version_media
    ADD CONSTRAINT crf_version_media_pkey PRIMARY KEY (crf_version_media_id);


--
-- Name: crf_version crf_version_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.crf_version
    ADD CONSTRAINT crf_version_pkey PRIMARY KEY (crf_version_id);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: dataset_item_status dataset_item_status_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dataset_item_status
    ADD CONSTRAINT dataset_item_status_pkey PRIMARY KEY (dataset_item_status_id);


--
-- Name: dataset dataset_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT dataset_pkey PRIMARY KEY (dataset_id);


--
-- Name: dc_computed_event dc_computed_event_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_computed_event
    ADD CONSTRAINT dc_computed_event_pkey PRIMARY KEY (dc_summary_event_id);


--
-- Name: dc_event dc_event_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_event
    ADD CONSTRAINT dc_event_pkey PRIMARY KEY (dc_event_id);


--
-- Name: dc_primitive dc_primitive_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_primitive
    ADD CONSTRAINT dc_primitive_pkey PRIMARY KEY (dc_primitive_id);


--
-- Name: dc_section_event dc_section_event_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_section_event
    ADD CONSTRAINT dc_section_event_pkey PRIMARY KEY (dc_event_id);


--
-- Name: dc_send_email_event dc_send_email_event_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_send_email_event
    ADD CONSTRAINT dc_send_email_event_pkey PRIMARY KEY (dc_event_id);


--
-- Name: dc_substitution_event dc_substitution_event_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_substitution_event
    ADD CONSTRAINT dc_substitution_event_pkey PRIMARY KEY (dc_event_id);


--
-- Name: decision_condition decision_condition_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.decision_condition
    ADD CONSTRAINT decision_condition_pkey PRIMARY KEY (decision_condition_id);


--
-- Name: discrepancy_note discrepancy_note_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.discrepancy_note
    ADD CONSTRAINT discrepancy_note_pkey PRIMARY KEY (discrepancy_note_id);


--
-- Name: discrepancy_note_type discrepancy_note_type_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.discrepancy_note_type
    ADD CONSTRAINT discrepancy_note_type_pkey PRIMARY KEY (discrepancy_note_type_id);


--
-- Name: event_definition_crf_tag duplicate_crfpath_tag_uniqueness_key; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_definition_crf_tag
    ADD CONSTRAINT duplicate_crfpath_tag_uniqueness_key UNIQUE (path, tag_id);


--
-- Name: study_event duplicate_event_uniqueness_key; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_event
    ADD CONSTRAINT duplicate_event_uniqueness_key UNIQUE (study_event_definition_id, study_subject_id, sample_ordinal);


--
-- Name: event_definition_crf_item_tag duplicate_itempath_tag_uniqueness_key; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_definition_crf_item_tag
    ADD CONSTRAINT duplicate_itempath_tag_uniqueness_key UNIQUE (path, tag_id);


--
-- Name: dyn_item_form_metadata dyn_item_form_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dyn_item_form_metadata
    ADD CONSTRAINT dyn_item_form_metadata_pkey PRIMARY KEY (id);


--
-- Name: dyn_item_group_metadata dyn_item_group_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dyn_item_group_metadata
    ADD CONSTRAINT dyn_item_group_metadata_pkey PRIMARY KEY (id);


--
-- Name: event_crf event_crf_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_crf
    ADD CONSTRAINT event_crf_pkey PRIMARY KEY (event_crf_id);


--
-- Name: event_definition_crf event_definition_crf_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_definition_crf
    ADD CONSTRAINT event_definition_crf_pkey PRIMARY KEY (event_definition_crf_id);


--
-- Name: export_format export_format_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.export_format
    ADD CONSTRAINT export_format_pkey PRIMARY KEY (export_format_id);


--
-- Name: filter filter_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.filter
    ADD CONSTRAINT filter_pkey PRIMARY KEY (filter_id);


--
-- Name: group_class_types group_class_types_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.group_class_types
    ADD CONSTRAINT group_class_types_pkey PRIMARY KEY (group_class_type_id);


--
-- Name: item_data item_data_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_data
    ADD CONSTRAINT item_data_pkey PRIMARY KEY (item_data_id);


--
-- Name: item_data_type item_data_type_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_data_type
    ADD CONSTRAINT item_data_type_pkey PRIMARY KEY (item_data_type_id);


--
-- Name: item_form_metadata item_form_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_form_metadata
    ADD CONSTRAINT item_form_metadata_pkey PRIMARY KEY (item_form_metadata_id);


--
-- Name: item_group_metadata item_group_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_group_metadata
    ADD CONSTRAINT item_group_metadata_pkey PRIMARY KEY (item_group_metadata_id);


--
-- Name: item_group item_group_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_group
    ADD CONSTRAINT item_group_pkey PRIMARY KEY (item_group_id);


--
-- Name: item item_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT item_pkey PRIMARY KEY (item_id);


--
-- Name: item_reference_type item_reference_type_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_reference_type
    ADD CONSTRAINT item_reference_type_pkey PRIMARY KEY (item_reference_type_id);


--
-- Name: measurement_unit measurement_unit_name_key; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.measurement_unit
    ADD CONSTRAINT measurement_unit_name_key UNIQUE (name);


--
-- Name: measurement_unit measurement_unit_oc_oid_key; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.measurement_unit
    ADD CONSTRAINT measurement_unit_oc_oid_key UNIQUE (oc_oid);


--
-- Name: measurement_unit measurement_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.measurement_unit
    ADD CONSTRAINT measurement_unit_pkey PRIMARY KEY (id);


--
-- Name: null_value_type null_value_type_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.null_value_type
    ADD CONSTRAINT null_value_type_pkey PRIMARY KEY (null_value_type_id);


--
-- Name: oc_qrtz_blob_triggers oc_qrtz_blob_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.oc_qrtz_blob_triggers
    ADD CONSTRAINT oc_qrtz_blob_triggers_pkey PRIMARY KEY (trigger_name, trigger_group);


--
-- Name: oc_qrtz_calendars oc_qrtz_calendars_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.oc_qrtz_calendars
    ADD CONSTRAINT oc_qrtz_calendars_pkey PRIMARY KEY (calendar_name);


--
-- Name: oc_qrtz_cron_triggers oc_qrtz_cron_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.oc_qrtz_cron_triggers
    ADD CONSTRAINT oc_qrtz_cron_triggers_pkey PRIMARY KEY (trigger_name, trigger_group);


--
-- Name: oc_qrtz_fired_triggers oc_qrtz_fired_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.oc_qrtz_fired_triggers
    ADD CONSTRAINT oc_qrtz_fired_triggers_pkey PRIMARY KEY (entry_id);


--
-- Name: oc_qrtz_job_details oc_qrtz_job_details_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.oc_qrtz_job_details
    ADD CONSTRAINT oc_qrtz_job_details_pkey PRIMARY KEY (job_name, job_group);


--
-- Name: oc_qrtz_job_listeners oc_qrtz_job_listeners_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.oc_qrtz_job_listeners
    ADD CONSTRAINT oc_qrtz_job_listeners_pkey PRIMARY KEY (job_name, job_group, job_listener);


--
-- Name: oc_qrtz_locks oc_qrtz_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.oc_qrtz_locks
    ADD CONSTRAINT oc_qrtz_locks_pkey PRIMARY KEY (lock_name, sched_name);


--
-- Name: oc_qrtz_paused_trigger_grps oc_qrtz_paused_trigger_grps_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.oc_qrtz_paused_trigger_grps
    ADD CONSTRAINT oc_qrtz_paused_trigger_grps_pkey PRIMARY KEY (trigger_group);


--
-- Name: oc_qrtz_scheduler_state oc_qrtz_scheduler_state_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.oc_qrtz_scheduler_state
    ADD CONSTRAINT oc_qrtz_scheduler_state_pkey PRIMARY KEY (instance_name);


--
-- Name: oc_qrtz_simple_triggers oc_qrtz_simple_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.oc_qrtz_simple_triggers
    ADD CONSTRAINT oc_qrtz_simple_triggers_pkey PRIMARY KEY (trigger_name, trigger_group);


--
-- Name: oc_qrtz_trigger_listeners oc_qrtz_trigger_listeners_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.oc_qrtz_trigger_listeners
    ADD CONSTRAINT oc_qrtz_trigger_listeners_pkey PRIMARY KEY (trigger_name, trigger_group, trigger_listener);


--
-- Name: oc_qrtz_triggers oc_qrtz_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.oc_qrtz_triggers
    ADD CONSTRAINT oc_qrtz_triggers_pkey PRIMARY KEY (trigger_name, trigger_group);


--
-- Name: openclinica_version openclinica_version_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.openclinica_version
    ADD CONSTRAINT openclinica_version_pkey PRIMARY KEY (id);


--
-- Name: event_crf_flag pk_event_crf_flag; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_crf_flag
    ADD CONSTRAINT pk_event_crf_flag PRIMARY KEY (id);


--
-- Name: event_crf_flag_workflow pk_event_crf_flag_workflow; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_crf_flag_workflow
    ADD CONSTRAINT pk_event_crf_flag_workflow PRIMARY KEY (id);


--
-- Name: event_definition_crf_item_tag pk_event_definition_crf_item_tag; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_definition_crf_item_tag
    ADD CONSTRAINT pk_event_definition_crf_item_tag PRIMARY KEY (id);


--
-- Name: event_definition_crf_tag pk_event_definition_crf_tag; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_definition_crf_tag
    ADD CONSTRAINT pk_event_definition_crf_tag PRIMARY KEY (id);


--
-- Name: item_data_flag pk_item_data_flag; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_data_flag
    ADD CONSTRAINT pk_item_data_flag PRIMARY KEY (id);


--
-- Name: item_data_flag_workflow pk_item_data_flag_workflow; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_data_flag_workflow
    ADD CONSTRAINT pk_item_data_flag_workflow PRIMARY KEY (id);


--
-- Name: item_data pk_item_data_new; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_data
    ADD CONSTRAINT pk_item_data_new UNIQUE (item_id, event_crf_id, ordinal);


--
-- Name: tag pk_tag; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.tag
    ADD CONSTRAINT pk_tag PRIMARY KEY (id);


--
-- Name: privilege privilege_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.privilege
    ADD CONSTRAINT privilege_pkey PRIMARY KEY (priv_id);


--
-- Name: resolution_status resolution_status_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.resolution_status
    ADD CONSTRAINT resolution_status_pkey PRIMARY KEY (resolution_status_id);


--
-- Name: response_set response_set_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.response_set
    ADD CONSTRAINT response_set_pkey PRIMARY KEY (response_set_id);


--
-- Name: response_type response_type_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.response_type
    ADD CONSTRAINT response_type_pkey PRIMARY KEY (response_type_id);


--
-- Name: rule_action rule_action_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_action
    ADD CONSTRAINT rule_action_pkey PRIMARY KEY (id);


--
-- Name: rule_action_property rule_action_property_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_action_property
    ADD CONSTRAINT rule_action_property_pkey PRIMARY KEY (id);


--
-- Name: rule_action_run_log rule_action_run_log_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_action_run_log
    ADD CONSTRAINT rule_action_run_log_pkey PRIMARY KEY (id);


--
-- Name: rule_action_run rule_action_run_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_action_run
    ADD CONSTRAINT rule_action_run_pkey PRIMARY KEY (id);


--
-- Name: rule_action_stratification_factor rule_action_stratification_factor_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_action_stratification_factor
    ADD CONSTRAINT rule_action_stratification_factor_pkey PRIMARY KEY (id);


--
-- Name: rule_expression rule_expression_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_expression
    ADD CONSTRAINT rule_expression_pkey PRIMARY KEY (id);


--
-- Name: rule rule_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule
    ADD CONSTRAINT rule_pkey PRIMARY KEY (id);


--
-- Name: rule_set_audit rule_set_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_set_audit
    ADD CONSTRAINT rule_set_audit_pkey PRIMARY KEY (id);


--
-- Name: rule_set rule_set_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_set
    ADD CONSTRAINT rule_set_pkey PRIMARY KEY (id);


--
-- Name: rule_set_rule_audit rule_set_rule_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_set_rule_audit
    ADD CONSTRAINT rule_set_rule_audit_pkey PRIMARY KEY (id);


--
-- Name: rule_set_rule rule_set_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.rule_set_rule
    ADD CONSTRAINT rule_set_rule_pkey PRIMARY KEY (id);


--
-- Name: scd_item_metadata scd_item_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.scd_item_metadata
    ADD CONSTRAINT scd_item_metadata_pkey PRIMARY KEY (id);


--
-- Name: section section_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT section_pkey PRIMARY KEY (section_id);


--
-- Name: status status_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT status_pkey PRIMARY KEY (status_id);


--
-- Name: study_event_definition study_event_definition_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_event_definition
    ADD CONSTRAINT study_event_definition_pkey PRIMARY KEY (study_event_definition_id);


--
-- Name: study_event study_event_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_event
    ADD CONSTRAINT study_event_pkey PRIMARY KEY (study_event_id);


--
-- Name: study_group_class study_group_class_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_group_class
    ADD CONSTRAINT study_group_class_pkey PRIMARY KEY (study_group_class_id);


--
-- Name: study_group study_group_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_group
    ADD CONSTRAINT study_group_pkey PRIMARY KEY (study_group_id);


--
-- Name: study_module_status study_module_status_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_module_status
    ADD CONSTRAINT study_module_status_pkey PRIMARY KEY (id);


--
-- Name: study_parameter study_parameter_handle_key; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_parameter
    ADD CONSTRAINT study_parameter_handle_key UNIQUE (handle);


--
-- Name: study_parameter study_parameter_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_parameter
    ADD CONSTRAINT study_parameter_pkey PRIMARY KEY (study_parameter_id);


--
-- Name: study study_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study
    ADD CONSTRAINT study_pkey PRIMARY KEY (study_id);


--
-- Name: study_subject study_subject_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_subject
    ADD CONSTRAINT study_subject_pkey PRIMARY KEY (study_subject_id);


--
-- Name: study_type study_type_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_type
    ADD CONSTRAINT study_type_pkey PRIMARY KEY (study_type_id);


--
-- Name: subject_event_status subject_event_status_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.subject_event_status
    ADD CONSTRAINT subject_event_status_pkey PRIMARY KEY (subject_event_status_id);


--
-- Name: subject_group_map subject_group_map_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.subject_group_map
    ADD CONSTRAINT subject_group_map_pkey PRIMARY KEY (subject_group_map_id);


--
-- Name: subject subject_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.subject
    ADD CONSTRAINT subject_pkey PRIMARY KEY (subject_id);


--
-- Name: crf uniq_crf_oc_oid; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.crf
    ADD CONSTRAINT uniq_crf_oc_oid UNIQUE (oc_oid);


--
-- Name: crf_version uniq_crf_version_oc_oid; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.crf_version
    ADD CONSTRAINT uniq_crf_version_oc_oid UNIQUE (oc_oid);


--
-- Name: item_group uniq_item_group_oc_oid; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_group
    ADD CONSTRAINT uniq_item_group_oc_oid UNIQUE (oc_oid);


--
-- Name: item uniq_item_oc_oid; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT uniq_item_oc_oid UNIQUE (oc_oid);


--
-- Name: event_crf uniq_study_event_crf_version_study_subject; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_crf
    ADD CONSTRAINT uniq_study_event_crf_version_study_subject UNIQUE (study_event_id, crf_version_id, study_subject_id);


--
-- Name: study_event_definition uniq_study_event_def_oid; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_event_definition
    ADD CONSTRAINT uniq_study_event_def_oid UNIQUE (oc_oid);


--
-- Name: event_definition_crf uniq_study_event_def_study_crf; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_definition_crf
    ADD CONSTRAINT uniq_study_event_def_study_crf UNIQUE (study_event_definition_id, study_id, crf_id);


--
-- Name: study uniq_study_oid; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study
    ADD CONSTRAINT uniq_study_oid UNIQUE (oc_oid);


--
-- Name: study_subject uniq_study_subject_oid; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_subject
    ADD CONSTRAINT uniq_study_subject_oid UNIQUE (oc_oid);


--
-- Name: usage_statistics_data usage_statistics_data_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.usage_statistics_data
    ADD CONSTRAINT usage_statistics_data_pkey PRIMARY KEY (id);


--
-- Name: user_account user_account_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_pkey PRIMARY KEY (user_id);


--
-- Name: user_role user_role_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.user_role
    ADD CONSTRAINT user_role_pkey PRIMARY KEY (role_id);


--
-- Name: user_type user_type_pkey; Type: CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.user_type
    ADD CONSTRAINT user_type_pkey PRIMARY KEY (user_type_id);


--
-- Name: crf_version_idx_crf; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX crf_version_idx_crf ON public.crf_version USING btree (crf_id);


--
-- Name: discrepancy_note_idx_entity_type; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX discrepancy_note_idx_entity_type ON public.discrepancy_note USING btree (entity_type);


--
-- Name: discrepancy_note_idx_parent; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX discrepancy_note_idx_parent ON public.discrepancy_note USING btree (discrepancy_note_id) WHERE ((parent_dn_id IS NULL) OR (parent_dn_id = 0));


--
-- Name: event_definition_crf_idx_crf; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX event_definition_crf_idx_crf ON public.event_definition_crf USING btree (crf_id);


--
-- Name: event_definition_crf_idx_parent_null; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX event_definition_crf_idx_parent_null ON public.event_definition_crf USING btree (parent_id) WHERE (parent_id IS NULL);


--
-- Name: event_definition_crf_idx_parent_zero; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX event_definition_crf_idx_parent_zero ON public.event_definition_crf USING btree (parent_id) WHERE ((parent_id IS NOT NULL) OR (parent_id <> 0));


--
-- Name: event_definition_crf_idx_study_event_definition; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX event_definition_crf_idx_study_event_definition ON public.event_definition_crf USING btree (study_event_definition_id);


--
-- Name: i_audit_event_audit_table; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_audit_event_audit_table ON public.audit_event USING btree (audit_table);


--
-- Name: i_audit_event_context_study_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_audit_event_context_study_id ON public.audit_event_context USING btree (study_id);


--
-- Name: i_audit_event_entity_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_audit_event_entity_id ON public.audit_event USING btree (entity_id);


--
-- Name: i_audit_event_user_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_audit_event_user_id ON public.audit_event USING btree (user_id);


--
-- Name: i_audit_log_event_audit_log_event_type_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_audit_log_event_audit_log_event_type_id ON public.audit_log_event USING btree (audit_log_event_type_id);


--
-- Name: i_audit_log_event_audit_table; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_audit_log_event_audit_table ON public.audit_log_event USING btree (audit_table);


--
-- Name: i_audit_log_event_entity_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_audit_log_event_entity_id ON public.audit_log_event USING btree (entity_id);


--
-- Name: i_audit_log_event_event_crf_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_audit_log_event_event_crf_id ON public.audit_log_event USING btree (event_crf_id);


--
-- Name: i_audit_log_event_event_crf_version_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_audit_log_event_event_crf_version_id ON public.audit_log_event USING btree (event_crf_version_id);


--
-- Name: i_audit_log_event_study_event_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_audit_log_event_study_event_id ON public.audit_log_event USING btree (study_event_id);


--
-- Name: i_audit_log_event_user_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_audit_log_event_user_id ON public.audit_log_event USING btree (user_id);


--
-- Name: i_completion_status_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_completion_status_status_id ON public.completion_status USING btree (status_id);


--
-- Name: i_crf_name; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_crf_name ON public.crf USING btree (name);


--
-- Name: i_crf_oc_oid; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_crf_oc_oid ON public.crf USING btree (oc_oid);


--
-- Name: i_crf_owner_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_crf_owner_id ON public.crf USING btree (owner_id);


--
-- Name: i_crf_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_crf_status_id ON public.crf USING btree (status_id);


--
-- Name: i_crf_version_name; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_crf_version_name ON public.crf_version USING btree (name);


--
-- Name: i_crf_version_oc_oid; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_crf_version_oc_oid ON public.crf_version USING btree (oc_oid);


--
-- Name: i_crf_version_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_crf_version_status_id ON public.crf_version USING btree (status_id);


--
-- Name: i_dataset_crf_version_map_dataset_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dataset_crf_version_map_dataset_id ON public.dataset_crf_version_map USING btree (dataset_id);


--
-- Name: i_dataset_crf_version_map_event_definition_crf_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dataset_crf_version_map_event_definition_crf_id ON public.dataset_crf_version_map USING btree (event_definition_crf_id);


--
-- Name: i_dataset_filter_map_dataset_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dataset_filter_map_dataset_id ON public.dataset_filter_map USING btree (dataset_id);


--
-- Name: i_dataset_filter_map_filter_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dataset_filter_map_filter_id ON public.dataset_filter_map USING btree (filter_id);


--
-- Name: i_dataset_filter_map_ordinal; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dataset_filter_map_ordinal ON public.dataset_filter_map USING btree (ordinal);


--
-- Name: i_dataset_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dataset_status_id ON public.dataset USING btree (status_id);


--
-- Name: i_dataset_study_group_class_map_dataset_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dataset_study_group_class_map_dataset_id ON public.dataset_study_group_class_map USING btree (dataset_id);


--
-- Name: i_dataset_study_group_class_map_study_group_class_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dataset_study_group_class_map_study_group_class_id ON public.dataset_study_group_class_map USING btree (study_group_class_id);


--
-- Name: i_dc_computed_event_dc_event_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dc_computed_event_dc_event_id ON public.dc_computed_event USING btree (dc_event_id);


--
-- Name: i_dc_computed_event_item_target_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dc_computed_event_item_target_id ON public.dc_computed_event USING btree (item_target_id);


--
-- Name: i_dc_primitive_decision_condition_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dc_primitive_decision_condition_id ON public.dc_primitive USING btree (decision_condition_id);


--
-- Name: i_dc_primitive_dynamic_value_item_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dc_primitive_dynamic_value_item_id ON public.dc_primitive USING btree (dynamic_value_item_id);


--
-- Name: i_dc_primitive_item_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dc_primitive_item_id ON public.dc_primitive USING btree (item_id);


--
-- Name: i_dc_section_event_section_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dc_section_event_section_id ON public.dc_section_event USING btree (section_id);


--
-- Name: i_dc_substitution_event_item_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dc_substitution_event_item_id ON public.dc_substitution_event USING btree (item_id);


--
-- Name: i_dc_summary_item_map_item_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dc_summary_item_map_item_id ON public.dc_summary_item_map USING btree (item_id);


--
-- Name: i_decision_condition_crf_version_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_decision_condition_crf_version_id ON public.decision_condition USING btree (crf_version_id);


--
-- Name: i_decision_condition_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_decision_condition_status_id ON public.decision_condition USING btree (status_id);


--
-- Name: i_didm_column_name; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_didm_column_name ON public.dn_item_data_map USING btree (column_name);


--
-- Name: i_difm_event_crf_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_difm_event_crf_id ON public.dyn_item_form_metadata USING btree (event_crf_id);


--
-- Name: i_difm_item_data_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_difm_item_data_id ON public.dyn_item_form_metadata USING btree (item_data_id);


--
-- Name: i_difm_item_form_metadata_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_difm_item_form_metadata_id ON public.dyn_item_form_metadata USING btree (item_form_metadata_id);


--
-- Name: i_difm_item_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_difm_item_id ON public.dyn_item_form_metadata USING btree (item_id);


--
-- Name: i_difm_show_item; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_difm_show_item ON public.dyn_item_form_metadata USING btree (show_item);


--
-- Name: i_digm_event_crf_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_digm_event_crf_id ON public.dyn_item_group_metadata USING btree (event_crf_id);


--
-- Name: i_digm_item_group_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_digm_item_group_id ON public.dyn_item_group_metadata USING btree (item_group_id);


--
-- Name: i_digm_item_group_metadata_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_digm_item_group_metadata_id ON public.dyn_item_group_metadata USING btree (item_group_metadata_id);


--
-- Name: i_digm_show_group; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_digm_show_group ON public.dyn_item_group_metadata USING btree (show_group);


--
-- Name: i_discrepancy_note_discrepancy_note_type_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_discrepancy_note_discrepancy_note_type_id ON public.discrepancy_note USING btree (discrepancy_note_type_id);


--
-- Name: i_discrepancy_note_entity_type; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_discrepancy_note_entity_type ON public.discrepancy_note USING btree (entity_type);


--
-- Name: i_discrepancy_note_owner_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_discrepancy_note_owner_id ON public.discrepancy_note USING btree (owner_id);


--
-- Name: i_discrepancy_note_parent_dn_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_discrepancy_note_parent_dn_id ON public.discrepancy_note USING btree (parent_dn_id);


--
-- Name: i_discrepancy_note_resolution_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_discrepancy_note_resolution_status_id ON public.discrepancy_note USING btree (resolution_status_id);


--
-- Name: i_discrepancy_note_study_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_discrepancy_note_study_id ON public.discrepancy_note USING btree (study_id);


--
-- Name: i_dn_event_crf_map_discrepancy_note_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dn_event_crf_map_discrepancy_note_id ON public.dn_event_crf_map USING btree (discrepancy_note_id);


--
-- Name: i_dn_event_crf_map_event_crf_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dn_event_crf_map_event_crf_id ON public.dn_event_crf_map USING btree (event_crf_id);


--
-- Name: i_dn_item_data_map_discrepancy_note_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dn_item_data_map_discrepancy_note_id ON public.dn_item_data_map USING btree (discrepancy_note_id);


--
-- Name: i_dn_item_data_map_item_data_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dn_item_data_map_item_data_id ON public.dn_item_data_map USING btree (item_data_id);


--
-- Name: i_dn_study_event_map_discrepancy_note_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dn_study_event_map_discrepancy_note_id ON public.dn_study_event_map USING btree (discrepancy_note_id);


--
-- Name: i_dn_study_event_map_study_event_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dn_study_event_map_study_event_id ON public.dn_study_event_map USING btree (study_event_id);


--
-- Name: i_dn_study_subject_map_discrepancy_note_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dn_study_subject_map_discrepancy_note_id ON public.dn_study_subject_map USING btree (discrepancy_note_id);


--
-- Name: i_dn_study_subject_map_study_subject_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dn_study_subject_map_study_subject_id ON public.dn_study_subject_map USING btree (study_subject_id);


--
-- Name: i_dn_subject_map_discrepancy_note_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dn_subject_map_discrepancy_note_id ON public.dn_subject_map USING btree (discrepancy_note_id);


--
-- Name: i_dn_subject_map_subject_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_dn_subject_map_subject_id ON public.dn_subject_map USING btree (subject_id);


--
-- Name: i_event_crf_completion_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_event_crf_completion_status_id ON public.event_crf USING btree (completion_status_id);


--
-- Name: i_event_crf_date_interviewed; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_event_crf_date_interviewed ON public.event_crf USING btree (date_interviewed);


--
-- Name: i_event_crf_interviewer_name; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_event_crf_interviewer_name ON public.event_crf USING btree (interviewer_name);


--
-- Name: i_event_crf_owner_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_event_crf_owner_id ON public.event_crf USING btree (owner_id);


--
-- Name: i_event_crf_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_event_crf_status_id ON public.event_crf USING btree (status_id);


--
-- Name: i_event_crf_study_event_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_event_crf_study_event_id ON public.event_crf USING btree (study_event_id);


--
-- Name: i_event_crf_study_subject_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_event_crf_study_subject_id ON public.event_crf USING btree (study_subject_id);


--
-- Name: i_event_crf_validator_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_event_crf_validator_id ON public.event_crf USING btree (validator_id);


--
-- Name: i_event_definition_crf_crf_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_event_definition_crf_crf_id ON public.event_definition_crf USING btree (crf_id);


--
-- Name: i_event_definition_crf_default_version_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_event_definition_crf_default_version_id ON public.event_definition_crf USING btree (default_version_id);


--
-- Name: i_event_definition_crf_electronic_signature; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_event_definition_crf_electronic_signature ON public.event_definition_crf USING btree (electronic_signature);


--
-- Name: i_event_definition_crf_ordinal; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_event_definition_crf_ordinal ON public.event_definition_crf USING btree (ordinal);


--
-- Name: i_event_definition_crf_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_event_definition_crf_status_id ON public.event_definition_crf USING btree (status_id);


--
-- Name: i_event_definition_crf_study_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_event_definition_crf_study_id ON public.event_definition_crf USING btree (study_id);


--
-- Name: i_filter_crf_version_map_crf_version_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_filter_crf_version_map_crf_version_id ON public.filter_crf_version_map USING btree (crf_version_id);


--
-- Name: i_filter_crf_version_map_filter_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_filter_crf_version_map_filter_id ON public.filter_crf_version_map USING btree (filter_id);


--
-- Name: i_ifm_item_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_ifm_item_id ON public.item_form_metadata USING btree (item_id);


--
-- Name: i_ifm_response_set_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_ifm_response_set_id ON public.item_form_metadata USING btree (response_set_id);


--
-- Name: i_ifm_section_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_ifm_section_id ON public.item_form_metadata USING btree (section_id);


--
-- Name: i_item_data_event_crf_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_item_data_event_crf_id ON public.item_data USING btree (event_crf_id);


--
-- Name: i_item_data_item_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_item_data_item_id ON public.item_data USING btree (item_id);


--
-- Name: i_item_data_ordinal; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_item_data_ordinal ON public.item_data USING btree (ordinal);


--
-- Name: i_item_data_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_item_data_status_id ON public.item_data USING btree (status_id);


--
-- Name: i_item_form_metadata_decision_condition_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_item_form_metadata_decision_condition_id ON public.item_form_metadata USING btree (decision_condition_id);


--
-- Name: i_item_form_metadata_ordinal; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_item_form_metadata_ordinal ON public.item_form_metadata USING btree (ordinal);


--
-- Name: i_item_form_metadata_parent_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_item_form_metadata_parent_id ON public.item_form_metadata USING btree (parent_id);


--
-- Name: i_item_group_crf_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_item_group_crf_id ON public.item_group USING btree (crf_id);


--
-- Name: i_item_group_metadata_crf_version_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_item_group_metadata_crf_version_id ON public.item_group_metadata USING btree (crf_version_id);


--
-- Name: i_item_group_metadata_item_group_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_item_group_metadata_item_group_id ON public.item_group_metadata USING btree (item_group_id);


--
-- Name: i_item_group_metadata_item_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_item_group_metadata_item_id ON public.item_group_metadata USING btree (item_id);


--
-- Name: i_item_group_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_item_group_status_id ON public.item_group USING btree (status_id);


--
-- Name: i_item_item_data_type_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_item_item_data_type_id ON public.item USING btree (item_data_type_id);


--
-- Name: i_item_item_reference_type_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_item_item_reference_type_id ON public.item USING btree (item_reference_type_id);


--
-- Name: i_item_name; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_item_name ON public.item USING btree (name);


--
-- Name: i_item_oc_oid; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_item_oc_oid ON public.item USING btree (oc_oid);


--
-- Name: i_item_units; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_item_units ON public.item USING btree (units);


--
-- Name: i_itm_form_metadata_crf_ver_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_itm_form_metadata_crf_ver_id ON public.item_form_metadata USING btree (crf_version_id);


--
-- Name: i_key_index; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_key_index ON public.configuration USING btree (key);


--
-- Name: i_null_value_type_code; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_null_value_type_code ON public.null_value_type USING btree (code);


--
-- Name: i_rule_action_action_type; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_action_action_type ON public.rule_action USING btree (action_type);


--
-- Name: i_rule_action_rule_set_rule_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_action_rule_set_rule_id ON public.rule_action USING btree (rule_set_rule_id);


--
-- Name: i_rule_action_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_action_status_id ON public.rule_action USING btree (status_id);


--
-- Name: i_rule_expression_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_expression_status_id ON public.rule_expression USING btree (status_id);


--
-- Name: i_rule_oc_oid; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_oc_oid ON public.rule USING btree (oc_oid);


--
-- Name: i_rule_rule_expression_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_rule_expression_id ON public.rule USING btree (rule_expression_id);


--
-- Name: i_rule_set_audit_rule_set_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_set_audit_rule_set_id ON public.rule_set_audit USING btree (rule_set_id);


--
-- Name: i_rule_set_audit_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_set_audit_status_id ON public.rule_set_audit USING btree (status_id);


--
-- Name: i_rule_set_crf_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_set_crf_id ON public.rule_set USING btree (crf_id);


--
-- Name: i_rule_set_crf_version_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_set_crf_version_id ON public.rule_set USING btree (crf_version_id);


--
-- Name: i_rule_set_rule_audit_rule_set_rule_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_set_rule_audit_rule_set_rule_id ON public.rule_set_rule_audit USING btree (rule_set_rule_id);


--
-- Name: i_rule_set_rule_audit_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_set_rule_audit_status_id ON public.rule_set_rule_audit USING btree (status_id);


--
-- Name: i_rule_set_rule_expression_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_set_rule_expression_id ON public.rule_set USING btree (rule_expression_id);


--
-- Name: i_rule_set_rule_rule_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_set_rule_rule_id ON public.rule_set_rule USING btree (rule_id);


--
-- Name: i_rule_set_rule_rule_set_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_set_rule_rule_set_id ON public.rule_set_rule USING btree (rule_set_id);


--
-- Name: i_rule_set_rule_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_set_rule_status_id ON public.rule_set_rule USING btree (status_id);


--
-- Name: i_rule_set_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_set_status_id ON public.rule_set USING btree (status_id);


--
-- Name: i_rule_set_study_event_definition_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_set_study_event_definition_id ON public.rule_set USING btree (study_event_definition_id);


--
-- Name: i_rule_set_study_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_set_study_id ON public.rule_set USING btree (study_id);


--
-- Name: i_rule_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_rule_status_id ON public.rule USING btree (status_id);


--
-- Name: i_section_ordinal; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_section_ordinal ON public.section USING btree (ordinal);


--
-- Name: i_section_parent_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_section_parent_id ON public.section USING btree (parent_id);


--
-- Name: i_section_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_section_status_id ON public.section USING btree (status_id);


--
-- Name: i_study_event_date_end; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_event_date_end ON public.study_event USING btree (date_end);


--
-- Name: i_study_event_date_start; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_event_date_start ON public.study_event USING btree (date_start);


--
-- Name: i_study_event_definition_oc_oid; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_event_definition_oc_oid ON public.study_event_definition USING btree (oc_oid);


--
-- Name: i_study_event_definition_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_event_definition_status_id ON public.study_event_definition USING btree (status_id);


--
-- Name: i_study_event_definition_update_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_event_definition_update_id ON public.study_event_definition USING btree (update_id);


--
-- Name: i_study_event_sample_ordinal; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_event_sample_ordinal ON public.study_event USING btree (sample_ordinal);


--
-- Name: i_study_event_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_event_status_id ON public.study_event USING btree (status_id);


--
-- Name: i_study_event_subject_event_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_event_subject_event_status_id ON public.study_event USING btree (subject_event_status_id);


--
-- Name: i_study_group_class_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_group_class_status_id ON public.study_group_class USING btree (status_id);


--
-- Name: i_study_group_class_study_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_group_class_study_id ON public.study_group_class USING btree (study_id);


--
-- Name: i_study_oc_oid; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_oc_oid ON public.study USING btree (oc_oid);


--
-- Name: i_study_owner_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_owner_id ON public.study USING btree (owner_id);


--
-- Name: i_study_parameter_value_study_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_parameter_value_study_id ON public.study_parameter_value USING btree (study_id);


--
-- Name: i_study_parent_study_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_parent_study_id ON public.study USING btree (parent_study_id);


--
-- Name: i_study_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_status_id ON public.study USING btree (status_id);


--
-- Name: i_study_subject_label; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_subject_label ON public.study_subject USING btree (label);


--
-- Name: i_study_subject_oc_oid; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_subject_oc_oid ON public.study_subject USING btree (oc_oid);


--
-- Name: i_study_subject_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_subject_status_id ON public.study_subject USING btree (status_id);


--
-- Name: i_study_type_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_type_id ON public.study USING btree (type_id);


--
-- Name: i_study_unique_identifier; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_unique_identifier ON public.study USING btree (name);


--
-- Name: i_study_user_role_user_name; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_study_user_role_user_name ON public.study_user_role USING btree (user_name);


--
-- Name: i_subject_date_created; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_subject_date_created ON public.subject USING btree (date_created);


--
-- Name: i_subject_date_of_birth; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_subject_date_of_birth ON public.subject USING btree (date_of_birth);


--
-- Name: i_subject_gender; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_subject_gender ON public.subject USING btree (gender);


--
-- Name: i_subject_group_map_status_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_subject_group_map_status_id ON public.subject_group_map USING btree (status_id);


--
-- Name: i_subject_group_map_study_group_class_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_subject_group_map_study_group_class_id ON public.subject_group_map USING btree (study_group_class_id);


--
-- Name: i_subject_unique_identifier; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_subject_unique_identifier ON public.subject USING btree (unique_identifier);


--
-- Name: i_user_account_user_name; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_user_account_user_name ON public.user_account USING btree (user_name);


--
-- Name: i_versioning_map_crf_version_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_versioning_map_crf_version_id ON public.versioning_map USING btree (crf_version_id);


--
-- Name: i_versioning_map_item_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX i_versioning_map_item_id ON public.versioning_map USING btree (item_id);


--
-- Name: idx_audit_user_api_log_created_at; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX idx_audit_user_api_log_created_at ON public.audit_user_api_log USING btree (created_at);


--
-- Name: idx_audit_user_api_log_endpoint; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX idx_audit_user_api_log_endpoint ON public.audit_user_api_log USING btree (endpoint_path);


--
-- Name: idx_audit_user_api_log_user_id; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX idx_audit_user_api_log_user_id ON public.audit_user_api_log USING btree (user_id);


--
-- Name: study_event_idx_study_event_definition; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX study_event_idx_study_event_definition ON public.study_event USING btree (study_event_definition_id);


--
-- Name: study_subject_idx_study; Type: INDEX; Schema: public; Owner: libreclinica
--

CREATE INDEX study_subject_idx_study ON public.study_subject USING btree (study_id);


--
-- Name: dn_item_data_map didm_update; Type: TRIGGER; Schema: public; Owner: libreclinica
--

CREATE TRIGGER didm_update AFTER INSERT ON public.dn_item_data_map FOR EACH ROW EXECUTE FUNCTION public.populate_ssid_in_didm_trigger();


--
-- Name: event_crf event_crf_initial; Type: TRIGGER; Schema: public; Owner: libreclinica
--

CREATE TRIGGER event_crf_initial AFTER INSERT ON public.event_crf FOR EACH ROW EXECUTE FUNCTION public.event_crf_initial_trigger();


--
-- Name: event_crf event_crf_update; Type: TRIGGER; Schema: public; Owner: libreclinica
--

CREATE TRIGGER event_crf_update AFTER UPDATE ON public.event_crf FOR EACH ROW EXECUTE FUNCTION public.event_crf_trigger();


--
-- Name: event_crf event_crf_update_1; Type: TRIGGER; Schema: public; Owner: libreclinica
--

CREATE TRIGGER event_crf_update_1 AFTER UPDATE ON public.event_crf FOR EACH ROW EXECUTE FUNCTION public.event_crf_version_change_trigger();


--
-- Name: event_definition_crf event_definition_crf_update; Type: TRIGGER; Schema: public; Owner: libreclinica
--

CREATE TRIGGER event_definition_crf_update AFTER UPDATE ON public.event_definition_crf FOR EACH ROW EXECUTE FUNCTION public.event_definition_crf_trigger();


--
-- Name: subject global_subject_insert_update; Type: TRIGGER; Schema: public; Owner: libreclinica
--

CREATE TRIGGER global_subject_insert_update AFTER INSERT OR UPDATE ON public.subject FOR EACH ROW EXECUTE FUNCTION public.global_subject_trigger();


--
-- Name: item_data item_data_initial; Type: TRIGGER; Schema: public; Owner: libreclinica
--

CREATE TRIGGER item_data_initial AFTER INSERT ON public.item_data FOR EACH ROW EXECUTE FUNCTION public.item_data_initial_trigger();


--
-- Name: item_data item_data_update; Type: TRIGGER; Schema: public; Owner: libreclinica
--

CREATE TRIGGER item_data_update AFTER DELETE OR UPDATE ON public.item_data FOR EACH ROW EXECUTE FUNCTION public.item_data_trigger();


--
-- Name: item_data repeating_data_insert; Type: TRIGGER; Schema: public; Owner: libreclinica
--

CREATE TRIGGER repeating_data_insert AFTER INSERT ON public.item_data FOR EACH ROW EXECUTE FUNCTION public.repeating_item_data_trigger();


--
-- Name: study_event study_event_insert_update; Type: TRIGGER; Schema: public; Owner: libreclinica
--

CREATE TRIGGER study_event_insert_update AFTER UPDATE ON public.study_event FOR EACH ROW EXECUTE FUNCTION public.study_event_trigger_new();


--
-- Name: study_subject study_subject_insert_updare; Type: TRIGGER; Schema: public; Owner: libreclinica
--

CREATE TRIGGER study_subject_insert_updare AFTER INSERT OR UPDATE ON public.study_subject FOR EACH ROW EXECUTE FUNCTION public.study_subject_trigger();


--
-- Name: subject_group_map subject_group_map_insert_update; Type: TRIGGER; Schema: public; Owner: libreclinica
--

CREATE TRIGGER subject_group_map_insert_update AFTER INSERT OR UPDATE ON public.subject_group_map FOR EACH ROW EXECUTE FUNCTION public.subject_group_assignment_trigger();


--
-- Name: audit_user_api_log audit_user_api_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.audit_user_api_log
    ADD CONSTRAINT audit_user_api_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.user_account(user_id) ON DELETE SET NULL;


--
-- Name: dataset dataset_fk_dataset_item_status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT dataset_fk_dataset_item_status FOREIGN KEY (dataset_item_status_id) REFERENCES public.dataset_item_status(dataset_item_status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: discrepancy_note discrepancy_note_asn_u_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.discrepancy_note
    ADD CONSTRAINT discrepancy_note_asn_u_id_fkey FOREIGN KEY (assigned_user_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: discrepancy_note discrepancy_note_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.discrepancy_note
    ADD CONSTRAINT discrepancy_note_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: discrepancy_note discrepancy_note_study_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.discrepancy_note
    ADD CONSTRAINT discrepancy_note_study_id_fkey FOREIGN KEY (study_id) REFERENCES public.study(study_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: discrepancy_note dn_discrepancy_note_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.discrepancy_note
    ADD CONSTRAINT dn_discrepancy_note_type_id_fk FOREIGN KEY (discrepancy_note_type_id) REFERENCES public.discrepancy_note_type(discrepancy_note_type_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dn_event_crf_map dn_event_crf_map_dn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dn_event_crf_map
    ADD CONSTRAINT dn_event_crf_map_dn_id_fkey FOREIGN KEY (discrepancy_note_id) REFERENCES public.discrepancy_note(discrepancy_note_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dn_event_crf_map dn_evnt_crf_map_evnt_crf_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dn_event_crf_map
    ADD CONSTRAINT dn_evnt_crf_map_evnt_crf_id_fk FOREIGN KEY (event_crf_id) REFERENCES public.event_crf(event_crf_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dn_item_data_map dn_item_data_map_dn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dn_item_data_map
    ADD CONSTRAINT dn_item_data_map_dn_id_fkey FOREIGN KEY (discrepancy_note_id) REFERENCES public.discrepancy_note(discrepancy_note_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dn_item_data_map dn_itm_data_map_itm_data_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dn_item_data_map
    ADD CONSTRAINT dn_itm_data_map_itm_data_id_fk FOREIGN KEY (item_data_id) REFERENCES public.item_data(item_data_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: discrepancy_note dn_resolution_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.discrepancy_note
    ADD CONSTRAINT dn_resolution_status_id_fkey FOREIGN KEY (resolution_status_id) REFERENCES public.resolution_status(resolution_status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dn_study_event_map dn_sem_study_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dn_study_event_map
    ADD CONSTRAINT dn_sem_study_event_id_fkey FOREIGN KEY (study_event_id) REFERENCES public.study_event(study_event_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dn_study_subject_map dn_ssm_study_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dn_study_subject_map
    ADD CONSTRAINT dn_ssm_study_subject_id_fkey FOREIGN KEY (study_subject_id) REFERENCES public.study_subject(study_subject_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dn_study_event_map dn_study_event_map_dn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dn_study_event_map
    ADD CONSTRAINT dn_study_event_map_dn_id_fkey FOREIGN KEY (discrepancy_note_id) REFERENCES public.discrepancy_note(discrepancy_note_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dn_study_subject_map dn_study_subject_map_dn_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dn_study_subject_map
    ADD CONSTRAINT dn_study_subject_map_dn_id_fk FOREIGN KEY (discrepancy_note_id) REFERENCES public.discrepancy_note(discrepancy_note_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dn_subject_map dn_subject_map_dn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dn_subject_map
    ADD CONSTRAINT dn_subject_map_dn_id_fkey FOREIGN KEY (discrepancy_note_id) REFERENCES public.discrepancy_note(discrepancy_note_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dn_subject_map dn_subject_map_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dn_subject_map
    ADD CONSTRAINT dn_subject_map_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subject(subject_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: item_data fk_answer_reference_item; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_data
    ADD CONSTRAINT fk_answer_reference_item FOREIGN KEY (item_id) REFERENCES public.item(item_id) ON UPDATE RESTRICT;


--
-- Name: archived_dataset_file fk_archived_reference_dataset; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.archived_dataset_file
    ADD CONSTRAINT fk_archived_reference_dataset FOREIGN KEY (dataset_id) REFERENCES public.dataset(dataset_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: archived_dataset_file fk_archived_reference_export_f; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.archived_dataset_file
    ADD CONSTRAINT fk_archived_reference_export_f FOREIGN KEY (export_format_id) REFERENCES public.export_format(export_format_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: audit_event_context fk_audit_ev_reference_audit_ev; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.audit_event_context
    ADD CONSTRAINT fk_audit_ev_reference_audit_ev FOREIGN KEY (audit_id) REFERENCES public.audit_event(audit_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: audit_event_values fk_audit_lo_ref_audit_lo; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.audit_event_values
    ADD CONSTRAINT fk_audit_lo_ref_audit_lo FOREIGN KEY (audit_id) REFERENCES public.audit_event(audit_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: audit_user_login fk_audit_user_login_id; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.audit_user_login
    ADD CONSTRAINT fk_audit_user_login_id FOREIGN KEY (user_account_id) REFERENCES public.user_account(user_id);


--
-- Name: completion_status fk_completi_fk_comple_status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.completion_status
    ADD CONSTRAINT fk_completi_fk_comple_status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: crf fk_crf_crf_user_user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.crf
    ADD CONSTRAINT fk_crf_crf_user_user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: crf fk_crf_fk_crf_fk_status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.crf
    ADD CONSTRAINT fk_crf_fk_crf_fk_status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: item_group_metadata fk_crf_metadata; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_group_metadata
    ADD CONSTRAINT fk_crf_metadata FOREIGN KEY (crf_version_id) REFERENCES public.crf_version(crf_version_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: crf_version fk_crf_vers_crf_versi_user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.crf_version
    ADD CONSTRAINT fk_crf_vers_crf_versi_user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: crf_version fk_crf_vers_fk_crf_ve_status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.crf_version
    ADD CONSTRAINT fk_crf_vers_fk_crf_ve_status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: crf_version_media fk_crf_version_id; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.crf_version_media
    ADD CONSTRAINT fk_crf_version_id FOREIGN KEY (crf_version_id) REFERENCES public.crf_version(crf_version_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dataset_crf_version_map fk_dataset__ref_event_event_de; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dataset_crf_version_map
    ADD CONSTRAINT fk_dataset__ref_event_event_de FOREIGN KEY (event_definition_crf_id) REFERENCES public.event_definition_crf(event_definition_crf_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dataset_crf_version_map fk_dataset_crf_ref_dataset; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dataset_crf_version_map
    ADD CONSTRAINT fk_dataset_crf_ref_dataset FOREIGN KEY (dataset_id) REFERENCES public.dataset(dataset_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dataset fk_dataset_fk_datase_status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT fk_dataset_fk_datase_status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dataset fk_dataset_fk_datase_study; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT fk_dataset_fk_datase_study FOREIGN KEY (study_id) REFERENCES public.study(study_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dataset fk_dataset_fk_datase_user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT fk_dataset_fk_datase_user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dataset_study_group_class_map fk_dataset_ref_study_grp_class; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dataset_study_group_class_map
    ADD CONSTRAINT fk_dataset_ref_study_grp_class FOREIGN KEY (study_group_class_id) REFERENCES public.study_group_class(study_group_class_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dataset_filter_map fk_dataset_reference_dataset; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dataset_filter_map
    ADD CONSTRAINT fk_dataset_reference_dataset FOREIGN KEY (dataset_id) REFERENCES public.dataset(dataset_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dataset_filter_map fk_dataset_reference_filter; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dataset_filter_map
    ADD CONSTRAINT fk_dataset_reference_filter FOREIGN KEY (filter_id) REFERENCES public.filter(filter_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dataset_study_group_class_map fk_dataset_study_ref_dataset; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dataset_study_group_class_map
    ADD CONSTRAINT fk_dataset_study_ref_dataset FOREIGN KEY (dataset_id) REFERENCES public.dataset(dataset_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dc_computed_event fk_dc_compu_fk_dc_com_dc_event; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_computed_event
    ADD CONSTRAINT fk_dc_compu_fk_dc_com_dc_event FOREIGN KEY (dc_event_id) REFERENCES public.dc_event(dc_event_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dc_event fk_dc_event_fk_dc_eve_decision; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_event
    ADD CONSTRAINT fk_dc_event_fk_dc_eve_decision FOREIGN KEY (decision_condition_id) REFERENCES public.decision_condition(decision_condition_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dc_primitive fk_dc_primi_fk_dc_pri_decision; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_primitive
    ADD CONSTRAINT fk_dc_primi_fk_dc_pri_decision FOREIGN KEY (decision_condition_id) REFERENCES public.decision_condition(decision_condition_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dc_primitive fk_dc_primi_fk_dc_pri_item; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_primitive
    ADD CONSTRAINT fk_dc_primi_fk_dc_pri_item FOREIGN KEY (dynamic_value_item_id) REFERENCES public.item(item_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dc_primitive fk_dc_primi_fk_item_i_item; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_primitive
    ADD CONSTRAINT fk_dc_primi_fk_item_i_item FOREIGN KEY (item_id) REFERENCES public.item(item_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dc_section_event fk_dc_secti_fk_dc_sec_dc_event; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_section_event
    ADD CONSTRAINT fk_dc_secti_fk_dc_sec_dc_event FOREIGN KEY (dc_event_id) REFERENCES public.dc_event(dc_event_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dc_send_email_event fk_dc_send__dc_send_e_dc_event; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_send_email_event
    ADD CONSTRAINT fk_dc_send__dc_send_e_dc_event FOREIGN KEY (dc_event_id) REFERENCES public.dc_event(dc_event_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dc_substitution_event fk_dc_subst_fk_dc_sub_dc_event; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_substitution_event
    ADD CONSTRAINT fk_dc_subst_fk_dc_sub_dc_event FOREIGN KEY (dc_event_id) REFERENCES public.dc_event(dc_event_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dc_substitution_event fk_dc_subst_fk_dc_sub_item; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_substitution_event
    ADD CONSTRAINT fk_dc_subst_fk_dc_sub_item FOREIGN KEY (item_id) REFERENCES public.item(item_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dc_summary_item_map fk_dc_summa_fk_dc_sum_dc_compu; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_summary_item_map
    ADD CONSTRAINT fk_dc_summa_fk_dc_sum_dc_compu FOREIGN KEY (dc_summary_event_id) REFERENCES public.dc_computed_event(dc_summary_event_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dc_summary_item_map fk_dc_summa_fk_dc_sum_item; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.dc_summary_item_map
    ADD CONSTRAINT fk_dc_summa_fk_dc_sum_item FOREIGN KEY (item_id) REFERENCES public.item(item_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: decision_condition fk_decision_fk_decisi_crf_vers; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.decision_condition
    ADD CONSTRAINT fk_decision_fk_decisi_crf_vers FOREIGN KEY (crf_version_id) REFERENCES public.crf_version(crf_version_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: decision_condition fk_decision_fk_decisi_status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.decision_condition
    ADD CONSTRAINT fk_decision_fk_decisi_status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: decision_condition fk_decision_fk_decisi_user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.decision_condition
    ADD CONSTRAINT fk_decision_fk_decisi_user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: event_crf fk_event_cr_fk_event__completi; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_crf
    ADD CONSTRAINT fk_event_cr_fk_event__completi FOREIGN KEY (completion_status_id) REFERENCES public.completion_status(completion_status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: event_crf fk_event_cr_fk_event__status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_crf
    ADD CONSTRAINT fk_event_cr_fk_event__status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: event_crf fk_event_cr_fk_event__study_ev; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_crf
    ADD CONSTRAINT fk_event_cr_fk_event__study_ev FOREIGN KEY (study_event_id) REFERENCES public.study_event(study_event_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: event_crf fk_event_cr_fk_event__user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_crf
    ADD CONSTRAINT fk_event_cr_fk_event__user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: event_crf fk_event_cr_reference_study_su; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_crf
    ADD CONSTRAINT fk_event_cr_reference_study_su FOREIGN KEY (study_subject_id) REFERENCES public.study_subject(study_subject_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: event_definition_crf fk_event_de_fk_study__status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_definition_crf
    ADD CONSTRAINT fk_event_de_fk_study__status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: event_definition_crf fk_event_de_reference_study_ev; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_definition_crf
    ADD CONSTRAINT fk_event_de_reference_study_ev FOREIGN KEY (study_event_definition_id) REFERENCES public.study_event_definition(study_event_definition_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: event_definition_crf fk_event_de_study_crf_user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_definition_crf
    ADD CONSTRAINT fk_event_de_study_crf_user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: filter_crf_version_map fk_filter_c_reference_crf_vers; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.filter_crf_version_map
    ADD CONSTRAINT fk_filter_c_reference_crf_vers FOREIGN KEY (crf_version_id) REFERENCES public.crf_version(crf_version_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: filter_crf_version_map fk_filter_c_reference_filter; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.filter_crf_version_map
    ADD CONSTRAINT fk_filter_c_reference_filter FOREIGN KEY (filter_id) REFERENCES public.filter(filter_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: filter fk_filter_fk_query__status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.filter
    ADD CONSTRAINT fk_filter_fk_query__status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: filter fk_filter_fk_query__user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.filter
    ADD CONSTRAINT fk_filter_fk_query__user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: study_group fk_group_class_study_group; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_group
    ADD CONSTRAINT fk_group_class_study_group FOREIGN KEY (study_group_class_id) REFERENCES public.study_group_class(study_group_class_id) ON UPDATE RESTRICT ON DELETE SET NULL;


--
-- Name: item_group_metadata fk_item; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_group_metadata
    ADD CONSTRAINT fk_item FOREIGN KEY (item_id) REFERENCES public.item(item_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: item_data fk_item_dat_fk_item_d_status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_data
    ADD CONSTRAINT fk_item_dat_fk_item_d_status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: item_data fk_item_dat_fk_item_d_user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_data
    ADD CONSTRAINT fk_item_dat_fk_item_d_user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: item fk_item_fk_item_f_item_ref; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT fk_item_fk_item_f_item_ref FOREIGN KEY (item_reference_type_id) REFERENCES public.item_reference_type(item_reference_type_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: item fk_item_fk_item_i_item_dat; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT fk_item_fk_item_i_item_dat FOREIGN KEY (item_data_type_id) REFERENCES public.item_data_type(item_data_type_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: item fk_item_fk_item_s_status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT fk_item_fk_item_s_status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: item fk_item_fk_item_u_user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT fk_item_fk_item_u_user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: item_group fk_item_gro_fk_item_g_status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_group
    ADD CONSTRAINT fk_item_gro_fk_item_g_status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: item_group fk_item_gro_fk_item_g_user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_group
    ADD CONSTRAINT fk_item_gro_fk_item_g_user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: item_group_metadata fk_item_group; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_group_metadata
    ADD CONSTRAINT fk_item_group FOREIGN KEY (item_group_id) REFERENCES public.item_group(item_group_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: item_group fk_item_group_crf; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_group
    ADD CONSTRAINT fk_item_group_crf FOREIGN KEY (crf_id) REFERENCES public.crf(crf_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: item_form_metadata fk_item_id; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_form_metadata
    ADD CONSTRAINT fk_item_id FOREIGN KEY (item_id) REFERENCES public.item(item_id) ON UPDATE RESTRICT;


--
-- Name: item_data fk_item_reference_subject; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_data
    ADD CONSTRAINT fk_item_reference_subject FOREIGN KEY (event_crf_id) REFERENCES public.event_crf(event_crf_id) ON UPDATE RESTRICT;


--
-- Name: study fk_old_status_id; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study
    ADD CONSTRAINT fk_old_status_id FOREIGN KEY (old_status_id) REFERENCES public.status(status_id);


--
-- Name: study_user_role fk_person_role_study_id; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_user_role
    ADD CONSTRAINT fk_person_role_study_id FOREIGN KEY (study_id) REFERENCES public.study(study_id) ON UPDATE RESTRICT;


--
-- Name: role_privilege_map fk_priv_id; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.role_privilege_map
    ADD CONSTRAINT fk_priv_id FOREIGN KEY (priv_id) REFERENCES public.privilege(priv_id) ON UPDATE RESTRICT;


--
-- Name: study_subject fk_project__reference_study2; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_subject
    ADD CONSTRAINT fk_project__reference_study2 FOREIGN KEY (study_id) REFERENCES public.study(study_id) ON UPDATE RESTRICT;


--
-- Name: response_set fk_response_fk_respon_response; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.response_set
    ADD CONSTRAINT fk_response_fk_respon_response FOREIGN KEY (response_type_id) REFERENCES public.response_type(response_type_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: role_privilege_map fk_role_id; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.role_privilege_map
    ADD CONSTRAINT fk_role_id FOREIGN KEY (role_id) REFERENCES public.user_role(role_id) ON UPDATE RESTRICT;


--
-- Name: item_form_metadata fk_rs_id; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_form_metadata
    ADD CONSTRAINT fk_rs_id FOREIGN KEY (response_set_id) REFERENCES public.response_set(response_set_id) ON UPDATE RESTRICT;


--
-- Name: item_form_metadata fk_sec_id; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.item_form_metadata
    ADD CONSTRAINT fk_sec_id FOREIGN KEY (section_id) REFERENCES public.section(section_id) ON UPDATE RESTRICT;


--
-- Name: section fk_section_fk_sectio_status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT fk_section_fk_sectio_status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: section fk_section_fk_sectio_user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT fk_section_fk_sectio_user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: section fk_section_version; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT fk_section_version FOREIGN KEY (crf_version_id) REFERENCES public.crf_version(crf_version_id) ON UPDATE RESTRICT;


--
-- Name: crf fk_source_study_id; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.crf
    ADD CONSTRAINT fk_source_study_id FOREIGN KEY (source_study_id) REFERENCES public.study(study_id);


--
-- Name: study_event fk_study_ev_fk_study__status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_event
    ADD CONSTRAINT fk_study_ev_fk_study__status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: study_event_definition fk_study_ev_fk_study__study; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_event_definition
    ADD CONSTRAINT fk_study_ev_fk_study__study FOREIGN KEY (study_id) REFERENCES public.study(study_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: study_event fk_study_ev_fk_study__study_ev; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_event
    ADD CONSTRAINT fk_study_ev_fk_study__study_ev FOREIGN KEY (study_event_definition_id) REFERENCES public.study_event_definition(study_event_definition_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: study_event fk_study_ev_fk_study__user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_event
    ADD CONSTRAINT fk_study_ev_fk_study__user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: study_event_definition fk_study_ev_fk_studye_status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_event_definition
    ADD CONSTRAINT fk_study_ev_fk_studye_status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: study_event_definition fk_study_ev_fk_studye_user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_event_definition
    ADD CONSTRAINT fk_study_ev_fk_studye_user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: study_event fk_study_ev_reference_study_su; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_event
    ADD CONSTRAINT fk_study_ev_reference_study_su FOREIGN KEY (study_subject_id) REFERENCES public.study_subject(study_subject_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: study fk_study_fk_study__status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study
    ADD CONSTRAINT fk_study_fk_study__status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: study fk_study_fk_study__user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study
    ADD CONSTRAINT fk_study_fk_study__user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: study_group_class fk_study_gr_fk_study__group_ty; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_group_class
    ADD CONSTRAINT fk_study_gr_fk_study__group_ty FOREIGN KEY (group_class_type_id) REFERENCES public.group_class_types(group_class_type_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: study_group_class fk_study_gr_fk_study__status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_group_class
    ADD CONSTRAINT fk_study_gr_fk_study__status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: study_group_class fk_study_gr_fk_study__user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_group_class
    ADD CONSTRAINT fk_study_gr_fk_study__user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: event_definition_crf fk_study_inst_reference; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_definition_crf
    ADD CONSTRAINT fk_study_inst_reference FOREIGN KEY (crf_id) REFERENCES public.crf(crf_id) ON UPDATE RESTRICT;


--
-- Name: study_module_status fk_study_module_study_id; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_module_status
    ADD CONSTRAINT fk_study_module_study_id FOREIGN KEY (study_id) REFERENCES public.study(study_id);


--
-- Name: event_definition_crf fk_study_reference_instrument; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_definition_crf
    ADD CONSTRAINT fk_study_reference_instrument FOREIGN KEY (study_id) REFERENCES public.study(study_id) ON UPDATE RESTRICT;


--
-- Name: study_subject fk_study_reference_subject; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_subject
    ADD CONSTRAINT fk_study_reference_subject FOREIGN KEY (subject_id) REFERENCES public.subject(subject_id) ON UPDATE RESTRICT ON DELETE SET NULL;


--
-- Name: study_subject fk_study_su_fk_study__status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_subject
    ADD CONSTRAINT fk_study_su_fk_study__status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: study_subject fk_study_su_fk_study__user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_subject
    ADD CONSTRAINT fk_study_su_fk_study__user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: study fk_study_type; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study
    ADD CONSTRAINT fk_study_type FOREIGN KEY (type_id) REFERENCES public.study_type(study_type_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: study_user_role fk_study_us_fk_study__status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_user_role
    ADD CONSTRAINT fk_study_us_fk_study__status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: study_user_role fk_study_us_study_use_user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_user_role
    ADD CONSTRAINT fk_study_us_study_use_user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: subject_group_map fk_subject__fk_sub_gr_user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.subject_group_map
    ADD CONSTRAINT fk_subject__fk_sub_gr_user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: subject_group_map fk_subject__fk_subjec_group_ro; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.subject_group_map
    ADD CONSTRAINT fk_subject__fk_subjec_group_ro FOREIGN KEY (study_group_id) REFERENCES public.study_group(study_group_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: subject_group_map fk_subject__fk_subjec_status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.subject_group_map
    ADD CONSTRAINT fk_subject__fk_subjec_status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: subject_group_map fk_subject__fk_subjec_study_gr; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.subject_group_map
    ADD CONSTRAINT fk_subject__fk_subjec_study_gr FOREIGN KEY (study_group_class_id) REFERENCES public.study_group_class(study_group_class_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: subject_group_map fk_subject__subject_g_study_su; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.subject_group_map
    ADD CONSTRAINT fk_subject__subject_g_study_su FOREIGN KEY (study_subject_id) REFERENCES public.study_subject(study_subject_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: subject fk_subject_fk_subjec_status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.subject
    ADD CONSTRAINT fk_subject_fk_subjec_status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: subject fk_subject_fk_subjec_user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.subject
    ADD CONSTRAINT fk_subject_fk_subjec_user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: event_crf fk_subject_referenc_instrument; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_crf
    ADD CONSTRAINT fk_subject_referenc_instrument FOREIGN KEY (crf_version_id) REFERENCES public.crf_version(crf_version_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_account fk_user_acc_fk_user_f_user_acc; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT fk_user_acc_fk_user_f_user_acc FOREIGN KEY (owner_id) REFERENCES public.user_account(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_account fk_user_acc_ref_user__user_typ; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT fk_user_acc_ref_user__user_typ FOREIGN KEY (user_type_id) REFERENCES public.user_type(user_type_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_account fk_user_acc_status_re_status; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT fk_user_acc_status_re_status FOREIGN KEY (status_id) REFERENCES public.status(status_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: versioning_map fk_versioni_fk_versio_crf_vers; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.versioning_map
    ADD CONSTRAINT fk_versioni_fk_versio_crf_vers FOREIGN KEY (crf_version_id) REFERENCES public.crf_version(crf_version_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: versioning_map fk_versioni_fk_versio_item; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.versioning_map
    ADD CONSTRAINT fk_versioni_fk_versio_item FOREIGN KEY (item_id) REFERENCES public.item(item_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: crf_version fk_versioni_reference_instrume; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.crf_version
    ADD CONSTRAINT fk_versioni_reference_instrume FOREIGN KEY (crf_id) REFERENCES public.crf(crf_id) ON UPDATE RESTRICT;


--
-- Name: event_definition_crf fk_versioning_study_inst; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.event_definition_crf
    ADD CONSTRAINT fk_versioning_study_inst FOREIGN KEY (default_version_id) REFERENCES public.crf_version(crf_version_id) ON UPDATE RESTRICT ON DELETE SET NULL;


--
-- Name: subject has_father; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.subject
    ADD CONSTRAINT has_father FOREIGN KEY (father_id) REFERENCES public.subject(subject_id) ON UPDATE RESTRICT ON DELETE SET NULL;


--
-- Name: subject has_mother; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.subject
    ADD CONSTRAINT has_mother FOREIGN KEY (mother_id) REFERENCES public.subject(subject_id) ON UPDATE RESTRICT ON DELETE SET NULL;


--
-- Name: oc_qrtz_blob_triggers oc_qrtz_blob_triggers_trg_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.oc_qrtz_blob_triggers
    ADD CONSTRAINT oc_qrtz_blob_triggers_trg_fkey FOREIGN KEY (trigger_name, trigger_group) REFERENCES public.oc_qrtz_triggers(trigger_name, trigger_group);


--
-- Name: oc_qrtz_cron_triggers oc_qrtz_cron_triggers_trg_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.oc_qrtz_cron_triggers
    ADD CONSTRAINT oc_qrtz_cron_triggers_trg_fkey FOREIGN KEY (trigger_name, trigger_group) REFERENCES public.oc_qrtz_triggers(trigger_name, trigger_group);


--
-- Name: oc_qrtz_job_listeners oc_qrtz_job_listeners_job_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.oc_qrtz_job_listeners
    ADD CONSTRAINT oc_qrtz_job_listeners_job_fkey FOREIGN KEY (job_name, job_group) REFERENCES public.oc_qrtz_job_details(job_name, job_group);


--
-- Name: oc_qrtz_simple_triggers oc_qrtz_simple_trigs_trg_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.oc_qrtz_simple_triggers
    ADD CONSTRAINT oc_qrtz_simple_trigs_trg_fkey FOREIGN KEY (trigger_name, trigger_group) REFERENCES public.oc_qrtz_triggers(trigger_name, trigger_group);


--
-- Name: oc_qrtz_trigger_listeners oc_qrtz_trigger_lsnrs_trg_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.oc_qrtz_trigger_listeners
    ADD CONSTRAINT oc_qrtz_trigger_lsnrs_trg_fkey FOREIGN KEY (trigger_name, trigger_group) REFERENCES public.oc_qrtz_triggers(trigger_name, trigger_group);


--
-- Name: oc_qrtz_triggers oc_qrtz_triggers_job_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.oc_qrtz_triggers
    ADD CONSTRAINT oc_qrtz_triggers_job_name_fkey FOREIGN KEY (job_name, job_group) REFERENCES public.oc_qrtz_job_details(job_name, job_group);


--
-- Name: study project_is_contained_within_pa; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study
    ADD CONSTRAINT project_is_contained_within_pa FOREIGN KEY (parent_study_id) REFERENCES public.study(study_id) ON UPDATE RESTRICT ON DELETE SET NULL;


--
-- Name: scd_item_metadata scd_meta_fk_control_meta_id; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.scd_item_metadata
    ADD CONSTRAINT scd_meta_fk_control_meta_id FOREIGN KEY (control_item_form_metadata_id) REFERENCES public.item_form_metadata(item_form_metadata_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: scd_item_metadata scd_meta_fk_scd_form_meta_id; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.scd_item_metadata
    ADD CONSTRAINT scd_meta_fk_scd_form_meta_id FOREIGN KEY (scd_item_form_metadata_id) REFERENCES public.item_form_metadata(item_form_metadata_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: study_parameter_value study_param_value_param_fkey; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_parameter_value
    ADD CONSTRAINT study_param_value_param_fkey FOREIGN KEY (parameter) REFERENCES public.study_parameter(handle) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: study_parameter_value study_param_value_study_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: libreclinica
--

ALTER TABLE ONLY public.study_parameter_value
    ADD CONSTRAINT study_param_value_study_id_fk FOREIGN KEY (study_id) REFERENCES public.study(study_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict FWLLvijq95jRgkaQniCDjlvZXRjo8fRzZZvtzvqnNc4Y1OrW7G6tRQtXsglwfwL

