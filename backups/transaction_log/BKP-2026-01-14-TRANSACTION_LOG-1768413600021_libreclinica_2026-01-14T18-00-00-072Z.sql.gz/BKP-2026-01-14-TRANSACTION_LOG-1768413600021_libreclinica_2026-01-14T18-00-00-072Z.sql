--
-- PostgreSQL database dump
--

\restrict fejkagOV7IGWgOrMgLYhBERmk3bYDjXe9Ctx4eowSZyKabxCIAqzNeZkhM4ZdlA

-- Dumped from database version 14.20
-- Dumped by pg_dump version 14.20

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: audit_log_event; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.audit_log_event (audit_id, audit_date, audit_table, user_id, entity_id, entity_name, reason_for_change, audit_log_event_type_id, old_value, new_value, event_crf_id, study_event_id, event_crf_version_id, item_data_repeat_key) FROM stdin;
1	2026-01-12 16:07:16.526622	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
2	2026-01-12 16:07:43.513032	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
3	2026-01-12 16:07:43.602895	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
4	2026-01-12 17:00:02.367544	system_backup	0	0	BKP-2026-01-12-TRANSACTION_LOG-1768237200022	Backup completed - checksum: 45234ddd748b1c3c	1	\N	{"type":"transaction_log","status":"completed","size":1452}	\N	\N	\N	\N
5	2026-01-12 17:00:09.68097	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
6	2026-01-12 17:50:44.980146	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
7	2026-01-12 17:50:45.014482	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
8	2026-01-12 17:54:09.267707	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
9	2026-01-12 17:55:09.930312	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
10	2026-01-12 17:55:31.31182	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
11	2026-01-12 17:55:38.501406	study	1	1	Study	\N	1	\N	\N	\N	\N	\N	\N
12	2026-01-12 17:56:16.242526	study	1	1	Study	\N	1	\N	\N	\N	\N	\N	\N
13	2026-01-12 17:56:27.185386	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
14	2026-01-12 17:56:27.406009	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
15	2026-01-12 17:56:37.010508	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
16	2026-01-12 17:56:37.442297	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
17	2026-01-12 17:57:56.507277	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
18	2026-01-12 17:57:58.521983	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
19	2026-01-12 17:58:00.755676	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
20	2026-01-12 17:59:17.950648	study	1	1	Study	\N	1	\N	\N	\N	\N	\N	\N
21	2026-01-12 18:00:00.433731	system_backup	0	0	BKP-2026-01-12-TRANSACTION_LOG-1768240800024	Backup completed - checksum: 6b65be2ac117e3ae	1	\N	{"type":"transaction_log","status":"completed","size":1857}	\N	\N	\N	\N
22	2026-01-12 18:00:12.643117	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
23	2026-01-12 18:00:12.660947	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
24	2026-01-12 18:00:13.317358	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
25	2026-01-12 18:00:18.912736	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
26	2026-01-12 18:00:19.850681	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
27	2026-01-12 18:00:26.222713	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
28	2026-01-12 18:00:26.781339	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
29	2026-01-12 18:00:41.870205	acc_organization	6	3	Organization	\N	\N	\N	Organization "Test Org" created with admin "john@test.com"	\N	\N	\N	\N
30	2026-01-12 18:25:22.319702	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
31	2026-01-12 18:25:23.334977	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
32	2026-01-12 18:25:23.340706	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
33	2026-01-12 19:00:00.684641	system_backup	0	0	BKP-2026-01-12-TRANSACTION_LOG-1768244400023	Backup completed - checksum: cc0aa6d0731148d5	1	\N	{"type":"transaction_log","status":"completed","size":2085}	\N	\N	\N	\N
34	2026-01-12 19:00:09.602246	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
35	2026-01-12 19:00:09.692801	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
36	2026-01-12 19:00:09.736409	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
37	2026-01-13 17:50:23.845869	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
38	2026-01-13 17:51:18.959689	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
39	2026-01-13 17:51:19.013866	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
40	2026-01-13 17:53:19.576201	study	1	1	Study	\N	1	\N	\N	\N	\N	\N	\N
41	2026-01-13 17:53:20.083445	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
42	2026-01-13 17:55:02.357034	study	1	1	Study	\N	1	\N	\N	\N	\N	\N	\N
43	2026-01-13 17:55:02.937849	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
44	2026-01-13 17:56:55.584825	study	1	1	Study	\N	1	\N	\N	\N	\N	\N	\N
45	2026-01-13 17:56:56.236248	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
46	2026-01-13 18:00:00.97579	system_backup	0	0	BKP-2026-01-13-TRANSACTION_LOG-1768327200031	Backup completed - checksum: fb249e60ef029a1e	1	\N	{"type":"transaction_log","status":"completed","size":2273}	\N	\N	\N	\N
47	2026-01-13 18:00:09.199934	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
48	2026-01-13 18:01:23.60985	study	1	1	Study	\N	1	\N	\N	\N	\N	\N	\N
49	2026-01-13 18:01:24.704886	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
50	2026-01-13 18:01:37.967479	study	1	1	Study	\N	1	\N	\N	\N	\N	\N	\N
51	2026-01-13 18:01:38.77647	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
52	2026-01-13 18:03:53.727847	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
53	2026-01-13 18:03:53.807774	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
54	2026-01-13 18:04:09.828043	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
55	2026-01-13 18:04:09.856907	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
56	2026-01-13 18:04:21.992148	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
57	2026-01-13 18:04:22.039087	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
58	2026-01-13 18:07:44.584498	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
59	2026-01-13 18:07:44.814442	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
60	2026-01-13 18:07:54.152147	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
61	2026-01-13 18:07:54.204479	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
62	2026-01-13 18:08:24.81422	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
63	2026-01-13 18:08:24.919545	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
64	2026-01-13 18:08:39.184333	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
65	2026-01-13 18:09:00.411971	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
66	2026-01-13 18:09:00.467371	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
67	2026-01-13 18:09:17.952354	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
68	2026-01-13 18:09:24.581337	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
69	2026-01-13 18:09:24.698674	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
70	2026-01-13 18:09:37.236823	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
71	2026-01-13 18:09:37.257681	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
72	2026-01-13 18:09:55.233701	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
73	2026-01-13 18:09:55.310795	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
74	2026-01-13 18:10:06.631335	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
75	2026-01-13 18:10:06.689404	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
76	2026-01-13 18:13:24.865828	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
77	2026-01-13 18:40:21.941382	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
78	2026-01-13 18:40:51.646121	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
79	2026-01-13 19:00:00.467194	system_backup	0	0	BKP-2026-01-13-TRANSACTION_LOG-1768330800028	Backup completed - checksum: 720c8c50f9981e3f	1	\N	{"type":"transaction_log","status":"completed","size":2697}	\N	\N	\N	\N
80	2026-01-13 19:00:07.222734	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
81	2026-01-13 19:57:37.65697	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
82	2026-01-13 19:58:43.086164	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
83	2026-01-13 19:59:09.324894	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
84	2026-01-13 20:00:00.513777	system_backup	0	0	BKP-2026-01-13-TRANSACTION_LOG-1768334400018	Backup completed - checksum: 9611dd3639f525b5	1	\N	{"type":"transaction_log","status":"completed","size":2782}	\N	\N	\N	\N
85	2026-01-13 20:00:08.286183	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
86	2026-01-13 20:01:45.008735	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
87	2026-01-13 20:02:23.216129	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
88	2026-01-13 20:02:23.295007	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
89	2026-01-13 20:03:03.557857	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
90	2026-01-13 20:09:59.921302	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
91	2026-01-13 20:09:59.996536	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
92	2026-01-13 20:11:39.830661	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
93	2026-01-13 20:11:39.99546	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
94	2026-01-13 20:11:47.953453	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
95	2026-01-13 20:11:47.974429	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
96	2026-01-13 20:12:19.451307	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
97	2026-01-13 20:12:19.47561	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
98	2026-01-13 20:12:53.460627	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
99	2026-01-13 20:12:53.494691	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
100	2026-01-14 11:58:02.401642	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
101	2026-01-14 11:58:29.801765	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
102	2026-01-14 11:58:29.823835	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
103	2026-01-14 11:59:43.526807	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
104	2026-01-14 11:59:43.619051	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
105	2026-01-14 12:00:00.428513	system_backup	0	0	BKP-2026-01-14-TRANSACTION_LOG-1768392000034	Backup completed - checksum: 516f7cf0a0141d8d	1	\N	{"type":"transaction_log","status":"completed","size":3077}	\N	\N	\N	\N
106	2026-01-14 12:00:07.653425	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
107	2026-01-14 12:00:07.794915	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
108	2026-01-14 12:00:29.323571	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
109	2026-01-14 12:00:29.373989	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
110	2026-01-14 12:00:53.891819	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
111	2026-01-14 12:00:53.95626	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
112	2026-01-14 12:01:08.45709	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
113	2026-01-14 12:01:08.471232	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
114	2026-01-14 12:01:33.481253	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
115	2026-01-14 12:01:33.552075	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
116	2026-01-14 12:01:40.851553	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
117	2026-01-14 12:01:40.897538	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
118	2026-01-14 12:02:44.650615	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
119	2026-01-14 12:02:44.718055	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
120	2026-01-14 13:00:00.443574	system_backup	0	0	BKP-2026-01-14-TRANSACTION_LOG-1768395600021	Backup completed - checksum: 41d9e0960d4aaefe	1	\N	{"type":"transaction_log","status":"completed","size":3295}	\N	\N	\N	\N
121	2026-01-14 13:00:07.690663	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
122	2026-01-14 13:00:07.72199	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
123	2026-01-14 13:34:41.894648	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
124	2026-01-14 13:34:41.925878	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
125	2026-01-14 14:00:00.498099	system_backup	0	0	BKP-2026-01-14-TRANSACTION_LOG-1768399200032	Backup completed - checksum: f464128d70a418b3	1	\N	{"type":"transaction_log","status":"completed","size":3375}	\N	\N	\N	\N
126	2026-01-14 14:00:07.524957	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
127	2026-01-14 14:00:07.539059	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
128	2026-01-14 15:00:00.45311	system_backup	0	0	BKP-2026-01-14-TRANSACTION_LOG-1768402800030	Backup completed - checksum: ef03ded8818c2417	1	\N	{"type":"transaction_log","status":"completed","size":3431}	\N	\N	\N	\N
129	2026-01-14 15:00:08.186752	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
130	2026-01-14 15:00:08.18704	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
131	2026-01-14 16:00:00.38919	system_backup	0	0	BKP-2026-01-14-TRANSACTION_LOG-1768406400024	Backup completed - checksum: 5d8f4d56505ac008	1	\N	{"type":"transaction_log","status":"completed","size":3491}	\N	\N	\N	\N
132	2026-01-14 16:00:08.103921	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
133	2026-01-14 16:00:08.195685	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
134	2026-01-14 17:00:00.482988	system_backup	0	0	BKP-2026-01-14-TRANSACTION_LOG-1768410000047	Backup completed - checksum: 343ad102f7cc1bdd	1	\N	{"type":"transaction_log","status":"completed","size":3550}	\N	\N	\N	\N
135	2026-01-14 17:00:07.790536	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
136	2026-01-14 17:00:09.124069	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
\.


--
-- Data for Name: audit_user_login; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.audit_user_login (id, user_name, user_account_id, login_attempt_date, login_status_code, version, details) FROM stdin;
3	root	1	2025-12-02 07:43:20.557514	1	1	Login from 127.0.0.1
4	root	1	2025-12-02 07:43:20.725061	2	1	Logout from 127.0.0.1
5	root	1	2025-12-02 07:43:21.972009	1	1	Login from 127.0.0.1
6	root	1	2025-12-02 07:44:00.390755	1	1	Login from 127.0.0.1
7	root	1	2025-12-02 07:53:25.857298	1	1	Login from 127.0.0.1
8	root	1	2025-12-02 07:53:40.971962	1	1	Login from 127.0.0.1
9	root	1	2025-12-02 07:55:02.444619	1	1	Login from 127.0.0.1
10	root	1	2025-12-02 07:55:59.747293	1	1	Login from 127.0.0.1
11	root	1	2025-12-02 09:10:49.102295	1	1	Login from 127.0.0.1
12	root	1	2025-12-02 09:44:58.0468	1	1	Login from 127.0.0.1
13	root	1	2025-12-02 09:51:28.359735	1	1	Login from 127.0.0.1
14	root	1	2025-12-02 10:09:18.307361	1	1	Login from 127.0.0.1
15	root	1	2025-12-03 04:38:45.747425	1	1	Login from 127.0.0.1
16	root	1	2025-12-03 04:40:41.554483	1	1	Login from 127.0.0.1
17	root	1	2025-12-03 05:01:24.17082	1	1	Login from 127.0.0.1
18	root	1	2025-12-03 05:03:21.401547	1	1	Login from 127.0.0.1
19	root	1	2025-12-03 05:06:22.865795	1	1	Login from 127.0.0.1
20	root	1	2025-12-03 05:07:10.454755	1	1	Login from 127.0.0.1
21	root	1	2025-12-03 05:07:40.966825	1	1	Login from 127.0.0.1
22	root	1	2025-12-03 05:14:36.115137	1	1	Login from 127.0.0.1
23	root	1	2025-12-03 05:15:12.466306	1	1	Login from 127.0.0.1
24	root	1	2025-12-03 05:16:29.677965	1	1	Login from 127.0.0.1
25	root	1	2025-12-03 05:16:35.17258	1	1	Login from 127.0.0.1
26	root	1	2025-12-03 06:11:22.103938	1	1	Login from 127.0.0.1
27	root	1	2025-12-03 06:49:39.26889	1	1	Login from 127.0.0.1
28	root	1	2025-12-03 06:52:38.584263	1	1	Login from 127.0.0.1
29	root	1	2025-12-04 14:09:01.444725	1	1	Login from 127.0.0.1
30	root	1	2025-12-04 14:17:36.905093	1	1	Login from 127.0.0.1
31	root	1	2025-12-04 14:20:00.875774	1	1	Login from 127.0.0.1
32	root	1	2025-12-04 14:24:53.013269	1	1	Login from 127.0.0.1
33	root	1	2025-12-04 15:55:59.41907	1	1	Login from 127.0.0.1
34	root	1	2025-12-04 15:56:04.871324	1	1	Login from 127.0.0.1
35	root	1	2025-12-04 15:57:08.237624	1	1	Login from 127.0.0.1
36	root	1	2025-12-04 15:57:14.753069	1	1	Login from 127.0.0.1
37	root	1	2025-12-04 15:57:21.997581	1	1	Login from 127.0.0.1
38	root	1	2025-12-04 15:57:31.605267	1	1	Login from 127.0.0.1
39	root	1	2025-12-04 15:57:39.065886	1	1	Login from 127.0.0.1
40	root	1	2025-12-15 19:29:11.850146	2	1	Logout from 127.0.0.1
41	root	1	2025-12-15 20:57:24.831203	2	1	Logout from 127.0.0.1
42	root	1	2025-12-15 22:00:14.109216	2	1	Logout from 127.0.0.1
43	root	1	2026-01-04 01:08:43.204277	2	1	Logout from 127.0.0.1
44	root	1	2026-01-06 08:31:51.080222	2	1	Logout from 127.0.0.1
45	root	1	2026-01-12 16:28:58.61427	2	1	Logout from 127.0.0.1
46	root	1	2026-01-12 17:50:44.374758	1	1	Login from 127.0.0.1
47	root	1	2026-01-12 17:52:13.910385	1	1	Login from 127.0.0.1
48	root	1	2026-01-12 17:52:24.130631	1	1	Login from 127.0.0.1
49	root	1	2026-01-12 17:52:36.162842	1	1	Login from 127.0.0.1
50	root	1	2026-01-12 17:55:38.422294	1	1	Login from 127.0.0.1
51	root	1	2026-01-12 17:56:16.128052	1	1	Login from 127.0.0.1
52	root	1	2026-01-12 17:59:17.815473	1	1	Login from 127.0.0.1
53	root	1	2026-01-13 17:51:17.189235	1	1	Login from 127.0.0.1
54	root	1	2026-01-13 18:32:39.578919	2	1	Logout from 127.0.0.1
55	root	1	2026-01-13 20:02:22.073691	1	1	Login from 127.0.0.1
56	root	1	2026-01-14 11:58:28.138206	1	1	Login from 127.0.0.1
57	root	1	2026-01-14 12:21:52.215191	2	1	Logout from 127.0.0.1
\.


--
-- Name: audit_log_event_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.audit_log_event_audit_id_seq', 136, true);


--
-- Name: audit_user_login_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.audit_user_login_id_seq', 57, true);


--
-- PostgreSQL database dump complete
--

\unrestrict fejkagOV7IGWgOrMgLYhBERmk3bYDjXe9Ctx4eowSZyKabxCIAqzNeZkhM4ZdlA

