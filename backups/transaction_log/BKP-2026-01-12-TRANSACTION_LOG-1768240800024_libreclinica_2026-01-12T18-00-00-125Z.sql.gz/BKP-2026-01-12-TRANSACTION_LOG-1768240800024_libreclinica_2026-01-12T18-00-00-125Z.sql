--
-- PostgreSQL database dump
--

\restrict CCCxzafo9R3FW16SzjQOfLx1IeRtHFvU87fpy1TlDt5gHT0HueLC2CEePq003be

-- Dumped from database version 14.20
-- Dumped by pg_dump version 14.20

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: audit_log_event; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.audit_log_event (audit_id, audit_date, audit_table, user_id, entity_id, entity_name, reason_for_change, audit_log_event_type_id, old_value, new_value, event_crf_id, study_event_id, event_crf_version_id, item_data_repeat_key) FROM stdin;
1	2026-01-12 16:07:16.526622	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
2	2026-01-12 16:07:43.513032	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
3	2026-01-12 16:07:43.602895	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
4	2026-01-12 17:00:02.367544	system_backup	0	0	BKP-2026-01-12-TRANSACTION_LOG-1768237200022	Backup completed - checksum: 45234ddd748b1c3c	1	\N	{"type":"transaction_log","status":"completed","size":1452}	\N	\N	\N	\N
5	2026-01-12 17:00:09.68097	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
6	2026-01-12 17:50:44.980146	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
7	2026-01-12 17:50:45.014482	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
8	2026-01-12 17:54:09.267707	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
9	2026-01-12 17:55:09.930312	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
10	2026-01-12 17:55:31.31182	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
11	2026-01-12 17:55:38.501406	study	1	1	Study	\N	1	\N	\N	\N	\N	\N	\N
12	2026-01-12 17:56:16.242526	study	1	1	Study	\N	1	\N	\N	\N	\N	\N	\N
13	2026-01-12 17:56:27.185386	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
14	2026-01-12 17:56:27.406009	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
15	2026-01-12 17:56:37.010508	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
16	2026-01-12 17:56:37.442297	study	1	1	root	Viewed subject list	20	\N	Viewed subject list	\N	\N	\N	\N
17	2026-01-12 17:57:56.507277	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
18	2026-01-12 17:57:58.521983	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
19	2026-01-12 17:58:00.755676	backup_scheduler	0	0	scheduler_started	\N	1	\N	{"fullBackupCron":"0 2 * * 0","incrementalBackupCron":"0 2 * * 1-6","transactionLogCron":"0 * * * *"}	\N	\N	\N	\N
20	2026-01-12 17:59:17.950648	study	1	1	Study	\N	1	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: audit_user_login; Type: TABLE DATA; Schema: public; Owner: libreclinica
--

COPY public.audit_user_login (id, user_name, user_account_id, login_attempt_date, login_status_code, version, details) FROM stdin;
3	root	1	2025-12-02 07:43:20.557514	1	1	Login from 127.0.0.1
4	root	1	2025-12-02 07:43:20.725061	2	1	Logout from 127.0.0.1
5	root	1	2025-12-02 07:43:21.972009	1	1	Login from 127.0.0.1
6	root	1	2025-12-02 07:44:00.390755	1	1	Login from 127.0.0.1
7	root	1	2025-12-02 07:53:25.857298	1	1	Login from 127.0.0.1
8	root	1	2025-12-02 07:53:40.971962	1	1	Login from 127.0.0.1
9	root	1	2025-12-02 07:55:02.444619	1	1	Login from 127.0.0.1
10	root	1	2025-12-02 07:55:59.747293	1	1	Login from 127.0.0.1
11	root	1	2025-12-02 09:10:49.102295	1	1	Login from 127.0.0.1
12	root	1	2025-12-02 09:44:58.0468	1	1	Login from 127.0.0.1
13	root	1	2025-12-02 09:51:28.359735	1	1	Login from 127.0.0.1
14	root	1	2025-12-02 10:09:18.307361	1	1	Login from 127.0.0.1
15	root	1	2025-12-03 04:38:45.747425	1	1	Login from 127.0.0.1
16	root	1	2025-12-03 04:40:41.554483	1	1	Login from 127.0.0.1
17	root	1	2025-12-03 05:01:24.17082	1	1	Login from 127.0.0.1
18	root	1	2025-12-03 05:03:21.401547	1	1	Login from 127.0.0.1
19	root	1	2025-12-03 05:06:22.865795	1	1	Login from 127.0.0.1
20	root	1	2025-12-03 05:07:10.454755	1	1	Login from 127.0.0.1
21	root	1	2025-12-03 05:07:40.966825	1	1	Login from 127.0.0.1
22	root	1	2025-12-03 05:14:36.115137	1	1	Login from 127.0.0.1
23	root	1	2025-12-03 05:15:12.466306	1	1	Login from 127.0.0.1
24	root	1	2025-12-03 05:16:29.677965	1	1	Login from 127.0.0.1
25	root	1	2025-12-03 05:16:35.17258	1	1	Login from 127.0.0.1
26	root	1	2025-12-03 06:11:22.103938	1	1	Login from 127.0.0.1
27	root	1	2025-12-03 06:49:39.26889	1	1	Login from 127.0.0.1
28	root	1	2025-12-03 06:52:38.584263	1	1	Login from 127.0.0.1
29	root	1	2025-12-04 14:09:01.444725	1	1	Login from 127.0.0.1
30	root	1	2025-12-04 14:17:36.905093	1	1	Login from 127.0.0.1
31	root	1	2025-12-04 14:20:00.875774	1	1	Login from 127.0.0.1
32	root	1	2025-12-04 14:24:53.013269	1	1	Login from 127.0.0.1
33	root	1	2025-12-04 15:55:59.41907	1	1	Login from 127.0.0.1
34	root	1	2025-12-04 15:56:04.871324	1	1	Login from 127.0.0.1
35	root	1	2025-12-04 15:57:08.237624	1	1	Login from 127.0.0.1
36	root	1	2025-12-04 15:57:14.753069	1	1	Login from 127.0.0.1
37	root	1	2025-12-04 15:57:21.997581	1	1	Login from 127.0.0.1
38	root	1	2025-12-04 15:57:31.605267	1	1	Login from 127.0.0.1
39	root	1	2025-12-04 15:57:39.065886	1	1	Login from 127.0.0.1
40	root	1	2025-12-15 19:29:11.850146	2	1	Logout from 127.0.0.1
41	root	1	2025-12-15 20:57:24.831203	2	1	Logout from 127.0.0.1
42	root	1	2025-12-15 22:00:14.109216	2	1	Logout from 127.0.0.1
43	root	1	2026-01-04 01:08:43.204277	2	1	Logout from 127.0.0.1
44	root	1	2026-01-06 08:31:51.080222	2	1	Logout from 127.0.0.1
45	root	1	2026-01-12 16:28:58.61427	2	1	Logout from 127.0.0.1
46	root	1	2026-01-12 17:50:44.374758	1	1	Login from 127.0.0.1
47	root	1	2026-01-12 17:52:13.910385	1	1	Login from 127.0.0.1
48	root	1	2026-01-12 17:52:24.130631	1	1	Login from 127.0.0.1
49	root	1	2026-01-12 17:52:36.162842	1	1	Login from 127.0.0.1
50	root	1	2026-01-12 17:55:38.422294	1	1	Login from 127.0.0.1
51	root	1	2026-01-12 17:56:16.128052	1	1	Login from 127.0.0.1
52	root	1	2026-01-12 17:59:17.815473	1	1	Login from 127.0.0.1
\.


--
-- Name: audit_log_event_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.audit_log_event_audit_id_seq', 20, true);


--
-- Name: audit_user_login_id_seq; Type: SEQUENCE SET; Schema: public; Owner: libreclinica
--

SELECT pg_catalog.setval('public.audit_user_login_id_seq', 52, true);


--
-- PostgreSQL database dump complete
--

\unrestrict CCCxzafo9R3FW16SzjQOfLx1IeRtHFvU87fpy1TlDt5gHT0HueLC2CEePq003be

