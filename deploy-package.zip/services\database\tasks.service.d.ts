/**
 * Tasks Service - Aggregates Real LibreClinica Work Items
 *
 * This service queries multiple tables to create a unified "My Tasks" view:
 *
 * 1. QUERIES (discrepancy_note) - Assigned queries needing response
 * 2. SCHEDULED EVENTS (study_event) - Upcoming visits needing data entry
 * 3. FORMS TO COMPLETE (event_crf) - Started but incomplete forms
 * 4. SDV PENDING (event_crf) - Forms requiring source data verification
 * 5. SIGNATURES REQUIRED (event_crf) - Completed forms awaiting e-signature
 *
 * Database Tables Used:
 * - discrepancy_note (queries) - assigned_user_id, owner_id
 * - study_event (scheduled visits) - owner_id
 * - event_crf (form data) - owner_id
 * - study_user_role (study access) - user_name, study_id
 * - subject_event_status (visit status values)
 * - resolution_status (query status values)
 * - status (general status: 1=available, 5=removed)
 *
 * Resolution Status IDs:
 * 1 = New, 2 = Updated, 3 = Resolution Proposed, 4 = Closed, 5 = Not Applicable
 *
 * Subject Event Status IDs:
 * 1 = Scheduled, 2 = Not Scheduled, 3 = Data Entry Started,
 * 4 = Completed, 5 = Stopped, 6 = Skipped, 7 = Locked, 8 = Signed
 */
export type TaskType = 'query' | 'scheduled_visit' | 'data_entry' | 'form_completion' | 'sdv_required' | 'signature_required' | 'overdue_visit';
export type TaskPriority = 'critical' | 'high' | 'medium' | 'low';
export type TaskStatus = 'pending' | 'in_progress' | 'overdue' | 'completed';
export interface Task {
    id: string;
    type: TaskType;
    title: string;
    description: string;
    status: TaskStatus;
    priority: TaskPriority;
    dueDate: Date | null;
    createdAt: Date;
    studyId: number;
    studyName: string;
    subjectId: number | null;
    subjectLabel: string | null;
    eventId: number | null;
    eventName: string | null;
    formId: number | null;
    formName: string | null;
    assignedToUserId: number | null;
    assignedToUsername: string | null;
    ownerId: number | null;
    ownerUsername: string | null;
    sourceTable: string;
    sourceId: number;
    metadata?: Record<string, any>;
}
export interface TaskSummary {
    total: number;
    byType: {
        queries: number;
        scheduledVisits: number;
        dataEntry: number;
        formCompletion: number;
        sdvRequired: number;
        signatureRequired: number;
    };
    byStatus: {
        pending: number;
        inProgress: number;
        overdue: number;
    };
    byPriority: {
        critical: number;
        high: number;
        medium: number;
        low: number;
    };
}
export interface TaskFilters {
    userId?: number;
    username?: string;
    studyId?: number;
    types?: TaskType[];
    status?: TaskStatus;
    priority?: TaskPriority;
    includeQueries?: boolean;
    limit?: number;
    offset?: number;
}
/**
 * Get all tasks for a user, aggregating from multiple sources
 */
export declare function getUserTasks(filters: TaskFilters): Promise<{
    success: boolean;
    data: Task[];
    total: number;
}>;
/**
 * Get task summary counts
 */
export declare function getTaskSummary(filters: TaskFilters): Promise<{
    success: boolean;
    data: TaskSummary;
}>;
/**
 * Get a single task by ID
 */
export declare function getTaskById(taskId: string): Promise<{
    success: boolean;
    data: Task | null;
}>;
//# sourceMappingURL=tasks.service.d.ts.map