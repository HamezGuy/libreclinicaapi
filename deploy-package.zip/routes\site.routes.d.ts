/**
 * Site/Location Routes
 *
 * API endpoints for site management including:
 * - CRUD operations for sites
 * - Patient-to-site assignments
 * - Site staff management
 * - Site statistics
 *
 * 21 CFR Part 11 Compliance:
 * - All site modifications require electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=site.routes.d.ts.map