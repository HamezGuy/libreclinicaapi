/**
 * Backup Routes - 21 CFR Part 11 Compliant
 *
 * REST API routes for database backup and recovery management.
 * All routes require authentication and administrative privileges.
 *
 * Implements SOP-008 Section 7.3 (Record Backup) and 7.4 (Record Recovery) requirements.
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=backup.routes.d.ts.map