/**
 * Event SOAP Service
 *
 * Handles study event operations via LibreClinica SOAP API
 * - Schedule study events for subjects
 * - Create event instances
 * - Update event status
 *
 * SOAP Endpoint: http://localhost:8080/LibreClinica/ws/studyEvent/v1
 */
import { ApiResponse } from '../../types';
/**
 * Event schedule request
 */
interface EventScheduleRequest {
    studyId: number;
    subjectId: number;
    studyEventDefinitionId: number;
    startDate?: string;
    endDate?: string;
    location?: string;
}
/**
 * Schedule a study event for a subject
 */
export declare const scheduleEvent: (request: EventScheduleRequest, userId: number, username: string) => Promise<ApiResponse<any>>;
/**
 * Create a new event instance
 */
export declare const createEvent: (studyOid: string, subjectOid: string, eventOid: string, userId: number, username: string) => Promise<ApiResponse<any>>;
declare const _default: {
    scheduleEvent: (request: EventScheduleRequest, userId: number, username: string) => Promise<ApiResponse<any>>;
    createEvent: (studyOid: string, subjectOid: string, eventOid: string, userId: number, username: string) => Promise<ApiResponse<any>>;
};
export default _default;
//# sourceMappingURL=eventSoap.service.d.ts.map