/**
 * ePRO (Electronic Patient-Reported Outcomes) Routes
 *
 * Endpoints for managing PRO instruments, patient assignments, and responses.
 * Integrates with LibreClinica's database for patient/subject information.
 *
 * 21 CFR Part 11 Compliance:
 * - §11.10(e): Full audit trail for all CREATE, UPDATE, DELETE operations
 * - §11.10(k): UTC timestamps for all events
 * - §11.50: Electronic signature for critical operations
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=epro.routes.d.ts.map