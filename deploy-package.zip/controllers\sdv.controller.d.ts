/**
 * SDV (Source Data Verification) Controller
 *
 * Handles SDV operations for LibreClinica:
 * - List SDV records with filtering
 * - Get individual SDV record details
 * - Get form data for SDV preview
 * - Verify/Unverify operations with audit trail
 * - Bulk verification
 */
import { Request, Response } from 'express';
export declare const list: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const get: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get form data for SDV preview
 * Returns all item_data for the specified event_crf
 */
export declare const getFormData: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const verify: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Bulk verify multiple SDV records
 */
export declare const bulkVerify: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get SDV status for a subject
 */
export declare const getSubjectStatus: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get SDV statistics for a study
 */
export declare const getStats: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get SDV by visit/event
 */
export declare const getByVisit: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Unverify SDV record
 */
export declare const unverify: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    list: (req: Request, res: Response, next: import("express").NextFunction) => void;
    get: (req: Request, res: Response, next: import("express").NextFunction) => void;
    verify: (req: Request, res: Response, next: import("express").NextFunction) => void;
    bulkVerify: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getSubjectStatus: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getStats: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getByVisit: (req: Request, res: Response, next: import("express").NextFunction) => void;
    unverify: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=sdv.controller.d.ts.map