/**
 * 21 CFR Part 11 Compliance Routes
 *
 * Endpoints for checking and managing compliance status
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=compliance.routes.d.ts.map