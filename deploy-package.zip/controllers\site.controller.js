"use strict";
/**
 * Site Controller
 *
 * Handles all site/location-related API endpoints including:
 * - CRUD operations for sites
 * - Patient-to-site assignments
 * - Site staff management
 * - Site statistics
 *
 * 21 CFR Part 11 Compliance:
 * - All site modifications require electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSiteStatistics = exports.removeStaff = exports.assignStaff = exports.getSiteStaff = exports.transferPatient = exports.getSitePatients = exports.deleteSite = exports.updateSite = exports.createSite = exports.getSiteById = exports.getSitesForStudy = void 0;
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const siteService = __importStar(require("../services/database/site.service"));
const logger_1 = require("../config/logger");
/**
 * Get all sites for a study
 * GET /api/sites/study/:studyId
 */
exports.getSitesForStudy = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.params;
    const { status, includeStats } = req.query;
    logger_1.logger.info('📍 Get sites for study request', { studyId, status, includeStats });
    const result = await siteService.getSitesForStudy(parseInt(studyId), {
        status: status,
        includeStats: includeStats === 'true'
    });
    res.json(result);
});
/**
 * Get a single site by ID
 * GET /api/sites/:id
 */
exports.getSiteById = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    logger_1.logger.info('📍 Get site by ID request', { siteId: id });
    const result = await siteService.getSiteById(parseInt(id));
    if (!result.success) {
        res.status(404).json(result);
        return;
    }
    res.json(result);
});
/**
 * Create a new site
 * POST /api/sites
 */
exports.createSite = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    logger_1.logger.info('📍 Create site request', {
        body: req.body,
        userId: user.userId
    });
    const result = await siteService.createSite(req.body, user.userId);
    res.status(result.success ? 201 : 400).json(result);
});
/**
 * Update a site
 * PUT /api/sites/:id
 */
exports.updateSite = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { id } = req.params;
    logger_1.logger.info('📍 Update site request', {
        siteId: id,
        body: req.body,
        userId: user.userId
    });
    const result = await siteService.updateSite(parseInt(id), req.body, user.userId);
    res.json(result);
});
/**
 * Delete a site
 * DELETE /api/sites/:id
 */
exports.deleteSite = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { id } = req.params;
    logger_1.logger.info('📍 Delete site request', { siteId: id, userId: user.userId });
    const result = await siteService.deleteSite(parseInt(id), user.userId);
    res.json(result);
});
/**
 * Get patients for a site
 * GET /api/sites/:id/patients
 */
exports.getSitePatients = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const { status, page, limit } = req.query;
    logger_1.logger.info('📍 Get site patients request', { siteId: id, status, page, limit });
    const result = await siteService.getSitePatients(parseInt(id), {
        status: status,
        page: parseInt(page) || 1,
        limit: parseInt(limit) || 50
    });
    res.json(result);
});
/**
 * Transfer a patient to a different site
 * POST /api/sites/transfer
 */
exports.transferPatient = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { studySubjectId, targetSiteId, reason } = req.body;
    logger_1.logger.info('📍 Transfer patient request', {
        studySubjectId,
        targetSiteId,
        reason,
        userId: user.userId
    });
    if (!studySubjectId || !targetSiteId || !reason) {
        res.status(400).json({
            success: false,
            message: 'studySubjectId, targetSiteId, and reason are required'
        });
        return;
    }
    const result = await siteService.transferPatientToSite(parseInt(studySubjectId), parseInt(targetSiteId), reason, user.userId);
    res.json(result);
});
/**
 * Get site staff
 * GET /api/sites/:id/staff
 */
exports.getSiteStaff = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    logger_1.logger.info('📍 Get site staff request', { siteId: id });
    const result = await siteService.getSiteStaff(parseInt(id));
    res.json(result);
});
/**
 * Assign staff to a site
 * POST /api/sites/:id/staff
 */
exports.assignStaff = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { id } = req.params;
    const { username, roleName } = req.body;
    logger_1.logger.info('📍 Assign staff request', {
        siteId: id,
        username,
        roleName,
        userId: user.userId
    });
    if (!username || !roleName) {
        res.status(400).json({
            success: false,
            message: 'username and roleName are required'
        });
        return;
    }
    const result = await siteService.assignStaffToSite(parseInt(id), username, roleName, user.userId);
    res.json(result);
});
/**
 * Remove staff from a site
 * DELETE /api/sites/:id/staff/:username
 */
exports.removeStaff = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { id, username } = req.params;
    logger_1.logger.info('📍 Remove staff request', {
        siteId: id,
        username,
        userId: user.userId
    });
    const result = await siteService.removeStaffFromSite(parseInt(id), username, user.userId);
    res.json(result);
});
/**
 * Get site statistics for a study
 * GET /api/sites/study/:studyId/stats
 */
exports.getSiteStatistics = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.params;
    logger_1.logger.info('📍 Get site statistics request', { studyId });
    const result = await siteService.getSiteStatistics(parseInt(studyId));
    res.json(result);
});
exports.default = {
    getSitesForStudy: exports.getSitesForStudy,
    getSiteById: exports.getSiteById,
    createSite: exports.createSite,
    updateSite: exports.updateSite,
    deleteSite: exports.deleteSite,
    getSitePatients: exports.getSitePatients,
    transferPatient: exports.transferPatient,
    getSiteStaff: exports.getSiteStaff,
    assignStaff: exports.assignStaff,
    removeStaff: exports.removeStaff,
    getSiteStatistics: exports.getSiteStatistics
};
//# sourceMappingURL=site.controller.js.map