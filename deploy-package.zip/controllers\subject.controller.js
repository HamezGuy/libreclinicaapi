"use strict";
/**
 * Subject Controller
 *
 * Handles all subject/patient-related API endpoints including:
 * - CRUD operations
 * - Progress tracking
 * - Events and forms
 *
 * All operations are tracked in the audit trail.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getForms = exports.getEvents = exports.remove = exports.updateStatus = exports.update = exports.getProgress = exports.create = exports.get = exports.list = void 0;
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const subjectService = __importStar(require("../services/hybrid/subject.service"));
const database_1 = require("../config/database");
const logger_1 = require("../config/logger");
const audit_service_1 = require("../services/database/audit.service");
exports.list = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, status, page, limit, search } = req.query;
    const user = req.user;
    // Validate studyId
    const parsedStudyId = parseInt(studyId);
    if (isNaN(parsedStudyId)) {
        logger_1.logger.warn('Invalid or missing studyId', { studyId, userId: user?.userId });
        res.status(400).json({
            success: false,
            message: 'Valid studyId is required',
            data: [],
            pagination: { page: 1, limit: 20, total: 0, totalPages: 0 }
        });
        return;
    }
    const result = await subjectService.getSubjectList(parsedStudyId, {
        status: status,
        page: parseInt(page) || 1,
        limit: parseInt(limit) || 20
    }, user?.userId, user?.username || user?.userName);
    // Track study access
    if (user?.userId && studyId) {
        await (0, audit_service_1.trackUserAction)({
            userId: user.userId,
            username: user.username || user.userName,
            action: 'STUDY_ACCESSED',
            entityType: 'study',
            entityId: parsedStudyId,
            details: 'Viewed subject list'
        });
    }
    res.json(result);
});
exports.get = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const user = req.user;
    const result = await subjectService.getSubjectById(parseInt(id));
    if (!result) {
        res.status(404).json({ success: false, message: 'Subject not found' });
        return;
    }
    // Track subject access
    if (user?.userId) {
        await (0, audit_service_1.trackUserAction)({
            userId: user.userId,
            username: user.username || user.userName,
            action: 'SUBJECT_VIEWED',
            entityType: 'study_subject',
            entityId: parseInt(id),
            entityName: result.label || result.studySubjectId,
            details: `Viewed subject ${result.label || id}`
        });
    }
    res.json({ success: true, data: result });
});
exports.create = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const result = await subjectService.createSubject(req.body, user.userId, user.username);
    res.status(result.success ? 201 : 400).json(result);
});
exports.getProgress = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const result = await subjectService.getSubjectProgress(parseInt(id));
    if (!result) {
        res.status(404).json({ success: false, message: 'Subject not found' });
        return;
    }
    res.json({ success: true, data: result });
});
/**
 * Update subject
 */
exports.update = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const user = req.user;
    const updates = req.body;
    logger_1.logger.info('Updating subject', { subjectId: id, userId: user.userId });
    const client = await database_1.pool.connect();
    try {
        await client.query('BEGIN');
        const updateFields = [];
        const params = [];
        let paramIndex = 1;
        // Update study_subject fields
        if (updates.secondaryLabel !== undefined) {
            updateFields.push(`secondary_label = $${paramIndex++}`);
            params.push(updates.secondaryLabel);
        }
        if (updateFields.length > 0) {
            updateFields.push(`date_updated = NOW()`);
            updateFields.push(`update_id = $${paramIndex++}`);
            params.push(user.userId);
            params.push(parseInt(id));
            const updateQuery = `
        UPDATE study_subject
        SET ${updateFields.join(', ')}
        WHERE study_subject_id = $${paramIndex}
      `;
            await client.query(updateQuery, params);
        }
        // Update subject table if demographic info provided
        if (updates.dateOfBirth || updates.gender) {
            const subjectQuery = `SELECT subject_id FROM study_subject WHERE study_subject_id = $1`;
            const subjectResult = await client.query(subjectQuery, [parseInt(id)]);
            if (subjectResult.rows.length > 0) {
                const subjectId = subjectResult.rows[0].subject_id;
                const subjectUpdates = [];
                const subjectParams = [];
                let subjectParamIndex = 1;
                if (updates.dateOfBirth) {
                    subjectUpdates.push(`date_of_birth = $${subjectParamIndex++}`);
                    subjectParams.push(updates.dateOfBirth);
                }
                if (updates.gender) {
                    subjectUpdates.push(`gender = $${subjectParamIndex++}`);
                    subjectParams.push(updates.gender === 'male' ? 'm' : updates.gender === 'female' ? 'f' : '');
                }
                if (subjectUpdates.length > 0) {
                    subjectParams.push(subjectId);
                    const subjectUpdateQuery = `
            UPDATE subject
            SET ${subjectUpdates.join(', ')}
            WHERE subject_id = $${subjectParamIndex}
          `;
                    await client.query(subjectUpdateQuery, subjectParams);
                }
            }
        }
        // Log audit event
        await client.query(`
      INSERT INTO audit_log_event (
        audit_date, audit_table, user_id, entity_id, entity_name,
        audit_log_event_type_id
      ) VALUES (
        NOW(), 'study_subject', $1, $2, 'Subject',
        (SELECT audit_log_event_type_id FROM audit_log_event_type WHERE name LIKE '%Update%' LIMIT 1)
      )
    `, [user.userId, parseInt(id)]);
        await client.query('COMMIT');
        // Fetch updated subject
        const updatedSubject = await subjectService.getSubjectById(parseInt(id));
        res.json({ success: true, data: updatedSubject, message: 'Subject updated successfully' });
    }
    catch (error) {
        await client.query('ROLLBACK');
        logger_1.logger.error('Update subject error', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
    finally {
        client.release();
    }
});
/**
 * Update subject status
 */
exports.updateStatus = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const user = req.user;
    const { statusId, reason } = req.body;
    logger_1.logger.info('Updating subject status', { subjectId: id, statusId, userId: user.userId });
    const client = await database_1.pool.connect();
    try {
        await client.query('BEGIN');
        // Get current status for audit
        const currentQuery = `SELECT status_id FROM study_subject WHERE study_subject_id = $1`;
        const currentResult = await client.query(currentQuery, [parseInt(id)]);
        if (currentResult.rows.length === 0) {
            res.status(404).json({ success: false, message: 'Subject not found' });
            return;
        }
        const oldStatus = currentResult.rows[0].status_id;
        // Update status
        await client.query(`
      UPDATE study_subject
      SET status_id = $1, date_updated = NOW(), update_id = $2
      WHERE study_subject_id = $3
    `, [statusId, user.userId, parseInt(id)]);
        // Log audit event
        await client.query(`
      INSERT INTO audit_log_event (
        audit_date, audit_table, user_id, entity_id, entity_name, old_value, new_value, reason_for_change,
        audit_log_event_type_id
      ) VALUES (
        NOW(), 'study_subject', $1, $2, 'Subject', $3, $4, $5,
        (SELECT audit_log_event_type_id FROM audit_log_event_type WHERE name LIKE '%Status%' LIMIT 1)
      )
    `, [user.userId, parseInt(id), oldStatus.toString(), statusId.toString(), reason || 'Status change']);
        await client.query('COMMIT');
        res.json({ success: true, message: 'Subject status updated successfully' });
    }
    catch (error) {
        await client.query('ROLLBACK');
        logger_1.logger.error('Update subject status error', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
    finally {
        client.release();
    }
});
/**
 * Soft delete subject (set status to removed)
 */
exports.remove = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const user = req.user;
    logger_1.logger.info('Removing subject', { subjectId: id, userId: user.userId });
    const client = await database_1.pool.connect();
    try {
        await client.query('BEGIN');
        // Check if subject exists
        const checkQuery = `SELECT study_subject_id FROM study_subject WHERE study_subject_id = $1`;
        const checkResult = await client.query(checkQuery, [parseInt(id)]);
        if (checkResult.rows.length === 0) {
            res.status(404).json({ success: false, message: 'Subject not found' });
            return;
        }
        // Soft delete (set status to removed = 5)
        await client.query(`
      UPDATE study_subject
      SET status_id = 5, date_updated = NOW(), update_id = $1
      WHERE study_subject_id = $2
    `, [user.userId, parseInt(id)]);
        // Log audit event
        await client.query(`
      INSERT INTO audit_log_event (
        audit_date, audit_table, user_id, entity_id, entity_name,
        audit_log_event_type_id
      ) VALUES (
        NOW(), 'study_subject', $1, $2, 'Subject',
        (SELECT audit_log_event_type_id FROM audit_log_event_type WHERE name LIKE '%Remove%' OR name LIKE '%Delete%' LIMIT 1)
      )
    `, [user.userId, parseInt(id)]);
        await client.query('COMMIT');
        res.json({ success: true, message: 'Subject removed successfully' });
    }
    catch (error) {
        await client.query('ROLLBACK');
        logger_1.logger.error('Remove subject error', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
    finally {
        client.release();
    }
});
/**
 * Get subject events
 */
exports.getEvents = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    logger_1.logger.info('Getting subject events', { subjectId: id });
    try {
        const query = `
      SELECT 
        se.study_event_id,
        se.study_subject_id,
        sed.study_event_definition_id,
        sed.name as event_name,
        sed.description as event_description,
        sed.type as event_type,
        sed.ordinal as event_order,
        se.sample_ordinal,
        se.date_start,
        se.date_end,
        se.location,
        sest.name as status,
        se.date_created,
        (
          SELECT COUNT(*)
          FROM event_crf ec
          WHERE ec.study_event_id = se.study_event_id
        ) as total_forms,
        (
          SELECT COUNT(*)
          FROM event_crf ec
          INNER JOIN completion_status cs ON ec.completion_status_id = cs.completion_status_id
          WHERE ec.study_event_id = se.study_event_id AND cs.name IN ('complete', 'signed')
        ) as completed_forms
      FROM study_event se
      INNER JOIN study_event_definition sed ON se.study_event_definition_id = sed.study_event_definition_id
      INNER JOIN subject_event_status sest ON se.subject_event_status_id = sest.subject_event_status_id
      WHERE se.study_subject_id = $1
      ORDER BY sed.ordinal, se.sample_ordinal
    `;
        const result = await database_1.pool.query(query, [parseInt(id)]);
        const events = result.rows.map(event => ({
            id: event.study_event_id.toString(),
            eventDefinitionId: event.study_event_definition_id.toString(),
            name: event.event_name,
            description: event.event_description || '',
            type: event.event_type || 'scheduled',
            order: event.event_order,
            occurrence: event.sample_ordinal,
            startDate: event.date_start,
            endDate: event.date_end,
            location: event.location || '',
            status: event.status,
            dateCreated: event.date_created,
            totalForms: parseInt(event.total_forms) || 0,
            completedForms: parseInt(event.completed_forms) || 0,
            completionPercentage: event.total_forms > 0
                ? Math.round((event.completed_forms / event.total_forms) * 100)
                : 0
        }));
        res.json({ success: true, data: events });
    }
    catch (error) {
        logger_1.logger.error('Get subject events error', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * Get subject forms/CRFs
 */
exports.getForms = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    logger_1.logger.info('Getting subject forms', { subjectId: id });
    try {
        const query = `
      SELECT 
        ec.event_crf_id,
        ec.study_event_id,
        se.study_subject_id,
        sed.name as event_name,
        c.crf_id,
        c.name as form_name,
        c.description as form_description,
        cv.crf_version_id,
        cv.name as version_name,
        ec.date_interviewed,
        ec.interviewer_name,
        cs.name as completion_status,
        st.name as status,
        ec.date_created,
        ec.date_updated,
        ec.validator_id,
        ec.date_validate,
        ec.date_completed
      FROM event_crf ec
      INNER JOIN study_event se ON ec.study_event_id = se.study_event_id
      INNER JOIN study_event_definition sed ON se.study_event_definition_id = sed.study_event_definition_id
      INNER JOIN crf_version cv ON ec.crf_version_id = cv.crf_version_id
      INNER JOIN crf c ON cv.crf_id = c.crf_id
      INNER JOIN completion_status cs ON ec.completion_status_id = cs.completion_status_id
      INNER JOIN status st ON ec.status_id = st.status_id
      WHERE se.study_subject_id = $1
      ORDER BY sed.ordinal, c.name
    `;
        const result = await database_1.pool.query(query, [parseInt(id)]);
        const forms = result.rows.map(form => ({
            id: form.event_crf_id.toString(),
            eventId: form.study_event_id.toString(),
            eventName: form.event_name,
            formId: form.crf_id.toString(),
            formName: form.form_name,
            formDescription: form.form_description || '',
            versionId: form.crf_version_id.toString(),
            versionName: form.version_name,
            interviewDate: form.date_interviewed,
            interviewer: form.interviewer_name || '',
            completionStatus: form.completion_status,
            status: form.status,
            dateCreated: form.date_created,
            dateUpdated: form.date_updated,
            dateCompleted: form.date_completed,
            dateValidated: form.date_validate,
            validatorId: form.validator_id
        }));
        res.json({ success: true, data: forms });
    }
    catch (error) {
        logger_1.logger.error('Get subject forms error', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
exports.default = {
    list: exports.list,
    get: exports.get,
    create: exports.create,
    update: exports.update,
    updateStatus: exports.updateStatus,
    remove: exports.remove,
    getProgress: exports.getProgress,
    getEvents: exports.getEvents,
    getForms: exports.getForms
};
//# sourceMappingURL=subject.controller.js.map