/**
 * Dashboard Service
 *
 * Provides analytics and statistics for dashboards
 * This is a RED X feature - LibreClinica has NO dashboard functionality!
 *
 * Dashboard Features:
 * - Enrollment statistics (by month, quarter, year)
 * - Form completion rates
 * - Query statistics
 * - User activity tracking
 * - Study progress metrics
 *
 * All data EXISTS in LibreClinica DB, we just need to query and aggregate it!
 */
import { EnrollmentStats, CompletionStats, QueryStats, UserActivityStats } from '../../types';
/**
 * Get enrollment statistics
 * RED X Feature: Enrollment Dashboard
 */
export declare const getEnrollmentStats: (studyId: number, startDate?: Date, endDate?: Date) => Promise<EnrollmentStats>;
/**
 * Get form completion statistics
 * RED X Feature: Completion Dashboard
 */
export declare const getCompletionStats: (studyId: number) => Promise<CompletionStats>;
/**
 * Get query/discrepancy statistics
 * RED X Feature: Query Dashboard
 */
export declare const getQueryStatistics: (studyId: number, timeframe?: "week" | "month" | "quarter" | "year") => Promise<QueryStats>;
/**
 * Get user activity statistics
 * RED X Feature: User Activity Dashboard
 * Note: audit_log_event does NOT have study_id column
 * We filter by users assigned to the study instead
 */
export declare const getUserActivityStats: (studyId: number, days?: number) => Promise<UserActivityStats>;
/**
 * Get overall study progress
 * Combines multiple metrics
 */
export declare const getStudyProgress: (studyId: number) => Promise<any>;
/**
 * Get enrollment trend over time
 */
export declare const getEnrollmentTrend: (studyId: number, days?: number) => Promise<any[]>;
/**
 * Get completion trend over time
 * Note: Uses date_updated when completion_status_id indicates complete (4 or 5)
 */
export declare const getCompletionTrend: (studyId: number, days?: number) => Promise<any[]>;
/**
 * Get site performance metrics
 */
export declare const getSitePerformance: (studyId: number) => Promise<any[]>;
/**
 * Get form completion rates by CRF
 */
export declare const getFormCompletionRates: (studyId: number) => Promise<any[]>;
/**
 * Get data quality metrics
 */
export declare const getDataQualityMetrics: (studyId: number) => Promise<any>;
/**
 * Get subject status distribution
 */
export declare const getSubjectStatusDistribution: (studyId: number) => Promise<any[]>;
/**
 * Get real-time activity feed
 */
export declare const getActivityFeed: (studyId: number, limit?: number) => Promise<any[]>;
/**
 * Get study health score
 */
export declare const getStudyHealthScore: (studyId: number) => Promise<any>;
/**
 * Get detailed user analytics
 * Provides comprehensive user activity tracking including:
 * - Login frequency and patterns
 * - Data entry activity
 * - Session metrics
 * - Role-based breakdown
 */
export declare const getUserAnalytics: (studyId: number, days?: number) => Promise<any>;
/**
 * Get top performers (most active users)
 */
export declare const getTopPerformers: (studyId: number, days?: number, limit?: number) => Promise<any[]>;
declare const _default: {
    getEnrollmentStats: (studyId: number, startDate?: Date, endDate?: Date) => Promise<EnrollmentStats>;
    getCompletionStats: (studyId: number) => Promise<CompletionStats>;
    getQueryStatistics: (studyId: number, timeframe?: "week" | "month" | "quarter" | "year") => Promise<QueryStats>;
    getUserActivityStats: (studyId: number, days?: number) => Promise<UserActivityStats>;
    getStudyProgress: (studyId: number) => Promise<any>;
    getEnrollmentTrend: (studyId: number, days?: number) => Promise<any[]>;
    getCompletionTrend: (studyId: number, days?: number) => Promise<any[]>;
    getSitePerformance: (studyId: number) => Promise<any[]>;
    getFormCompletionRates: (studyId: number) => Promise<any[]>;
    getDataQualityMetrics: (studyId: number) => Promise<any>;
    getSubjectStatusDistribution: (studyId: number) => Promise<any[]>;
    getActivityFeed: (studyId: number, limit?: number) => Promise<any[]>;
    getStudyHealthScore: (studyId: number) => Promise<any>;
    getUserAnalytics: (studyId: number, days?: number) => Promise<any>;
    getTopPerformers: (studyId: number, days?: number, limit?: number) => Promise<any[]>;
};
export default _default;
//# sourceMappingURL=dashboard.service.d.ts.map