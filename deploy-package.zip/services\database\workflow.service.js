"use strict";
/**
 * Workflow Service
 *
 * Implements REAL EDC workflow patterns:
 *
 * 1. AUTO-TRIGGERED WORKFLOWS - Created automatically by system events:
 *    - Form submission → SDV Required, Data Review
 *    - Subject enrollment → Enrollment Verification
 *    - Visit completion → Visit Review
 *    - Data changes → Audit Review
 *    - Query opened → Query Response Required
 *
 * 2. MANUAL WORKFLOWS - Created by coordinators/monitors:
 *    - Data queries
 *    - Change requests
 *    - Protocol deviation reviews
 *
 * 3. WORKFLOW LIFECYCLE:
 *    pending → in_progress → awaiting_approval → approved/rejected → completed
 *                         ↘ cancelled
 *
 * Database Tables Used:
 * - discrepancy_note (LibreClinica's task/query table)
 * - resolution_status (workflow status values)
 * - discrepancy_note_type (workflow types)
 * - dn_study_subject_map (links to subjects)
 * - dn_item_data_map (links to form data)
 * - acc_workflow_task (our extended workflow table - created via migration)
 *
 * 21 CFR Part 11 Compliance:
 * - All workflow actions are audit logged
 * - Status transitions are tracked
 * - User actions are recorded with timestamps
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAllWorkflows = getAllWorkflows;
exports.getUserWorkflows = getUserWorkflows;
exports.getUserTaskSummary = getUserTaskSummary;
exports.createWorkflow = createWorkflow;
exports.updateWorkflowStatus = updateWorkflowStatus;
exports.completeWorkflow = completeWorkflow;
exports.approveWorkflow = approveWorkflow;
exports.rejectWorkflow = rejectWorkflow;
exports.handoffWorkflow = handoffWorkflow;
exports.triggerFormSubmittedWorkflow = triggerFormSubmittedWorkflow;
exports.triggerVisitCompletedWorkflow = triggerVisitCompletedWorkflow;
exports.triggerSubjectEnrolledWorkflow = triggerSubjectEnrolledWorkflow;
exports.triggerSDVCompletedWorkflow = triggerSDVCompletedWorkflow;
exports.triggerSignatureAppliedWorkflow = triggerSignatureAppliedWorkflow;
const database_1 = require("../../config/database");
const logger_1 = require("../../config/logger");
const emailService = __importStar(require("../email/email.service"));
// ============ WORKFLOW TYPE MAPPINGS ============
// Maps our workflow types to LibreClinica discrepancy_note_type_id
const WORKFLOW_TYPE_TO_DN_TYPE = {
    'data_query': 3, // Query
    'form_review': 2, // Annotation
    'change_request': 4, // Reason for Change
    'protocol_deviation': 1, // Failed Validation Check
    'adverse_event': 3, // Query
    'visit_completion': 2, // Annotation
    'patient_enrollment': 2, // Annotation
    'electronic_signature': 2, // Annotation
    'study_milestone': 2, // Annotation
    'sdv_required': 2, // Annotation
    'signature_required': 2, // Annotation
    'data_entry': 2, // Annotation
    'custom': 3 // Query
};
// Maps LibreClinica discrepancy_note_type to our workflow types
const DN_TYPE_TO_WORKFLOW = {
    'Failed Validation Check': 'protocol_deviation',
    'Query': 'data_query',
    'Annotation': 'form_review',
    'Reason for Change': 'change_request'
};
// Maps our status to LibreClinica resolution_status_id
const STATUS_TO_RESOLUTION = {
    'pending': 1, // New
    'in_progress': 2, // Updated  
    'awaiting_approval': 3, // Resolution Proposed
    'approved': 4, // Closed
    'completed': 4, // Closed
    'rejected': 5, // Not Applicable
    'cancelled': 5, // Not Applicable
    'overdue': 2 // Updated (but flagged as overdue)
};
// Maps LibreClinica resolution_status to our status
const RESOLUTION_TO_STATUS = {
    'New': 'pending',
    'Updated': 'in_progress',
    'Resolution Proposed': 'awaiting_approval',
    'Closed': 'completed',
    'Not Applicable': 'cancelled'
};
// ============ CORE WORKFLOW FUNCTIONS ============
/**
 * Get all workflows with optional filters
 */
async function getAllWorkflows(filters = {}) {
    logger_1.logger.info('Getting all workflows', filters);
    try {
        const { status, priority, assignedTo, studyId, type, limit = 100, offset = 0 } = filters;
        let query = `
      SELECT 
        dn.discrepancy_note_id as id,
        dn.description as title,
        dn.detailed_notes as description,
        dn.date_created as created_at,
        COALESCE(dn.date_updated, dn.date_created) as updated_at,
        rs.name as resolution_status,
        dnt.name as dn_type,
        dn.study_id,
        s.name as study_name,
        dn.assigned_user_id,
        dn.owner_id,
        ua.user_name as assigned_to,
        COALESCE(ua.first_name || ' ' || ua.last_name, ua.user_name, 'Unassigned') as assigned_to_name,
        owner.user_name as created_by,
        ss.study_subject_id as subject_id,
        ss.label as subject_label,
        dn.entity_type,
        -- Extended workflow properties from notes
        CASE 
          WHEN dn.detailed_notes LIKE '%TYPE:%' THEN 
            SUBSTRING(dn.detailed_notes FROM 'TYPE:([a-z_]+)')
          ELSE NULL
        END as workflow_type,
        CASE
          WHEN dn.detailed_notes LIKE '%PRIORITY:%' THEN
            SUBSTRING(dn.detailed_notes FROM 'PRIORITY:([a-z]+)')
          ELSE 'medium'
        END as priority,
        CASE
          WHEN dn.detailed_notes LIKE '%DUE:%' THEN
            TO_TIMESTAMP(SUBSTRING(dn.detailed_notes FROM 'DUE:([0-9-T:]+)'), 'YYYY-MM-DD"T"HH24:MI:SS')
          ELSE dn.date_created + INTERVAL '7 days'
        END as due_date,
        CASE
          WHEN dn.detailed_notes LIKE '%REQUIRES_APPROVAL:true%' THEN true
          ELSE false
        END as requires_approval,
        CASE
          WHEN dn.detailed_notes LIKE '%REQUIRES_SIGNATURE:true%' THEN true
          ELSE false
        END as requires_signature
      FROM discrepancy_note dn
      JOIN resolution_status rs ON dn.resolution_status_id = rs.resolution_status_id
      JOIN discrepancy_note_type dnt ON dn.discrepancy_note_type_id = dnt.discrepancy_note_type_id
      LEFT JOIN user_account ua ON dn.assigned_user_id = ua.user_id
      LEFT JOIN user_account owner ON dn.owner_id = owner.user_id
      LEFT JOIN study s ON dn.study_id = s.study_id
      LEFT JOIN dn_study_subject_map dssm ON dn.discrepancy_note_id = dssm.discrepancy_note_id
      LEFT JOIN study_subject ss ON dssm.study_subject_id = ss.study_subject_id
      WHERE dn.parent_dn_id IS NULL
    `;
        const params = [];
        let paramIdx = 1;
        if (status) {
            const resolutionId = STATUS_TO_RESOLUTION[status];
            query += ` AND dn.resolution_status_id = $${paramIdx++}`;
            params.push(resolutionId);
        }
        if (assignedTo) {
            query += ` AND ua.user_name = $${paramIdx++}`;
            params.push(assignedTo);
        }
        if (studyId) {
            query += ` AND dn.study_id = $${paramIdx++}`;
            params.push(studyId);
        }
        query += ` ORDER BY dn.date_created DESC LIMIT $${paramIdx++} OFFSET $${paramIdx++}`;
        params.push(limit, offset);
        const result = await database_1.pool.query(query, params);
        const workflows = result.rows.map((row) => mapRowToWorkflow(row));
        return { success: true, data: workflows };
    }
    catch (error) {
        logger_1.logger.error('Error getting workflows', { error: error.message });
        throw error;
    }
}
/**
 * Get workflows for a specific user
 */
async function getUserWorkflows(userId) {
    logger_1.logger.info('Getting user workflows', { userId });
    try {
        const query = `
      SELECT 
        dn.discrepancy_note_id as id,
        dn.description as title,
        dn.detailed_notes as description,
        dn.date_created as created_at,
        COALESCE(dn.date_updated, dn.date_created) as updated_at,
        rs.name as resolution_status,
        dnt.name as dn_type,
        dn.study_id,
        s.name as study_name,
        ua.user_name as assigned_to,
        COALESCE(ua.first_name || ' ' || ua.last_name, ua.user_name) as assigned_to_name,
        owner.user_name as created_by,
        ss.study_subject_id as subject_id,
        ss.label as subject_label,
        dn.entity_type,
        CASE
          WHEN dn.detailed_notes LIKE '%PRIORITY:%' THEN
            SUBSTRING(dn.detailed_notes FROM 'PRIORITY:([a-z]+)')
          ELSE 'medium'
        END as priority,
        dn.date_created + INTERVAL '7 days' as due_date
      FROM discrepancy_note dn
      JOIN resolution_status rs ON dn.resolution_status_id = rs.resolution_status_id
      JOIN discrepancy_note_type dnt ON dn.discrepancy_note_type_id = dnt.discrepancy_note_type_id
      LEFT JOIN user_account ua ON dn.assigned_user_id = ua.user_id
      LEFT JOIN user_account owner ON dn.owner_id = owner.user_id
      LEFT JOIN study s ON dn.study_id = s.study_id
      LEFT JOIN dn_study_subject_map dssm ON dn.discrepancy_note_id = dssm.discrepancy_note_id
      LEFT JOIN study_subject ss ON dssm.study_subject_id = ss.study_subject_id
      WHERE (ua.user_name = $1 OR dn.owner_id = (SELECT user_id FROM user_account WHERE user_name = $1))
      AND dn.parent_dn_id IS NULL
      AND rs.name IN ('New', 'Updated', 'Resolution Proposed')
      ORDER BY dn.date_created DESC
      LIMIT 100
    `;
        const result = await database_1.pool.query(query, [userId]);
        const workflows = result.rows.map((row) => mapRowToWorkflow(row));
        return { success: true, data: workflows };
    }
    catch (error) {
        logger_1.logger.error('Error getting user workflows', { error: error.message });
        throw error;
    }
}
/**
 * Get user task summary
 */
async function getUserTaskSummary(userId) {
    logger_1.logger.info('Getting user task summary', { userId });
    try {
        // Get count summary
        const countQuery = `
      SELECT 
        COUNT(*) FILTER (WHERE rs.name = 'New') as pending,
        COUNT(*) FILTER (WHERE rs.name = 'Updated') as in_progress,
        COUNT(*) FILTER (WHERE rs.name = 'Resolution Proposed') as awaiting_approval,
        COUNT(*) FILTER (WHERE rs.name = 'Closed') as completed,
        COUNT(*) as total
      FROM discrepancy_note dn
      LEFT JOIN user_account ua ON dn.assigned_user_id = ua.user_id
      JOIN resolution_status rs ON dn.resolution_status_id = rs.resolution_status_id
      WHERE (ua.user_name = $1 OR dn.owner_id = (SELECT user_id FROM user_account WHERE user_name = $1))
      AND dn.parent_dn_id IS NULL
    `;
        const countResult = await database_1.pool.query(countQuery, [userId]);
        const counts = countResult.rows[0] || {};
        // Get all active tasks
        const tasksResult = await getUserWorkflows(userId);
        const allTasks = tasksResult.data || [];
        // Organize tasks
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const overdue = [];
        const dueToday = [];
        const inProgress = [];
        const pending = [];
        for (const task of allTasks) {
            if (task.dueDate) {
                const dueDate = new Date(task.dueDate);
                if (dueDate < today) {
                    overdue.push({ ...task, status: 'overdue', priority: 'critical' });
                }
                else if (dueDate.toDateString() === today.toDateString()) {
                    dueToday.push(task);
                }
                else if (task.status === 'in_progress') {
                    inProgress.push(task);
                }
                else if (task.status === 'pending') {
                    pending.push(task);
                }
            }
            else if (task.status === 'in_progress') {
                inProgress.push(task);
            }
            else if (task.status === 'pending') {
                pending.push(task);
            }
        }
        // Get completed today count
        const completedTodayQuery = `
      SELECT COUNT(*) as count
      FROM discrepancy_note dn
      LEFT JOIN user_account ua ON dn.assigned_user_id = ua.user_id
      JOIN resolution_status rs ON dn.resolution_status_id = rs.resolution_status_id
      WHERE (ua.user_name = $1 OR dn.owner_id = (SELECT user_id FROM user_account WHERE user_name = $1))
      AND rs.name = 'Closed'
      AND dn.date_updated::date = CURRENT_DATE
    `;
        const completedTodayResult = await database_1.pool.query(completedTodayQuery, [userId]);
        const completedToday = parseInt(completedTodayResult.rows[0]?.count || '0');
        return {
            success: true,
            data: {
                totalTasks: parseInt(counts.total) || 0,
                pendingTasks: parseInt(counts.pending) || 0,
                inProgressTasks: parseInt(counts.in_progress) || 0,
                awaitingApprovalTasks: parseInt(counts.awaiting_approval) || 0,
                completedTasks: parseInt(counts.completed) || 0,
                overdueTasks: overdue.length,
                statistics: {
                    overdueCount: overdue.length,
                    totalActive: (parseInt(counts.pending) || 0) + (parseInt(counts.in_progress) || 0),
                    completedToday,
                    completedThisWeek: parseInt(counts.completed) || 0,
                    avgCompletionTime: 0
                },
                tasks: {
                    overdue,
                    dueToday,
                    inProgress,
                    pending
                }
            }
        };
    }
    catch (error) {
        logger_1.logger.error('Error getting user task summary', { error: error.message });
        throw error;
    }
}
/**
 * Create a new workflow task
 */
async function createWorkflow(dto, userId, username) {
    logger_1.logger.info('Creating workflow', { dto, userId });
    const client = await database_1.pool.connect();
    try {
        await client.query('BEGIN');
        // Get assigned user ID
        let assignedUserId = userId;
        const assigneeUsername = Array.isArray(dto.assignedTo) ? dto.assignedTo[0] : dto.assignedTo;
        if (assigneeUsername) {
            const userResult = await client.query('SELECT user_id FROM user_account WHERE user_name = $1', [assigneeUsername]);
            if (userResult.rows.length > 0) {
                assignedUserId = userResult.rows[0].user_id;
            }
        }
        // Map workflow type to discrepancy note type
        const discrepancyNoteTypeId = WORKFLOW_TYPE_TO_DN_TYPE[dto.type] || 3;
        // Map entity type
        const entityTypeMap = {
            'patient': 'studySub',
            'subject': 'studySub',
            'form': 'itemData',
            'event': 'studyEvent',
            'study': 'study',
            'event_crf': 'eventCrf'
        };
        const lcEntityType = entityTypeMap[dto.entityType || ''] || 'studySub';
        // Build detailed notes with workflow metadata (for storage/retrieval)
        const metadataNotes = [
            dto.description || '',
            `\n---WORKFLOW_METADATA---`,
            `TYPE:${dto.type}`,
            `PRIORITY:${dto.priority}`,
            dto.dueDate ? `DUE:${new Date(dto.dueDate).toISOString()}` : '',
            dto.requiresApproval ? 'REQUIRES_APPROVAL:true' : '',
            dto.requiresSignature ? 'REQUIRES_SIGNATURE:true' : '',
            dto.autoGenerated ? `AUTO_GENERATED:${dto.sourceEvent || 'system'}` : ''
        ].filter(Boolean).join('\n');
        // Create discrepancy note
        const insertQuery = `
      INSERT INTO discrepancy_note (
        description, detailed_notes, discrepancy_note_type_id,
        resolution_status_id, study_id, assigned_user_id,
        owner_id, entity_type, date_created
      )
      VALUES ($1, $2, $3, 1, $4, $5, $6, $7, NOW())
      RETURNING discrepancy_note_id
    `;
        const result = await client.query(insertQuery, [
            dto.title,
            metadataNotes,
            discrepancyNoteTypeId,
            dto.studyId || 1,
            assignedUserId,
            userId,
            lcEntityType
        ]);
        const workflowId = result.rows[0].discrepancy_note_id;
        // Link to entity if provided
        if (dto.entityId && (dto.entityType === 'patient' || dto.entityType === 'subject')) {
            try {
                let subjectId = dto.entityId;
                if (isNaN(Number(subjectId))) {
                    const subjectResult = await client.query('SELECT study_subject_id FROM study_subject WHERE label = $1 LIMIT 1', [dto.entityId.toString()]);
                    if (subjectResult.rows.length > 0) {
                        subjectId = subjectResult.rows[0].study_subject_id;
                    }
                }
                if (!isNaN(Number(subjectId))) {
                    await client.query('INSERT INTO dn_study_subject_map (discrepancy_note_id, study_subject_id, column_name) VALUES ($1, $2, $3)', [workflowId, subjectId, 'label']);
                }
            }
            catch (mapError) {
                logger_1.logger.warn('Could not link workflow to subject', { error: mapError });
            }
        }
        // Link to event_crf if provided
        if (dto.eventCrfId) {
            try {
                await client.query('INSERT INTO dn_event_crf_map (discrepancy_note_id, event_crf_id, column_name) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING', [workflowId, dto.eventCrfId, 'crf']);
            }
            catch (mapError) {
                logger_1.logger.warn('Could not link workflow to event_crf', { error: mapError });
            }
        }
        // Log audit trail
        await client.query(`
      INSERT INTO audit_log_event (
        audit_date, audit_table, user_id, entity_id, entity_name, 
        audit_log_event_type_id, new_value
      )
      VALUES (NOW(), 'discrepancy_note', $1, $2, 'Workflow Created',
        (SELECT audit_log_event_type_id FROM audit_log_event_type WHERE name = 'Entity Created' LIMIT 1),
        $3)
    `, [userId, workflowId, dto.title]);
        await client.query('COMMIT');
        // Send notification to assigned user if different from creator
        if (assignedUserId !== userId && !dto.autoGenerated) {
            try {
                const userEmailResult = await database_1.pool.query('SELECT email, first_name, last_name FROM user_account WHERE user_id = $1', [assignedUserId]);
                if (userEmailResult.rows.length > 0 && userEmailResult.rows[0].email) {
                    await emailService.queueDirectEmail({
                        recipientEmail: userEmailResult.rows[0].email,
                        recipientUserId: assignedUserId,
                        subject: `New Task Assigned: ${dto.title}`,
                        htmlBody: `
              <h2>You have been assigned a new task</h2>
              <p><strong>Task:</strong> ${dto.title}</p>
              <p><strong>Description:</strong> ${dto.description || 'No description provided'}</p>
              <p><strong>Priority:</strong> ${dto.priority}</p>
              <p>Please log in to the EDC system to view and complete this task.</p>
            `,
                        textBody: `New task assigned: ${dto.title}. Please log in to view details.`,
                        priority: dto.priority === 'critical' ? 1 : dto.priority === 'high' ? 2 : 5,
                        studyId: dto.studyId,
                        entityType: 'workflow',
                        entityId: workflowId
                    });
                }
            }
            catch (notifyError) {
                logger_1.logger.warn('Failed to send notification', { error: notifyError.message });
            }
        }
        logger_1.logger.info('Workflow created successfully', { workflowId });
        return {
            success: true,
            data: {
                id: workflowId,
                title: dto.title,
                type: dto.type,
                status: 'pending',
                assignedTo: assigneeUsername
            },
            message: 'Workflow created successfully'
        };
    }
    catch (error) {
        await client.query('ROLLBACK');
        logger_1.logger.error('Error creating workflow', { error: error.message });
        throw error;
    }
    finally {
        client.release();
    }
}
/**
 * Update workflow status
 */
async function updateWorkflowStatus(workflowId, status, userId) {
    logger_1.logger.info('Updating workflow status', { workflowId, status, userId });
    try {
        const resolutionId = STATUS_TO_RESOLUTION[status] || 1;
        await database_1.pool.query(`UPDATE discrepancy_note 
       SET resolution_status_id = $1, date_updated = NOW() 
       WHERE discrepancy_note_id = $2`, [resolutionId, workflowId]);
        // Audit log
        await database_1.pool.query(`
      INSERT INTO audit_log_event (
        audit_date, audit_table, user_id, entity_id, entity_name, 
        audit_log_event_type_id, new_value
      )
      VALUES (NOW(), 'discrepancy_note', $1, $2, 'Status Updated',
        (SELECT audit_log_event_type_id FROM audit_log_event_type WHERE name = 'Entity Updated' LIMIT 1),
        $3)
    `, [userId, workflowId, status]);
        return { success: true, message: 'Status updated successfully' };
    }
    catch (error) {
        logger_1.logger.error('Error updating workflow status', { error: error.message });
        throw error;
    }
}
/**
 * Complete a workflow
 */
async function completeWorkflow(workflowId, userId, signature) {
    logger_1.logger.info('Completing workflow', { workflowId, userId });
    return updateWorkflowStatus(workflowId, 'completed', userId);
}
/**
 * Approve a workflow
 */
async function approveWorkflow(workflowId, userId, reason) {
    logger_1.logger.info('Approving workflow', { workflowId, userId, reason });
    try {
        await database_1.pool.query(`UPDATE discrepancy_note 
       SET resolution_status_id = 4, 
           detailed_notes = detailed_notes || $1, 
           date_updated = NOW() 
       WHERE discrepancy_note_id = $2`, [`\n\n[APPROVED by user ${userId}]: ${reason}`, workflowId]);
        return { success: true, message: 'Workflow approved successfully' };
    }
    catch (error) {
        logger_1.logger.error('Error approving workflow', { error: error.message });
        throw error;
    }
}
/**
 * Reject a workflow
 */
async function rejectWorkflow(workflowId, userId, reason) {
    logger_1.logger.info('Rejecting workflow', { workflowId, userId, reason });
    try {
        await database_1.pool.query(`UPDATE discrepancy_note 
       SET resolution_status_id = 5, 
           detailed_notes = detailed_notes || $1, 
           date_updated = NOW() 
       WHERE discrepancy_note_id = $2`, [`\n\n[REJECTED by user ${userId}]: ${reason}`, workflowId]);
        return { success: true, message: 'Workflow rejected' };
    }
    catch (error) {
        logger_1.logger.error('Error rejecting workflow', { error: error.message });
        throw error;
    }
}
/**
 * Handoff workflow to another user
 */
async function handoffWorkflow(workflowId, toUserId, reason, currentUserId) {
    logger_1.logger.info('Handing off workflow', { workflowId, toUserId, reason });
    try {
        const userResult = await database_1.pool.query('SELECT user_id FROM user_account WHERE user_name = $1', [toUserId]);
        if (userResult.rows.length === 0) {
            return { success: false, message: 'Target user not found' };
        }
        const newAssignedUserId = userResult.rows[0].user_id;
        await database_1.pool.query(`UPDATE discrepancy_note 
       SET assigned_user_id = $1, 
           detailed_notes = detailed_notes || $2, 
           date_updated = NOW() 
       WHERE discrepancy_note_id = $3`, [newAssignedUserId, `\n\n[HANDOFF]: ${reason}`, workflowId]);
        return { success: true, message: 'Workflow handed off successfully' };
    }
    catch (error) {
        logger_1.logger.error('Error handing off workflow', { error: error.message });
        throw error;
    }
}
// ============ AUTO-TRIGGER FUNCTIONS ============
// These functions are called by other services to auto-create workflows
/**
 * Trigger: Form submitted - creates SDV required workflow
 */
async function triggerFormSubmittedWorkflow(eventCrfId, studyId, subjectId, formName, submittedByUserId) {
    logger_1.logger.info('Auto-triggering form submitted workflow', { eventCrfId, formName });
    try {
        // Get study monitors who should receive SDV tasks
        const monitorsResult = await database_1.pool.query(`
      SELECT DISTINCT ua.user_name
      FROM study_user_role sur
      JOIN user_account ua ON sur.owner_id = ua.user_id
      WHERE sur.study_id = $1 
      AND sur.role_id IN (6, 7)  -- Monitor roles
      AND sur.status_id = 1
      LIMIT 1
    `, [studyId]);
        const assignee = monitorsResult.rows[0]?.user_name || 'root';
        await createWorkflow({
            title: `SDV Required: ${formName}`,
            description: `Source data verification required for form "${formName}"`,
            type: 'sdv_required',
            priority: 'medium',
            assignedTo: [assignee],
            dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
            studyId,
            entityType: 'event_crf',
            entityId: subjectId,
            eventCrfId,
            requiresApproval: false,
            autoGenerated: true,
            sourceEvent: 'form_submitted'
        }, submittedByUserId, 'system');
    }
    catch (error) {
        logger_1.logger.error('Error triggering form submitted workflow', { error: error.message });
    }
}
/**
 * Trigger: Visit completed - creates visit review workflow
 */
async function triggerVisitCompletedWorkflow(studyEventId, studyId, subjectId, visitName, completedByUserId) {
    logger_1.logger.info('Auto-triggering visit completed workflow', { studyEventId, visitName });
    try {
        await createWorkflow({
            title: `Visit Review: ${visitName}`,
            description: `Review completed visit "${visitName}"`,
            type: 'visit_completion',
            priority: 'medium',
            assignedTo: ['root'], // Assign to coordinator
            dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days
            studyId,
            entityType: 'subject',
            entityId: subjectId,
            autoGenerated: true,
            sourceEvent: 'visit_completed'
        }, completedByUserId, 'system');
    }
    catch (error) {
        logger_1.logger.error('Error triggering visit completed workflow', { error: error.message });
    }
}
/**
 * Trigger: Subject enrolled - creates enrollment verification workflow
 */
async function triggerSubjectEnrolledWorkflow(subjectId, studyId, subjectLabel, enrolledByUserId) {
    logger_1.logger.info('Auto-triggering subject enrolled workflow', { subjectId, subjectLabel });
    try {
        await createWorkflow({
            title: `Enrollment Verification: ${subjectLabel}`,
            description: `Verify enrollment for subject "${subjectLabel}"`,
            type: 'patient_enrollment',
            priority: 'high',
            assignedTo: ['root'], // Assign to coordinator
            dueDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000), // 1 day
            studyId,
            entityType: 'subject',
            entityId: subjectId,
            requiresApproval: true,
            autoGenerated: true,
            sourceEvent: 'subject_enrolled'
        }, enrolledByUserId, 'system');
    }
    catch (error) {
        logger_1.logger.error('Error triggering subject enrolled workflow', { error: error.message });
    }
}
/**
 * Trigger: SDV completed - closes related workflows
 */
async function triggerSDVCompletedWorkflow(eventCrfId, verifiedByUserId) {
    logger_1.logger.info('Auto-completing SDV workflows', { eventCrfId });
    try {
        // Find and close any SDV workflows for this event_crf
        const result = await database_1.pool.query(`
      SELECT dn.discrepancy_note_id
      FROM discrepancy_note dn
      LEFT JOIN dn_event_crf_map decm ON dn.discrepancy_note_id = decm.discrepancy_note_id
      WHERE decm.event_crf_id = $1
      AND dn.detailed_notes LIKE '%TYPE:sdv_required%'
      AND dn.resolution_status_id IN (1, 2)
    `, [eventCrfId]);
        for (const row of result.rows) {
            await completeWorkflow(row.discrepancy_note_id.toString(), verifiedByUserId);
        }
    }
    catch (error) {
        logger_1.logger.error('Error completing SDV workflows', { error: error.message });
    }
}
/**
 * Trigger: E-Signature applied - closes signature workflows
 */
async function triggerSignatureAppliedWorkflow(eventCrfId, signedByUserId) {
    logger_1.logger.info('Auto-completing signature workflows', { eventCrfId });
    try {
        const result = await database_1.pool.query(`
      SELECT dn.discrepancy_note_id
      FROM discrepancy_note dn
      LEFT JOIN dn_event_crf_map decm ON dn.discrepancy_note_id = decm.discrepancy_note_id
      WHERE decm.event_crf_id = $1
      AND dn.detailed_notes LIKE '%TYPE:signature_required%'
      AND dn.resolution_status_id IN (1, 2)
    `, [eventCrfId]);
        for (const row of result.rows) {
            await completeWorkflow(row.discrepancy_note_id.toString(), signedByUserId);
        }
    }
    catch (error) {
        logger_1.logger.error('Error completing signature workflows', { error: error.message });
    }
}
// ============ HELPER FUNCTIONS ============
function mapRowToWorkflow(row) {
    const createdAt = new Date(row.created_at);
    const dueDate = row.due_date ? new Date(row.due_date) : new Date(createdAt.getTime() + 7 * 24 * 60 * 60 * 1000);
    const now = new Date();
    // Determine status
    let status = RESOLUTION_TO_STATUS[row.resolution_status] || 'pending';
    if (status !== 'completed' && status !== 'cancelled' && dueDate < now) {
        status = 'overdue';
    }
    // Determine type
    let type = 'custom';
    if (row.workflow_type) {
        type = row.workflow_type;
    }
    else if (row.dn_type) {
        type = DN_TYPE_TO_WORKFLOW[row.dn_type] || 'custom';
    }
    // Calculate priority
    let priority = row.priority || 'medium';
    if (status === 'overdue') {
        priority = 'critical';
    }
    else if (dueDate) {
        const daysUntilDue = Math.ceil((dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
        if (daysUntilDue <= 1)
            priority = 'high';
        else if (daysUntilDue <= 3)
            priority = 'medium';
        else
            priority = 'low';
    }
    // Clean description (remove metadata)
    let description = row.description || '';
    const metadataIdx = description.indexOf('---WORKFLOW_METADATA---');
    if (metadataIdx > -1) {
        description = description.substring(0, metadataIdx).trim();
    }
    return {
        id: row.id?.toString() || '',
        title: row.title || 'Untitled Task',
        description,
        type,
        status,
        priority,
        assignedTo: row.assigned_to ? [row.assigned_to] : [],
        assignedToName: row.assigned_to_name || 'Unassigned',
        currentOwner: row.assigned_to || row.created_by,
        createdBy: row.created_by,
        createdAt,
        updatedAt: row.updated_at ? new Date(row.updated_at) : undefined,
        dueDate,
        studyId: row.study_id,
        studyName: row.study_name,
        subjectId: row.subject_id,
        subjectLabel: row.subject_label,
        relatedEntity: row.subject_label ? {
            type: 'subject',
            id: row.subject_label,
            name: row.subject_label
        } : undefined,
        requiresApproval: row.requires_approval || false,
        requiresSignature: row.requires_signature || false,
        requiredActions: [],
        completedActions: [],
        auditTrail: []
    };
}
exports.default = {
    getAllWorkflows,
    getUserWorkflows,
    getUserTaskSummary,
    createWorkflow,
    updateWorkflowStatus,
    completeWorkflow,
    approveWorkflow,
    rejectWorkflow,
    handoffWorkflow,
    triggerFormSubmittedWorkflow,
    triggerVisitCompletedWorkflow,
    triggerSubjectEnrolledWorkflow,
    triggerSDVCompletedWorkflow,
    triggerSignatureAppliedWorkflow
};
//# sourceMappingURL=workflow.service.js.map