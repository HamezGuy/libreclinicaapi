/**
 * Subject Transfer Service
 *
 * Handles subject transfers between sites within a study.
 * Includes approval workflow, audit logging, and notification triggers.
 *
 * 21 CFR Part 11 Compliance:
 * - Full audit trail of all transfer actions
 * - Electronic signatures for approvals
 * - Atomic transactions for data integrity
 */
export interface TransferRequest {
    studySubjectId: number;
    destinationSiteId: number;
    reasonForTransfer: string;
    notes?: string;
    initiatedBy: number;
    requiresApprovals?: boolean;
}
export interface TransferApproval {
    transferId: number;
    approvalType: 'source' | 'destination';
    approvedBy: number;
    password: string;
}
export interface TransferCancellation {
    transferId: number;
    cancelledBy: number;
    cancelReason: string;
}
export interface Transfer {
    transferId: number;
    studySubjectId: number;
    studyId: number;
    subjectLabel: string;
    sourceSiteId: number;
    sourceSiteName: string;
    destinationSiteId: number;
    destinationSiteName: string;
    reasonForTransfer: string;
    transferStatus: 'pending' | 'approved' | 'completed' | 'cancelled';
    requiresApprovals: boolean;
    initiatedBy: number;
    initiatedByName: string;
    initiatedAt: Date;
    sourceApprovedBy?: number;
    sourceApprovedByName?: string;
    sourceApprovedAt?: Date;
    destinationApprovedBy?: number;
    destinationApprovedByName?: string;
    destinationApprovedAt?: Date;
    completedBy?: number;
    completedByName?: string;
    completedAt?: Date;
    cancelledBy?: number;
    cancelledByName?: string;
    cancelledAt?: Date;
    cancelReason?: string;
    notes?: string;
}
/**
 * Initiate a subject transfer
 */
export declare function initiateTransfer(request: TransferRequest): Promise<Transfer>;
/**
 * Approve a transfer (source or destination site)
 */
export declare function approveTransfer(approval: TransferApproval): Promise<Transfer>;
/**
 * Complete a transfer (move subject to new site)
 */
export declare function completeTransfer(transferId: number, completedBy: number): Promise<Transfer>;
/**
 * Cancel a pending transfer
 */
export declare function cancelTransfer(cancellation: TransferCancellation): Promise<Transfer>;
/**
 * Get transfer details by ID
 */
export declare function getTransferDetails(transferId: number): Promise<Transfer>;
/**
 * Get transfer history for a subject
 */
export declare function getTransferHistory(studySubjectId: number): Promise<Transfer[]>;
/**
 * Get pending transfers for a site
 */
export declare function getPendingTransfers(siteId: number): Promise<Transfer[]>;
/**
 * Check if subject has a pending transfer
 */
export declare function hasPendingTransfer(studySubjectId: number): Promise<boolean>;
/**
 * Get available destination sites for transfer
 */
export declare function getAvailableSites(studySubjectId: number, userId: number): Promise<Array<{
    siteId: number;
    siteName: string;
}>>;
declare const _default: {
    initiateTransfer: typeof initiateTransfer;
    approveTransfer: typeof approveTransfer;
    completeTransfer: typeof completeTransfer;
    cancelTransfer: typeof cancelTransfer;
    getTransferDetails: typeof getTransferDetails;
    getTransferHistory: typeof getTransferHistory;
    getPendingTransfers: typeof getPendingTransfers;
    hasPendingTransfer: typeof hasPendingTransfer;
    getAvailableSites: typeof getAvailableSites;
};
export default _default;
//# sourceMappingURL=transfer.service.d.ts.map