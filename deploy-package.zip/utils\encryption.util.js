"use strict";
/**
 * Data Encryption Utility
 *
 * 21 CFR Part 11 §11.10(a) - Data-at-Rest Encryption
 *
 * Provides field-level encryption for sensitive data using AES-256-GCM
 * This supplements volume-level encryption for defense-in-depth
 *
 * Features:
 * - AES-256-GCM authenticated encryption
 * - Unique IV per encryption operation
 * - Key derivation from master secret
 * - PostgreSQL pgcrypto compatibility layer
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SENSITIVE_FIELDS = void 0;
exports.encryptField = encryptField;
exports.decryptField = decryptField;
exports.isEncrypted = isEncrypted;
exports.encryptObjectFields = encryptObjectFields;
exports.decryptObjectFields = decryptObjectFields;
exports.generateMasterKey = generateMasterKey;
exports.generateSalt = generateSalt;
exports.hashForComparison = hashForComparison;
exports.getPgCryptoEncryptSQL = getPgCryptoEncryptSQL;
exports.getPgCryptoDecryptSQL = getPgCryptoDecryptSQL;
const crypto_1 = __importDefault(require("crypto"));
const environment_1 = require("../config/environment");
const logger_1 = require("../config/logger");
// Encryption algorithm - AES-256-GCM provides authenticated encryption
const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 16; // 128 bits for GCM
const AUTH_TAG_LENGTH = 16; // 128 bits
const SALT_LENGTH = 32;
/**
 * Get or derive encryption key from environment
 * Uses PBKDF2 for key derivation from master secret
 */
function getEncryptionKey() {
    const masterSecret = environment_1.config.encryption?.masterKey || environment_1.config.jwt.secret;
    if (masterSecret === 'change-me-in-production') {
        logger_1.logger.warn('Using default encryption key - CHANGE IN PRODUCTION!');
    }
    // Derive a proper 256-bit key using PBKDF2
    // Salt is static per deployment (stored in config)
    const salt = environment_1.config.encryption?.salt || 'libreclinica-default-salt';
    return crypto_1.default.pbkdf2Sync(masterSecret, salt, 100000, 32, 'sha256');
}
/**
 * Encrypt sensitive data using AES-256-GCM
 *
 * @param plaintext - The data to encrypt
 * @returns Base64-encoded encrypted data with IV and auth tag
 */
function encryptField(plaintext) {
    if (!plaintext)
        return plaintext;
    try {
        const key = getEncryptionKey();
        const iv = crypto_1.default.randomBytes(IV_LENGTH);
        const cipher = crypto_1.default.createCipheriv(ALGORITHM, key, iv);
        let encrypted = cipher.update(plaintext, 'utf8', 'hex');
        encrypted += cipher.final('hex');
        const authTag = cipher.getAuthTag();
        // Format: iv:authTag:ciphertext (all hex encoded)
        const result = `ENC:${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted}`;
        return result;
    }
    catch (error) {
        logger_1.logger.error('Encryption failed', { error: error.message });
        throw new Error('Data encryption failed');
    }
}
/**
 * Decrypt data encrypted with encryptField
 *
 * @param encryptedData - The encrypted data string
 * @returns Decrypted plaintext
 */
function decryptField(encryptedData) {
    if (!encryptedData)
        return encryptedData;
    // Check if data is encrypted (has our prefix)
    if (!encryptedData.startsWith('ENC:')) {
        // Return as-is if not encrypted (for backward compatibility)
        return encryptedData;
    }
    try {
        const key = getEncryptionKey();
        const parts = encryptedData.split(':');
        if (parts.length !== 4) {
            throw new Error('Invalid encrypted data format');
        }
        const iv = Buffer.from(parts[1], 'hex');
        const authTag = Buffer.from(parts[2], 'hex');
        const ciphertext = parts[3];
        const decipher = crypto_1.default.createDecipheriv(ALGORITHM, key, iv);
        decipher.setAuthTag(authTag);
        let decrypted = decipher.update(ciphertext, 'hex', 'utf8');
        decrypted += decipher.final('utf8');
        return decrypted;
    }
    catch (error) {
        logger_1.logger.error('Decryption failed', { error: error.message });
        throw new Error('Data decryption failed - data may be corrupted or key mismatch');
    }
}
/**
 * Check if a field value is encrypted
 */
function isEncrypted(value) {
    return value?.startsWith('ENC:') || false;
}
/**
 * Encrypt an object's specified fields
 *
 * @param obj - Object to encrypt fields in
 * @param fieldsToEncrypt - Array of field names to encrypt
 * @returns Object with specified fields encrypted
 */
function encryptObjectFields(obj, fieldsToEncrypt) {
    const result = { ...obj };
    for (const field of fieldsToEncrypt) {
        const value = result[field];
        if (typeof value === 'string' && value && !isEncrypted(value)) {
            result[field] = encryptField(value);
        }
    }
    return result;
}
/**
 * Decrypt an object's specified fields
 *
 * @param obj - Object to decrypt fields in
 * @param fieldsToDecrypt - Array of field names to decrypt
 * @returns Object with specified fields decrypted
 */
function decryptObjectFields(obj, fieldsToDecrypt) {
    const result = { ...obj };
    for (const field of fieldsToDecrypt) {
        const value = result[field];
        if (typeof value === 'string' && isEncrypted(value)) {
            result[field] = decryptField(value);
        }
    }
    return result;
}
/**
 * Generate a secure random encryption key
 * Use this to generate a new master key for production
 */
function generateMasterKey() {
    return crypto_1.default.randomBytes(32).toString('base64');
}
/**
 * Generate a secure random salt
 */
function generateSalt() {
    return crypto_1.default.randomBytes(SALT_LENGTH).toString('base64');
}
/**
 * Hash sensitive data for comparison without decryption
 * Uses SHA-256 with application salt
 */
function hashForComparison(data) {
    const salt = environment_1.config.encryption?.salt || 'libreclinica-default-salt';
    return crypto_1.default.createHmac('sha256', salt).update(data).digest('hex');
}
/**
 * PostgreSQL pgcrypto compatibility - generate SQL for encryption
 * Use this when you need to encrypt data directly in SQL queries
 *
 * NOTE: Requires pgcrypto extension to be installed:
 * CREATE EXTENSION IF NOT EXISTS pgcrypto;
 */
function getPgCryptoEncryptSQL(columnAlias, keyParam = '$key') {
    return `encode(pgp_sym_encrypt(${columnAlias}::text, ${keyParam}), 'base64')`;
}
/**
 * PostgreSQL pgcrypto compatibility - generate SQL for decryption
 */
function getPgCryptoDecryptSQL(columnAlias, keyParam = '$key') {
    return `pgp_sym_decrypt(decode(${columnAlias}, 'base64'), ${keyParam})`;
}
/**
 * Sensitive field definitions for different entity types
 * These fields should be encrypted at rest
 */
exports.SENSITIVE_FIELDS = {
    // Patient/Subject data (PHI)
    subject: [
        'date_of_birth',
        'unique_identifier',
        'secondary_label'
    ],
    // User data
    user: [
        'email',
        'phone',
        'first_name',
        'last_name'
    ],
    // Form data (may contain PHI)
    itemData: [
        'value' // All form field values encrypted
    ],
    // Adverse events
    adverseEvent: [
        'description',
        'notes'
    ],
    // Consent data
    consent: [
        'signature_data',
        'ip_address'
    ]
};
exports.default = {
    encryptField,
    decryptField,
    isEncrypted,
    encryptObjectFields,
    decryptObjectFields,
    generateMasterKey,
    generateSalt,
    hashForComparison,
    getPgCryptoEncryptSQL,
    getPgCryptoDecryptSQL,
    SENSITIVE_FIELDS: exports.SENSITIVE_FIELDS
};
//# sourceMappingURL=encryption.util.js.map