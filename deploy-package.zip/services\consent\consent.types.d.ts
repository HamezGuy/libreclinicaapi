/**
 * eConsent Types
 *
 * Type definitions for the electronic consent module.
 */
export interface ConsentDocument {
    documentId: number;
    studyId: number;
    name: string;
    description?: string;
    documentType: 'main' | 'assent' | 'lar' | 'optional' | 'addendum';
    languageCode: string;
    status: 'draft' | 'active' | 'retired';
    requiresWitness: boolean;
    requiresLAR: boolean;
    ageOfMajority: number;
    minReadingTime: number;
    ownerId?: number;
    ownerName?: string;
    dateCreated: Date;
    dateUpdated: Date;
    activeVersion?: ConsentVersion;
}
export interface ConsentDocumentCreate {
    studyId: number;
    name: string;
    description?: string;
    documentType?: 'main' | 'assent' | 'lar' | 'optional' | 'addendum';
    languageCode?: string;
    requiresWitness?: boolean;
    requiresLAR?: boolean;
    ageOfMajority?: number;
    minReadingTime?: number;
    createdBy: number;
}
export interface ConsentVersion {
    versionId: number;
    documentId: number;
    versionNumber: string;
    versionName?: string;
    content: ConsentContent;
    pdfTemplate?: string;
    effectiveDate: Date;
    expirationDate?: Date;
    irbApprovalDate?: Date;
    irbApprovalNumber?: string;
    changeSummary?: string;
    status: 'draft' | 'approved' | 'active' | 'superseded';
    approvedBy?: number;
    approvedByName?: string;
    approvedAt?: Date;
    createdBy?: number;
    dateCreated: Date;
    dateUpdated: Date;
}
export interface ConsentVersionCreate {
    documentId: number;
    versionNumber: string;
    versionName?: string;
    content: ConsentContent;
    pdfTemplate?: string;
    effectiveDate: Date;
    expirationDate?: Date;
    irbApprovalDate?: Date;
    irbApprovalNumber?: string;
    changeSummary?: string;
    createdBy: number;
}
export interface ConsentContent {
    pages: ConsentPage[];
    acknowledgments: ConsentAcknowledgment[];
    signatureRequirements: SignatureRequirement[];
}
export interface ConsentPage {
    pageNumber: number;
    title: string;
    content: string;
    requiresView: boolean;
    hasVideo?: boolean;
    videoUrl?: string;
    estimatedReadingTime?: number;
}
export interface ConsentAcknowledgment {
    id: string;
    text: string;
    required: boolean;
    order: number;
}
export interface SignatureRequirement {
    type: 'subject' | 'witness' | 'lar' | 'investigator';
    label: string;
    required: boolean;
    order: number;
}
export interface SubjectConsent {
    consentId: number;
    studySubjectId: number;
    subjectLabel?: string;
    versionId: number;
    versionNumber?: string;
    documentName?: string;
    consentType: 'subject' | 'witness' | 'lar' | 'reconsent';
    consentStatus: 'pending' | 'in_progress' | 'consented' | 'declined' | 'withdrawn' | 'expired';
    subjectName?: string;
    subjectSignatureData?: any;
    subjectSignedAt?: Date;
    subjectIpAddress?: string;
    witnessName?: string;
    witnessRelationship?: string;
    witnessSignatureData?: any;
    witnessSignedAt?: Date;
    larName?: string;
    larRelationship?: string;
    larSignatureData?: any;
    larSignedAt?: Date;
    larReason?: string;
    presentedAt?: Date;
    timeSpentReading: number;
    pagesViewed?: any;
    acknowledgementsChecked?: any;
    questionsAsked?: string;
    copyEmailedTo?: string;
    copyEmailedAt?: Date;
    pdfFilePath?: string;
    withdrawnAt?: Date;
    withdrawalReason?: string;
    withdrawnByName?: string;
    consentedBy?: number;
    consentedByName?: string;
    dateCreated: Date;
    dateUpdated: Date;
}
export interface SubjectConsentCreate {
    studySubjectId: number;
    versionId: number;
    consentType?: 'subject' | 'witness' | 'lar' | 'reconsent';
    subjectName: string;
    subjectSignatureData: any;
    subjectIpAddress?: string;
    subjectUserAgent?: string;
    witnessName?: string;
    witnessRelationship?: string;
    witnessSignatureData?: any;
    larName?: string;
    larRelationship?: string;
    larSignatureData?: any;
    larReason?: string;
    timeSpentReading: number;
    pagesViewed: any;
    acknowledgementsChecked: any;
    questionsAsked?: string;
    consentedBy: number;
}
export interface ReconsentRequest {
    requestId: number;
    versionId: number;
    versionNumber?: string;
    studySubjectId: number;
    subjectLabel?: string;
    previousConsentId?: number;
    previousVersionNumber?: string;
    reason: string;
    requestedAt: Date;
    requestedBy?: number;
    requestedByName?: string;
    dueDate?: Date;
    completedConsentId?: number;
    status: 'pending' | 'completed' | 'declined' | 'waived';
    waivedBy?: number;
    waivedReason?: string;
    dateUpdated: Date;
}
export interface ReconsentRequestCreate {
    versionId: number;
    studySubjectId: number;
    reason: string;
    dueDate?: Date;
    requestedBy: number;
}
export interface ConsentDashboard {
    stats: {
        totalSubjects: number;
        consented: number;
        pending: number;
        declined: number;
        withdrawn: number;
        pendingReconsent: number;
    };
    pendingConsents: Array<{
        studySubjectId: number;
        subjectLabel: string;
        siteName: string;
        enrolledAt: Date;
        daysWithoutConsent: number;
    }>;
    pendingReconsents: ReconsentRequest[];
    recentConsents: SubjectConsent[];
    documentVersions: Array<{
        documentId: number;
        documentName: string;
        activeVersion: string;
        subjectsConsented: number;
    }>;
}
export interface ConsentSession {
    sessionId: string;
    studySubjectId: number;
    versionId: number;
    startedAt: Date;
    presentedBy: number;
    pagesViewed: number[];
    currentPage: number;
    timePerPage: Record<number, number>;
    totalTimeSpent: number;
    acknowledgementsChecked: string[];
}
//# sourceMappingURL=consent.types.d.ts.map