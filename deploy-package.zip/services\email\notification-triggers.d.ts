/**
 * Notification Triggers
 *
 * Handles automatic email notifications triggered by system events.
 * Checks user preferences before sending notifications.
 */
/**
 * Trigger: New query opened
 */
export declare function triggerQueryOpened(queryId: number, studyId: number, siteId: number, subjectId: number, createdByUserId: number, assignedToUserId: number, queryText: string): Promise<void>;
/**
 * Trigger: Query response received
 */
export declare function triggerQueryResponse(queryId: number, studyId: number, respondedByUserId: number, originalCreatorUserId: number, responseText: string): Promise<void>;
/**
 * Trigger: Query closed
 */
export declare function triggerQueryClosed(queryId: number, studyId: number, closedByUserId: number, notifyUserIds: number[]): Promise<void>;
/**
 * Trigger: Form requires signature
 */
export declare function triggerSignatureRequired(eventCrfId: number, studyId: number, subjectId: number, formName: string, signerUserId: number): Promise<void>;
/**
 * Trigger: Form submitted
 */
export declare function triggerFormSubmitted(eventCrfId: number, studyId: number, siteId: number, subjectId: number, formName: string, submittedByUserId: number): Promise<void>;
/**
 * Trigger: SDV status changed
 */
export declare function triggerSDVStatusChange(eventCrfId: number, studyId: number, subjectId: number, formName: string, newStatus: 'verified' | 'not_verified', verifiedByUserId: number, dataEntryUserId: number): Promise<void>;
/**
 * Trigger: Subject enrolled
 */
export declare function triggerSubjectEnrolled(subjectId: number, studyId: number, siteId: number, subjectLabel: string, enrolledByUserId: number): Promise<void>;
/**
 * Trigger: Visit overdue
 */
export declare function triggerVisitOverdue(studyEventId: number, studyId: number, siteId: number, subjectId: number, visitName: string, daysOverdue: number): Promise<void>;
/**
 * Trigger: Protocol deviation detected
 */
export declare function triggerProtocolDeviation(studyId: number, siteId: number, subjectId: number, deviationType: string, description: string, detectedByUserId: number): Promise<void>;
/**
 * Trigger: Study lock/unlock
 */
export declare function triggerStudyLockChange(studyId: number, isLocked: boolean, changedByUserId: number): Promise<void>;
/**
 * Trigger: User role assigned
 */
export declare function triggerRoleAssigned(userId: number, studyId: number, roleName: string, assignedByUserId: number): Promise<void>;
declare const _default: {
    triggerQueryOpened: typeof triggerQueryOpened;
    triggerQueryResponse: typeof triggerQueryResponse;
    triggerQueryClosed: typeof triggerQueryClosed;
    triggerSignatureRequired: typeof triggerSignatureRequired;
    triggerFormSubmitted: typeof triggerFormSubmitted;
    triggerSDVStatusChange: typeof triggerSDVStatusChange;
    triggerSubjectEnrolled: typeof triggerSubjectEnrolled;
    triggerVisitOverdue: typeof triggerVisitOverdue;
    triggerProtocolDeviation: typeof triggerProtocolDeviation;
    triggerStudyLockChange: typeof triggerStudyLockChange;
    triggerRoleAssigned: typeof triggerRoleAssigned;
};
export default _default;
//# sourceMappingURL=notification-triggers.d.ts.map