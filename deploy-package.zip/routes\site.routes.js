"use strict";
/**
 * Site/Location Routes
 *
 * API endpoints for site management including:
 * - CRUD operations for sites
 * - Patient-to-site assignments
 * - Site staff management
 * - Site statistics
 *
 * 21 CFR Part 11 Compliance:
 * - All site modifications require electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const controller = __importStar(require("../controllers/site.controller"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const authorization_middleware_1 = require("../middleware/authorization.middleware");
const part11_middleware_1 = require("../middleware/part11.middleware");
const router = express_1.default.Router();
// All routes require authentication
router.use(auth_middleware_1.authMiddleware);
// ============================================================================
// READ OPERATIONS - All authenticated users
// ============================================================================
// Get all sites for a study
router.get('/study/:studyId', controller.getSitesForStudy);
// Get site statistics for a study
router.get('/study/:studyId/stats', controller.getSiteStatistics);
// Get a single site by ID
router.get('/:id', controller.getSiteById);
// Get patients for a site
router.get('/:id/patients', controller.getSitePatients);
// Get staff for a site
router.get('/:id/staff', controller.getSiteStaff);
// ============================================================================
// WRITE OPERATIONS - Require admin/coordinator role + electronic signature
// ============================================================================
// Create a new site
router.post('/', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.SITE_CREATE || 'Site Creation'), controller.createSite);
// Update a site
router.put('/:id', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.SITE_UPDATE || 'Site Update'), controller.updateSite);
// Delete a site
router.delete('/:id', (0, authorization_middleware_1.requireRole)('admin'), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.SITE_DELETE || 'Site Deletion'), controller.deleteSite);
// Transfer a patient to a different site
router.post('/transfer', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.SUBJECT_TRANSFER || 'Patient Transfer'), controller.transferPatient);
// Assign staff to a site
router.post('/:id/staff', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.STAFF_ASSIGN || 'Staff Assignment'), controller.assignStaff);
// Remove staff from a site
router.delete('/:id/staff/:username', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.STAFF_REMOVE || 'Staff Removal'), controller.removeStaff);
exports.default = router;
//# sourceMappingURL=site.routes.js.map