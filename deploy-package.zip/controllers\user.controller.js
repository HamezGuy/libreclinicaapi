"use strict";
/**
 * User Controller
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUserRole = exports.assignToStudy = exports.getRoles = exports.remove = exports.update = exports.create = exports.get = exports.list = void 0;
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const userService = __importStar(require("../services/database/user.service"));
exports.list = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, role, enabled, page, limit } = req.query;
    const result = await userService.getUsers({
        studyId: studyId ? parseInt(studyId) : undefined,
        role: role,
        enabled: enabled !== undefined ? enabled === 'true' : undefined,
        page: parseInt(page) || 1,
        limit: parseInt(limit) || 20
    });
    res.json(result);
});
exports.get = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const result = await userService.getUserById(parseInt(id));
    if (!result) {
        res.status(404).json({ success: false, message: 'User not found' });
        return;
    }
    res.json({ success: true, data: result });
});
exports.create = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const creator = req.user;
    const result = await userService.createUser(req.body, creator.userId);
    res.status(result.success ? 201 : 400).json(result);
});
exports.update = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const updater = req.user;
    const { id } = req.params;
    const result = await userService.updateUser(parseInt(id), req.body, updater.userId);
    res.json(result);
});
exports.remove = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const deleter = req.user;
    const { id } = req.params;
    const result = await userService.deleteUser(parseInt(id), deleter.userId);
    res.json(result);
});
/**
 * Get available roles
 */
exports.getRoles = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const roles = userService.getAvailableRoles();
    res.json({
        success: true,
        data: roles,
        message: 'Available LibreClinica roles'
    });
});
/**
 * Assign user to study with role
 */
exports.assignToStudy = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const assigner = req.user;
    const { id } = req.params;
    const { studyId, roleName } = req.body;
    if (!studyId || !roleName) {
        res.status(400).json({
            success: false,
            message: 'studyId and roleName are required'
        });
        return;
    }
    const result = await userService.assignUserToStudy(parseInt(id), parseInt(studyId), roleName, assigner.userId);
    res.status(result.success ? 200 : 400).json(result);
});
/**
 * Get user's role for a specific study
 */
exports.getUserRole = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id, studyId } = req.params;
    const result = await userService.getUserStudyRole(parseInt(id), parseInt(studyId));
    if (!result) {
        res.status(404).json({
            success: false,
            message: 'User not assigned to this study'
        });
        return;
    }
    res.json({ success: true, data: result });
});
exports.default = { list: exports.list, get: exports.get, create: exports.create, update: exports.update, remove: exports.remove, getRoles: exports.getRoles, assignToStudy: exports.assignToStudy, getUserRole: exports.getUserRole };
//# sourceMappingURL=user.controller.js.map