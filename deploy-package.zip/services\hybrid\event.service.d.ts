/**
 * Study Event Service (Hybrid)
 *
 * Study Event (Phase) management combining SOAP and Database
 * - Use Database for reading events
 * - Use SOAP for scheduling events (GxP compliant)
 */
import { ApiResponse } from '../../types';
/**
 * Get all study events (phases) for a study
 */
export declare const getStudyEvents: (studyId: number) => Promise<any[]>;
/**
 * Get study event by ID
 */
export declare const getStudyEventById: (eventDefinitionId: number) => Promise<any>;
/**
 * Get subject events (patient's scheduled events)
 */
export declare const getSubjectEvents: (studySubjectId: number) => Promise<any[]>;
/**
 * Get CRFs for a study event definition (template level)
 */
export declare const getEventCRFs: (eventDefinitionId: number) => Promise<any[]>;
/**
 * Get patient's event_crfs for a specific study_event (instance level)
 * These are the editable copies of templates for this patient's phase
 */
export declare const getPatientEventCRFs: (studyEventId: number) => Promise<any[]>;
/**
 * Schedule subject event (via SOAP for GxP compliance, with direct SQL fallback)
 */
export declare const scheduleSubjectEvent: (data: {
    studySubjectId: number;
    studyEventDefinitionId: number;
    startDate?: string;
    endDate?: string;
    location?: string;
}, userId: number, username: string) => Promise<ApiResponse<any>>;
/**
 * Create study event definition
 */
export declare const createStudyEvent: (data: {
    studyId: number;
    name: string;
    description?: string;
    ordinal: number;
    type?: string;
    repeating?: boolean;
    category?: string;
}, userId: number) => Promise<{
    success: boolean;
    eventDefinitionId?: number;
    message?: string;
}>;
/**
 * Update study event definition
 */
export declare const updateStudyEvent: (eventDefinitionId: number, data: {
    name?: string;
    description?: string;
    ordinal?: number;
    type?: string;
    repeating?: boolean;
    category?: string;
}, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Delete study event definition (set status to removed)
 */
export declare const deleteStudyEvent: (eventDefinitionId: number, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Get all CRFs available to assign to an event (for a study)
 */
export declare const getAvailableCrfsForEvent: (studyId: number, eventDefinitionId: number) => Promise<any[]>;
/**
 * Assign a CRF (template) to a study event (phase)
 */
export declare const assignCrfToEvent: (data: {
    studyEventDefinitionId: number;
    crfId: number;
    crfVersionId?: number;
    required?: boolean;
    doubleEntry?: boolean;
    hideCrf?: boolean;
    ordinal?: number;
    electronicSignature?: boolean;
}, userId: number) => Promise<{
    success: boolean;
    eventDefinitionCrfId?: number;
    message?: string;
}>;
/**
 * Update CRF settings for an event
 */
export declare const updateEventCrf: (eventDefinitionCrfId: number, data: {
    required?: boolean;
    doubleEntry?: boolean;
    hideCrf?: boolean;
    ordinal?: number;
    defaultVersionId?: number;
    electronicSignature?: boolean;
}, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Remove CRF from event (soft delete)
 */
export declare const removeCrfFromEvent: (eventDefinitionCrfId: number, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Reorder CRFs within an event
 */
export declare const reorderEventCrfs: (studyEventDefinitionId: number, orderedCrfIds: number[], userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Bulk assign multiple CRFs to an event
 */
export declare const bulkAssignCrfsToEvent: (studyEventDefinitionId: number, crfAssignments: Array<{
    crfId: number;
    required?: boolean;
    ordinal?: number;
}>, userId: number) => Promise<{
    success: boolean;
    assignedCount?: number;
    message?: string;
}>;
declare const _default: {
    getStudyEvents: (studyId: number) => Promise<any[]>;
    getStudyEventById: (eventDefinitionId: number) => Promise<any>;
    getSubjectEvents: (studySubjectId: number) => Promise<any[]>;
    getEventCRFs: (eventDefinitionId: number) => Promise<any[]>;
    scheduleSubjectEvent: (data: {
        studySubjectId: number;
        studyEventDefinitionId: number;
        startDate?: string;
        endDate?: string;
        location?: string;
    }, userId: number, username: string) => Promise<ApiResponse<any>>;
    createStudyEvent: (data: {
        studyId: number;
        name: string;
        description?: string;
        ordinal: number;
        type?: string;
        repeating?: boolean;
        category?: string;
    }, userId: number) => Promise<{
        success: boolean;
        eventDefinitionId?: number;
        message?: string;
    }>;
    updateStudyEvent: (eventDefinitionId: number, data: {
        name?: string;
        description?: string;
        ordinal?: number;
        type?: string;
        repeating?: boolean;
        category?: string;
    }, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    deleteStudyEvent: (eventDefinitionId: number, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    getAvailableCrfsForEvent: (studyId: number, eventDefinitionId: number) => Promise<any[]>;
    assignCrfToEvent: (data: {
        studyEventDefinitionId: number;
        crfId: number;
        crfVersionId?: number;
        required?: boolean;
        doubleEntry?: boolean;
        hideCrf?: boolean;
        ordinal?: number;
        electronicSignature?: boolean;
    }, userId: number) => Promise<{
        success: boolean;
        eventDefinitionCrfId?: number;
        message?: string;
    }>;
    updateEventCrf: (eventDefinitionCrfId: number, data: {
        required?: boolean;
        doubleEntry?: boolean;
        hideCrf?: boolean;
        ordinal?: number;
        defaultVersionId?: number;
        electronicSignature?: boolean;
    }, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    removeCrfFromEvent: (eventDefinitionCrfId: number, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    reorderEventCrfs: (studyEventDefinitionId: number, orderedCrfIds: number[], userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    bulkAssignCrfsToEvent: (studyEventDefinitionId: number, crfAssignments: Array<{
        crfId: number;
        required?: boolean;
        ordinal?: number;
    }>, userId: number) => Promise<{
        success: boolean;
        assignedCount?: number;
        message?: string;
    }>;
};
export default _default;
//# sourceMappingURL=event.service.d.ts.map