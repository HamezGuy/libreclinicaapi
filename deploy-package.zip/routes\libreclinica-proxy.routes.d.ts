/**
 * LibreClinica Proxy Routes
 *
 * These routes proxy to LibreClinica's NATIVE REST APIs instead of duplicating functionality.
 * LibreClinica Core (port 8080) provides its own REST endpoints that we should use.
 *
 * Native LibreClinica REST endpoints:
 * - /rest/metadata/* - Study metadata in XML/JSON/HTML/PDF
 * - /rest/clinicaldata/* - Clinical data extraction
 * - /rest/openrosa/* - ODK-compatible form API
 * - /auth/api/v1/system/* - System status
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=libreclinica-proxy.routes.d.ts.map