/**
 * Error Handler Middleware
 *
 * Global error handling for the API
 * - Catches and formats all errors
 * - Prevents sensitive data exposure
 * - Provides user-friendly error messages
 * - Logs errors for debugging
 *
 * Compliance: 21 CFR Part 11 §11.10(c) - Protection of Records
 */
import { Request, Response, NextFunction } from 'express';
/**
 * Custom error class with additional properties
 */
export declare class ApiError extends Error {
    statusCode: number;
    isOperational: boolean;
    details?: any;
    constructor(statusCode: number, message: string, isOperational?: boolean, details?: any, stack?: string);
}
/**
 * Common API errors
 */
export declare class BadRequestError extends ApiError {
    constructor(message?: string, details?: any);
}
export declare class UnauthorizedError extends ApiError {
    constructor(message?: string);
}
export declare class ForbiddenError extends ApiError {
    constructor(message?: string);
}
export declare class NotFoundError extends ApiError {
    constructor(message?: string);
}
export declare class ConflictError extends ApiError {
    constructor(message?: string, details?: any);
}
export declare class ValidationError extends ApiError {
    constructor(message?: string, details?: any);
}
export declare class InternalServerError extends ApiError {
    constructor(message?: string);
}
export declare class ServiceUnavailableError extends ApiError {
    constructor(message?: string);
}
/**
 * Global error handler middleware
 * Must be the last middleware in the chain
 */
export declare const errorHandler: (err: Error | ApiError, req: Request, res: Response, next: NextFunction) => void;
/**
 * 404 handler for undefined routes
 */
export declare const notFoundHandler: (req: Request, res: Response, next: NextFunction) => void;
/**
 * Async handler wrapper
 * Catches errors in async route handlers
 */
export declare const asyncHandler: (fn: Function) => (req: Request, res: Response, next: NextFunction) => void;
export default errorHandler;
//# sourceMappingURL=errorHandler.middleware.d.ts.map