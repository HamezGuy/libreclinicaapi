/**
 * Validation Rules Controller
 *
 * Manages validation rules for CRFs/forms
 * 21 CFR Part 11 §11.10(h) - Device checks (validation rules)
 */
import { Request, Response, NextFunction } from 'express';
/**
 * Get validation rules for a CRF
 */
export declare const getRulesForCrf: (req: Request, res: Response, next: NextFunction) => Promise<void>;
/**
 * Get validation rules for a study (all CRFs)
 */
export declare const getRulesForStudy: (req: Request, res: Response, next: NextFunction) => Promise<void>;
/**
 * Get a single validation rule
 */
export declare const getRule: (req: Request, res: Response, next: NextFunction) => Promise<void>;
/**
 * Create a new validation rule
 */
export declare const createRule: (req: Request, res: Response, next: NextFunction) => Promise<void>;
/**
 * Update a validation rule
 */
export declare const updateRule: (req: Request, res: Response, next: NextFunction) => Promise<void>;
/**
 * Toggle validation rule active state
 */
export declare const toggleRule: (req: Request, res: Response, next: NextFunction) => Promise<void>;
/**
 * Delete a validation rule
 */
export declare const deleteRule: (req: Request, res: Response, next: NextFunction) => Promise<void>;
/**
 * Validate form data against rules
 *
 * Accepts options from query params OR request body:
 * - createQueries: If true, creates queries (discrepancy notes) for validation failures
 * - studyId: Required if createQueries is true
 * - subjectId: Optional, links query to subject
 * - eventCrfId: Optional, links query to event CRF
 *
 * Request body can contain:
 * - formData: The actual form data to validate (if separate from other fields)
 * - Or: form fields directly in the body
 */
export declare const validateData: (req: Request, res: Response, next: NextFunction) => Promise<void>;
/**
 * Test a single rule against test data
 */
export declare const testRule: (req: Request, res: Response, next: NextFunction) => Promise<void>;
declare const _default: {
    getRulesForCrf: (req: Request, res: Response, next: NextFunction) => Promise<void>;
    getRulesForStudy: (req: Request, res: Response, next: NextFunction) => Promise<void>;
    getRule: (req: Request, res: Response, next: NextFunction) => Promise<void>;
    createRule: (req: Request, res: Response, next: NextFunction) => Promise<void>;
    updateRule: (req: Request, res: Response, next: NextFunction) => Promise<void>;
    toggleRule: (req: Request, res: Response, next: NextFunction) => Promise<void>;
    deleteRule: (req: Request, res: Response, next: NextFunction) => Promise<void>;
    validateData: (req: Request, res: Response, next: NextFunction) => Promise<void>;
    testRule: (req: Request, res: Response, next: NextFunction) => Promise<void>;
};
export default _default;
//# sourceMappingURL=validation-rules.controller.d.ts.map