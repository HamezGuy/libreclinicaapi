/**
 * Rate Limiter Middleware
 *
 * Implements rate limiting to protect API from abuse
 * - General API rate limiting
 * - Stricter limits for authentication endpoints
 * - IP-based and user-based limiting
 *
 * Compliance: Security best practice, prevents brute force attacks
 */
/**
 * General API rate limiter
 * Applies to all API endpoints
 *
 * Default: 1000 requests per 15 minutes per IP (development: 10000)
 */
export declare const apiRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
/**
 * Authentication rate limiter for LOGIN only
 * Stricter limits for login endpoints to prevent brute force
 *
 * Default: 10 login attempts per 15 minutes per IP
 */
export declare const authRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
/**
 * Refresh token rate limiter
 * More generous limits for refresh tokens (legitimate app behavior)
 *
 * Default: 60 refresh attempts per 15 minutes per IP
 */
export declare const refreshRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
/**
 * Password reset rate limiter
 * Limit password reset attempts
 *
 * Default: 3 attempts per hour per IP
 */
export declare const passwordResetRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
/**
 * SOAP operation rate limiter
 * Limit write operations to LibreClinica
 * More generous for data entry workflows
 *
 * Default: 50 requests per 15 minutes per IP
 */
export declare const soapRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
/**
 * Report generation rate limiter
 * Limit resource-intensive report generation
 *
 * Default: 10 reports per hour per user
 */
export declare const reportRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
/**
 * Audit export rate limiter
 * Limit audit trail exports (resource intensive)
 *
 * Default: 5 exports per hour per user
 */
export declare const auditExportRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
/**
 * File upload rate limiter
 * Limit file upload operations
 *
 * Default: 20 uploads per hour per user
 */
export declare const uploadRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
/**
 * User creation rate limiter
 * Limit user account creation (admin only)
 *
 * Default: 10 users per hour per admin
 */
export declare const userCreationRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
/**
 * Export all rate limiters
 */
declare const _default: {
    apiRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
    authRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
    refreshRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
    passwordResetRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
    soapRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
    reportRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
    auditExportRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
    uploadRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
    userCreationRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
};
export default _default;
//# sourceMappingURL=rateLimiter.middleware.d.ts.map