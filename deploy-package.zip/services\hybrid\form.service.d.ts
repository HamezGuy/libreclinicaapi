/**
 * Form Service (Hybrid)
 *
 * Form data management combining SOAP and Database
 * - Use SOAP for saving form data (GxP compliant with validation)
 * - Use Database for reading form data (faster)
 *
 * 21 CFR Part 11 §11.10(e) - Audit Trail for document actions
 */
import { FormDataRequest, ApiResponse } from '../../types';
/**
 * Save form data via SOAP (GxP compliant)
 *
 * This function now applies validation rules before saving:
 * - Hard edits (severity: 'error') will BLOCK the save
 * - Soft edits (severity: 'warning') will be returned but allow save
 *
 * Supports both frontend and backend naming conventions:
 * - Frontend: studyId, subjectId, eventId, formId, data
 * - Backend: studyId, subjectId, studyEventDefinitionId, crfId, formData
 *
 * 21 CFR Part 11 §11.10(h) - Device checks to determine validity
 */
export declare const saveFormData: (request: FormDataRequest & {
    formId?: number;
    data?: Record<string, any>;
    eventId?: number;
}, userId: number, username: string) => Promise<ApiResponse<any>>;
/**
 * Get form data from database
 * Returns data along with lock status for UI to respect
 */
export declare const getFormData: (eventCrfId: number) => Promise<any>;
/**
 * Get form metadata with all field properties
 */
export declare const getFormMetadata: (crfId: number) => Promise<any>;
/**
 * Get form status
 */
export declare const getFormStatus: (eventCrfId: number) => Promise<any>;
/**
 * Validate form data (business rules)
 */
export declare const validateFormData: (formData: Record<string, any>) => {
    isValid: boolean;
    errors: string[];
};
/**
 * Get all CRFs (Form Templates) for a study
 */
export declare const getStudyForms: (studyId: number) => Promise<any[]>;
/**
 * Get all CRFs (templates) - includes drafts and published
 * Status IDs: 1=available, 2=unavailable/locked, 5=removed
 */
export declare const getAllForms: () => Promise<any[]>;
/**
 * Get CRF by ID
 */
export declare const getFormById: (crfId: number) => Promise<any>;
/**
 * Validation rule interface
 */
interface ValidationRule {
    type: string;
    value?: any;
    message?: string;
}
/**
 * Conditional rule interface
 */
interface ConditionalRule {
    fieldId: string;
    operator: string;
    value: any;
}
/**
 * Form field option interface
 */
interface FormFieldOption {
    label: string;
    value: string;
    order?: number;
}
/**
 * Form field interface - COMPLETE match to frontend FormField model
 */
interface FormField {
    id?: string;
    name?: string;
    type: string;
    label: string;
    description?: string;
    helpText?: string;
    placeholder?: string;
    required?: boolean;
    readonly?: boolean;
    hidden?: boolean;
    isRequired?: boolean;
    isReadonly?: boolean;
    isHidden?: boolean;
    validationRules?: ValidationRule[];
    options?: FormFieldOption[];
    defaultValue?: any;
    isPhiField?: boolean;
    phiClassification?: {
        isPhiField: boolean;
        phiType?: string;
        encryptionRequired: boolean;
        accessLevel: string;
        auditRequired: boolean;
        dataMinimization: boolean;
        retentionPeriodDays?: number;
    };
    auditRequired?: boolean;
    linkedFormIds?: string[];
    patientDataMapping?: string;
    nestedFormId?: string;
    allowMultiple?: boolean;
    allowedFileTypes?: string[];
    maxFileSize?: number;
    maxFiles?: number;
    width?: 'full' | 'half' | 'third' | 'quarter';
    columnPosition?: 'left' | 'right' | 'center';
    order?: number;
    section?: string;
    groupId?: string;
    calculationFormula?: string;
    dependsOn?: string[];
    showWhen?: ConditionalRule[];
    requiredWhen?: ConditionalRule[];
    conditionalLogic?: any[];
    visibilityConditions?: any[];
    customAttributes?: Record<string, any>;
    unit?: string;
    min?: number;
    max?: number;
    format?: string;
    criticalDataPoint?: boolean;
    auditTrail?: {
        trackChanges: boolean;
        reasonRequired: boolean;
    };
}
/**
 * Create a new form template (CRF) with fields
 */
export declare const createForm: (data: {
    name: string;
    description?: string;
    studyId?: number;
    fields?: FormField[];
    category?: string;
    version?: string;
}, userId: number) => Promise<{
    success: boolean;
    crfId?: number;
    message?: string;
}>;
/**
 * Update a form template with fields
 */
export declare const updateForm: (crfId: number, data: {
    name?: string;
    description?: string;
    status?: "draft" | "published" | "archived";
    fields?: FormField[];
    category?: string;
}, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Delete a form template (soft delete by changing status)
 */
export declare const deleteForm: (crfId: number, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Get all versions of a CRF
 * Returns version history for display
 */
export declare const getFormVersions: (crfId: number) => Promise<{
    success: boolean;
    versions?: any[];
    message?: string;
}>;
/**
 * Create a new version of an existing CRF
 * - Copies all fields/items from source version
 * - Creates new crf_version record
 * - Maintains link to parent CRF
 *
 * This implements "forking" at the version level - same CRF, new version
 */
export declare const createFormVersion: (crfId: number, data: {
    versionName: string;
    revisionNotes?: string;
    copyFromVersionId?: number;
}, userId: number) => Promise<{
    success: boolean;
    crfVersionId?: number;
    message?: string;
}>;
/**
 * Fork (copy) an entire CRF to create a new independent form
 * - Creates new CRF record
 * - Copies specified version (or latest)
 * - Copies all items/sections/item_groups
 * - Updates OIDs to be unique
 *
 * This implements "forking" at the CRF level - completely new CRF
 */
export declare const forkForm: (sourceCrfId: number, data: {
    newName: string;
    description?: string;
    targetStudyId?: number;
}, userId: number) => Promise<{
    success: boolean;
    newCrfId?: number;
    message?: string;
}>;
declare const _default: {
    saveFormData: (request: FormDataRequest & {
        formId?: number;
        data?: Record<string, any>;
        eventId?: number;
    }, userId: number, username: string) => Promise<ApiResponse<any>>;
    getFormData: (eventCrfId: number) => Promise<any>;
    getFormMetadata: (crfId: number) => Promise<any>;
    getFormStatus: (eventCrfId: number) => Promise<any>;
    validateFormData: (formData: Record<string, any>) => {
        isValid: boolean;
        errors: string[];
    };
    getStudyForms: (studyId: number) => Promise<any[]>;
    getAllForms: () => Promise<any[]>;
    getFormById: (crfId: number) => Promise<any>;
    createForm: (data: {
        name: string;
        description?: string;
        studyId?: number;
        fields?: FormField[];
        category?: string;
        version?: string;
    }, userId: number) => Promise<{
        success: boolean;
        crfId?: number;
        message?: string;
    }>;
    updateForm: (crfId: number, data: {
        name?: string;
        description?: string;
        status?: "draft" | "published" | "archived";
        fields?: FormField[];
        category?: string;
    }, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    deleteForm: (crfId: number, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    getFormVersions: (crfId: number) => Promise<{
        success: boolean;
        versions?: any[];
        message?: string;
    }>;
    createFormVersion: (crfId: number, data: {
        versionName: string;
        revisionNotes?: string;
        copyFromVersionId?: number;
    }, userId: number) => Promise<{
        success: boolean;
        crfVersionId?: number;
        message?: string;
    }>;
    forkForm: (sourceCrfId: number, data: {
        newName: string;
        description?: string;
        targetStudyId?: number;
    }, userId: number) => Promise<{
        success: boolean;
        newCrfId?: number;
        message?: string;
    }>;
};
export default _default;
//# sourceMappingURL=form.service.d.ts.map