/**
 * Validation Rules Routes
 *
 * API endpoints for managing validation rules
 *
 * 21 CFR Part 11 Compliance:
 * - Rule creation/modification requires electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=validation-rules.routes.d.ts.map