"use strict";
/**
 * Wound Controller
 *
 * Handles HTTP requests for wound capture sessions
 * Integrates with WoundScanner iOS app
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSyncStatus = exports.syncBatch = exports.submitAuditEntries = exports.submitToLibreClinica = exports.signSession = exports.getSessionMeasurements = exports.submitMeasurements = exports.getSessionImages = exports.uploadImage = exports.getPatientSessions = exports.getSession = exports.createSession = exports.uploadMiddleware = void 0;
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const woundService = __importStar(require("../services/hybrid/wound.service"));
const multer_1 = __importDefault(require("multer"));
// Configure multer for image uploads
const upload = (0, multer_1.default)({
    storage: multer_1.default.memoryStorage(),
    limits: {
        fileSize: 20 * 1024 * 1024 // 20MB max
    }
});
exports.uploadMiddleware = upload.single('image');
// ============================================================================
// SESSION ENDPOINTS
// ============================================================================
/**
 * POST /api/wounds/sessions
 * Create a new wound capture session
 */
exports.createSession = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    if (!user) {
        res.status(401).json({ success: false, message: 'Unauthorized' });
        return;
    }
    const { patientId, templateId, studyId, studyEventId, siteId, deviceId, source } = req.body;
    if (!patientId || !templateId) {
        res.status(400).json({
            success: false,
            message: 'patientId and templateId are required'
        });
        return;
    }
    const result = await woundService.createSession({ patientId, templateId, studyId, studyEventId, siteId, deviceId, source }, user.userId.toString(), user.userName);
    res.status(result.success ? 201 : 400).json(result);
});
/**
 * GET /api/wounds/sessions/:id
 * Get session by ID
 */
exports.getSession = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const result = await woundService.getSession(id);
    if (!result.success) {
        res.status(404).json(result);
        return;
    }
    res.json(result);
});
/**
 * GET /api/wounds/patients/:patientId/sessions
 * Get all sessions for a patient
 */
exports.getPatientSessions = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { patientId } = req.params;
    const { page = '1', limit = '20' } = req.query;
    const result = await woundService.getPatientSessions(patientId, parseInt(page), parseInt(limit));
    res.json(result);
});
// ============================================================================
// IMAGE ENDPOINTS
// ============================================================================
/**
 * POST /api/wounds/sessions/:id/images
 * Upload wound image
 */
exports.uploadImage = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { id: sessionId } = req.params;
    if (!user) {
        res.status(401).json({ success: false, message: 'Unauthorized' });
        return;
    }
    if (!req.file) {
        res.status(400).json({ success: false, message: 'No image file provided' });
        return;
    }
    const hash = req.body.hash || '';
    const result = await woundService.uploadImage(sessionId, req.file.buffer, req.file.originalname, req.file.mimetype, hash, user.userId.toString());
    res.status(result.success ? 201 : 400).json(result);
});
/**
 * GET /api/wounds/sessions/:id/images
 * Get images for a session
 */
exports.getSessionImages = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id: sessionId } = req.params;
    // For now, return success - implement image listing if needed
    res.json({ success: true, data: [], message: 'Not implemented yet' });
});
// ============================================================================
// MEASUREMENT ENDPOINTS
// ============================================================================
/**
 * POST /api/wounds/sessions/:id/measurements
 * Submit wound measurements
 */
exports.submitMeasurements = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { id: sessionId } = req.params;
    if (!user) {
        res.status(401).json({ success: false, message: 'Unauthorized' });
        return;
    }
    const { measurements, dataHash } = req.body;
    if (!measurements || !Array.isArray(measurements) || measurements.length === 0) {
        res.status(400).json({
            success: false,
            message: 'measurements array is required'
        });
        return;
    }
    const result = await woundService.submitMeasurements({ sessionId, measurements, dataHash: dataHash || '' }, user.userId.toString(), user.userName);
    res.status(result.success ? 200 : 400).json(result);
});
/**
 * GET /api/wounds/sessions/:id/measurements
 * Get measurements for a session
 */
exports.getSessionMeasurements = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id: sessionId } = req.params;
    const result = await woundService.getSessionMeasurements(sessionId);
    res.json(result);
});
// ============================================================================
// SIGNATURE ENDPOINTS
// ============================================================================
/**
 * PUT /api/wounds/sessions/:id/sign
 * Apply electronic signature to session
 */
exports.signSession = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { id: sessionId } = req.params;
    if (!user) {
        res.status(401).json({ success: false, message: 'Unauthorized' });
        return;
    }
    const { signature } = req.body;
    if (!signature) {
        res.status(400).json({
            success: false,
            message: 'signature object is required'
        });
        return;
    }
    const result = await woundService.signSession({ sessionId, signature }, user.userId.toString());
    res.status(result.success ? 200 : 400).json(result);
});
// ============================================================================
// SUBMISSION ENDPOINTS
// ============================================================================
/**
 * POST /api/wounds/sessions/:id/submit
 * Submit session to LibreClinica
 */
exports.submitToLibreClinica = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { id: sessionId } = req.params;
    if (!user) {
        res.status(401).json({ success: false, message: 'Unauthorized' });
        return;
    }
    const { auditTrail } = req.body;
    const result = await woundService.submitToLibreClinica({ sessionId, auditTrail }, user.userId, user.userName);
    res.status(result.success ? 200 : 400).json(result);
});
// ============================================================================
// AUDIT ENDPOINTS
// ============================================================================
/**
 * POST /api/wounds/audit/log
 * Submit audit entries from iOS app
 */
exports.submitAuditEntries = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { entries } = req.body;
    if (!entries || !Array.isArray(entries)) {
        res.status(400).json({
            success: false,
            message: 'entries array is required'
        });
        return;
    }
    const result = await woundService.submitAuditEntries(entries);
    res.json({ success: true, ...result });
});
// ============================================================================
// SYNC ENDPOINTS
// ============================================================================
/**
 * POST /api/wounds/sync/batch
 * Batch sync offline sessions
 */
exports.syncBatch = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    if (!user) {
        res.status(401).json({ success: false, message: 'Unauthorized' });
        return;
    }
    const { sessions, deviceId } = req.body;
    if (!sessions || !Array.isArray(sessions)) {
        res.status(400).json({
            success: false,
            message: 'sessions array is required'
        });
        return;
    }
    const syncedSessions = [];
    const failedSessions = [];
    for (const pendingSession of sessions) {
        try {
            // Create session
            const createResult = await woundService.createSession({
                patientId: pendingSession.patientId,
                templateId: pendingSession.templateId,
                deviceId,
                source: 'ios_app'
            }, user.userId.toString(), user.userName);
            if (!createResult.success || !createResult.sessionId) {
                failedSessions.push({
                    localId: pendingSession.localId,
                    error: createResult.message || 'Failed to create session',
                    retryable: true
                });
                continue;
            }
            const serverSessionId = createResult.sessionId;
            // Submit measurements
            if (pendingSession.measurements && pendingSession.measurements.length > 0) {
                await woundService.submitMeasurements({
                    sessionId: serverSessionId,
                    measurements: pendingSession.measurements,
                    dataHash: ''
                }, user.userId.toString(), user.userName);
            }
            // Apply signature if present
            if (pendingSession.signature) {
                await woundService.signSession({
                    sessionId: serverSessionId,
                    signature: pendingSession.signature
                }, user.userId.toString());
            }
            // Submit to LibreClinica
            const submitResult = await woundService.submitToLibreClinica({ sessionId: serverSessionId, auditTrail: pendingSession.auditTrail }, user.userId, user.userName);
            syncedSessions.push({
                localId: pendingSession.localId,
                serverId: serverSessionId,
                libreClinicaId: submitResult.libreClinicaId
            });
        }
        catch (error) {
            failedSessions.push({
                localId: pendingSession.localId,
                error: error.message,
                retryable: true
            });
        }
    }
    res.json({
        success: true,
        syncedSessions,
        failedSessions
    });
});
/**
 * GET /api/wounds/sync/status
 * Get sync status
 */
exports.getSyncStatus = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    // For now, return placeholder status
    res.json({
        success: true,
        data: {
            pendingCount: 0,
            lastSync: new Date()
        }
    });
});
exports.default = {
    createSession: exports.createSession,
    getSession: exports.getSession,
    getPatientSessions: exports.getPatientSessions,
    uploadImage: exports.uploadImage,
    uploadMiddleware: exports.uploadMiddleware,
    getSessionImages: exports.getSessionImages,
    submitMeasurements: exports.submitMeasurements,
    getSessionMeasurements: exports.getSessionMeasurements,
    signSession: exports.signSession,
    submitToLibreClinica: exports.submitToLibreClinica,
    submitAuditEntries: exports.submitAuditEntries,
    syncBatch: exports.syncBatch,
    getSyncStatus: exports.getSyncStatus
};
//# sourceMappingURL=wound.controller.js.map