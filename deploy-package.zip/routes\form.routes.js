"use strict";
/**
 * Form Routes
 *
 * CRUD operations for form templates (CRFs) and form data
 *
 * 21 CFR Part 11 Compliance:
 * - All data modifications require electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const controller = __importStar(require("../controllers/form.controller"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const authorization_middleware_1 = require("../middleware/authorization.middleware");
const validation_middleware_1 = require("../middleware/validation.middleware");
const rateLimiter_middleware_1 = require("../middleware/rateLimiter.middleware");
const part11_middleware_1 = require("../middleware/part11.middleware");
const router = express_1.default.Router();
router.use(auth_middleware_1.authMiddleware);
// Form templates (CRFs) - read operations (no signature required)
router.get('/', controller.list);
router.get('/by-study', controller.getByStudy);
router.get('/:id', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.get);
router.get('/:crfId/metadata', controller.getMetadata);
// Version history (no signature required - read only)
router.get('/:id/versions', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.getVersions);
// Form templates (CRFs) - write operations (signature required per §11.50)
router.post('/', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.CRF_CREATE), controller.create);
router.put('/:id', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.CRF_UPDATE), controller.update);
router.delete('/:id', (0, authorization_middleware_1.requireRole)('admin'), (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.CRF_DELETE), controller.remove);
// Template Forking/Versioning - write operations (signature required per §11.50)
// Create new version of existing CRF
router.post('/:id/versions', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.CRF_CREATE), controller.createVersion);
// Fork (copy) entire CRF to new independent form
router.post('/:id/fork', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.CRF_CREATE), controller.fork);
// Form data operations (signature required for data entry per §11.50)
router.post('/save', (0, authorization_middleware_1.requireRole)('data_entry', 'investigator', 'coordinator'), rateLimiter_middleware_1.soapRateLimiter, (0, validation_middleware_1.validate)({ body: validation_middleware_1.formSchemas.saveData }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.FORM_DATA_SAVE), controller.saveData);
router.get('/data/:eventCrfId', controller.getData);
router.get('/status/:eventCrfId', controller.getStatus);
exports.default = router;
//# sourceMappingURL=form.routes.js.map