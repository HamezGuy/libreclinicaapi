/**
 * Adverse Event (AE/SAE) Routes
 * Uses EXISTING LibreClinica SOAP APIs for Part 11 compliance
 * AEs are CRF forms - imported via dataSoap.service
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=ae.routes.d.ts.map