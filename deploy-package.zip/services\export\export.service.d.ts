/**
 * Data Export Service
 *
 * Uses EXISTING LibreClinica SOAP APIs for Part 11 compliance:
 * - studySoap for study metadata (getMetadata)
 * - studySubject SOAP for subject lists
 * - Proxies to LibreClinica's built-in extract functionality
 *
 * Also integrates with LibreClinica's dataset_* tables:
 * - dataset: Main dataset configuration
 * - dataset_crf_version_map: Links datasets to CRF versions
 * - dataset_filter_map: Dataset filters
 * - dataset_item_status: Item status filters
 * - dataset_study_group_class_map: Study group filters
 * - archived_dataset_file: Previously exported files
 *
 * LibreClinica Models Used:
 * - DatasetBean (extract/DatasetBean.java)
 * - ExportFormatBean (extract/ExportFormatBean.java)
 * - ExportSubjectDataBean (submit/crfdata/ExportSubjectDataBean.java)
 */
export type ExportFormat = 'csv' | 'odm' | 'spss' | 'txt';
export interface DatasetConfig {
    studyOID: string;
    name?: string;
    description?: string;
    dateStart?: string;
    dateEnd?: string;
    eventOIDs?: string[];
    crfOIDs?: string[];
    showEventLocation?: boolean;
    showEventStart?: boolean;
    showEventEnd?: boolean;
    showSubjectDob?: boolean;
    showSubjectGender?: boolean;
    showSubjectStatus?: boolean;
    showCRFstatus?: boolean;
    showCRFversion?: boolean;
}
export interface ExportResult {
    success: boolean;
    data?: {
        content: string | Buffer;
        filename: string;
        mimeType: string;
        recordCount?: number;
    };
    error?: string;
}
/**
 * Get study metadata for export configuration
 * Uses EXISTING SOAP studyService.getMetadata
 */
export declare const getStudyMetadataForExport: (studyOID: string, username: string) => Promise<any>;
/**
 * Get all subjects for a study (for export preview)
 * Uses EXISTING SOAP studySubject.listAllByStudy
 */
export declare const getSubjectsForExport: (studyOID: string, username: string) => Promise<any[]>;
/**
 * Build ODM XML export using SOAP-retrieved data
 * Matches LibreClinica's ClinicalDataReportBean structure
 */
export declare const buildOdmExport: (datasetConfig: DatasetConfig, username: string) => Promise<string>;
/**
 * Build CSV export from SOAP data
 * Matches LibreClinica's TabReportBean/CommaReportBean
 */
export declare const buildCsvExport: (datasetConfig: DatasetConfig, username: string) => Promise<string>;
/**
 * Execute export with specified format
 */
export declare const executeExport: (datasetConfig: DatasetConfig, format: ExportFormat, username: string) => Promise<ExportResult>;
/**
 * Create a dataset in LibreClinica's dataset table
 * This stores the export configuration for re-use and audit trail
 */
export declare const createDataset: (datasetConfig: DatasetConfig, userId: number) => Promise<{
    datasetId: number;
    success: boolean;
    error?: string;
}>;
/**
 * Get saved datasets for a study
 */
export declare const getDatasets: (studyOID: string) => Promise<any[]>;
/**
 * Archive an exported file in LibreClinica's archived_dataset_file table
 */
export declare const archiveExportedFile: (datasetId: number, filename: string, filepath: string, format: string, userId: number) => Promise<boolean>;
/**
 * Get archived exports for a dataset
 */
export declare const getArchivedExports: (datasetId: number) => Promise<any[]>;
/**
 * Build full CDISC ODM export with all clinical data
 * Uses LibreClinica's dataset tables and item_data for complete export
 */
export declare const buildFullOdmExport: (datasetConfig: DatasetConfig, username: string) => Promise<string>;
declare const _default: {
    getStudyMetadataForExport: (studyOID: string, username: string) => Promise<any>;
    getSubjectsForExport: (studyOID: string, username: string) => Promise<any[]>;
    buildOdmExport: (datasetConfig: DatasetConfig, username: string) => Promise<string>;
    buildCsvExport: (datasetConfig: DatasetConfig, username: string) => Promise<string>;
    buildFullOdmExport: (datasetConfig: DatasetConfig, username: string) => Promise<string>;
    executeExport: (datasetConfig: DatasetConfig, format: ExportFormat, username: string) => Promise<ExportResult>;
    createDataset: (datasetConfig: DatasetConfig, userId: number) => Promise<{
        datasetId: number;
        success: boolean;
        error?: string;
    }>;
    getDatasets: (studyOID: string) => Promise<any[]>;
    archiveExportedFile: (datasetId: number, filename: string, filepath: string, format: string, userId: number) => Promise<boolean>;
    getArchivedExports: (datasetId: number) => Promise<any[]>;
};
export default _default;
//# sourceMappingURL=export.service.d.ts.map