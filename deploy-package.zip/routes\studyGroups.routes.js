"use strict";
/**
 * Study Groups Routes
 *
 * API endpoints for managing study group classes and subject group assignments.
 * Used for randomization, treatment arms, demographics grouping, etc.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const authorization_middleware_1 = require("../middleware/authorization.middleware");
const studyGroupsService = __importStar(require("../services/database/studyGroups.service"));
const logger_1 = require("../config/logger");
const router = express_1.default.Router();
// All routes require authentication
router.use(auth_middleware_1.authMiddleware);
/**
 * GET /api/study-groups/class-types
 * Get available group class types (Arm, Family/Pedigree, Demographic, Other)
 */
router.get('/class-types', async (req, res) => {
    try {
        const types = await studyGroupsService.getGroupClassTypes();
        res.json({ success: true, data: types });
    }
    catch (error) {
        logger_1.logger.error('Failed to get group class types', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/study-groups/study/:studyId
 * Get all group classes and their groups for a study
 */
router.get('/study/:studyId', async (req, res) => {
    try {
        const studyId = parseInt(req.params.studyId);
        if (isNaN(studyId)) {
            res.status(400).json({ success: false, message: 'Invalid study ID' });
            return;
        }
        const groupClasses = await studyGroupsService.getStudyGroupClasses(studyId);
        res.json({ success: true, data: groupClasses });
    }
    catch (error) {
        logger_1.logger.error('Failed to get study group classes', {
            studyId: req.params.studyId,
            error: error.message
        });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * POST /api/study-groups/class
 * Create a new study group class (admin/coordinator only)
 */
router.post('/class', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), async (req, res) => {
    try {
        const user = req.user;
        const { studyId, name, groupClassTypeId, subjectAssignment } = req.body;
        if (!studyId || !name || !groupClassTypeId) {
            res.status(400).json({
                success: false,
                message: 'studyId, name, and groupClassTypeId are required'
            });
            return;
        }
        const result = await studyGroupsService.createStudyGroupClass({
            studyId: parseInt(studyId),
            name,
            groupClassTypeId: parseInt(groupClassTypeId),
            subjectAssignment: subjectAssignment || 'Optional'
        }, user.userId);
        if (result.success) {
            res.status(201).json(result);
        }
        else {
            res.status(400).json(result);
        }
    }
    catch (error) {
        logger_1.logger.error('Failed to create study group class', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * POST /api/study-groups/group
 * Create a new group within a class (admin/coordinator only)
 */
router.post('/group', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), async (req, res) => {
    try {
        const { studyGroupClassId, name, description } = req.body;
        if (!studyGroupClassId || !name) {
            res.status(400).json({
                success: false,
                message: 'studyGroupClassId and name are required'
            });
            return;
        }
        const result = await studyGroupsService.createStudyGroup({
            studyGroupClassId: parseInt(studyGroupClassId),
            name,
            description
        });
        if (result.success) {
            res.status(201).json(result);
        }
        else {
            res.status(400).json(result);
        }
    }
    catch (error) {
        logger_1.logger.error('Failed to create study group', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/study-groups/subject/:studySubjectId
 * Get group assignments for a subject
 */
router.get('/subject/:studySubjectId', async (req, res) => {
    try {
        const studySubjectId = parseInt(req.params.studySubjectId);
        if (isNaN(studySubjectId)) {
            res.status(400).json({ success: false, message: 'Invalid study subject ID' });
            return;
        }
        const assignments = await studyGroupsService.getSubjectGroupAssignments(studySubjectId);
        res.json({ success: true, data: assignments });
    }
    catch (error) {
        logger_1.logger.error('Failed to get subject group assignments', {
            studySubjectId: req.params.studySubjectId,
            error: error.message
        });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * POST /api/study-groups/subject/:studySubjectId/assign
 * Assign a subject to groups
 */
router.post('/subject/:studySubjectId/assign', async (req, res) => {
    try {
        const user = req.user;
        const studySubjectId = parseInt(req.params.studySubjectId);
        const { assignments } = req.body;
        if (isNaN(studySubjectId)) {
            res.status(400).json({ success: false, message: 'Invalid study subject ID' });
            return;
        }
        if (!assignments || !Array.isArray(assignments)) {
            res.status(400).json({
                success: false,
                message: 'assignments array is required'
            });
            return;
        }
        const result = await studyGroupsService.assignSubjectToGroups(studySubjectId, assignments, user.userId);
        if (result.success) {
            // Return updated assignments
            const updatedAssignments = await studyGroupsService.getSubjectGroupAssignments(studySubjectId);
            res.json({ success: true, data: updatedAssignments });
        }
        else {
            res.status(400).json(result);
        }
    }
    catch (error) {
        logger_1.logger.error('Failed to assign subject to groups', {
            studySubjectId: req.params.studySubjectId,
            error: error.message
        });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/study-groups/group/:studyGroupId/subjects
 * Get all subjects in a group
 */
router.get('/group/:studyGroupId/subjects', async (req, res) => {
    try {
        const studyGroupId = parseInt(req.params.studyGroupId);
        if (isNaN(studyGroupId)) {
            res.status(400).json({ success: false, message: 'Invalid study group ID' });
            return;
        }
        const subjects = await studyGroupsService.getSubjectsInGroup(studyGroupId);
        res.json({ success: true, data: subjects });
    }
    catch (error) {
        logger_1.logger.error('Failed to get subjects in group', {
            studyGroupId: req.params.studyGroupId,
            error: error.message
        });
        res.status(500).json({ success: false, message: error.message });
    }
});
exports.default = router;
//# sourceMappingURL=studyGroups.routes.js.map