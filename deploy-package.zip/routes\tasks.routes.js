"use strict";
/**
 * Tasks Routes
 *
 * Unified task management endpoints aggregating:
 * - Queries (discrepancy_note)
 * - Scheduled Visits (study_event)
 * - Data Entry (study_event/event_crf)
 * - Form Completion (event_crf)
 * - SDV Required (event_crf)
 * - Signature Required (event_crf)
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_middleware_1 = require("../middleware/auth.middleware");
const tasks_controller_1 = __importDefault(require("../controllers/tasks.controller"));
const router = (0, express_1.Router)();
// All routes require authentication
router.use(auth_middleware_1.authMiddleware);
// Get tasks for current user
router.get('/', tasks_controller_1.default.getTasks);
// Get task summary for current user
router.get('/summary', tasks_controller_1.default.getTaskSummary);
// Get overdue tasks
router.get('/overdue', tasks_controller_1.default.getOverdueTasks);
// Get tasks by type
router.get('/type/:type', tasks_controller_1.default.getTasksByType);
// Get tasks for specific user
router.get('/user/:username', tasks_controller_1.default.getUserTasks);
// Get task summary for specific user
router.get('/user/:username/summary', tasks_controller_1.default.getUserTaskSummary);
// Get single task by ID
router.get('/:taskId', tasks_controller_1.default.getTask);
exports.default = router;
//# sourceMappingURL=tasks.routes.js.map