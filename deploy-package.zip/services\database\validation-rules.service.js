"use strict";
/**
 * Validation Rules Service
 *
 * Manages validation rules for CRFs (forms) in LibreClinica
 *
 * LibreClinica stores validation at the item level in item_form_metadata:
 * - regexp: Regular expression pattern
 * - regexp_error_msg: Error message when validation fails
 * - required: Whether the field is required
 *
 * This service extends that with a custom rules table for advanced validations.
 *
 * 21 CFR Part 11 §11.10(h) - Device checks (validation rules)
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateFormData = exports.deleteRule = exports.toggleRule = exports.updateRule = exports.createRule = exports.getRuleById = exports.getRulesForStudy = exports.getRulesForCrf = exports.initializeValidationRulesTable = void 0;
const database_1 = require("../../config/database");
const logger_1 = require("../../config/logger");
// Track if table has been initialized
let tableInitialized = false;
/**
 * Map LibreClinica rule action_type to our rule_type
 *
 * LibreClinica action types:
 * - DISCREPANCY_NRS: Non-resolvable discrepancy (warning)
 * - DISCREPANCY_RS: Resolvable discrepancy (error)
 * - EMAIL: Send email notification
 * - HIDE: Hide an item
 * - SHOW: Show an item
 * - INSERT: Insert data
 * - RANDOMIZATION: Trigger randomization
 * - STRATIFICATION_FACTOR: Calculate stratification
 */
const mapActionTypeToRuleType = (actionType) => {
    const typeMap = {
        'DISCREPANCY_NRS': 'business_logic',
        'DISCREPANCY_RS': 'business_logic',
        'EMAIL': 'notification',
        'HIDE': 'consistency',
        'SHOW': 'consistency',
        'INSERT': 'calculation',
        'RANDOMIZATION': 'business_logic',
        'STRATIFICATION_FACTOR': 'calculation'
    };
    return typeMap[actionType] || 'business_logic';
};
/**
 * Initialize the validation_rules table if it doesn't exist
 * Uses simple columns without foreign key constraints to avoid dependency issues
 */
const initializeValidationRulesTable = async () => {
    if (tableInitialized) {
        return true;
    }
    // First check if table exists
    const checkQuery = `
    SELECT EXISTS (
      SELECT FROM information_schema.tables 
      WHERE table_name = 'validation_rules'
    );
  `;
    try {
        const checkResult = await database_1.pool.query(checkQuery);
        if (checkResult.rows[0].exists) {
            tableInitialized = true;
            return true;
        }
    }
    catch (e) {
        // Continue to try creating
    }
    // Create table without foreign key constraints for flexibility
    const createTableQuery = `
    CREATE TABLE IF NOT EXISTS validation_rules (
      validation_rule_id SERIAL PRIMARY KEY,
      crf_id INTEGER,
      crf_version_id INTEGER,
      item_id INTEGER,
      name VARCHAR(255) NOT NULL,
      description TEXT,
      rule_type VARCHAR(50) NOT NULL,
      field_path VARCHAR(255),
      severity VARCHAR(20) DEFAULT 'error',
      error_message TEXT NOT NULL,
      warning_message TEXT,
      active BOOLEAN DEFAULT true,
      min_value NUMERIC,
      max_value NUMERIC,
      pattern TEXT,
      operator VARCHAR(20),
      compare_field_path VARCHAR(255),
      custom_expression TEXT,
      date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      date_updated TIMESTAMP,
      owner_id INTEGER,
      update_id INTEGER
    );
  `;
    const createIndexQuery = `
    CREATE INDEX IF NOT EXISTS idx_validation_rules_crf ON validation_rules(crf_id);
    CREATE INDEX IF NOT EXISTS idx_validation_rules_item ON validation_rules(item_id);
    CREATE INDEX IF NOT EXISTS idx_validation_rules_active ON validation_rules(active);
  `;
    try {
        await database_1.pool.query(createTableQuery);
        await database_1.pool.query(createIndexQuery);
        tableInitialized = true;
        logger_1.logger.info('Validation rules table initialized successfully');
        return true;
    }
    catch (error) {
        logger_1.logger.error('Failed to initialize validation_rules table:', error.message);
        return false;
    }
};
exports.initializeValidationRulesTable = initializeValidationRulesTable;
/**
 * Get all validation rules for a CRF
 */
const getRulesForCrf = async (crfId) => {
    logger_1.logger.info('Getting validation rules for CRF', { crfId });
    // Ensure table exists before querying
    await (0, exports.initializeValidationRulesTable)();
    try {
        // First get rules from the custom validation_rules table
        const customRulesQuery = `
      SELECT 
        vr.validation_rule_id as id,
        vr.crf_id,
        vr.crf_version_id,
        vr.item_id,
        vr.name,
        vr.description,
        vr.rule_type,
        vr.field_path,
        vr.severity,
        vr.error_message,
        vr.warning_message,
        vr.active,
        vr.min_value,
        vr.max_value,
        vr.pattern,
        vr.operator,
        vr.compare_field_path,
        vr.custom_expression,
        vr.date_created,
        vr.date_updated,
        vr.owner_id as created_by,
        vr.update_id as updated_by
      FROM validation_rules vr
      WHERE vr.crf_id = $1
      ORDER BY vr.name
    `;
        let customRules = [];
        try {
            const customResult = await database_1.pool.query(customRulesQuery, [crfId]);
            customRules = customResult.rows.map(mapDbRowToRule);
        }
        catch (e) {
            // Table might not exist yet
            logger_1.logger.debug('Custom validation_rules table not available:', e.message);
        }
        // Also extract rules from item_form_metadata
        const itemRulesQuery = `
      SELECT 
        ifm.item_id as id,
        cv.crf_id,
        ifm.crf_version_id,
        i.item_id,
        i.name,
        i.description,
        CASE 
          WHEN ifm.regexp IS NOT NULL THEN 'format'
          WHEN ifm.required = true THEN 'required'
          ELSE NULL
        END as rule_type,
        i.name as field_path,
        'error' as severity,
        COALESCE(ifm.regexp_error_msg, 'Invalid format') as error_message,
        NULL as warning_message,
        true as active,
        NULL as min_value,
        NULL as max_value,
        ifm.regexp as pattern,
        NULL as operator,
        NULL as compare_field_path,
        NULL as custom_expression,
        cv.date_created,
        NULL as date_updated,
        cv.owner_id as created_by,
        NULL as updated_by
      FROM item_form_metadata ifm
      INNER JOIN crf_version cv ON ifm.crf_version_id = cv.crf_version_id
      INNER JOIN item i ON ifm.item_id = i.item_id
      WHERE cv.crf_id = $1
        AND (ifm.regexp IS NOT NULL OR ifm.required = true)
      ORDER BY i.name
    `;
        const itemResult = await database_1.pool.query(itemRulesQuery, [crfId]);
        const itemRules = itemResult.rows
            .filter(row => row.rule_type !== null)
            .map(mapDbRowToRule);
        // Also get rules from LibreClinica's native rule/rule_expression/rule_action tables
        // These are the advanced rules created in LibreClinica's Rules Module
        let nativeRules = [];
        try {
            const nativeRulesQuery = `
        SELECT 
          r.id,
          r.name,
          r.description,
          r.oc_oid,
          r.enabled,
          r.study_id,
          re.value as expression,
          re.context as expression_context,
          rs.target as target_oid,
          rs.study_event_definition_id,
          rs.crf_id,
          rs.crf_version_id,
          rs.item_id,
          rs.item_group_id,
          ra.action_type,
          ra.message as action_message,
          ra.expression_evaluates_to
        FROM rule r
        INNER JOIN rule_expression re ON r.rule_expression_id = re.id
        INNER JOIN rule_set rs ON rs.study_id = r.study_id
        INNER JOIN rule_set_rule rsr ON rsr.rule_set_id = rs.id AND rsr.rule_id = r.id
        LEFT JOIN rule_action ra ON ra.rule_set_rule_id = rsr.id
        WHERE rs.crf_id = $1 AND r.enabled = true
        ORDER BY r.name
      `;
            const nativeResult = await database_1.pool.query(nativeRulesQuery, [crfId]);
            nativeRules = nativeResult.rows.map(row => ({
                id: row.id + 100000, // Offset to avoid ID conflicts with custom rules
                crfId: row.crf_id,
                crfVersionId: row.crf_version_id,
                itemId: row.item_id,
                name: row.name || 'LibreClinica Rule',
                description: row.description || '',
                ruleType: mapActionTypeToRuleType(row.action_type),
                fieldPath: row.target_oid || '',
                severity: row.action_type === 'DISCREPANCY_NRS' ? 'warning' : 'error',
                errorMessage: row.action_message || 'Validation failed',
                warningMessage: row.action_type === 'DISCREPANCY_NRS' ? row.action_message : undefined,
                active: row.enabled || true,
                customExpression: row.expression,
                dateCreated: new Date(),
                createdBy: row.owner_id || 1, // Required field
                // Store reference to native rule for advanced use
                nativeRuleId: row.id,
                nativeOcOid: row.oc_oid,
                expressionContext: row.expression_context
            }));
        }
        catch (e) {
            // Native rules tables might not be available or might have no data
            logger_1.logger.debug('LibreClinica native rules not available:', e.message);
        }
        // Combine and deduplicate (custom rules take precedence)
        const allRules = [...customRules];
        for (const itemRule of itemRules) {
            const exists = customRules.some(r => r.fieldPath === itemRule.fieldPath && r.ruleType === itemRule.ruleType);
            if (!exists) {
                allRules.push(itemRule);
            }
        }
        // Add native LibreClinica rules
        for (const nativeRule of nativeRules) {
            const exists = allRules.some(r => r.customExpression === nativeRule.customExpression);
            if (!exists) {
                allRules.push(nativeRule);
            }
        }
        return allRules;
    }
    catch (error) {
        logger_1.logger.error('Get validation rules error', { error: error.message });
        throw error;
    }
};
exports.getRulesForCrf = getRulesForCrf;
/**
 * Get all validation rules for a study (all CRFs)
 *
 * Returns unique CRFs associated with the study through:
 * 1. Event definitions (edc -> sed -> study)
 * 2. Source study ID
 * 3. Fallback to all available CRFs if none found
 *
 * Uses UNION to combine sources and GROUP BY to deduplicate
 */
const getRulesForStudy = async (studyId) => {
    logger_1.logger.info('Getting validation rules for study', { studyId });
    try {
        // Combined query using UNION to get unique CRFs from multiple sources
        // This ensures no duplicates while checking all possible associations
        const combinedCrfsQuery = `
      WITH study_crfs AS (
        -- CRFs assigned to study event definitions
        SELECT DISTINCT c.crf_id, c.name, 1 as priority
        FROM crf c
        INNER JOIN crf_version cv ON c.crf_id = cv.crf_id
        INNER JOIN event_definition_crf edc ON cv.crf_id = edc.crf_id
        INNER JOIN study_event_definition sed ON edc.study_event_definition_id = sed.study_event_definition_id
        WHERE sed.study_id = $1
          AND c.status_id = 1
        
        UNION
        
        -- CRFs created for this study (source_study_id)
        SELECT DISTINCT c.crf_id, c.name, 2 as priority
        FROM crf c
        WHERE c.source_study_id = $1
          AND c.status_id = 1
      )
      SELECT DISTINCT ON (crf_id) crf_id, name
      FROM study_crfs
      ORDER BY crf_id, priority
    `;
        let crfsResult = await database_1.pool.query(combinedCrfsQuery, [studyId]);
        logger_1.logger.info('Study CRFs (combined query)', { studyId, count: crfsResult.rows.length });
        // Fallback: Get ALL available CRFs if none found for this study
        if (crfsResult.rows.length === 0) {
            const allCrfsQuery = `
        SELECT DISTINCT crf_id, name
        FROM crf
        WHERE status_id = 1
        ORDER BY name
        LIMIT 50
      `;
            crfsResult = await database_1.pool.query(allCrfsQuery);
            logger_1.logger.info('All available CRFs (fallback)', { count: crfsResult.rows.length });
        }
        // Use Map to ensure uniqueness by crf_id
        const crfMap = new Map();
        for (const crf of crfsResult.rows) {
            if (!crfMap.has(crf.crf_id)) {
                crfMap.set(crf.crf_id, {
                    crfId: crf.crf_id,
                    crfName: crf.name
                });
            }
        }
        // Convert to array and fetch rules for each unique CRF
        const results = [];
        for (const crf of crfMap.values()) {
            const rules = await (0, exports.getRulesForCrf)(crf.crfId);
            results.push({
                crfId: crf.crfId,
                crfName: crf.crfName,
                rules
            });
        }
        // Sort by name for consistent ordering
        results.sort((a, b) => a.crfName.localeCompare(b.crfName));
        logger_1.logger.info('Returning unique CRFs for study', { studyId, uniqueCount: results.length });
        return results;
    }
    catch (error) {
        logger_1.logger.error('Get study validation rules error', { error: error.message });
        throw error;
    }
};
exports.getRulesForStudy = getRulesForStudy;
/**
 * Get a single validation rule by ID
 */
const getRuleById = async (ruleId) => {
    // Ensure table exists
    await (0, exports.initializeValidationRulesTable)();
    try {
        const query = `
      SELECT 
        validation_rule_id as id,
        crf_id,
        crf_version_id,
        item_id,
        name,
        description,
        rule_type,
        field_path,
        severity,
        error_message,
        warning_message,
        active,
        min_value,
        max_value,
        pattern,
        operator,
        compare_field_path,
        custom_expression,
        date_created,
        date_updated,
        owner_id as created_by,
        update_id as updated_by
      FROM validation_rules 
      WHERE validation_rule_id = $1
    `;
        const result = await database_1.pool.query(query, [ruleId]);
        if (result.rows.length === 0) {
            return null;
        }
        return mapDbRowToRule(result.rows[0]);
    }
    catch (error) {
        logger_1.logger.error('Get rule by ID error', { error: error.message });
        return null;
    }
};
exports.getRuleById = getRuleById;
/**
 * Create a new validation rule
 */
const createRule = async (rule, userId) => {
    logger_1.logger.info('Creating validation rule', { rule, userId });
    const client = await database_1.pool.connect();
    try {
        await client.query('BEGIN');
        // Ensure the table exists
        await (0, exports.initializeValidationRulesTable)();
        const insertQuery = `
      INSERT INTO validation_rules (
        crf_id, crf_version_id, item_id, name, description, rule_type,
        field_path, severity, error_message, warning_message, active,
        min_value, max_value, pattern, operator, compare_field_path,
        custom_expression, date_created, owner_id
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, true, $11, $12, $13, $14, $15, $16, CURRENT_TIMESTAMP, $17)
      RETURNING validation_rule_id
    `;
        // Support both fieldPath and fieldName for API compatibility
        const fieldPath = rule.fieldPath || rule.fieldName || '';
        const result = await client.query(insertQuery, [
            rule.crfId,
            rule.crfVersionId || null,
            rule.itemId || null,
            rule.name,
            rule.description || '',
            rule.ruleType,
            fieldPath,
            rule.severity || 'error',
            rule.errorMessage,
            rule.warningMessage || null,
            rule.minValue || null,
            rule.maxValue || null,
            rule.pattern || null,
            rule.operator || null,
            rule.compareFieldPath || null,
            rule.customExpression || null,
            userId
        ]);
        // Also update item_form_metadata if this is a format or required rule
        if (rule.itemId && (rule.ruleType === 'format' || rule.ruleType === 'required')) {
            if (rule.ruleType === 'format' && rule.pattern) {
                await client.query(`
          UPDATE item_form_metadata 
          SET regexp = $1, regexp_error_msg = $2 
          WHERE item_id = $3
        `, [rule.pattern, rule.errorMessage, rule.itemId]);
            }
            else if (rule.ruleType === 'required') {
                await client.query(`
          UPDATE item_form_metadata SET required = true WHERE item_id = $1
        `, [rule.itemId]);
            }
        }
        await client.query('COMMIT');
        return { success: true, ruleId: result.rows[0].validation_rule_id };
    }
    catch (error) {
        await client.query('ROLLBACK');
        logger_1.logger.error('Create validation rule error', { error: error.message });
        return { success: false, message: error.message };
    }
    finally {
        client.release();
    }
};
exports.createRule = createRule;
/**
 * Update a validation rule
 */
const updateRule = async (ruleId, updates, userId) => {
    logger_1.logger.info('Updating validation rule', { ruleId, updates, userId });
    const client = await database_1.pool.connect();
    try {
        await client.query('BEGIN');
        const updateQuery = `
      UPDATE validation_rules SET
        name = COALESCE($1, name),
        description = COALESCE($2, description),
        rule_type = COALESCE($3, rule_type),
        field_path = COALESCE($4, field_path),
        severity = COALESCE($5, severity),
        error_message = COALESCE($6, error_message),
        warning_message = COALESCE($7, warning_message),
        min_value = $8,
        max_value = $9,
        pattern = $10,
        operator = $11,
        compare_field_path = $12,
        custom_expression = $13,
        date_updated = CURRENT_TIMESTAMP,
        update_id = $14
      WHERE validation_rule_id = $15
    `;
        await client.query(updateQuery, [
            updates.name,
            updates.description,
            updates.ruleType,
            updates.fieldPath,
            updates.severity,
            updates.errorMessage,
            updates.warningMessage,
            updates.minValue ?? null,
            updates.maxValue ?? null,
            updates.pattern ?? null,
            updates.operator ?? null,
            updates.compareFieldPath ?? null,
            updates.customExpression ?? null,
            userId,
            ruleId
        ]);
        await client.query('COMMIT');
        return { success: true };
    }
    catch (error) {
        await client.query('ROLLBACK');
        logger_1.logger.error('Update validation rule error', { error: error.message });
        return { success: false, message: error.message };
    }
    finally {
        client.release();
    }
};
exports.updateRule = updateRule;
/**
 * Toggle validation rule active state
 */
const toggleRule = async (ruleId, active, userId) => {
    try {
        await database_1.pool.query(`
      UPDATE validation_rules 
      SET active = $1, date_updated = CURRENT_TIMESTAMP, update_id = $2
      WHERE validation_rule_id = $3
    `, [active, userId, ruleId]);
        return { success: true };
    }
    catch (error) {
        logger_1.logger.error('Toggle rule error', { error: error.message });
        return { success: false };
    }
};
exports.toggleRule = toggleRule;
/**
 * Delete a validation rule
 */
const deleteRule = async (ruleId, userId) => {
    logger_1.logger.info('Deleting validation rule', { ruleId, userId });
    try {
        await database_1.pool.query(`DELETE FROM validation_rules WHERE validation_rule_id = $1`, [ruleId]);
        return { success: true };
    }
    catch (error) {
        logger_1.logger.error('Delete validation rule error', { error: error.message });
        return { success: false, message: error.message };
    }
};
exports.deleteRule = deleteRule;
/**
 * Validate form data against rules
 *
 * @param crfId - The CRF ID to validate against
 * @param formData - The form data to validate
 * @param options - Optional parameters for query creation
 * @param options.createQueries - If true, creates queries for validation failures
 * @param options.studyId - Study ID for query creation
 * @param options.subjectId - Subject ID for query creation
 * @param options.eventCrfId - Event CRF ID for query creation
 * @param options.userId - User ID who triggered validation
 */
const validateFormData = async (crfId, formData, options) => {
    logger_1.logger.info('Validating form data', { crfId, fieldsCount: Object.keys(formData).length });
    const rules = await (0, exports.getRulesForCrf)(crfId);
    const errors = [];
    const warnings = [];
    let queriesCreated = 0;
    for (const rule of rules) {
        if (!rule.active)
            continue;
        const value = getNestedValue(formData, rule.fieldPath);
        const validationResult = applyRule(rule, value, formData);
        if (!validationResult.valid) {
            if (rule.severity === 'error') {
                const error = {
                    fieldPath: rule.fieldPath,
                    message: rule.errorMessage,
                    severity: 'error'
                };
                // Create query for validation failure if requested
                if (options?.createQueries && options.studyId && options.userId) {
                    try {
                        const queryId = await createValidationQuery({
                            studyId: options.studyId,
                            subjectId: options.subjectId,
                            eventCrfId: options.eventCrfId,
                            fieldPath: rule.fieldPath,
                            ruleName: rule.name,
                            errorMessage: rule.errorMessage,
                            value: value,
                            userId: options.userId
                        });
                        if (queryId) {
                            error.queryId = queryId;
                            queriesCreated++;
                        }
                    }
                    catch (e) {
                        logger_1.logger.error('Failed to create validation query:', e.message);
                    }
                }
                errors.push(error);
            }
            else {
                warnings.push({
                    fieldPath: rule.fieldPath,
                    message: rule.warningMessage || rule.errorMessage
                });
            }
        }
    }
    return {
        valid: errors.length === 0,
        errors,
        warnings,
        queriesCreated
    };
};
exports.validateFormData = validateFormData;
/**
 * Create a query (discrepancy note) for a validation failure
 */
async function createValidationQuery(params) {
    try {
        const description = `Validation Error: ${params.ruleName}`;
        const detailedNotes = `Field: ${params.fieldPath}\nValue: ${JSON.stringify(params.value)}\nError: ${params.errorMessage}`;
        const result = await database_1.pool.query(`
      INSERT INTO discrepancy_note (
        description,
        detailed_notes,
        discrepancy_note_type_id,
        resolution_status_id,
        study_id,
        owner_id,
        date_created,
        entity_type
      ) VALUES ($1, $2, 1, 1, $3, $4, CURRENT_TIMESTAMP, 'itemData')
      RETURNING discrepancy_note_id
    `, [description, detailedNotes, params.studyId, params.userId]);
        const queryId = result.rows[0]?.discrepancy_note_id;
        // Link to study subject if provided
        if (queryId && params.subjectId) {
            await database_1.pool.query(`
        INSERT INTO dn_study_subject_map (discrepancy_note_id, study_subject_id, column_name)
        VALUES ($1, $2, $3)
      `, [queryId, params.subjectId, params.fieldPath]);
        }
        // Link to event CRF if provided
        if (queryId && params.eventCrfId) {
            await database_1.pool.query(`
        INSERT INTO dn_event_crf_map (discrepancy_note_id, event_crf_id, column_name)
        VALUES ($1, $2, $3)
      `, [queryId, params.eventCrfId, params.fieldPath]);
        }
        logger_1.logger.info('Created validation query', { queryId, fieldPath: params.fieldPath });
        return queryId;
    }
    catch (error) {
        logger_1.logger.error('Error creating validation query:', error.message);
        return null;
    }
}
/**
 * Apply a single validation rule to a value
 */
function applyRule(rule, value, allData) {
    // Handle null/undefined values
    if (value === null || value === undefined || value === '') {
        if (rule.ruleType === 'required') {
            return { valid: false };
        }
        // Other rules don't apply to empty values
        return { valid: true };
    }
    switch (rule.ruleType) {
        case 'required':
            return { valid: value !== null && value !== undefined && value !== '' };
        case 'range':
            const numValue = Number(value);
            if (isNaN(numValue))
                return { valid: false };
            if (rule.minValue !== undefined && numValue < rule.minValue)
                return { valid: false };
            if (rule.maxValue !== undefined && numValue > rule.maxValue)
                return { valid: false };
            return { valid: true };
        case 'format':
            if (!rule.pattern)
                return { valid: true };
            try {
                const regex = new RegExp(rule.pattern);
                return { valid: regex.test(String(value)) };
            }
            catch {
                return { valid: true }; // Invalid regex = no validation
            }
        case 'consistency':
            const compareValue = getNestedValue(allData, rule.compareFieldPath || '');
            return { valid: compareValues(value, compareValue, rule.operator || '==') };
        case 'business_logic':
        case 'cross_form':
            // Custom expression evaluation would go here
            if (rule.customExpression) {
                try {
                    // Safe evaluation using Function constructor
                    const evalFn = new Function('value', 'data', `return ${rule.customExpression}`);
                    return { valid: Boolean(evalFn(value, allData)) };
                }
                catch {
                    return { valid: true };
                }
            }
            return { valid: true };
        default:
            return { valid: true };
    }
}
/**
 * Compare two values with an operator
 */
function compareValues(a, b, operator) {
    // Handle date comparison
    if (a instanceof Date || !isNaN(Date.parse(a))) {
        const dateA = new Date(a).getTime();
        const dateB = new Date(b).getTime();
        a = dateA;
        b = dateB;
    }
    switch (operator) {
        case '==': return a == b;
        case '===': return a === b;
        case '!=': return a != b;
        case '!==': return a !== b;
        case '>': return a > b;
        case '<': return a < b;
        case '>=': return a >= b;
        case '<=': return a <= b;
        default: return true;
    }
}
/**
 * Get nested value from object using dot notation
 */
function getNestedValue(obj, path) {
    if (!path)
        return undefined;
    return path.split('.').reduce((current, key) => current?.[key], obj);
}
/**
 * Map database row to ValidationRule interface
 */
function mapDbRowToRule(row) {
    return {
        id: row.id || row.validation_rule_id,
        crfId: row.crf_id,
        crfVersionId: row.crf_version_id,
        itemId: row.item_id,
        name: row.name,
        description: row.description || '',
        ruleType: row.rule_type,
        fieldPath: row.field_path,
        severity: row.severity || 'error',
        errorMessage: row.error_message,
        warningMessage: row.warning_message,
        active: row.active !== false,
        minValue: row.min_value ? Number(row.min_value) : undefined,
        maxValue: row.max_value ? Number(row.max_value) : undefined,
        pattern: row.pattern,
        operator: row.operator,
        compareFieldPath: row.compare_field_path,
        customExpression: row.custom_expression,
        dateCreated: row.date_created,
        dateUpdated: row.date_updated,
        createdBy: row.created_by || row.owner_id,
        updatedBy: row.updated_by || row.update_id
    };
}
exports.default = {
    initializeValidationRulesTable: exports.initializeValidationRulesTable,
    getRulesForCrf: exports.getRulesForCrf,
    getRulesForStudy: exports.getRulesForStudy,
    getRuleById: exports.getRuleById,
    createRule: exports.createRule,
    updateRule: exports.updateRule,
    toggleRule: exports.toggleRule,
    deleteRule: exports.deleteRule,
    validateFormData: exports.validateFormData
};
//# sourceMappingURL=validation-rules.service.js.map