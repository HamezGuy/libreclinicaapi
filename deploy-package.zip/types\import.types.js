"use strict";
/**
 * Data Import Types - Using LibreClinica Models
 * Matches SubjectDataBean, StudyEventDataBean, FormDataBean, ImportItemDataBean
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=import.types.js.map