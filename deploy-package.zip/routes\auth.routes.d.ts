/**
 * Authentication Routes
 *
 * Includes WoundScanner capture token endpoints
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=auth.routes.d.ts.map