"use strict";
/**
 * SOAP Client
 *
 * Custom SOAP client for LibreClinica Web Services
 * - Uses raw HTTP with WS-Security headers (LibreClinica specific)
 * - Handles authentication with MD5-hashed passwords
 * - Provides retry logic and error handling
 *
 * LibreClinica SOAP Web Services (at /libreclinica-ws/ws):
 * - Study Service: Uses v1:listAllRequest, v1:getMetadataRequest
 * - StudySubject Service: Uses v1:createRequest, v1:listAllByStudyRequest
 * - Data Service: Uses v1:importRequest
 * - Event Service: Uses v1:scheduleRequest
 *
 * IMPORTANT: LibreClinica requires WS-Security UsernameToken with MD5-hashed password!
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.resetSoapClient = exports.getSoapClient = exports.SoapClient = void 0;
const axios_1 = __importDefault(require("axios"));
const environment_1 = require("../../config/environment");
const logger_1 = require("../../config/logger");
const xml2js_1 = require("xml2js");
/**
 * Namespace mappings for LibreClinica SOAP services
 */
const SOAP_NAMESPACES = {
    study: 'http://openclinica.org/ws/study/v1',
    studySubject: 'http://openclinica.org/ws/studySubject/v1',
    data: 'http://openclinica.org/ws/data/v1',
    event: 'http://openclinica.org/ws/event/v1'
};
/**
 * SOAP Client Class
 * Custom implementation for LibreClinica's WS-Security requirements
 */
class SoapClient {
    constructor() {
        // Configuration with MD5-hashed password for WS-Security
        // LibreClinica 1.4: WS-Security improved, reduced timeout/retries needed
        this.config = {
            baseUrl: environment_1.config.libreclinica.soapUrl || 'http://localhost:8090/libreclinica-ws/ws',
            username: environment_1.config.libreclinica.soapUsername || 'root',
            password: environment_1.config.libreclinica.soapPassword || '25d55ad283aa400af464c76d713c07ad',
            timeout: 15000, // Reduced - LC 1.4 is more responsive with fixed WS-Security
            maxRetries: 2 // Reduced - LC 1.4 WS-Security works reliably now
        };
        // Create HTTP client
        this.httpClient = axios_1.default.create({
            timeout: this.config.timeout,
            headers: {
                'Content-Type': 'text/xml;charset=UTF-8',
                'Accept': 'text/xml, application/xml'
            }
        });
    }
    /**
     * Build WS-Security SOAP envelope
     */
    buildSoapEnvelope(serviceName, methodName, parameters) {
        const namespace = SOAP_NAMESPACES[serviceName];
        // Convert parameters to XML elements
        const parametersXml = this.buildParametersXml(parameters);
        return `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
                  xmlns:v1="${namespace}"
                  xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">
   <soapenv:Header>
      <wsse:Security soapenv:mustUnderstand="1">
         <wsse:UsernameToken>
            <wsse:Username>${this.config.username}</wsse:Username>
            <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">${this.config.password}</wsse:Password>
         </wsse:UsernameToken>
      </wsse:Security>
   </soapenv:Header>
   <soapenv:Body>
      <v1:${methodName}Request>
         ${parametersXml}
      </v1:${methodName}Request>
   </soapenv:Body>
</soapenv:Envelope>`;
    }
    /**
     * Convert parameters object to XML elements
     */
    buildParametersXml(params, prefix = 'v1') {
        if (!params || Object.keys(params).length === 0) {
            return '';
        }
        let xml = '';
        for (const [key, value] of Object.entries(params)) {
            if (value === null || value === undefined)
                continue;
            if (typeof value === 'object' && !Array.isArray(value)) {
                // Nested object
                xml += `<${prefix}:${key}>${this.buildParametersXml(value, prefix)}</${prefix}:${key}>`;
            }
            else if (Array.isArray(value)) {
                // Array - repeat the element
                for (const item of value) {
                    if (typeof item === 'object') {
                        xml += `<${prefix}:${key}>${this.buildParametersXml(item, prefix)}</${prefix}:${key}>`;
                    }
                    else {
                        xml += `<${prefix}:${key}>${this.escapeXml(String(item))}</${prefix}:${key}>`;
                    }
                }
            }
            else {
                xml += `<${prefix}:${key}>${this.escapeXml(String(value))}</${prefix}:${key}>`;
            }
        }
        return xml;
    }
    /**
     * Escape special XML characters
     */
    escapeXml(str) {
        return str
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&apos;');
    }
    /**
     * Parse SOAP response
     */
    async parseSoapResponse(xmlResponse) {
        try {
            const result = await (0, xml2js_1.parseStringPromise)(xmlResponse, {
                explicitArray: false,
                ignoreAttrs: false,
                tagNameProcessors: [(name) => name.replace(/^.*:/, '')]
            });
            // Extract body content
            const envelope = result.Envelope || result['SOAP-ENV:Envelope'] || result;
            const body = envelope.Body || envelope['SOAP-ENV:Body'];
            if (!body) {
                throw new Error('No SOAP Body found in response');
            }
            // Check for fault
            const fault = body.Fault || body['SOAP-ENV:Fault'];
            if (fault) {
                throw new Error(fault.faultstring || fault.faultcode || 'SOAP Fault');
            }
            // Return first child of body (the response element)
            const bodyKeys = Object.keys(body).filter(k => k !== '$');
            if (bodyKeys.length > 0) {
                return body[bodyKeys[0]];
            }
            return body;
        }
        catch (error) {
            logger_1.logger.error('Failed to parse SOAP response', { error: error.message });
            throw error;
        }
    }
    /**
     * Execute SOAP request with retry logic
     */
    async executeRequest(options) {
        const { serviceName, methodName, parameters, userId, username } = options;
        logger_1.logger.info('Executing SOAP request', {
            serviceName,
            methodName,
            userId,
            username: username || 'system'
        });
        let lastError;
        // Retry logic
        for (let attempt = 1; attempt <= this.config.maxRetries; attempt++) {
            try {
                const soapEnvelope = this.buildSoapEnvelope(serviceName, methodName, parameters);
                // Build the full service URL (e.g., /libreclinica-ws/ws/study/v1)
                const serviceUrl = `${this.config.baseUrl}/${serviceName}/v1`;
                logger_1.logger.debug('SOAP Request', {
                    url: serviceUrl,
                    serviceName,
                    methodName
                });
                const startTime = Date.now();
                const response = await this.httpClient.post(serviceUrl, soapEnvelope);
                const duration = Date.now() - startTime;
                logger_1.logger.info('SOAP request successful', {
                    serviceName,
                    methodName,
                    duration,
                    attempt,
                    status: response.status
                });
                const parsedResponse = await this.parseSoapResponse(response.data);
                return {
                    success: true,
                    data: parsedResponse
                };
            }
            catch (error) {
                lastError = error;
                const statusCode = error.response?.status;
                const responseData = error.response?.data;
                logger_1.logger.warn(`SOAP request failed (attempt ${attempt}/${this.config.maxRetries})`, {
                    serviceName,
                    methodName,
                    error: error.message,
                    statusCode,
                    attempt
                });
                // Don't retry on authentication errors
                if (statusCode === 401 || statusCode === 403) {
                    break;
                }
                // Try to parse fault from response
                if (responseData) {
                    try {
                        const fault = await this.parseSoapResponse(responseData);
                        logger_1.logger.debug('SOAP Fault details', { fault });
                    }
                    catch {
                        // Ignore parsing errors for fault
                    }
                }
                // Wait before retry (exponential backoff)
                if (attempt < this.config.maxRetries) {
                    await this.delay(attempt * 1000);
                }
            }
        }
        logger_1.logger.error('SOAP request failed after all retries', {
            serviceName,
            methodName,
            error: lastError.message
        });
        return {
            success: false,
            error: lastError.message,
            soapFault: lastError.response?.data
        };
    }
    /**
     * Test SOAP connection
     * Uses appropriate method for each service type
     */
    async testConnection(serviceName = 'study') {
        try {
            logger_1.logger.debug('Testing SOAP connection', { serviceName });
            // Use 'study' service for testing - it has a simple listAll method
            // studySubject requires study reference which makes it unsuitable for connection testing
            const testService = 'study';
            const result = await this.executeRequest({
                serviceName: testService,
                methodName: 'listAll',
                parameters: {}
            });
            logger_1.logger.info(`SOAP connection test: ${result.success ? 'SUCCESS' : 'FAILED'}`, {
                serviceName: testService,
                success: result.success
            });
            return result.success;
        }
        catch (error) {
            logger_1.logger.error(`SOAP connection test failed`, {
                error: error.message
            });
            return false;
        }
    }
    /**
     * Clear any cached state (for reconnection)
     */
    clearClients() {
        logger_1.logger.info('SOAP client state cleared');
        // Nothing to clear with our stateless HTTP approach
    }
    /**
     * Delay helper for retry logic
     */
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    /**
     * Parse SOAP error
     */
    parseSoapError(error) {
        if (error.response?.data) {
            const data = error.response.data;
            if (typeof data === 'string' && data.includes('faultstring')) {
                const match = data.match(/<faultstring>([^<]+)<\/faultstring>/);
                if (match) {
                    return match[1];
                }
            }
        }
        return error.message || 'Unknown SOAP error';
    }
    /**
     * Get configuration (for diagnostics)
     */
    getConfig() {
        return {
            baseUrl: this.config.baseUrl,
            username: this.config.username,
            passwordSet: !!this.config.password
        };
    }
}
exports.SoapClient = SoapClient;
/**
 * Singleton instance
 */
let soapClientInstance = null;
/**
 * Get SOAP client singleton
 */
const getSoapClient = () => {
    if (!soapClientInstance) {
        soapClientInstance = new SoapClient();
    }
    return soapClientInstance;
};
exports.getSoapClient = getSoapClient;
/**
 * Reset SOAP client singleton (useful for testing/reconnection)
 */
const resetSoapClient = () => {
    soapClientInstance = null;
};
exports.resetSoapClient = resetSoapClient;
exports.default = exports.getSoapClient;
//# sourceMappingURL=soapClient.js.map