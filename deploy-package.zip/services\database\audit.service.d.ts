/**
 * Audit Service
 *
 * Handles audit trail queries from LibreClinica database
 * - Query audit_log_event table
 * - Filter by study, subject, user, date range
 * - Export audit trail (CSV, PDF, JSON)
 * - Subject-specific audit history
 *
 * Compliance: 21 CFR Part 11 §11.10(e) - Audit Trail
 */
import { AuditQuery, AuditLogEvent, PaginatedResponse, AuditExportRequest } from '../../types';
/**
 * Get audit trail with filters
 * Main method for querying audit history
 */
export declare const getAuditTrail: (query: AuditQuery) => Promise<PaginatedResponse<AuditLogEvent>>;
/**
 * Get audit trail for specific subject
 * Returns complete audit history for a subject
 */
export declare const getSubjectAudit: (subjectId: number, page?: number, limit?: number) => Promise<PaginatedResponse<AuditLogEvent>>;
/**
 * Get recent audit events
 * Returns most recent audit events across all studies
 * COMBINES: audit_log_event (data changes) + audit_user_login (login/logout events)
 */
export declare const getRecentAuditEvents: (limit?: number) => Promise<AuditLogEvent[]>;
/**
 * Export audit trail to CSV
 * Note: audit_log_event does NOT have study_id or subject_id columns
 * We filter by audit_table and date range instead
 */
export declare const exportAuditTrailCSV: (request: AuditExportRequest) => Promise<string>;
/**
 * Get audit statistics
 * COMBINES: audit_log_event (data changes) + audit_user_login (login/logout events)
 */
export declare const getAuditStatistics: (days?: number) => Promise<any>;
/**
 * Get audit event types from database
 */
export declare const getAuditEventTypes: () => Promise<any[]>;
/**
 * Get auditable tables list
 */
export declare const getAuditableTables: () => Promise<any[]>;
/**
 * Get form/CRF specific audit trail
 */
export declare const getFormAudit: (eventCrfId: number) => Promise<any[]>;
/**
 * Get audit by date range with summary
 */
export declare const getAuditSummary: (startDate: string, endDate: string) => Promise<any>;
/**
 * Get compliance report
 * Returns audit data formatted for 21 CFR Part 11 compliance reports
 */
export declare const getComplianceReport: (request: {
    startDate: string;
    endDate: string;
    studyId?: number;
}) => Promise<any>;
/**
 * Record audit event directly to database
 * Uses LibreClinica's CORRECT audit_log_event schema
 */
export declare const recordAuditEvent: (data: {
    audit_table: string;
    entity_id: number;
    user_id: number;
    user_name: string;
    audit_log_event_type_id: number;
    old_value?: string;
    new_value?: string;
    reason_for_change?: string;
    study_id?: number;
    event_crf_id?: number;
    study_event_id?: number;
}) => Promise<{
    success: boolean;
    data?: {
        audit_id: number;
    };
    message?: string;
}>;
/**
 * Common audit event types for tracking user actions
 */
export declare const AuditEventTypes: {
    FORM_VIEWED: number;
    FORM_CREATED: number;
    FORM_UPDATED: number;
    FORM_DELETED: number;
    FORM_SIGNED: number;
    SUBJECT_VIEWED: number;
    SUBJECT_CREATED: number;
    SUBJECT_UPDATED: number;
    STUDY_ACCESSED: number;
    STUDY_EXPORTED: number;
    QUERY_CREATED: number;
    QUERY_RESPONDED: number;
    QUERY_CLOSED: number;
    SDV_VERIFIED: number;
    SDV_REJECTED: number;
    REPORT_GENERATED: number;
    AUDIT_EXPORTED: number;
};
/**
 * Track user action - Simplified API for controllers to record audit events
 * Uses LibreClinica's CORRECT audit_log_event schema
 *
 * @example
 * await trackUserAction({
 *   userId: user.userId,
 *   username: user.username,
 *   action: 'FORM_VIEWED',
 *   entityType: 'event_crf',
 *   entityId: eventCrfId,
 *   details: 'Viewed wound assessment form'
 * });
 */
export declare const trackUserAction: (data: {
    userId: number;
    username: string;
    action: string;
    entityType: string;
    entityId?: number;
    entityName?: string;
    details?: string;
    oldValue?: string;
    newValue?: string;
    studyId?: number;
    eventCrfId?: number;
    studyEventId?: number;
}) => Promise<{
    success: boolean;
    auditId?: number;
}>;
/**
 * Track document/form access
 */
export declare const trackDocumentAccess: (userId: number, username: string, documentType: string, documentId: number, documentName?: string, action?: "view" | "edit" | "sign" | "export") => Promise<void>;
/**
 * Get audit logs with flexible filtering
 * Alias for getAuditTrail with additional parameters
 */
export declare const getAuditLogs: (params: {
    studyId?: number;
    userId?: number;
    eventType?: string;
    startDate?: string;
    endDate?: string;
    limit?: number;
    offset?: number;
}) => Promise<any>;
/**
 * Get subject audit trail
 * Alias for getSubjectAudit with API response format
 */
export declare const getSubjectAuditTrail: (subjectId: number) => Promise<any>;
/**
 * Get form audit trail
 * Alias for getFormAudit with API response format
 */
export declare const getFormAuditTrail: (eventCrfId: number) => Promise<any>;
/**
 * Record electronic signature to database
 */
export declare const recordElectronicSignature: (data: {
    entity_type: string;
    entity_id: number;
    signer_username: string;
    meaning: string;
    reason_for_change?: string;
    signed_at: Date;
}) => Promise<{
    success: boolean;
    data?: {
        signature_id: number;
    };
    message?: string;
}>;
/**
 * Get audit statistics for dashboard
 */
export declare const getAuditStats: (days?: number) => Promise<any>;
/**
 * Export audit logs in specified format
 */
export declare const exportAuditLogs: (params: {
    studyId?: number;
    startDate?: string;
    endDate?: string;
}, format?: "csv" | "json") => Promise<any>;
/**
 * Get login history from audit_user_login table
 * Returns all login/logout/failed login events
 *
 * 21 CFR Part 11 §11.10(e) - Audit Trail for login events
 *
 * @param params.userId - Filter by specific user
 * @param params.startDate - Filter events after this date
 * @param params.endDate - Filter events before this date
 * @param params.status - Filter by status: 'success' (1), 'failed' (0), 'logout' (2), or 'all'
 * @param params.limit - Maximum number of records
 * @param params.offset - Pagination offset
 */
export declare const getLoginHistory: (params: {
    userId?: number;
    username?: string;
    startDate?: string;
    endDate?: string;
    status?: "success" | "failed" | "logout" | "all";
    limit?: number;
    offset?: number;
}) => Promise<{
    success: boolean;
    data: any[];
    pagination: {
        total: number;
        limit: number;
        offset: number;
    };
}>;
/**
 * Get login statistics for compliance reporting
 * Returns counts of successful logins, failed attempts, and logouts
 */
export declare const getLoginStatistics: (days?: number) => Promise<{
    success: boolean;
    data: {
        successfulLogins: number;
        failedLogins: number;
        logouts: number;
        uniqueUsers: number;
        byDay: Array<{
            date: string;
            success: number;
            failed: number;
            logout: number;
        }>;
    };
}>;
declare const _default: {
    getAuditTrail: (query: AuditQuery) => Promise<PaginatedResponse<AuditLogEvent>>;
    getSubjectAudit: (subjectId: number, page?: number, limit?: number) => Promise<PaginatedResponse<AuditLogEvent>>;
    getRecentAuditEvents: (limit?: number) => Promise<AuditLogEvent[]>;
    exportAuditTrailCSV: (request: AuditExportRequest) => Promise<string>;
    getAuditStatistics: (days?: number) => Promise<any>;
    getAuditEventTypes: () => Promise<any[]>;
    getAuditableTables: () => Promise<any[]>;
    getFormAudit: (eventCrfId: number) => Promise<any[]>;
    getAuditSummary: (startDate: string, endDate: string) => Promise<any>;
    getComplianceReport: (request: {
        startDate: string;
        endDate: string;
        studyId?: number;
    }) => Promise<any>;
    recordAuditEvent: (data: {
        audit_table: string;
        entity_id: number;
        user_id: number;
        user_name: string;
        audit_log_event_type_id: number;
        old_value?: string;
        new_value?: string;
        reason_for_change?: string;
        study_id?: number;
        event_crf_id?: number;
        study_event_id?: number;
    }) => Promise<{
        success: boolean;
        data?: {
            audit_id: number;
        };
        message?: string;
    }>;
    getAuditLogs: (params: {
        studyId?: number;
        userId?: number;
        eventType?: string;
        startDate?: string;
        endDate?: string;
        limit?: number;
        offset?: number;
    }) => Promise<any>;
    getSubjectAuditTrail: (subjectId: number) => Promise<any>;
    getFormAuditTrail: (eventCrfId: number) => Promise<any>;
    recordElectronicSignature: (data: {
        entity_type: string;
        entity_id: number;
        signer_username: string;
        meaning: string;
        reason_for_change?: string;
        signed_at: Date;
    }) => Promise<{
        success: boolean;
        data?: {
            signature_id: number;
        };
        message?: string;
    }>;
    getAuditStats: (days?: number) => Promise<any>;
    exportAuditLogs: (params: {
        studyId?: number;
        startDate?: string;
        endDate?: string;
    }, format?: "csv" | "json") => Promise<any>;
    trackUserAction: (data: {
        userId: number;
        username: string;
        action: string;
        entityType: string;
        entityId?: number;
        entityName?: string;
        details?: string;
        oldValue?: string;
        newValue?: string;
        studyId?: number;
        eventCrfId?: number;
        studyEventId?: number;
    }) => Promise<{
        success: boolean;
        auditId?: number;
    }>;
    trackDocumentAccess: (userId: number, username: string, documentType: string, documentId: number, documentName?: string, action?: "view" | "edit" | "sign" | "export") => Promise<void>;
    AuditEventTypes: {
        FORM_VIEWED: number;
        FORM_CREATED: number;
        FORM_UPDATED: number;
        FORM_DELETED: number;
        FORM_SIGNED: number;
        SUBJECT_VIEWED: number;
        SUBJECT_CREATED: number;
        SUBJECT_UPDATED: number;
        STUDY_ACCESSED: number;
        STUDY_EXPORTED: number;
        QUERY_CREATED: number;
        QUERY_RESPONDED: number;
        QUERY_CLOSED: number;
        SDV_VERIFIED: number;
        SDV_REJECTED: number;
        REPORT_GENERATED: number;
        AUDIT_EXPORTED: number;
    };
    getLoginHistory: (params: {
        userId?: number;
        username?: string;
        startDate?: string;
        endDate?: string;
        status?: "success" | "failed" | "logout" | "all";
        limit?: number;
        offset?: number;
    }) => Promise<{
        success: boolean;
        data: any[];
        pagination: {
            total: number;
            limit: number;
            offset: number;
        };
    }>;
    getLoginStatistics: (days?: number) => Promise<{
        success: boolean;
        data: {
            successfulLogins: number;
            failedLogins: number;
            logouts: number;
            uniqueUsers: number;
            byDay: Array<{
                date: string;
                success: number;
                failed: number;
                logout: number;
            }>;
        };
    }>;
};
export default _default;
//# sourceMappingURL=audit.service.d.ts.map