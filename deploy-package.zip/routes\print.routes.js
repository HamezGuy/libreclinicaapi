"use strict";
/**
 * Print Routes
 *
 * API endpoints for PDF generation and printing:
 * - Form PDF generation (completed forms)
 * - Blank form PDF generation (templates)
 * - Casebook generation (all forms for a subject)
 * - Audit trail PDF generation
 *
 * 21 CFR Part 11: All print events are logged to audit trail
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_middleware_1 = require("../middleware/auth.middleware");
const logger_1 = require("../config/logger");
const pdfService = __importStar(require("../services/pdf/pdf.service"));
const router = (0, express_1.Router)();
/**
 * Parse PDF options from query parameters
 */
function parsePdfOptions(query) {
    return {
        pageSize: query.pageSize === 'A4' ? 'A4' : 'Letter',
        orientation: query.orientation === 'landscape' ? 'landscape' : 'portrait',
        watermark: query.watermark,
        includeHeader: query.includeHeader !== 'false',
        includeFooter: query.includeFooter !== 'false',
        includeAuditTrail: query.includeAuditTrail === 'true',
        includeSignatures: query.includeSignatures !== 'false'
    };
}
/**
 * GET /api/print/forms/:eventCrfId/pdf
 * Generate PDF for a completed form
 */
router.get('/forms/:eventCrfId/pdf', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const eventCrfId = parseInt(req.params.eventCrfId);
        const options = parsePdfOptions(req.query);
        const user = req.user;
        if (isNaN(eventCrfId)) {
            return res.status(400).json({ success: false, message: 'Invalid event CRF ID' });
        }
        logger_1.logger.info('Generating form PDF', { eventCrfId, userId: user.userId });
        const result = await pdfService.generateFormPDF(eventCrfId, options, user.userId, user.username);
        if (!result.success) {
            return res.status(404).json({ success: false, message: result.error });
        }
        res.setHeader('Content-Type', result.contentType || 'text/html');
        res.setHeader('Content-Disposition', `inline; filename="${result.filename}"`);
        res.send(result.buffer);
    }
    catch (error) {
        logger_1.logger.error('Error generating form PDF', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/print/forms/:eventCrfId/download
 * Download PDF for a completed form
 */
router.get('/forms/:eventCrfId/download', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const eventCrfId = parseInt(req.params.eventCrfId);
        const options = parsePdfOptions(req.query);
        const user = req.user;
        if (isNaN(eventCrfId)) {
            return res.status(400).json({ success: false, message: 'Invalid event CRF ID' });
        }
        const result = await pdfService.generateFormPDF(eventCrfId, options, user.userId, user.username);
        if (!result.success) {
            return res.status(404).json({ success: false, message: result.error });
        }
        res.setHeader('Content-Type', result.contentType || 'text/html');
        res.setHeader('Content-Disposition', `attachment; filename="${result.filename}"`);
        res.send(result.buffer);
    }
    catch (error) {
        logger_1.logger.error('Error downloading form PDF', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/print/templates/:crfVersionId/blank-pdf
 * Generate blank form PDF (template)
 */
router.get('/templates/:crfVersionId/blank-pdf', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const crfVersionId = parseInt(req.params.crfVersionId);
        const options = parsePdfOptions(req.query);
        const user = req.user;
        if (isNaN(crfVersionId)) {
            return res.status(400).json({ success: false, message: 'Invalid CRF version ID' });
        }
        logger_1.logger.info('Generating blank form PDF', { crfVersionId, userId: user.userId });
        const result = await pdfService.generateBlankFormPDF(crfVersionId, options, user.userId, user.username);
        if (!result.success) {
            return res.status(404).json({ success: false, message: result.error });
        }
        res.setHeader('Content-Type', result.contentType || 'text/html');
        res.setHeader('Content-Disposition', `inline; filename="${result.filename}"`);
        res.send(result.buffer);
    }
    catch (error) {
        logger_1.logger.error('Error generating blank form PDF', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/print/subjects/:studySubjectId/casebook
 * Generate casebook PDF (all forms for a subject)
 */
router.get('/subjects/:studySubjectId/casebook', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const studySubjectId = parseInt(req.params.studySubjectId);
        const options = parsePdfOptions(req.query);
        const user = req.user;
        if (isNaN(studySubjectId)) {
            return res.status(400).json({ success: false, message: 'Invalid study subject ID' });
        }
        logger_1.logger.info('Generating casebook PDF', { studySubjectId, userId: user.userId });
        const result = await pdfService.generateCasebookPDF(studySubjectId, options, user.userId, user.username);
        if (!result.success) {
            return res.status(404).json({ success: false, message: result.error });
        }
        res.setHeader('Content-Type', result.contentType || 'text/html');
        res.setHeader('Content-Disposition', `inline; filename="${result.filename}"`);
        res.send(result.buffer);
    }
    catch (error) {
        logger_1.logger.error('Error generating casebook PDF', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/print/audit/:entityType/:entityId/pdf
 * Generate audit trail PDF
 */
router.get('/audit/:entityType/:entityId/pdf', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const { entityType } = req.params;
        const entityId = parseInt(req.params.entityId);
        const options = parsePdfOptions(req.query);
        const user = req.user;
        if (isNaN(entityId)) {
            return res.status(400).json({ success: false, message: 'Invalid entity ID' });
        }
        // Validate entity type
        const validEntityTypes = ['event_crf', 'study_subject', 'study_event', 'study'];
        if (!validEntityTypes.includes(entityType)) {
            return res.status(400).json({
                success: false,
                message: `Invalid entity type. Must be one of: ${validEntityTypes.join(', ')}`
            });
        }
        logger_1.logger.info('Generating audit trail PDF', { entityType, entityId, userId: user.userId });
        const result = await pdfService.generateAuditTrailPDF(entityType, entityId, options, user.userId, user.username);
        if (!result.success) {
            return res.status(404).json({ success: false, message: result.error });
        }
        res.setHeader('Content-Type', result.contentType || 'text/html');
        res.setHeader('Content-Disposition', `inline; filename="${result.filename}"`);
        res.send(result.buffer);
    }
    catch (error) {
        logger_1.logger.error('Error generating audit trail PDF', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/print/forms/:eventCrfId/data
 * Get form data for client-side rendering (used by frontend print preview)
 */
router.get('/forms/:eventCrfId/data', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const eventCrfId = parseInt(req.params.eventCrfId);
        if (isNaN(eventCrfId)) {
            return res.status(400).json({ success: false, message: 'Invalid event CRF ID' });
        }
        const formData = await pdfService.getFormDataForPrint(eventCrfId);
        if (!formData) {
            return res.status(404).json({ success: false, message: 'Form not found' });
        }
        res.json({ success: true, data: formData });
    }
    catch (error) {
        logger_1.logger.error('Error getting form print data', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/print/templates/:crfVersionId/data
 * Get blank form data for client-side rendering
 */
router.get('/templates/:crfVersionId/data', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const crfVersionId = parseInt(req.params.crfVersionId);
        if (isNaN(crfVersionId)) {
            return res.status(400).json({ success: false, message: 'Invalid CRF version ID' });
        }
        const formData = await pdfService.getBlankFormDataForPrint(crfVersionId);
        if (!formData) {
            return res.status(404).json({ success: false, message: 'Form template not found' });
        }
        res.json({ success: true, data: formData });
    }
    catch (error) {
        logger_1.logger.error('Error getting blank form print data', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/print/subjects/:studySubjectId/casebook/data
 * Get casebook data for client-side rendering
 */
router.get('/subjects/:studySubjectId/casebook/data', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const studySubjectId = parseInt(req.params.studySubjectId);
        const user = req.user;
        if (isNaN(studySubjectId)) {
            return res.status(400).json({ success: false, message: 'Invalid study subject ID' });
        }
        const casebookData = await pdfService.getCasebookDataForPrint(studySubjectId, user.username);
        if (!casebookData) {
            return res.status(404).json({ success: false, message: 'Subject not found' });
        }
        res.json({ success: true, data: casebookData });
    }
    catch (error) {
        logger_1.logger.error('Error getting casebook print data', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/print/audit/:entityType/:entityId/data
 * Get audit trail data for client-side rendering
 */
router.get('/audit/:entityType/:entityId/data', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const { entityType } = req.params;
        const entityId = parseInt(req.params.entityId);
        const user = req.user;
        if (isNaN(entityId)) {
            return res.status(400).json({ success: false, message: 'Invalid entity ID' });
        }
        const auditData = await pdfService.getAuditTrailForPrint(entityType, entityId, user.username);
        if (!auditData) {
            return res.status(404).json({ success: false, message: 'Audit trail not found' });
        }
        res.json({ success: true, data: auditData });
    }
    catch (error) {
        logger_1.logger.error('Error getting audit trail print data', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
exports.default = router;
//# sourceMappingURL=print.routes.js.map