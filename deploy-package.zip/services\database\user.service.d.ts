/**
 * User Service
 *
 * Handles user management (CRUD operations)
 * RED X Feature: User Management API
 *
 * LibreClinica has NO user management API - we build it!
 */
import { User, PaginatedResponse } from '../../types';
/**
 * Get users with filters
 */
export declare const getUsers: (filters: {
    studyId?: number;
    role?: string;
    enabled?: boolean;
    page?: number;
    limit?: number;
}) => Promise<PaginatedResponse<User>>;
/**
 * Get user by ID
 */
export declare const getUserById: (userId: number) => Promise<User | null>;
/**
 * Create new user - supports ALL LibreClinica user_account fields
 */
export declare const createUser: (data: {
    username: string;
    firstName: string;
    lastName: string;
    email: string;
    password: string;
    phone?: string;
    institutionalAffiliation?: string;
    userTypeId?: number;
    role?: string;
    studyId?: number;
    activeStudyId?: number;
    runWebservices?: boolean;
    enableApiKey?: boolean;
    apiKey?: string;
    accessCode?: string;
    authtype?: "STANDARD" | "MARKED" | "TWO_FACTOR";
    authsecret?: string;
    passwdChallengeQuestion?: string;
    passwdChallengeAnswer?: string;
    timeZone?: string;
}, creatorId: number) => Promise<{
    success: boolean;
    userId?: number;
    message?: string;
}>;
/**
 * Update user - supports ALL LibreClinica user_account fields
 */
export declare const updateUser: (userId: number, data: {
    firstName?: string;
    lastName?: string;
    email?: string;
    phone?: string;
    institutionalAffiliation?: string;
    enabled?: boolean;
    accountNonLocked?: boolean;
    userTypeId?: number;
    activeStudyId?: number;
    runWebservices?: boolean;
    enableApiKey?: boolean;
    apiKey?: string;
    accessCode?: string;
    authtype?: "STANDARD" | "MARKED" | "TWO_FACTOR";
    authsecret?: string;
    passwdChallengeQuestion?: string;
    passwdChallengeAnswer?: string;
    timeZone?: string;
}, updaterId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Soft delete user (disable)
 */
export declare const deleteUser: (userId: number, deleterId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Assign user to study with role
 * Note: roleName should match LibreClinica role names exactly
 * Valid role names: admin, coordinator, director, Investigator, ra, monitor, ra2
 */
export declare const assignUserToStudy: (userId: number, studyId: number, roleName: string, assignerId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Get all available roles
 */
export declare const getAvailableRoles: () => {
    id: number;
    name: string;
    description: string;
}[];
/**
 * Get user's role for a specific study with permissions
 */
export declare const getUserStudyRole: (userId: number, studyId: number) => Promise<{
    roleName: string;
    canSubmitData: boolean;
    canExtractData: boolean;
    canManageStudy: boolean;
    canMonitor: boolean;
} | null>;
declare const _default: {
    getUsers: (filters: {
        studyId?: number;
        role?: string;
        enabled?: boolean;
        page?: number;
        limit?: number;
    }) => Promise<PaginatedResponse<User>>;
    getUserById: (userId: number) => Promise<User | null>;
    createUser: (data: {
        username: string;
        firstName: string;
        lastName: string;
        email: string;
        password: string;
        phone?: string;
        institutionalAffiliation?: string;
        userTypeId?: number;
        role?: string;
        studyId?: number;
        activeStudyId?: number;
        runWebservices?: boolean;
        enableApiKey?: boolean;
        apiKey?: string;
        accessCode?: string;
        authtype?: "STANDARD" | "MARKED" | "TWO_FACTOR";
        authsecret?: string;
        passwdChallengeQuestion?: string;
        passwdChallengeAnswer?: string;
        timeZone?: string;
    }, creatorId: number) => Promise<{
        success: boolean;
        userId?: number;
        message?: string;
    }>;
    updateUser: (userId: number, data: {
        firstName?: string;
        lastName?: string;
        email?: string;
        phone?: string;
        institutionalAffiliation?: string;
        enabled?: boolean;
        accountNonLocked?: boolean;
        userTypeId?: number;
        activeStudyId?: number;
        runWebservices?: boolean;
        enableApiKey?: boolean;
        apiKey?: string;
        accessCode?: string;
        authtype?: "STANDARD" | "MARKED" | "TWO_FACTOR";
        authsecret?: string;
        passwdChallengeQuestion?: string;
        passwdChallengeAnswer?: string;
        timeZone?: string;
    }, updaterId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    deleteUser: (userId: number, deleterId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    assignUserToStudy: (userId: number, studyId: number, roleName: string, assignerId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    getAvailableRoles: () => {
        id: number;
        name: string;
        description: string;
    }[];
    getUserStudyRole: (userId: number, studyId: number) => Promise<{
        roleName: string;
        canSubmitData: boolean;
        canExtractData: boolean;
        canManageStudy: boolean;
        canMonitor: boolean;
    } | null>;
};
export default _default;
//# sourceMappingURL=user.service.d.ts.map