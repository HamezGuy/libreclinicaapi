/**
 * SOAP Health & Diagnostics Routes
 *
 * Provides endpoints to:
 * - Check SOAP connection status
 * - Test individual SOAP services
 * - Get SOAP configuration details
 * - Run SOAP diagnostics
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=soap.routes.d.ts.map