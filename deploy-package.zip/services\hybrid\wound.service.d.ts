/**
 * Wound Service (Hybrid)
 *
 * Wound capture session management with LibreClinica integration
 * - Creates and manages wound capture sessions
 * - Stores images and measurements
 * - Handles electronic signatures
 * - Submits to LibreClinica via SOAP
 *
 * 21 CFR Part 11 Compliance:
 * - All operations logged to audit trail
 * - Electronic signatures with hash verification
 * - Data integrity checks throughout
 */
import { WoundSession, CreateSessionRequest, CreateSessionResponse, ImageUploadResponse, WoundMeasurement, SubmitMeasurementsRequest, SubmitMeasurementsResponse, SignSessionRequest, SignSessionResponse, SubmitToLibreClinicaRequest, SubmitToLibreClinicaResponse, AuditEntry, WoundApiResponse, PaginatedWoundResponse } from '../../types/wound.types';
/**
 * Create a new wound capture session
 */
export declare const createSession: (request: CreateSessionRequest, userId: string, userName: string) => Promise<CreateSessionResponse>;
/**
 * Get session by ID
 */
export declare const getSession: (sessionId: string) => Promise<WoundApiResponse<WoundSession>>;
/**
 * Get sessions for a patient
 */
export declare const getPatientSessions: (patientId: string, page?: number, limit?: number) => Promise<PaginatedWoundResponse<WoundSession>>;
/**
 * Upload wound image
 */
export declare const uploadImage: (sessionId: string, imageData: Buffer, originalFilename: string, contentType: string, providedHash: string, userId: string) => Promise<ImageUploadResponse>;
/**
 * Submit wound measurements
 */
export declare const submitMeasurements: (request: SubmitMeasurementsRequest, userId: string, userName: string) => Promise<SubmitMeasurementsResponse>;
/**
 * Get measurements for a session
 */
export declare const getSessionMeasurements: (sessionId: string) => Promise<WoundApiResponse<WoundMeasurement[]>>;
/**
 * Apply electronic signature to session
 */
export declare const signSession: (request: SignSessionRequest, userId: string) => Promise<SignSessionResponse>;
/**
 * Submit wound session to LibreClinica
 */
export declare const submitToLibreClinica: (request: SubmitToLibreClinicaRequest, userId: number, userName: string) => Promise<SubmitToLibreClinicaResponse>;
/**
 * Log audit entry
 */
export declare const logAuditEntry: (entry: Partial<AuditEntry>) => Promise<void>;
/**
 * Submit batch audit entries from iOS
 */
export declare const submitAuditEntries: (entries: AuditEntry[]) => Promise<{
    received: boolean;
    count: number;
}>;
declare const _default: {
    createSession: (request: CreateSessionRequest, userId: string, userName: string) => Promise<CreateSessionResponse>;
    getSession: (sessionId: string) => Promise<WoundApiResponse<WoundSession>>;
    getPatientSessions: (patientId: string, page?: number, limit?: number) => Promise<PaginatedWoundResponse<WoundSession>>;
    uploadImage: (sessionId: string, imageData: Buffer, originalFilename: string, contentType: string, providedHash: string, userId: string) => Promise<ImageUploadResponse>;
    submitMeasurements: (request: SubmitMeasurementsRequest, userId: string, userName: string) => Promise<SubmitMeasurementsResponse>;
    getSessionMeasurements: (sessionId: string) => Promise<WoundApiResponse<WoundMeasurement[]>>;
    signSession: (request: SignSessionRequest, userId: string) => Promise<SignSessionResponse>;
    submitToLibreClinica: (request: SubmitToLibreClinicaRequest, userId: number, userName: string) => Promise<SubmitToLibreClinicaResponse>;
    logAuditEntry: (entry: Partial<AuditEntry>) => Promise<void>;
    submitAuditEntries: (entries: AuditEntry[]) => Promise<{
        received: boolean;
        count: number;
    }>;
};
export default _default;
//# sourceMappingURL=wound.service.d.ts.map