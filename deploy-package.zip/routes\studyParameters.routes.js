"use strict";
/**
 * Study Parameters Routes
 *
 * API endpoints for managing study configuration parameters.
 * These control enrollment behavior, subject ID generation, etc.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const authorization_middleware_1 = require("../middleware/authorization.middleware");
const studyParamsService = __importStar(require("../services/database/studyParameters.service"));
const logger_1 = require("../config/logger");
const router = express_1.default.Router();
// All routes require authentication
router.use(auth_middleware_1.authMiddleware);
/**
 * GET /api/study-parameters/available
 * Get all available study parameter definitions (reference data)
 */
router.get('/available', async (req, res) => {
    try {
        const parameters = await studyParamsService.getAvailableParameters();
        res.json({ success: true, data: parameters });
    }
    catch (error) {
        logger_1.logger.error('Failed to get available parameters', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/study-parameters/:studyId
 * Get study parameters for a specific study
 */
router.get('/:studyId', async (req, res) => {
    try {
        const studyId = parseInt(req.params.studyId);
        if (isNaN(studyId)) {
            res.status(400).json({ success: false, message: 'Invalid study ID' });
            return;
        }
        const config = await studyParamsService.getStudyParameters(studyId);
        res.json({ success: true, data: config });
    }
    catch (error) {
        logger_1.logger.error('Failed to get study parameters', {
            studyId: req.params.studyId,
            error: error.message
        });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/study-parameters/:studyId/raw
 * Get raw parameter values for editing
 */
router.get('/:studyId/raw', async (req, res) => {
    try {
        const studyId = parseInt(req.params.studyId);
        if (isNaN(studyId)) {
            res.status(400).json({ success: false, message: 'Invalid study ID' });
            return;
        }
        const params = await studyParamsService.getRawStudyParameters(studyId);
        res.json({ success: true, data: params });
    }
    catch (error) {
        logger_1.logger.error('Failed to get raw study parameters', {
            studyId: req.params.studyId,
            error: error.message
        });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * PUT /api/study-parameters/:studyId
 * Update study parameters (admin/coordinator only)
 */
router.put('/:studyId', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), async (req, res) => {
    try {
        const studyId = parseInt(req.params.studyId);
        const user = req.user;
        if (isNaN(studyId)) {
            res.status(400).json({ success: false, message: 'Invalid study ID' });
            return;
        }
        const parameters = req.body;
        if (!parameters || typeof parameters !== 'object') {
            res.status(400).json({ success: false, message: 'Parameters object required' });
            return;
        }
        await studyParamsService.saveStudyParameters(studyId, parameters, user.userId);
        // Return the updated config
        const updatedConfig = await studyParamsService.getStudyParameters(studyId);
        res.json({ success: true, data: updatedConfig, message: 'Parameters saved successfully' });
    }
    catch (error) {
        logger_1.logger.error('Failed to save study parameters', {
            studyId: req.params.studyId,
            error: error.message
        });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * POST /api/study-parameters/:studyId/initialize
 * Initialize default parameters for a new study (admin only)
 */
router.post('/:studyId/initialize', (0, authorization_middleware_1.requireRole)('admin'), async (req, res) => {
    try {
        const studyId = parseInt(req.params.studyId);
        const user = req.user;
        if (isNaN(studyId)) {
            res.status(400).json({ success: false, message: 'Invalid study ID' });
            return;
        }
        await studyParamsService.initializeStudyParameters(studyId, user.userId);
        const config = await studyParamsService.getStudyParameters(studyId);
        res.json({ success: true, data: config, message: 'Parameters initialized' });
    }
    catch (error) {
        logger_1.logger.error('Failed to initialize study parameters', {
            studyId: req.params.studyId,
            error: error.message
        });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/study-parameters/:studyId/next-subject-id
 * Generate next subject ID based on study settings
 */
router.get('/:studyId/next-subject-id', async (req, res) => {
    try {
        const studyId = parseInt(req.params.studyId);
        if (isNaN(studyId)) {
            res.status(400).json({ success: false, message: 'Invalid study ID' });
            return;
        }
        const nextId = await studyParamsService.generateNextSubjectId(studyId);
        res.json({ success: true, data: { nextSubjectId: nextId } });
    }
    catch (error) {
        logger_1.logger.error('Failed to generate next subject ID', {
            studyId: req.params.studyId,
            error: error.message
        });
        res.status(500).json({ success: false, message: error.message });
    }
});
exports.default = router;
//# sourceMappingURL=studyParameters.routes.js.map