"use strict";
/**
 * Double Data Entry (DDE) Routes
 *
 * API endpoints for DDE workflow including:
 * - Status checks
 * - Second entry submission
 * - Comparison retrieval
 * - Discrepancy resolution
 * - Finalization
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_middleware_1 = require("../middleware/auth.middleware");
const logger_1 = require("../config/logger");
const dde_service_1 = require("../services/database/dde.service");
const router = (0, express_1.Router)();
/**
 * Require data manager role for resolution operations
 */
const requireDataManager = async (req, res, next) => {
    const user = req.user;
    if (!user) {
        return res.status(401).json({ success: false, message: 'Not authenticated' });
    }
    const allowedRoles = ['admin', 'data_manager', 'clinical_research_coordinator'];
    if (!allowedRoles.includes(user.role)) {
        return res.status(403).json({
            success: false,
            message: 'Data manager role required for this operation'
        });
    }
    next();
};
// ============================================================================
// Status & Checks
// ============================================================================
/**
 * GET /api/dde/forms/:eventCrfId/status
 * Get DDE status for a form
 */
router.get('/forms/:eventCrfId/status', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const eventCrfId = parseInt(req.params.eventCrfId);
        const [isRequired, status] = await Promise.all([
            (0, dde_service_1.isDDERequired)(eventCrfId),
            (0, dde_service_1.getDDEStatus)(eventCrfId)
        ]);
        res.json({
            success: true,
            data: {
                isRequired,
                status
            }
        });
    }
    catch (error) {
        logger_1.logger.error('Error getting DDE status', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/dde/forms/:eventCrfId/can-enter
 * Check if current user can perform DDE entry
 */
router.get('/forms/:eventCrfId/can-enter', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const eventCrfId = parseInt(req.params.eventCrfId);
        const userId = req.user?.userId;
        const result = await (0, dde_service_1.canUserPerformDDE)(eventCrfId, userId);
        res.json({ success: true, data: result });
    }
    catch (error) {
        logger_1.logger.error('Error checking DDE permission', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
// ============================================================================
// Entry Operations
// ============================================================================
/**
 * POST /api/dde/forms/:eventCrfId/first-entry-complete
 * Mark first entry as complete (called when initial form is submitted)
 */
router.post('/forms/:eventCrfId/first-entry-complete', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const eventCrfId = parseInt(req.params.eventCrfId);
        const userId = req.user?.userId;
        const status = await (0, dde_service_1.markFirstEntryComplete)(eventCrfId, userId);
        res.json({ success: true, data: status });
    }
    catch (error) {
        logger_1.logger.error('Error marking first entry complete', { error: error.message });
        res.status(400).json({ success: false, message: error.message });
    }
});
/**
 * POST /api/dde/forms/:eventCrfId/second-entry
 * Submit second entry data
 */
router.post('/forms/:eventCrfId/second-entry', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const eventCrfId = parseInt(req.params.eventCrfId);
        const userId = req.user?.userId;
        const { entries } = req.body;
        if (!Array.isArray(entries) || entries.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'entries array is required'
            });
        }
        const status = await (0, dde_service_1.submitSecondEntry)({
            eventCrfId,
            entries,
            userId
        });
        res.json({ success: true, data: status });
    }
    catch (error) {
        logger_1.logger.error('Error submitting second entry', { error: error.message });
        res.status(400).json({ success: false, message: error.message });
    }
});
// ============================================================================
// Comparison & Resolution
// ============================================================================
/**
 * GET /api/dde/forms/:eventCrfId/comparison
 * Get comparison results between first and second entries
 */
router.get('/forms/:eventCrfId/comparison', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const eventCrfId = parseInt(req.params.eventCrfId);
        const comparison = await (0, dde_service_1.compareEntries)(eventCrfId);
        res.json({ success: true, data: comparison });
    }
    catch (error) {
        logger_1.logger.error('Error getting comparison', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * POST /api/dde/discrepancies/:discrepancyId/resolve
 * Resolve a discrepancy
 */
router.post('/discrepancies/:discrepancyId/resolve', auth_middleware_1.authMiddleware, requireDataManager, async (req, res) => {
    try {
        const discrepancyId = parseInt(req.params.discrepancyId);
        const { resolution, newValue, adjudicationNotes } = req.body;
        const userId = req.user?.userId;
        if (!resolution) {
            return res.status(400).json({
                success: false,
                message: 'resolution is required (first_correct, second_correct, new_value, or adjudicated)'
            });
        }
        if ((resolution === 'new_value' || resolution === 'adjudicated') && !newValue) {
            return res.status(400).json({
                success: false,
                message: 'newValue is required for this resolution type'
            });
        }
        await (0, dde_service_1.resolveDiscrepancy)({
            discrepancyId,
            resolution,
            newValue,
            adjudicationNotes,
            resolvedBy: userId
        });
        res.json({ success: true, message: 'Discrepancy resolved' });
    }
    catch (error) {
        logger_1.logger.error('Error resolving discrepancy', { error: error.message });
        res.status(400).json({ success: false, message: error.message });
    }
});
/**
 * POST /api/dde/forms/:eventCrfId/finalize
 * Finalize DDE (all discrepancies must be resolved)
 */
router.post('/forms/:eventCrfId/finalize', auth_middleware_1.authMiddleware, requireDataManager, async (req, res) => {
    try {
        const eventCrfId = parseInt(req.params.eventCrfId);
        const userId = req.user?.userId;
        const status = await (0, dde_service_1.finalizeDDE)(eventCrfId, userId);
        res.json({ success: true, data: status });
    }
    catch (error) {
        logger_1.logger.error('Error finalizing DDE', { error: error.message });
        res.status(400).json({ success: false, message: error.message });
    }
});
// ============================================================================
// Dashboard
// ============================================================================
/**
 * GET /api/dde/dashboard
 * Get DDE dashboard with pending work items
 */
router.get('/dashboard', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const userId = req.user?.userId;
        const siteId = req.query.siteId ? parseInt(req.query.siteId) : undefined;
        const dashboard = await (0, dde_service_1.getDDEDashboard)(userId, siteId);
        res.json({ success: true, data: dashboard });
    }
    catch (error) {
        logger_1.logger.error('Error getting DDE dashboard', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
exports.default = router;
//# sourceMappingURL=dde.routes.js.map