/**
 * Form Controller
 *
 * Handles form/CRF operations with audit tracking
 */
import { Request, Response } from 'express';
export declare const saveData: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getData: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getMetadata: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getStatus: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const list: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const get: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getByStudy: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Create a new form template (CRF)
 */
export declare const create: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Update a form template
 */
export declare const update: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Delete a form template
 */
export declare const remove: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get all versions of a form template
 */
export declare const getVersions: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Create a new version of an existing form template
 * This is "forking" at the version level - same CRF, new version
 */
export declare const createVersion: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Fork (copy) an entire form template to create a new independent form
 * This is "forking" at the CRF level - completely new CRF
 */
export declare const fork: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    saveData: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getData: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getMetadata: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getStatus: (req: Request, res: Response, next: import("express").NextFunction) => void;
    list: (req: Request, res: Response, next: import("express").NextFunction) => void;
    get: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getByStudy: (req: Request, res: Response, next: import("express").NextFunction) => void;
    create: (req: Request, res: Response, next: import("express").NextFunction) => void;
    update: (req: Request, res: Response, next: import("express").NextFunction) => void;
    remove: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getVersions: (req: Request, res: Response, next: import("express").NextFunction) => void;
    createVersion: (req: Request, res: Response, next: import("express").NextFunction) => void;
    fork: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=form.controller.d.ts.map