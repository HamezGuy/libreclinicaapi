"use strict";
/**
 * Data Locks Controller
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.unlock = exports.lock = exports.list = void 0;
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const dataLocksService = __importStar(require("../services/database/data-locks.service"));
exports.list = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, page, limit } = req.query;
    const result = await dataLocksService.getLockedRecords({
        studyId: studyId ? parseInt(studyId) : undefined,
        page: parseInt(page) || 1,
        limit: parseInt(limit) || 20
    });
    res.json(result);
});
exports.lock = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { eventCrfId } = req.body;
    if (!eventCrfId) {
        res.status(400).json({ success: false, message: 'eventCrfId is required' });
        return;
    }
    const result = await dataLocksService.lockRecord(eventCrfId, user.userId);
    res.status(result.success ? 201 : 400).json(result);
});
exports.unlock = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { eventCrfId } = req.params;
    const result = await dataLocksService.unlockRecord(parseInt(eventCrfId), user.userId);
    res.json(result);
});
exports.default = { list: exports.list, lock: exports.lock, unlock: exports.unlock };
//# sourceMappingURL=data-locks.controller.js.map