/**
 * 21 CFR Part 11 Compliance Middleware
 *
 * Provides compliance features for FDA 21 CFR Part 11:
 * - §11.10(e) Audit Trails: Complete, immutable audit records
 * - §11.10(k) Time Stamps: UTC timestamps for all events
 * - §11.50 Electronic Signatures: Verification and non-repudiation
 * - §11.10(d) Access Controls: Role-based authorization
 *
 * Usage:
 *   import { part11Audit, requireSignature, verifyPassword } from './part11.middleware';
 *   router.post('/critical-action', part11Audit('ENTITY_UPDATED'), requireSignature, handler);
 */
import { Request, Response, NextFunction } from 'express';
/**
 * Part 11 Audit Event Types
 * These map to audit_log_event_type_id in LibreClinica
 */
export declare const Part11EventTypes: {
    RECORD_CREATED: number;
    RECORD_UPDATED: number;
    RECORD_DELETED: number;
    RECORD_VIEWED: number;
    RECORD_EXPORTED: number;
    SIGNATURE_APPLIED: number;
    SIGNATURE_VERIFIED: number;
    SIGNATURE_REJECTED: number;
    ACCESS_GRANTED: number;
    ACCESS_DENIED: number;
    PERMISSION_CHANGED: number;
    SYSTEM_CONFIGURATION_CHANGED: number;
    BACKUP_CREATED: number;
    DATA_IMPORTED: number;
    DATA_EXPORTED: number;
    CONSENT_DOCUMENTED: number;
    CONSENT_WITHDRAWN: number;
    CONSENT_VERSION_ACTIVATED: number;
    PRO_INSTRUMENT_CREATED: number;
    PRO_ASSIGNMENT_CREATED: number;
    PRO_RESPONSE_SUBMITTED: number;
    PRO_REMINDER_SENT: number;
    KIT_REGISTERED: number;
    KIT_DISPENSED: number;
    KIT_RETURNED: number;
    SHIPMENT_CREATED: number;
    SHIPMENT_RECEIVED: number;
    TEMPERATURE_EXCURSION: number;
    TRANSFER_INITIATED: number;
    TRANSFER_APPROVED: number;
    TRANSFER_COMPLETED: number;
    TRANSFER_CANCELLED: number;
    EMAIL_TEMPLATE_UPDATED: number;
    EMAIL_QUEUED: number;
    EMAIL_SENT: number;
    NOTIFICATION_PREFERENCE_CHANGED: number;
};
/**
 * Part 11 Audit Context
 * Attached to request for audit trail creation
 */
export interface Part11AuditContext {
    eventType: number;
    entityType: string;
    entityId?: number;
    entityName?: string;
    oldValue?: any;
    newValue?: any;
    reasonForChange?: string;
    signatureRequired?: boolean;
    signatureVerified?: boolean;
    signatureMeaning?: string;
    ipAddress?: string;
    userAgent?: string;
}
/**
 * Extended Request with Part 11 audit context
 */
export interface Part11Request extends Request {
    part11?: Part11AuditContext;
    user?: {
        userId: number;
        userName: string;
        email: string;
        userType: string;
        role: string;
        studyIds: number[];
    };
}
/**
 * Record a Part 11 compliant audit event
 *
 * Requirements per §11.10(e):
 * - User identification (user_id)
 * - Date and time (UTC timestamp)
 * - Action performed (event type)
 * - Old value (before change)
 * - New value (after change)
 * - Reason for change (if applicable)
 *
 * Additional compliance features:
 * - IP address for non-repudiation
 * - User agent for device identification
 * - Cryptographic hash chain for tamper detection
 */
export declare function recordPart11Audit(userId: number, userName: string, eventType: number, entityType: string, entityId: number | null, entityName: string | null, oldValue: any, newValue: any, reasonForChange: string | null, additionalData?: {
    studyId?: number;
    eventCrfId?: number;
    studyEventId?: number;
    ipAddress?: string;
    signatureMeaning?: string;
}): Promise<{
    auditId: number;
    timestamp: Date;
    integrityHash?: string;
}>;
/**
 * Middleware to create Part 11 audit context
 * Attaches audit context to request for later use
 */
export declare function part11Audit(eventType: keyof typeof Part11EventTypes | number, entityType: string, options?: {
    signatureRequired?: boolean;
    captureOldValue?: boolean;
}): (req: Part11Request, res: Response, next: NextFunction) => void;
/**
 * Verify user password for electronic signature
 * Required for critical operations per §11.50
 *
 * The signature must be:
 * - Unique to the individual (tied to their password)
 * - Linked to the record being signed
 * - Include the meaning of the signature
 */
export declare function verifyElectronicSignature(userId: number, password: string, meaning: string): Promise<{
    verified: boolean;
    userName: string;
    error?: string;
}>;
/**
 * Middleware to require electronic signature for critical operations
 * Per §11.50, electronic signatures must be verified before critical changes
 */
export declare function requireSignature(req: Part11Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>> | undefined>;
/**
 * Signature meanings for different operation types
 * Per §11.50(a), signature meaning must be clearly indicated
 */
export declare const SignatureMeanings: {
    FORM_DATA_SAVE: string;
    FORM_DATA_UPDATE: string;
    FORM_COMPLETE: string;
    FORM_LOCK: string;
    STUDY_CREATE: string;
    STUDY_UPDATE: string;
    STUDY_DELETE: string;
    SUBJECT_ENROLL: string;
    SUBJECT_UPDATE: string;
    SUBJECT_WITHDRAW: string;
    SUBJECT_DELETE: string;
    EVENT_CREATE: string;
    EVENT_SCHEDULE: string;
    EVENT_UPDATE: string;
    EVENT_DELETE: string;
    QUERY_CREATE: string;
    QUERY_RESPOND: string;
    QUERY_CLOSE: string;
    CRF_CREATE: string;
    CRF_UPDATE: string;
    CRF_DELETE: string;
    CRF_ASSIGN: string;
    SITE_CREATE: string;
    SITE_UPDATE: string;
    SITE_DELETE: string;
    SUBJECT_TRANSFER: string;
    STAFF_ASSIGN: string;
    STAFF_REMOVE: string;
    RULE_CREATE: string;
    RULE_UPDATE: string;
    RULE_DELETE: string;
    FORM_LINK_CREATE: string;
    FORM_LINK_UPDATE: string;
    FORM_LINK_DELETE: string;
    APPROVE: string;
    REJECT: string;
    VERIFY: string;
    AUTHORIZE: string;
};
/**
 * Factory function to create signature requirement middleware with specific meaning
 *
 * @param defaultMeaning - The default signature meaning if not provided in request
 * @returns Middleware that requires electronic signature
 */
export declare function requireSignatureFor(defaultMeaning: string): (req: Part11Request, res: Response, next: NextFunction) => Promise<void | Response<any, Record<string, any>>>;
/**
 * Helper function to create audit entry from request context
 * Call this at the end of successful operations
 */
export declare function createAuditFromRequest(req: Part11Request, entityId: number, entityName: string, oldValue?: any, newValue?: any, reason?: string): Promise<{
    auditId: number;
    timestamp: Date;
} | null>;
/**
 * Helper to format timestamp as ISO 8601 UTC string
 * Required for §11.10(k) time stamp compliance
 */
export declare function formatPart11Timestamp(date?: Date): string;
/**
 * Validate that a timestamp is in correct Part 11 format
 */
export declare function isValidPart11Timestamp(timestamp: string): boolean;
/**
 * Verify audit log chain integrity
 * Detects any tampering with audit records per §11.10(e)
 *
 * @param entityType - The entity type to verify (e.g., 'study_subject', 'event_crf')
 * @param limit - Maximum number of records to verify (default: 1000)
 * @returns Verification result with any detected integrity violations
 */
export declare function verifyAuditChainIntegrity(entityType: string, limit?: number): Promise<{
    verified: boolean;
    totalRecords: number;
    validRecords: number;
    invalidRecords: number;
    violations: Array<{
        auditId: number;
        expectedHash: string;
        actualHash: string;
        timestamp: Date;
    }>;
}>;
declare const _default: {
    Part11EventTypes: {
        RECORD_CREATED: number;
        RECORD_UPDATED: number;
        RECORD_DELETED: number;
        RECORD_VIEWED: number;
        RECORD_EXPORTED: number;
        SIGNATURE_APPLIED: number;
        SIGNATURE_VERIFIED: number;
        SIGNATURE_REJECTED: number;
        ACCESS_GRANTED: number;
        ACCESS_DENIED: number;
        PERMISSION_CHANGED: number;
        SYSTEM_CONFIGURATION_CHANGED: number;
        BACKUP_CREATED: number;
        DATA_IMPORTED: number;
        DATA_EXPORTED: number;
        CONSENT_DOCUMENTED: number;
        CONSENT_WITHDRAWN: number;
        CONSENT_VERSION_ACTIVATED: number;
        PRO_INSTRUMENT_CREATED: number;
        PRO_ASSIGNMENT_CREATED: number;
        PRO_RESPONSE_SUBMITTED: number;
        PRO_REMINDER_SENT: number;
        KIT_REGISTERED: number;
        KIT_DISPENSED: number;
        KIT_RETURNED: number;
        SHIPMENT_CREATED: number;
        SHIPMENT_RECEIVED: number;
        TEMPERATURE_EXCURSION: number;
        TRANSFER_INITIATED: number;
        TRANSFER_APPROVED: number;
        TRANSFER_COMPLETED: number;
        TRANSFER_CANCELLED: number;
        EMAIL_TEMPLATE_UPDATED: number;
        EMAIL_QUEUED: number;
        EMAIL_SENT: number;
        NOTIFICATION_PREFERENCE_CHANGED: number;
    };
    SignatureMeanings: {
        FORM_DATA_SAVE: string;
        FORM_DATA_UPDATE: string;
        FORM_COMPLETE: string;
        FORM_LOCK: string;
        STUDY_CREATE: string;
        STUDY_UPDATE: string;
        STUDY_DELETE: string;
        SUBJECT_ENROLL: string;
        SUBJECT_UPDATE: string;
        SUBJECT_WITHDRAW: string;
        SUBJECT_DELETE: string;
        EVENT_CREATE: string;
        EVENT_SCHEDULE: string;
        EVENT_UPDATE: string;
        EVENT_DELETE: string;
        QUERY_CREATE: string;
        QUERY_RESPOND: string;
        QUERY_CLOSE: string;
        CRF_CREATE: string;
        CRF_UPDATE: string;
        CRF_DELETE: string;
        CRF_ASSIGN: string;
        SITE_CREATE: string;
        SITE_UPDATE: string;
        SITE_DELETE: string;
        SUBJECT_TRANSFER: string;
        STAFF_ASSIGN: string;
        STAFF_REMOVE: string;
        RULE_CREATE: string;
        RULE_UPDATE: string;
        RULE_DELETE: string;
        FORM_LINK_CREATE: string;
        FORM_LINK_UPDATE: string;
        FORM_LINK_DELETE: string;
        APPROVE: string;
        REJECT: string;
        VERIFY: string;
        AUTHORIZE: string;
    };
    recordPart11Audit: typeof recordPart11Audit;
    part11Audit: typeof part11Audit;
    verifyElectronicSignature: typeof verifyElectronicSignature;
    requireSignature: typeof requireSignature;
    requireSignatureFor: typeof requireSignatureFor;
    verifyAuditChainIntegrity: typeof verifyAuditChainIntegrity;
    createAuditFromRequest: typeof createAuditFromRequest;
    formatPart11Timestamp: typeof formatPart11Timestamp;
    isValidPart11Timestamp: typeof isValidPart11Timestamp;
};
export default _default;
//# sourceMappingURL=part11.middleware.d.ts.map