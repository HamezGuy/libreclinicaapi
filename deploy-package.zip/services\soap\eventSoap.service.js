"use strict";
/**
 * Event SOAP Service
 *
 * Handles study event operations via LibreClinica SOAP API
 * - Schedule study events for subjects
 * - Create event instances
 * - Update event status
 *
 * SOAP Endpoint: http://localhost:8080/LibreClinica/ws/studyEvent/v1
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createEvent = exports.scheduleEvent = void 0;
const soapClient_1 = require("./soapClient");
const logger_1 = require("../../config/logger");
/**
 * Schedule a study event for a subject
 */
const scheduleEvent = async (request, userId, username) => {
    logger_1.logger.info('Scheduling study event via SOAP', {
        studyId: request.studyId,
        subjectId: request.subjectId,
        eventDefinitionId: request.studyEventDefinitionId,
        userId,
        username
    });
    try {
        const odmXml = buildScheduleEventOdm(request);
        const soapClient = (0, soapClient_1.getSoapClient)();
        const response = await soapClient.executeRequest({
            serviceName: 'event',
            methodName: 'schedule',
            parameters: {
                odm: odmXml
            },
            userId,
            username
        });
        if (!response.success) {
            logger_1.logger.error('Event scheduling failed', {
                error: response.error,
                subjectId: request.subjectId,
                eventDefinitionId: request.studyEventDefinitionId
            });
            return {
                success: false,
                message: response.error || 'Failed to schedule event'
            };
        }
        logger_1.logger.info('Event scheduled successfully', {
            subjectId: request.subjectId,
            eventDefinitionId: request.studyEventDefinitionId
        });
        return {
            success: true,
            data: response.data,
            message: 'Event scheduled successfully'
        };
    }
    catch (error) {
        logger_1.logger.error('Event scheduling error', {
            error: error.message,
            subjectId: request.subjectId
        });
        return {
            success: false,
            message: `Event scheduling failed: ${error.message}`
        };
    }
};
exports.scheduleEvent = scheduleEvent;
/**
 * Create a new event instance
 */
const createEvent = async (studyOid, subjectOid, eventOid, userId, username) => {
    logger_1.logger.info('Creating study event via SOAP', {
        studyOid,
        subjectOid,
        eventOid,
        userId
    });
    try {
        const odmXml = buildCreateEventOdm(studyOid, subjectOid, eventOid);
        const soapClient = (0, soapClient_1.getSoapClient)();
        const response = await soapClient.executeRequest({
            serviceName: 'event',
            methodName: 'create',
            parameters: {
                odm: odmXml
            },
            userId,
            username
        });
        if (!response.success) {
            return {
                success: false,
                message: response.error || 'Failed to create event'
            };
        }
        logger_1.logger.info('Event created successfully', {
            eventOid
        });
        return {
            success: true,
            data: response.data,
            message: 'Event created successfully'
        };
    }
    catch (error) {
        logger_1.logger.error('Event creation error', {
            error: error.message,
            eventOid
        });
        return {
            success: false,
            message: `Event creation failed: ${error.message}`
        };
    }
};
exports.createEvent = createEvent;
/**
 * Build ODM XML for event scheduling
 */
function buildScheduleEventOdm(request) {
    const { studyId, subjectId, studyEventDefinitionId, startDate, endDate, location } = request;
    const studyOid = `S_${studyId}`;
    const subjectOid = `SS_${subjectId}`;
    const eventOid = `SE_${studyEventDefinitionId}`;
    const timestamp = new Date().toISOString();
    let odmXml = `<?xml version="1.0" encoding="UTF-8"?>
<ODM xmlns="http://www.cdisc.org/ns/odm/v1.3"
     xmlns:OpenClinica="http://www.openclinica.org/ns/odm_ext_v130/v3.1"
     ODMVersion="1.3"
     FileType="Transactional"
     FileOID="ODM-${Date.now()}"
     CreationDateTime="${timestamp}">
  <ClinicalData StudyOID="${studyOid}" MetaDataVersionOID="v1.0.0">
    <SubjectData SubjectKey="${subjectOid}">
      <StudyEventData StudyEventOID="${eventOid}" StudyEventRepeatKey="1">`;
    if (startDate) {
        odmXml += `
        <OpenClinica:StartDate>${startDate}</OpenClinica:StartDate>`;
    }
    if (endDate) {
        odmXml += `
        <OpenClinica:EndDate>${endDate}</OpenClinica:EndDate>`;
    }
    if (location) {
        odmXml += `
        <OpenClinica:Location>${escapeXml(location)}</OpenClinica:Location>`;
    }
    odmXml += `
      </StudyEventData>
    </SubjectData>
  </ClinicalData>
</ODM>`;
    return odmXml;
}
/**
 * Build ODM XML for event creation
 */
function buildCreateEventOdm(studyOid, subjectOid, eventOid) {
    const timestamp = new Date().toISOString();
    return `<?xml version="1.0" encoding="UTF-8"?>
<ODM xmlns="http://www.cdisc.org/ns/odm/v1.3"
     ODMVersion="1.3"
     FileType="Transactional"
     FileOID="ODM-${Date.now()}"
     CreationDateTime="${timestamp}">
  <ClinicalData StudyOID="${studyOid}" MetaDataVersionOID="v1.0.0">
    <SubjectData SubjectKey="${subjectOid}">
      <StudyEventData StudyEventOID="${eventOid}" StudyEventRepeatKey="1">
      </StudyEventData>
    </SubjectData>
  </ClinicalData>
</ODM>`;
}
/**
 * Escape XML special characters
 */
function escapeXml(unsafe) {
    return unsafe
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');
}
exports.default = {
    scheduleEvent: exports.scheduleEvent,
    createEvent: exports.createEvent
};
//# sourceMappingURL=eventSoap.service.js.map