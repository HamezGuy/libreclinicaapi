"use strict";
/**
 * Organization Routes
 *
 * Routes for organization management, invite codes, access requests, and invitations
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const controller = __importStar(require("../controllers/organization.controller"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const authorization_middleware_1 = require("../middleware/authorization.middleware");
const router = express_1.default.Router();
// ============================================================================
// Public Routes (no authentication required)
// ============================================================================
// Organization registration (self-service)
router.post('/register', controller.registerOrganization);
// Code validation and registration
router.post('/codes/validate', controller.validateCode);
router.post('/codes/register', controller.registerWithCode);
// Access requests
router.post('/access-requests', controller.createAccessRequest);
// Invitation validation and acceptance
router.get('/invitations/:token/validate', controller.validateInvitation);
router.post('/invitations/:token/accept', controller.acceptInvitation);
// ============================================================================
// Protected Routes (authentication required)
// ============================================================================
router.use(auth_middleware_1.authMiddleware);
// Get current user's organizations
router.get('/my', controller.getMyOrganizations);
// ============================================================================
// Admin Routes (admin or coordinator role required)
// ============================================================================
// List and manage organizations
router.get('/', (0, authorization_middleware_1.requireRole)('admin'), controller.listOrganizations);
router.get('/:id', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), controller.getOrganization);
router.patch('/:id/status', (0, authorization_middleware_1.requireRole)('admin'), controller.updateStatus);
// Organization codes management
router.post('/:id/codes', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), controller.generateCode);
router.get('/:id/codes', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), controller.listCodes);
router.patch('/:orgId/codes/:codeId', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), controller.deactivateCode);
// Access requests management
router.get('/access-requests', (0, authorization_middleware_1.requireRole)('admin'), controller.listAccessRequests);
router.patch('/access-requests/:id', (0, authorization_middleware_1.requireRole)('admin'), controller.reviewAccessRequest);
// User invitations
router.post('/invitations', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), controller.createInvitation);
exports.default = router;
//# sourceMappingURL=organization.routes.js.map