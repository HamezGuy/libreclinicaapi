/**
 * Study SOAP Service
 *
 * Handles study metadata retrieval via LibreClinica SOAP API
 * - Get study metadata (structure, events, CRFs)
 * - Parse ODM metadata responses
 * - Extract study definitions
 *
 * SOAP Endpoint: http://localhost:8080/LibreClinica/ws/study/v1
 */
import { ApiResponse } from '../../types';
interface SoapStudyMetadata {
    study: any;
    events: any[];
    crfs: any[];
}
/**
 * Get study metadata via SOAP
 * Returns complete study structure including events and CRFs
 */
export declare const getStudyMetadata: (studyOid: string, userId: number, username: string) => Promise<ApiResponse<SoapStudyMetadata>>;
/**
 * List all studies via SOAP
 */
export declare const listStudies: (userId: number, username: string) => Promise<ApiResponse<any[]>>;
/**
 * Parse ODM metadata XML to structured format
 */
export declare const parseOdmMetadata: (odmXml: string) => Promise<SoapStudyMetadata>;
/**
 * Get study OID by study ID
 * Helper function to convert study ID to OID format
 */
export declare const getStudyOid: (studyId: number) => string;
/**
 * Extract study ID from OID
 */
export declare const extractStudyId: (studyOid: string) => number;
declare const _default: {
    getStudyMetadata: (studyOid: string, userId: number, username: string) => Promise<ApiResponse<SoapStudyMetadata>>;
    listStudies: (userId: number, username: string) => Promise<ApiResponse<any[]>>;
    parseOdmMetadata: (odmXml: string) => Promise<SoapStudyMetadata>;
    getStudyOid: (studyId: number) => string;
    extractStudyId: (studyOid: string) => number;
};
export default _default;
//# sourceMappingURL=studySoap.service.d.ts.map