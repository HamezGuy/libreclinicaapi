/**
 * Study Parameters Routes
 *
 * API endpoints for managing study configuration parameters.
 * These control enrollment behavior, subject ID generation, etc.
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=studyParameters.routes.d.ts.map