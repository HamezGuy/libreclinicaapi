"use strict";
/**
 * Audit Controller
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLoginStats = exports.getLoginHistory = exports.getRecent = exports.getComplianceReport = exports.getSummary = exports.getFormAudit = exports.getStats = exports.getTables = exports.getEventTypes = exports.getSubjectAudit = exports.exportCsv = exports.get = void 0;
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const auditService = __importStar(require("../services/database/audit.service"));
exports.get = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, subjectId, userId, eventType, startDate, endDate, page, limit } = req.query;
    const result = await auditService.getAuditTrail({
        studyId: studyId ? parseInt(studyId) : undefined,
        subjectId: subjectId ? parseInt(subjectId) : undefined,
        userId: userId ? parseInt(userId) : undefined,
        eventType: eventType,
        startDate: startDate,
        endDate: endDate,
        page: parseInt(page) || 1,
        limit: parseInt(limit) || 50
    });
    res.json(result);
});
exports.exportCsv = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, startDate, endDate } = req.query;
    const csv = await auditService.exportAuditTrailCSV({
        studyId: parseInt(studyId),
        startDate: startDate,
        endDate: endDate,
        format: 'csv'
    });
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename=audit-trail-${Date.now()}.csv`);
    res.send(csv);
});
exports.getSubjectAudit = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const { page, limit } = req.query;
    const result = await auditService.getSubjectAudit(parseInt(id), parseInt(page) || 1, parseInt(limit) || 100);
    res.json(result);
});
/**
 * Get audit event types
 */
exports.getEventTypes = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const result = await auditService.getAuditEventTypes();
    res.json({ success: true, data: result });
});
/**
 * Get auditable tables list
 */
exports.getTables = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const result = await auditService.getAuditableTables();
    res.json({ success: true, data: result });
});
/**
 * Get audit statistics
 */
exports.getStats = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { days } = req.query;
    const result = await auditService.getAuditStatistics(parseInt(days) || 30);
    res.json({ success: true, data: result });
});
/**
 * Get form audit trail
 */
exports.getFormAudit = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { eventCrfId } = req.params;
    const result = await auditService.getFormAudit(parseInt(eventCrfId));
    res.json({ success: true, data: result });
});
/**
 * Get audit summary by date range
 */
exports.getSummary = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { startDate, endDate } = req.query;
    if (!startDate || !endDate) {
        res.status(400).json({ success: false, message: 'startDate and endDate are required' });
        return;
    }
    const result = await auditService.getAuditSummary(startDate, endDate);
    res.json(result);
});
/**
 * Get compliance report
 */
exports.getComplianceReport = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { startDate, endDate, studyId } = req.query;
    if (!startDate || !endDate) {
        res.status(400).json({ success: false, message: 'startDate and endDate are required' });
        return;
    }
    const result = await auditService.getComplianceReport({
        startDate: startDate,
        endDate: endDate,
        studyId: studyId ? parseInt(studyId) : undefined
    });
    res.json(result);
});
/**
 * Get recent audit events
 */
exports.getRecent = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { limit } = req.query;
    const result = await auditService.getRecentAuditEvents(parseInt(limit) || 50);
    res.json({ success: true, data: result });
});
/**
 * Get login history
 * Returns login/logout/failed login events from audit_user_login
 *
 * 21 CFR Part 11 §11.10(e) - Audit Trail for login events
 */
exports.getLoginHistory = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { userId, username, startDate, endDate, status, limit, offset } = req.query;
    const result = await auditService.getLoginHistory({
        userId: userId ? parseInt(userId) : undefined,
        username: username,
        startDate: startDate,
        endDate: endDate,
        status: status,
        limit: parseInt(limit) || 100,
        offset: parseInt(offset) || 0
    });
    res.json(result);
});
/**
 * Get login statistics
 * Returns login/logout/failed counts and daily breakdown
 */
exports.getLoginStats = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { days } = req.query;
    const result = await auditService.getLoginStatistics(parseInt(days) || 30);
    res.json(result);
});
exports.default = {
    get: exports.get,
    exportCsv: exports.exportCsv,
    getSubjectAudit: exports.getSubjectAudit,
    getEventTypes: exports.getEventTypes,
    getTables: exports.getTables,
    getStats: exports.getStats,
    getFormAudit: exports.getFormAudit,
    getSummary: exports.getSummary,
    getComplianceReport: exports.getComplianceReport,
    getRecent: exports.getRecent,
    getLoginHistory: exports.getLoginHistory,
    getLoginStats: exports.getLoginStats
};
//# sourceMappingURL=audit.controller.js.map