"use strict";
/**
 * Organization Service
 *
 * Handles organization management, invite codes, access requests, and invitations
 * Integrates with LibreClinica's user_account and study tables
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.acceptInvitation = exports.validateInvitation = exports.createInvitation = exports.reviewAccessRequest = exports.getAccessRequests = exports.createAccessRequest = exports.deactivateOrganizationCode = exports.getOrganizationCodes = exports.registerWithCode = exports.validateOrganizationCode = exports.generateOrganizationCode = exports.getUserOrganizations = exports.updateOrganizationStatus = exports.getOrganizations = exports.getOrganizationById = exports.createOrganizationWithAdmin = void 0;
const database_1 = require("../../config/database");
const logger_1 = require("../../config/logger");
const password_util_1 = require("../../utils/password.util");
const crypto_1 = __importDefault(require("crypto"));
// ============================================================================
// Organization CRUD
// ============================================================================
/**
 * Create a new organization with admin user
 * This is used for self-registration - creates org + first admin user in one transaction
 */
const createOrganizationWithAdmin = async (orgData, adminData) => {
    logger_1.logger.info('Creating organization with admin', { orgName: orgData.name, adminEmail: adminData.email });
    const client = await database_1.pool.connect();
    try {
        await client.query('BEGIN');
        // Validate password
        const passwordValidation = (0, password_util_1.validatePassword)(adminData.password);
        if (!passwordValidation.isValid) {
            return {
                success: false,
                message: `Password validation failed: ${passwordValidation.errors.join(', ')}`
            };
        }
        // Check if organization name already exists
        const orgExists = await client.query('SELECT organization_id FROM acc_organization WHERE name = $1', [orgData.name]);
        if (orgExists.rows.length > 0) {
            return { success: false, message: 'Organization name already exists' };
        }
        // Check if org email already exists
        const orgEmailExists = await client.query('SELECT organization_id FROM acc_organization WHERE email = $1', [orgData.email]);
        if (orgEmailExists.rows.length > 0) {
            return { success: false, message: 'Organization email already registered' };
        }
        // Check if admin email already exists in user_account
        const userEmailExists = await client.query('SELECT user_id FROM user_account WHERE email = $1', [adminData.email]);
        if (userEmailExists.rows.length > 0) {
            return { success: false, message: 'Admin email already registered as a user' };
        }
        // Generate username from email
        let username = adminData.email.split('@')[0].toLowerCase().replace(/[^a-z0-9]/g, '');
        // Ensure username is unique
        const usernameExists = await client.query('SELECT user_id FROM user_account WHERE user_name = $1', [username]);
        if (usernameExists.rows.length > 0) {
            username = `${username}${Date.now().toString().slice(-4)}`;
        }
        // Hash password (MD5 for LibreClinica compatibility)
        const hashedPassword = (0, password_util_1.hashPasswordMD5)(adminData.password);
        // Create user account first (so we have owner_id for organization)
        const userInsert = await client.query(`
      INSERT INTO user_account (
        user_name, first_name, last_name, email, passwd, passwd_timestamp,
        phone, institutional_affiliation, user_type_id, status_id, owner_id,
        date_created
      ) VALUES (
        $1, $2, $3, $4, $5, NOW(), $6, $7, 1, 1, 1, NOW()
      )
      RETURNING user_id
    `, [
            username,
            adminData.firstName,
            adminData.lastName,
            adminData.email,
            hashedPassword,
            adminData.phone || null,
            orgData.name // Use org name as institutional affiliation
        ]);
        const userId = userInsert.rows[0].user_id;
        // Update owner_id to self
        await client.query('UPDATE user_account SET owner_id = $1 WHERE user_id = $1', [userId]);
        // Create organization with pending status (requires approval)
        const orgInsert = await client.query(`
      INSERT INTO acc_organization (
        name, type, status, email, phone, website,
        street, city, state, postal_code, country,
        owner_id, date_created, date_updated
      ) VALUES (
        $1, $2, 'pending', $3, $4, $5,
        $6, $7, $8, $9, $10,
        $11, NOW(), NOW()
      )
      RETURNING organization_id
    `, [
            orgData.name,
            orgData.type,
            orgData.email,
            orgData.phone || null,
            orgData.website || null,
            orgData.street || null,
            orgData.city || null,
            orgData.state || null,
            orgData.postalCode || null,
            orgData.country || null,
            userId
        ]);
        const organizationId = orgInsert.rows[0].organization_id;
        // Create organization membership for admin
        await client.query(`
      INSERT INTO acc_organization_membership (
        organization_id, user_id, role, status, date_created
      ) VALUES ($1, $2, 'owner', 'active', NOW())
    `, [organizationId, userId]);
        // Log audit event
        await client.query(`
      INSERT INTO audit_log_event (
        audit_date, audit_table, user_id, entity_id, entity_name, new_value,
        audit_log_event_type_id
      ) VALUES (
        NOW(), 'acc_organization', $1, $2, 'Organization', $3,
        (SELECT audit_log_event_type_id FROM audit_log_event_type WHERE name = 'User Created' LIMIT 1)
      )
    `, [userId, organizationId, `Organization "${orgData.name}" created with admin "${adminData.email}"`]);
        await client.query('COMMIT');
        logger_1.logger.info('Organization created successfully', { organizationId, userId, orgName: orgData.name });
        return {
            success: true,
            organizationId,
            userId,
            message: 'Organization registration submitted. Pending approval.'
        };
    }
    catch (error) {
        await client.query('ROLLBACK');
        logger_1.logger.error('Create organization error', { error: error.message, orgData });
        // Handle specific postgres errors
        if (error.code === '23505') {
            if (error.constraint?.includes('org_name')) {
                return { success: false, message: 'Organization name already exists' };
            }
            if (error.constraint?.includes('org_email')) {
                return { success: false, message: 'Organization email already registered' };
            }
        }
        return {
            success: false,
            message: `Failed to create organization: ${error.message}`
        };
    }
    finally {
        client.release();
    }
};
exports.createOrganizationWithAdmin = createOrganizationWithAdmin;
/**
 * Get organization by ID
 */
const getOrganizationById = async (organizationId) => {
    try {
        const result = await database_1.pool.query(`
      SELECT 
        organization_id, name, type, status, email, phone, website,
        street, city, state, postal_code, country,
        owner_id, approved_by, approved_at, date_created, date_updated
      FROM acc_organization
      WHERE organization_id = $1
    `, [organizationId]);
        if (result.rows.length === 0) {
            return null;
        }
        return mapOrganizationRow(result.rows[0]);
    }
    catch (error) {
        logger_1.logger.error('Get organization error', { error: error.message, organizationId });
        throw error;
    }
};
exports.getOrganizationById = getOrganizationById;
/**
 * Get organizations with optional filters
 */
const getOrganizations = async (filters) => {
    try {
        const { status, type, page = 1, limit = 20 } = filters;
        const offset = (page - 1) * limit;
        const conditions = [];
        const params = [];
        let paramIndex = 1;
        if (status) {
            conditions.push(`status = $${paramIndex++}`);
            params.push(status);
        }
        if (type) {
            conditions.push(`type = $${paramIndex++}`);
            params.push(type);
        }
        const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
        // Count total
        const countResult = await database_1.pool.query(`SELECT COUNT(*) as total FROM acc_organization ${whereClause}`, params);
        const total = parseInt(countResult.rows[0].total);
        // Get data
        params.push(limit, offset);
        const dataResult = await database_1.pool.query(`
      SELECT 
        organization_id, name, type, status, email, phone, website,
        street, city, state, postal_code, country,
        owner_id, approved_by, approved_at, date_created, date_updated
      FROM acc_organization
      ${whereClause}
      ORDER BY date_created DESC
      LIMIT $${paramIndex++} OFFSET $${paramIndex}
    `, params);
        return {
            data: dataResult.rows.map(mapOrganizationRow),
            total
        };
    }
    catch (error) {
        logger_1.logger.error('Get organizations error', { error: error.message });
        throw error;
    }
};
exports.getOrganizations = getOrganizations;
/**
 * Update organization status (approve/reject/suspend)
 */
const updateOrganizationStatus = async (organizationId, status, approvedBy, notes) => {
    const client = await database_1.pool.connect();
    try {
        await client.query('BEGIN');
        const updateResult = await client.query(`
      UPDATE acc_organization
      SET status = $1, approved_by = $2, approved_at = NOW(), date_updated = NOW()
      WHERE organization_id = $3
      RETURNING name
    `, [status, approvedBy, organizationId]);
        if (updateResult.rows.length === 0) {
            await client.query('ROLLBACK');
            return { success: false, message: 'Organization not found' };
        }
        // Log audit event
        await client.query(`
      INSERT INTO audit_log_event (
        audit_date, audit_table, user_id, entity_id, entity_name, new_value,
        audit_log_event_type_id
      ) VALUES (
        NOW(), 'acc_organization', $1, $2, 'Organization', $3,
        (SELECT audit_log_event_type_id FROM audit_log_event_type WHERE name = 'User Updated' LIMIT 1)
      )
    `, [approvedBy, organizationId, `Status changed to ${status}${notes ? ': ' + notes : ''}`]);
        await client.query('COMMIT');
        logger_1.logger.info('Organization status updated', { organizationId, status, approvedBy });
        return { success: true, message: `Organization ${status}` };
    }
    catch (error) {
        await client.query('ROLLBACK');
        logger_1.logger.error('Update organization status error', { error: error.message, organizationId });
        return { success: false, message: error.message };
    }
    finally {
        client.release();
    }
};
exports.updateOrganizationStatus = updateOrganizationStatus;
/**
 * Get user's organizations
 */
const getUserOrganizations = async (userId) => {
    try {
        const result = await database_1.pool.query(`
      SELECT o.organization_id, o.name, m.role, o.status
      FROM acc_organization o
      INNER JOIN acc_organization_membership m ON o.organization_id = m.organization_id
      WHERE m.user_id = $1 AND m.status = 'active'
      ORDER BY o.name
    `, [userId]);
        return result.rows.map(row => ({
            organizationId: row.organization_id,
            name: row.name,
            role: row.role,
            status: row.status
        }));
    }
    catch (error) {
        logger_1.logger.error('Get user organizations error', { error: error.message, userId });
        return [];
    }
};
exports.getUserOrganizations = getUserOrganizations;
// ============================================================================
// Organization Codes
// ============================================================================
/**
 * Generate a new organization invite code
 */
const generateOrganizationCode = async (organizationId, createdBy, options = {}) => {
    try {
        // Verify organization exists and is active
        const orgCheck = await database_1.pool.query('SELECT status FROM acc_organization WHERE organization_id = $1', [organizationId]);
        if (orgCheck.rows.length === 0) {
            return { success: false, message: 'Organization not found' };
        }
        if (orgCheck.rows[0].status !== 'active') {
            return { success: false, message: 'Organization is not active' };
        }
        // Generate unique code (12 chars, uppercase alphanumeric)
        const code = crypto_1.default.randomBytes(6).toString('hex').toUpperCase();
        const result = await database_1.pool.query(`
      INSERT INTO acc_organization_code (
        code, organization_id, max_uses, expires_at, default_role, is_active, created_by, date_created
      ) VALUES ($1, $2, $3, $4, $5, true, $6, NOW())
      RETURNING code_id
    `, [
            code,
            organizationId,
            options.maxUses || null,
            options.expiresAt || null,
            options.defaultRole || 'member',
            createdBy
        ]);
        logger_1.logger.info('Organization code generated', { organizationId, codeId: result.rows[0].code_id });
        return {
            success: true,
            code,
            codeId: result.rows[0].code_id
        };
    }
    catch (error) {
        logger_1.logger.error('Generate organization code error', { error: error.message, organizationId });
        return { success: false, message: error.message };
    }
};
exports.generateOrganizationCode = generateOrganizationCode;
/**
 * Validate an organization code
 */
const validateOrganizationCode = async (code) => {
    try {
        const result = await database_1.pool.query(`
      SELECT 
        c.code_id, c.organization_id, c.max_uses, c.current_uses, 
        c.expires_at, c.default_role, c.is_active,
        o.name as organization_name, o.status as org_status
      FROM acc_organization_code c
      INNER JOIN acc_organization o ON c.organization_id = o.organization_id
      WHERE c.code = $1
    `, [code.toUpperCase()]);
        if (result.rows.length === 0) {
            return { isValid: false, message: 'Invalid code' };
        }
        const codeData = result.rows[0];
        // Check if code is active
        if (!codeData.is_active) {
            return { isValid: false, message: 'This code has been deactivated' };
        }
        // Check organization status
        if (codeData.org_status !== 'active') {
            return { isValid: false, message: 'Organization is not active' };
        }
        // Check expiration
        if (codeData.expires_at && new Date(codeData.expires_at) < new Date()) {
            return { isValid: false, message: 'This code has expired' };
        }
        // Check usage limit
        if (codeData.max_uses !== null && codeData.current_uses >= codeData.max_uses) {
            return { isValid: false, message: 'This code has reached its usage limit' };
        }
        return {
            isValid: true,
            organizationId: codeData.organization_id,
            organizationName: codeData.organization_name,
            defaultRole: codeData.default_role
        };
    }
    catch (error) {
        logger_1.logger.error('Validate organization code error', { error: error.message });
        return { isValid: false, message: 'Error validating code' };
    }
};
exports.validateOrganizationCode = validateOrganizationCode;
/**
 * Register a new user with an organization code
 */
const registerWithCode = async (code, userData, ipAddress) => {
    const client = await database_1.pool.connect();
    try {
        await client.query('BEGIN');
        // Validate code first
        const validation = await (0, exports.validateOrganizationCode)(code);
        if (!validation.isValid) {
            return { success: false, message: validation.message };
        }
        // Validate password
        const passwordValidation = (0, password_util_1.validatePassword)(userData.password);
        if (!passwordValidation.isValid) {
            return { success: false, message: `Password: ${passwordValidation.errors.join(', ')}` };
        }
        // Check if email already exists
        const emailExists = await client.query('SELECT user_id FROM user_account WHERE email = $1', [userData.email]);
        if (emailExists.rows.length > 0) {
            return { success: false, message: 'Email already registered' };
        }
        // Generate username
        let username = userData.email.split('@')[0].toLowerCase().replace(/[^a-z0-9]/g, '');
        const usernameCheck = await client.query('SELECT user_id FROM user_account WHERE user_name = $1', [username]);
        if (usernameCheck.rows.length > 0) {
            username = `${username}${Date.now().toString().slice(-4)}`;
        }
        // Hash password
        const hashedPassword = (0, password_util_1.hashPasswordMD5)(userData.password);
        // Get code details
        const codeResult = await client.query('SELECT code_id, organization_id, default_role FROM acc_organization_code WHERE code = $1', [code.toUpperCase()]);
        const codeData = codeResult.rows[0];
        // Create user account
        const userInsert = await client.query(`
      INSERT INTO user_account (
        user_name, first_name, last_name, email, passwd, passwd_timestamp,
        phone, user_type_id, status_id, owner_id, date_created
      ) VALUES (
        $1, $2, $3, $4, $5, NOW(), $6, 2, 1, 1, NOW()
      )
      RETURNING user_id
    `, [
            username,
            userData.firstName,
            userData.lastName,
            userData.email,
            hashedPassword,
            userData.phone || null
        ]);
        const userId = userInsert.rows[0].user_id;
        // Update owner_id to self
        await client.query('UPDATE user_account SET owner_id = $1 WHERE user_id = $1', [userId]);
        // Create organization membership
        await client.query(`
      INSERT INTO acc_organization_membership (
        organization_id, user_id, role, status, date_created
      ) VALUES ($1, $2, $3, 'active', NOW())
    `, [codeData.organization_id, userId, codeData.default_role]);
        // Update code usage
        await client.query(`
      UPDATE acc_organization_code
      SET current_uses = current_uses + 1, date_updated = NOW()
      WHERE code_id = $1
    `, [codeData.code_id]);
        // Log code usage
        await client.query(`
      INSERT INTO acc_organization_code_usage (code_id, user_id, used_at, ip_address)
      VALUES ($1, $2, NOW(), $3)
    `, [codeData.code_id, userId, ipAddress || null]);
        await client.query('COMMIT');
        logger_1.logger.info('User registered with code', { userId, organizationId: codeData.organization_id });
        return {
            success: true,
            userId,
            organizationId: codeData.organization_id,
            message: 'Registration successful'
        };
    }
    catch (error) {
        await client.query('ROLLBACK');
        logger_1.logger.error('Register with code error', { error: error.message });
        return { success: false, message: error.message };
    }
    finally {
        client.release();
    }
};
exports.registerWithCode = registerWithCode;
/**
 * Get organization codes
 */
const getOrganizationCodes = async (organizationId) => {
    try {
        const result = await database_1.pool.query(`
      SELECT 
        c.code_id, c.code, c.organization_id, c.max_uses, c.current_uses,
        c.expires_at, c.default_role, c.is_active, c.created_by, c.date_created,
        o.name as organization_name
      FROM acc_organization_code c
      INNER JOIN acc_organization o ON c.organization_id = o.organization_id
      WHERE c.organization_id = $1
      ORDER BY c.date_created DESC
    `, [organizationId]);
        return result.rows.map(row => ({
            codeId: row.code_id,
            code: row.code,
            organizationId: row.organization_id,
            organizationName: row.organization_name,
            maxUses: row.max_uses,
            currentUses: row.current_uses,
            expiresAt: row.expires_at,
            defaultRole: row.default_role,
            isActive: row.is_active,
            createdBy: row.created_by,
            dateCreated: row.date_created
        }));
    }
    catch (error) {
        logger_1.logger.error('Get organization codes error', { error: error.message, organizationId });
        return [];
    }
};
exports.getOrganizationCodes = getOrganizationCodes;
/**
 * Deactivate an organization code
 */
const deactivateOrganizationCode = async (codeId, userId) => {
    try {
        const result = await database_1.pool.query(`
      UPDATE acc_organization_code
      SET is_active = false, date_updated = NOW()
      WHERE code_id = $1
      RETURNING organization_id
    `, [codeId]);
        if (result.rows.length === 0) {
            return { success: false, message: 'Code not found' };
        }
        logger_1.logger.info('Organization code deactivated', { codeId, userId });
        return { success: true, message: 'Code deactivated' };
    }
    catch (error) {
        logger_1.logger.error('Deactivate organization code error', { error: error.message, codeId });
        return { success: false, message: error.message };
    }
};
exports.deactivateOrganizationCode = deactivateOrganizationCode;
// ============================================================================
// Access Requests
// ============================================================================
/**
 * Create an access request
 */
const createAccessRequest = async (data) => {
    try {
        // Check if email already registered
        const emailExists = await database_1.pool.query('SELECT user_id FROM user_account WHERE email = $1', [data.email]);
        if (emailExists.rows.length > 0) {
            return { success: false, message: 'Email already registered. Please login.' };
        }
        // Check for pending request with same email
        const pendingExists = await database_1.pool.query(`SELECT request_id FROM acc_access_request WHERE email = $1 AND status = 'pending'`, [data.email]);
        if (pendingExists.rows.length > 0) {
            return { success: false, message: 'You already have a pending access request' };
        }
        const result = await database_1.pool.query(`
      INSERT INTO acc_access_request (
        email, first_name, last_name, phone, organization_name,
        professional_title, credentials, reason,
        organization_id, requested_role, status, date_created
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, 'pending', NOW())
      RETURNING request_id
    `, [
            data.email,
            data.firstName,
            data.lastName,
            data.phone || null,
            data.organizationName || null,
            data.professionalTitle || null,
            data.credentials || null,
            data.reason || null,
            data.organizationId || null,
            data.requestedRole || 'member'
        ]);
        logger_1.logger.info('Access request created', { requestId: result.rows[0].request_id, email: data.email });
        return {
            success: true,
            requestId: result.rows[0].request_id,
            message: 'Access request submitted. You will be notified once reviewed.'
        };
    }
    catch (error) {
        logger_1.logger.error('Create access request error', { error: error.message });
        return { success: false, message: error.message };
    }
};
exports.createAccessRequest = createAccessRequest;
/**
 * Get access requests with filters
 */
const getAccessRequests = async (filters) => {
    try {
        const { status, organizationId, page = 1, limit = 20 } = filters;
        const offset = (page - 1) * limit;
        const conditions = [];
        const params = [];
        let paramIndex = 1;
        if (status) {
            conditions.push(`status = $${paramIndex++}`);
            params.push(status);
        }
        if (organizationId) {
            conditions.push(`organization_id = $${paramIndex++}`);
            params.push(organizationId);
        }
        const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
        // Count total
        const countResult = await database_1.pool.query(`SELECT COUNT(*) as total FROM acc_access_request ${whereClause}`, params);
        const total = parseInt(countResult.rows[0].total);
        // Get data
        params.push(limit, offset);
        const dataResult = await database_1.pool.query(`
      SELECT *
      FROM acc_access_request
      ${whereClause}
      ORDER BY date_created DESC
      LIMIT $${paramIndex++} OFFSET $${paramIndex}
    `, params);
        return {
            data: dataResult.rows.map(row => ({
                requestId: row.request_id,
                email: row.email,
                firstName: row.first_name,
                lastName: row.last_name,
                phone: row.phone,
                organizationName: row.organization_name,
                professionalTitle: row.professional_title,
                credentials: row.credentials,
                reason: row.reason,
                organizationId: row.organization_id,
                requestedRole: row.requested_role,
                status: row.status,
                reviewedBy: row.reviewed_by,
                reviewedAt: row.reviewed_at,
                reviewNotes: row.review_notes,
                userId: row.user_id,
                dateCreated: row.date_created
            })),
            total
        };
    }
    catch (error) {
        logger_1.logger.error('Get access requests error', { error: error.message });
        throw error;
    }
};
exports.getAccessRequests = getAccessRequests;
/**
 * Review an access request (approve or reject)
 */
const reviewAccessRequest = async (requestId, reviewedBy, decision, notes, password) => {
    const client = await database_1.pool.connect();
    try {
        await client.query('BEGIN');
        // Get request details
        const requestResult = await client.query('SELECT * FROM acc_access_request WHERE request_id = $1', [requestId]);
        if (requestResult.rows.length === 0) {
            return { success: false, message: 'Access request not found' };
        }
        const request = requestResult.rows[0];
        if (request.status !== 'pending') {
            return { success: false, message: 'Request has already been reviewed' };
        }
        let userId;
        if (decision === 'approved') {
            // Generate password if not provided
            const userPassword = password || crypto_1.default.randomBytes(8).toString('hex') + '!@1A';
            // Validate password
            const passwordValidation = (0, password_util_1.validatePassword)(userPassword);
            if (!passwordValidation.isValid) {
                return { success: false, message: `Password: ${passwordValidation.errors.join(', ')}` };
            }
            // Generate username
            let username = request.email.split('@')[0].toLowerCase().replace(/[^a-z0-9]/g, '');
            const usernameCheck = await client.query('SELECT user_id FROM user_account WHERE user_name = $1', [username]);
            if (usernameCheck.rows.length > 0) {
                username = `${username}${Date.now().toString().slice(-4)}`;
            }
            // Hash password
            const hashedPassword = (0, password_util_1.hashPasswordMD5)(userPassword);
            // Create user account
            const userInsert = await client.query(`
        INSERT INTO user_account (
          user_name, first_name, last_name, email, passwd, passwd_timestamp,
          phone, user_type_id, status_id, owner_id, date_created
        ) VALUES ($1, $2, $3, $4, $5, NOW(), $6, 2, 1, $7, NOW())
        RETURNING user_id
      `, [
                username,
                request.first_name,
                request.last_name,
                request.email,
                hashedPassword,
                request.phone,
                reviewedBy
            ]);
            userId = userInsert.rows[0].user_id;
            // If organization specified, add membership
            if (request.organization_id) {
                await client.query(`
          INSERT INTO acc_organization_membership (
            organization_id, user_id, role, status, invited_by, date_created
          ) VALUES ($1, $2, $3, 'active', $4, NOW())
        `, [request.organization_id, userId, request.requested_role || 'member', reviewedBy]);
            }
            // TODO: Send welcome email with password
            logger_1.logger.info('Access request approved - user created', {
                requestId,
                userId,
                email: request.email,
                tempPassword: userPassword
            });
        }
        // Update request status
        await client.query(`
      UPDATE acc_access_request
      SET status = $1, reviewed_by = $2, reviewed_at = NOW(), review_notes = $3, user_id = $4, date_updated = NOW()
      WHERE request_id = $5
    `, [decision, reviewedBy, notes || null, userId || null, requestId]);
        await client.query('COMMIT');
        return {
            success: true,
            userId,
            message: decision === 'approved' ? 'Request approved and user created' : 'Request rejected'
        };
    }
    catch (error) {
        await client.query('ROLLBACK');
        logger_1.logger.error('Review access request error', { error: error.message, requestId });
        return { success: false, message: error.message };
    }
    finally {
        client.release();
    }
};
exports.reviewAccessRequest = reviewAccessRequest;
// ============================================================================
// User Invitations
// ============================================================================
/**
 * Create a user invitation
 */
const createInvitation = async (email, invitedBy, options = {}) => {
    try {
        // Check if email already registered
        const emailExists = await database_1.pool.query('SELECT user_id FROM user_account WHERE email = $1', [email]);
        if (emailExists.rows.length > 0) {
            return { success: false, message: 'Email already registered' };
        }
        // Check for pending invitation
        const pendingExists = await database_1.pool.query(`SELECT invitation_id FROM acc_user_invitation WHERE email = $1 AND status = 'pending' AND expires_at > NOW()`, [email]);
        if (pendingExists.rows.length > 0) {
            return { success: false, message: 'A pending invitation already exists for this email' };
        }
        // Generate unique token
        const token = crypto_1.default.randomBytes(32).toString('hex');
        // Calculate expiration (default 7 days)
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + (options.expiresInDays || 7));
        const result = await database_1.pool.query(`
      INSERT INTO acc_user_invitation (
        email, token, organization_id, study_id, role,
        status, expires_at, invited_by, message, date_created
      ) VALUES ($1, $2, $3, $4, $5, 'pending', $6, $7, $8, NOW())
      RETURNING invitation_id
    `, [
            email,
            token,
            options.organizationId || null,
            options.studyId || null,
            options.role || 'member',
            expiresAt,
            invitedBy,
            options.message || null
        ]);
        logger_1.logger.info('User invitation created', { invitationId: result.rows[0].invitation_id, email });
        return {
            success: true,
            token,
            invitationId: result.rows[0].invitation_id
        };
    }
    catch (error) {
        logger_1.logger.error('Create invitation error', { error: error.message });
        return { success: false, message: error.message };
    }
};
exports.createInvitation = createInvitation;
/**
 * Validate an invitation token
 */
const validateInvitation = async (token) => {
    try {
        const result = await database_1.pool.query(`
      SELECT 
        i.*,
        o.name as organization_name,
        s.name as study_name,
        CONCAT(u.first_name, ' ', u.last_name) as inviter_name
      FROM acc_user_invitation i
      LEFT JOIN acc_organization o ON i.organization_id = o.organization_id
      LEFT JOIN study s ON i.study_id = s.study_id
      LEFT JOIN user_account u ON i.invited_by = u.user_id
      WHERE i.token = $1
    `, [token]);
        if (result.rows.length === 0) {
            return { isValid: false };
        }
        const invitation = result.rows[0];
        if (invitation.status !== 'pending') {
            return { isValid: false };
        }
        if (new Date(invitation.expires_at) < new Date()) {
            return { isValid: false };
        }
        return {
            isValid: true,
            email: invitation.email,
            organizationId: invitation.organization_id,
            organizationName: invitation.organization_name,
            studyId: invitation.study_id,
            studyName: invitation.study_name,
            role: invitation.role,
            inviterName: invitation.inviter_name,
            message: invitation.message
        };
    }
    catch (error) {
        logger_1.logger.error('Validate invitation error', { error: error.message });
        return { isValid: false };
    }
};
exports.validateInvitation = validateInvitation;
/**
 * Accept an invitation and create user account
 */
const acceptInvitation = async (token, userData) => {
    const client = await database_1.pool.connect();
    try {
        await client.query('BEGIN');
        // Validate invitation
        const validation = await (0, exports.validateInvitation)(token);
        if (!validation.isValid || !validation.email) {
            return { success: false, message: 'Invalid or expired invitation' };
        }
        // Validate password
        const passwordValidation = (0, password_util_1.validatePassword)(userData.password);
        if (!passwordValidation.isValid) {
            return { success: false, message: `Password: ${passwordValidation.errors.join(', ')}` };
        }
        // Generate username
        let username = validation.email.split('@')[0].toLowerCase().replace(/[^a-z0-9]/g, '');
        const usernameCheck = await client.query('SELECT user_id FROM user_account WHERE user_name = $1', [username]);
        if (usernameCheck.rows.length > 0) {
            username = `${username}${Date.now().toString().slice(-4)}`;
        }
        // Hash password
        const hashedPassword = (0, password_util_1.hashPasswordMD5)(userData.password);
        // Get invitation details
        const invResult = await client.query('SELECT invitation_id, organization_id, study_id, role, invited_by FROM acc_user_invitation WHERE token = $1', [token]);
        const invitation = invResult.rows[0];
        // Create user account
        const userInsert = await client.query(`
      INSERT INTO user_account (
        user_name, first_name, last_name, email, passwd, passwd_timestamp,
        phone, user_type_id, status_id, owner_id, date_created
      ) VALUES ($1, $2, $3, $4, $5, NOW(), $6, 2, 1, $7, NOW())
      RETURNING user_id
    `, [
            username,
            userData.firstName,
            userData.lastName,
            validation.email,
            hashedPassword,
            userData.phone || null,
            invitation.invited_by
        ]);
        const userId = userInsert.rows[0].user_id;
        // Add organization membership if specified
        if (invitation.organization_id) {
            await client.query(`
        INSERT INTO acc_organization_membership (
          organization_id, user_id, role, status, invited_by, date_created
        ) VALUES ($1, $2, $3, 'active', $4, NOW())
      `, [invitation.organization_id, userId, invitation.role || 'member', invitation.invited_by]);
        }
        // Add study role if specified
        if (invitation.study_id) {
            await client.query(`
        INSERT INTO study_user_role (
          role_name, study_id, status_id, owner_id, date_created, user_name
        ) VALUES ($1, $2, 1, $3, NOW(), $4)
      `, [invitation.role || 'ra', invitation.study_id, invitation.invited_by, username]);
        }
        // Update invitation status
        await client.query(`
      UPDATE acc_user_invitation
      SET status = 'accepted', accepted_by = $1, accepted_at = NOW()
      WHERE invitation_id = $2
    `, [userId, invitation.invitation_id]);
        await client.query('COMMIT');
        logger_1.logger.info('Invitation accepted', { invitationId: invitation.invitation_id, userId });
        return {
            success: true,
            userId,
            message: 'Account created successfully'
        };
    }
    catch (error) {
        await client.query('ROLLBACK');
        logger_1.logger.error('Accept invitation error', { error: error.message });
        return { success: false, message: error.message };
    }
    finally {
        client.release();
    }
};
exports.acceptInvitation = acceptInvitation;
// ============================================================================
// Helper Functions
// ============================================================================
function mapOrganizationRow(row) {
    return {
        organizationId: row.organization_id,
        name: row.name,
        type: row.type,
        status: row.status,
        email: row.email,
        phone: row.phone,
        website: row.website,
        street: row.street,
        city: row.city,
        state: row.state,
        postalCode: row.postal_code,
        country: row.country,
        ownerId: row.owner_id,
        approvedBy: row.approved_by,
        approvedAt: row.approved_at,
        dateCreated: row.date_created,
        dateUpdated: row.date_updated
    };
}
exports.default = {
    // Organizations
    createOrganizationWithAdmin: exports.createOrganizationWithAdmin,
    getOrganizationById: exports.getOrganizationById,
    getOrganizations: exports.getOrganizations,
    updateOrganizationStatus: exports.updateOrganizationStatus,
    getUserOrganizations: exports.getUserOrganizations,
    // Codes
    generateOrganizationCode: exports.generateOrganizationCode,
    validateOrganizationCode: exports.validateOrganizationCode,
    registerWithCode: exports.registerWithCode,
    getOrganizationCodes: exports.getOrganizationCodes,
    deactivateOrganizationCode: exports.deactivateOrganizationCode,
    // Access Requests
    createAccessRequest: exports.createAccessRequest,
    getAccessRequests: exports.getAccessRequests,
    reviewAccessRequest: exports.reviewAccessRequest,
    // Invitations
    createInvitation: exports.createInvitation,
    validateInvitation: exports.validateInvitation,
    acceptInvitation: exports.acceptInvitation
};
//# sourceMappingURL=organization.service.js.map