"use strict";
/**
 * Validation Rules Routes
 *
 * API endpoints for managing validation rules
 *
 * 21 CFR Part 11 Compliance:
 * - Rule creation/modification requires electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const controller = __importStar(require("../controllers/validation-rules.controller"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const authorization_middleware_1 = require("../middleware/authorization.middleware");
const part11_middleware_1 = require("../middleware/part11.middleware");
const router = (0, express_1.Router)();
// All routes require authentication
router.use(auth_middleware_1.authMiddleware);
// Get validation rules for a CRF (no signature required)
router.get('/crf/:crfId', controller.getRulesForCrf);
// Get validation rules for a study (all CRFs)
router.get('/study/:studyId', controller.getRulesForStudy);
// Get a single rule
router.get('/:ruleId', controller.getRule);
// Create a new rule (admin/coordinator only + signature)
router.post('/', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, part11_middleware_1.requireSignatureFor)('I authorize creation of this validation rule'), controller.createRule);
// Update a rule (signature required)
router.put('/:ruleId', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, part11_middleware_1.requireSignatureFor)('I authorize modification of this validation rule'), controller.updateRule);
// Toggle rule active state (signature required)
router.patch('/:ruleId/toggle', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, part11_middleware_1.requireSignatureFor)('I authorize toggling this validation rule'), controller.toggleRule);
// Delete a rule (admin only + signature)
router.delete('/:ruleId', (0, authorization_middleware_1.requireRole)('admin'), (0, part11_middleware_1.requireSignatureFor)('I authorize deletion of this validation rule'), controller.deleteRule);
// Validate form data against rules (no signature - read-only operation)
router.post('/validate/:crfId', controller.validateData);
// Test a rule (no signature - read-only operation)
router.post('/test', controller.testRule);
exports.default = router;
//# sourceMappingURL=validation-rules.routes.js.map