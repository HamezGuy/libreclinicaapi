"use strict";
/**
 * Subject Routes
 *
 * API endpoints for subject/patient management including:
 * - List and search subjects
 * - CRUD operations
 * - Progress tracking
 * - Events and forms
 *
 * 21 CFR Part 11 Compliance:
 * - Subject enrollment requires electronic signature (§11.50)
 * - Subject modifications require electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const controller = __importStar(require("../controllers/subject.controller"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const authorization_middleware_1 = require("../middleware/authorization.middleware");
const validation_middleware_1 = require("../middleware/validation.middleware");
const rateLimiter_middleware_1 = require("../middleware/rateLimiter.middleware");
const part11_middleware_1 = require("../middleware/part11.middleware");
const studyParamsService = __importStar(require("../services/database/studyParameters.service"));
const studyGroupsService = __importStar(require("../services/database/studyGroups.service"));
const logger_1 = require("../config/logger");
const router = express_1.default.Router();
router.use(auth_middleware_1.authMiddleware);
/**
 * GET /api/subjects/enrollment-config/:studyId
 * Get study parameters and group classes needed for enrollment form
 * This tells the frontend how to configure the enrollment form dynamically
 */
router.get('/enrollment-config/:studyId', async (req, res) => {
    try {
        const studyId = parseInt(req.params.studyId);
        if (isNaN(studyId)) {
            res.status(400).json({ success: false, message: 'Invalid study ID' });
            return;
        }
        // Fetch study parameters and group classes in parallel
        const [parameters, groupClasses, nextSubjectId] = await Promise.all([
            studyParamsService.getStudyParameters(studyId),
            studyGroupsService.getStudyGroupClasses(studyId),
            studyParamsService.generateNextSubjectId(studyId)
        ]);
        res.json({
            success: true,
            data: {
                studyId,
                parameters,
                groupClasses,
                suggestedSubjectId: nextSubjectId,
                // UI hints based on parameters
                formConfig: {
                    showDateOfBirth: parameters.collectDob !== 'not_used',
                    dateOfBirthRequired: parameters.collectDob === 'required',
                    yearOfBirthOnly: parameters.collectDob === 'year_only',
                    showGender: parameters.genderRequired,
                    genderRequired: parameters.genderRequired,
                    showPersonId: parameters.subjectPersonIdRequired !== 'not_used',
                    personIdRequired: parameters.subjectPersonIdRequired === 'required',
                    showSecondaryLabel: parameters.secondaryLabelViewable,
                    subjectIdAutoGenerate: parameters.subjectIdGeneration !== 'manual',
                    subjectIdEditable: parameters.subjectIdGeneration !== 'auto_non_editable',
                    showEventLocation: parameters.eventLocationRequired !== 'not_used',
                    eventLocationRequired: parameters.eventLocationRequired === 'required',
                    randomizationEnabled: parameters.randomization === 'enabled',
                    requiredGroupClasses: groupClasses.filter(gc => gc.subjectAssignment === 'Required'),
                    optionalGroupClasses: groupClasses.filter(gc => gc.subjectAssignment === 'Optional')
                }
            }
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to get enrollment config', {
            studyId: req.params.studyId,
            error: error.message
        });
        res.status(500).json({ success: false, message: error.message });
    }
});
// Read operations (no signature required)
router.get('/', (0, validation_middleware_1.validate)({ query: validation_middleware_1.subjectSchemas.list }), controller.list);
router.get('/:id', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.get);
router.get('/:id/progress', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.getProgress);
router.get('/:id/events', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.getEvents);
router.get('/:id/forms', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.getForms);
// Create/Update operations - require coordinator or investigator role + signature
router.post('/', (0, authorization_middleware_1.requireRole)('coordinator', 'investigator'), rateLimiter_middleware_1.soapRateLimiter, (0, validation_middleware_1.validate)({ body: validation_middleware_1.subjectSchemas.create }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.SUBJECT_ENROLL), controller.create);
router.put('/:id', (0, authorization_middleware_1.requireRole)('coordinator', 'investigator'), (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.SUBJECT_UPDATE), controller.update);
router.put('/:id/status', (0, authorization_middleware_1.requireRole)('coordinator', 'investigator'), (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.SUBJECT_WITHDRAW), controller.updateStatus);
// Delete operation - require admin role (soft delete) + signature
router.delete('/:id', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.SUBJECT_DELETE), controller.remove);
exports.default = router;
//# sourceMappingURL=subject.routes.js.map