/**
 * Skip Logic Types
 *
 * Advanced skip logic, branching rules, and form linking for EDC forms.
 * Supports:
 * - Field visibility conditions (show/hide based on other field values)
 * - Conditional required fields
 * - Form branching (link to other forms based on answers)
 * - Section show/hide
 * - Calculated field triggers
 *
 * 21 CFR Part 11 §11.10(h) - Device checks (validation and logic rules)
 */
export type SkipLogicOperator = 'equals' | 'not_equals' | 'greater_than' | 'less_than' | 'greater_than_or_equal' | 'less_than_or_equal' | 'contains' | 'not_contains' | 'starts_with' | 'ends_with' | 'is_empty' | 'is_not_empty' | 'in_list' | 'not_in_list' | 'between' | 'not_between' | 'matches_regex' | 'is_true' | 'is_false' | 'date_before' | 'date_after' | 'date_between' | 'age_greater_than' | 'age_less_than';
export type LogicalOperator = 'AND' | 'OR';
/**
 * A single condition in a skip logic rule
 */
export interface SkipLogicCondition {
    id?: string;
    fieldId: string;
    fieldName?: string;
    operator: SkipLogicOperator;
    value: any;
    value2?: any;
    logicalOperator?: LogicalOperator;
}
/**
 * A group of conditions that can be nested
 */
export interface ConditionGroup {
    id?: string;
    conditions: SkipLogicCondition[];
    nestedGroups?: ConditionGroup[];
    groupOperator: LogicalOperator;
}
export type SkipLogicActionType = 'show' | 'hide' | 'require' | 'optional' | 'disable' | 'enable' | 'set_value' | 'clear_value' | 'open_form' | 'show_section' | 'hide_section' | 'show_message' | 'trigger_calculation' | 'create_query' | 'send_notification';
/**
 * Action to perform when conditions are met
 */
export interface SkipLogicAction {
    id?: string;
    type: SkipLogicActionType;
    targetFieldId?: string;
    targetFieldName?: string;
    targetSectionId?: string;
    targetFormId?: number;
    targetFormName?: string;
    value?: any;
    message?: string;
    notificationRecipients?: string[];
    queryType?: string;
    priority?: number;
}
/**
 * Complete skip logic rule combining conditions and actions
 */
export interface SkipLogicRule {
    id: string;
    name: string;
    description?: string;
    enabled: boolean;
    priority: number;
    conditions: SkipLogicCondition[];
    conditionGroups?: ConditionGroup[];
    actions: SkipLogicAction[];
    elseActions?: SkipLogicAction[];
    crfId?: number;
    crfVersionId?: number;
    sectionId?: string;
    createdAt?: Date;
    createdBy?: number;
    updatedAt?: Date;
    updatedBy?: number;
}
/**
 * Form link definition - opens another form based on field value
 */
export interface FormLink {
    id: string;
    name: string;
    description?: string;
    sourceCrfId: number;
    sourceFieldId: string;
    sourceFieldName?: string;
    triggerConditions: SkipLogicCondition[];
    targetCrfId: number;
    targetCrfName?: string;
    targetCrfVersionId?: number;
    linkType: 'modal' | 'redirect' | 'new_tab' | 'embedded';
    required: boolean;
    autoOpen: boolean;
    prefillFields?: FormLinkPrefill[];
    enabled: boolean;
    createdAt?: Date;
    createdBy?: number;
}
/**
 * Prefill configuration for linked forms
 */
export interface FormLinkPrefill {
    sourceFieldId: string;
    targetFieldId: string;
    transformFunction?: string;
}
/**
 * Common trigger patterns for form linking
 */
export declare const COMMON_LINK_TRIGGERS: {
    YES_ANSWER: {
        operator: SkipLogicOperator;
        value: string;
    };
    NO_ANSWER: {
        operator: SkipLogicOperator;
        value: string;
    };
    TRUE_ANSWER: {
        operator: SkipLogicOperator;
        value: boolean;
    };
    FALSE_ANSWER: {
        operator: SkipLogicOperator;
        value: boolean;
    };
    NOT_EMPTY: {
        operator: SkipLogicOperator;
        value: null;
    };
    VALUE_SELECTED: (value: string) => {
        operator: SkipLogicOperator;
        value: string;
    };
    VALUE_IN_RANGE: (min: number, max: number) => {
        operator: SkipLogicOperator;
        value: number;
        value2: number;
    };
};
/**
 * Form branching configuration - determines which forms to show based on answers
 */
export interface FormBranch {
    id: string;
    name: string;
    sourceEventDefinitionId?: number;
    sourceCrfId: number;
    conditions: SkipLogicCondition[];
    targetForms: FormBranchTarget[];
    enabled: boolean;
    priority: number;
}
export interface FormBranchTarget {
    crfId: number;
    crfName?: string;
    required: boolean;
    order: number;
}
export interface SkipLogicEvaluationResult {
    ruleId: string;
    conditionsMet: boolean;
    actionsToExecute: SkipLogicAction[];
    evaluatedAt: Date;
    evaluationDetails?: {
        conditionResults: {
            condition: SkipLogicCondition;
            result: boolean;
        }[];
    };
}
export interface FieldVisibilityState {
    fieldId: string;
    visible: boolean;
    required: boolean;
    disabled: boolean;
    value?: any;
    linkedForms?: {
        formId: number;
        formName: string;
        autoOpen: boolean;
    }[];
    message?: string;
    evaluatedAt: Date;
}
export interface FormBranchingResult {
    sourceFormId: number;
    branchId?: string;
    activeBranches: {
        targetFormId: number;
        targetFormName?: string;
        required: boolean;
        autoOpen: boolean;
    }[];
    evaluatedAt: Date;
}
/**
 * Database row for skip_logic_rules table
 */
export interface SkipLogicRuleRow {
    rule_id: number;
    crf_id: number;
    crf_version_id?: number;
    name: string;
    description?: string;
    conditions_json: string;
    actions_json: string;
    else_actions_json?: string;
    enabled: boolean;
    priority: number;
    date_created: Date;
    date_updated?: Date;
    owner_id: number;
    update_id?: number;
}
/**
 * Database row for form_links table
 */
export interface FormLinkRow {
    link_id: number;
    name: string;
    description?: string;
    source_crf_id: number;
    source_field_id: string;
    trigger_conditions_json: string;
    target_crf_id: number;
    target_crf_version_id?: number;
    link_type: string;
    required: boolean;
    auto_open: boolean;
    prefill_fields_json?: string;
    enabled: boolean;
    date_created: Date;
    date_updated?: Date;
    owner_id: number;
    update_id?: number;
}
export interface CreateSkipLogicRuleRequest {
    crfId: number;
    crfVersionId?: number;
    name: string;
    description?: string;
    conditions: SkipLogicCondition[];
    actions: SkipLogicAction[];
    elseActions?: SkipLogicAction[];
    enabled?: boolean;
    priority?: number;
}
export interface UpdateSkipLogicRuleRequest {
    name?: string;
    description?: string;
    conditions?: SkipLogicCondition[];
    actions?: SkipLogicAction[];
    elseActions?: SkipLogicAction[];
    enabled?: boolean;
    priority?: number;
}
export interface CreateFormLinkRequest {
    name: string;
    description?: string;
    sourceCrfId: number;
    sourceFieldId: string;
    triggerConditions: SkipLogicCondition[];
    targetCrfId: number;
    targetCrfVersionId?: number;
    linkType?: 'modal' | 'redirect' | 'new_tab' | 'embedded';
    required?: boolean;
    autoOpen?: boolean;
    prefillFields?: FormLinkPrefill[];
}
export interface EvaluateSkipLogicRequest {
    crfId: number;
    formData: Record<string, any>;
    subjectId?: number;
    eventId?: number;
}
export interface EvaluateSkipLogicResponse {
    success: boolean;
    fieldStates: Record<string, FieldVisibilityState>;
    linkedForms: {
        fieldId: string;
        targetFormId: number;
        targetFormName: string;
        shouldOpen: boolean;
    }[];
    messages: {
        fieldId?: string;
        message: string;
        type: 'info' | 'warning' | 'error';
    }[];
}
//# sourceMappingURL=skip-logic.types.d.ts.map