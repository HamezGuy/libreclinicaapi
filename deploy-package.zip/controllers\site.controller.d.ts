/**
 * Site Controller
 *
 * Handles all site/location-related API endpoints including:
 * - CRUD operations for sites
 * - Patient-to-site assignments
 * - Site staff management
 * - Site statistics
 *
 * 21 CFR Part 11 Compliance:
 * - All site modifications require electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
import { Request, Response } from 'express';
/**
 * Get all sites for a study
 * GET /api/sites/study/:studyId
 */
export declare const getSitesForStudy: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get a single site by ID
 * GET /api/sites/:id
 */
export declare const getSiteById: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Create a new site
 * POST /api/sites
 */
export declare const createSite: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Update a site
 * PUT /api/sites/:id
 */
export declare const updateSite: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Delete a site
 * DELETE /api/sites/:id
 */
export declare const deleteSite: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get patients for a site
 * GET /api/sites/:id/patients
 */
export declare const getSitePatients: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Transfer a patient to a different site
 * POST /api/sites/transfer
 */
export declare const transferPatient: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get site staff
 * GET /api/sites/:id/staff
 */
export declare const getSiteStaff: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Assign staff to a site
 * POST /api/sites/:id/staff
 */
export declare const assignStaff: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Remove staff from a site
 * DELETE /api/sites/:id/staff/:username
 */
export declare const removeStaff: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get site statistics for a study
 * GET /api/sites/study/:studyId/stats
 */
export declare const getSiteStatistics: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    getSitesForStudy: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getSiteById: (req: Request, res: Response, next: import("express").NextFunction) => void;
    createSite: (req: Request, res: Response, next: import("express").NextFunction) => void;
    updateSite: (req: Request, res: Response, next: import("express").NextFunction) => void;
    deleteSite: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getSitePatients: (req: Request, res: Response, next: import("express").NextFunction) => void;
    transferPatient: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getSiteStaff: (req: Request, res: Response, next: import("express").NextFunction) => void;
    assignStaff: (req: Request, res: Response, next: import("express").NextFunction) => void;
    removeStaff: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getSiteStatistics: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=site.controller.d.ts.map