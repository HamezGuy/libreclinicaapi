/**
 * Double Data Entry (DDE) Service
 *
 * Implements double data entry workflow using LibreClinica's NATIVE tables.
 * LibreClinica already supports DDE via:
 * - event_definition_crf.double_entry (boolean flag)
 * - event_crf.completion_status_id (1=not_started, 2=initial_data_entry, 3=complete, etc.)
 * - event_crf.validator_id (stores second entry user)
 * - Uses discrepancy_note for tracking differences
 *
 * 21 CFR Part 11 Compliance:
 * - Full audit trail via audit_log_event
 * - Different user required for second entry (validator)
 * - Complete data integrity checks
 *
 * NOTE: This version uses ONLY existing LibreClinica tables - NO custom acc_* tables
 */
export interface DDEEntryRequest {
    eventCrfId: number;
    entries: {
        itemId: number;
        value: string;
    }[];
    userId: number;
}
export interface DDEStatus {
    statusId: number;
    eventCrfId: number;
    firstEntryStatus: 'pending' | 'in_progress' | 'complete';
    firstEntryBy?: number;
    firstEntryByName?: string;
    firstEntryAt?: Date;
    secondEntryStatus: 'pending' | 'in_progress' | 'complete';
    secondEntryBy?: number;
    secondEntryByName?: string;
    secondEntryAt?: Date;
    comparisonStatus: 'pending' | 'matched' | 'discrepancies' | 'resolved';
    totalItems: number;
    matchedItems: number;
    discrepancyCount: number;
    resolvedCount: number;
    ddeComplete: boolean;
}
export interface DDEItemComparison {
    itemId: number;
    itemName: string;
    itemDescription?: string;
    firstValue: string;
    secondValue: string;
    matches: boolean;
    discrepancyId?: number;
    resolutionStatus?: string;
    resolvedValue?: string;
    resolvedBy?: string;
}
export interface DDEComparison {
    eventCrfId: number;
    subjectLabel: string;
    formName: string;
    items: DDEItemComparison[];
    summary: {
        total: number;
        matched: number;
        discrepancies: number;
        resolved: number;
    };
}
export interface DDEResolution {
    discrepancyId: number;
    resolution: 'first_correct' | 'second_correct' | 'new_value' | 'adjudicated';
    newValue?: string;
    adjudicationNotes?: string;
    resolvedBy: number;
}
export interface DDEDashboardItem {
    eventCrfId: number;
    studySubjectId: number;
    subjectLabel: string;
    studyName: string;
    siteName: string;
    formName: string;
    eventName: string;
    ddeStatus: DDEStatus;
    daysWaiting: number;
}
/**
 * Check if DDE is required for an event_crf
 * Uses LibreClinica's native double_entry flag in event_definition_crf
 */
export declare function isDDERequired(eventCrfId: number): Promise<boolean>;
/**
 * Get DDE status for an event_crf
 * Uses LibreClinica's native completion_status_id and validator fields
 */
export declare function getDDEStatus(eventCrfId: number): Promise<DDEStatus | null>;
/**
 * Check if a user can perform DDE entry
 */
export declare function canUserPerformDDE(eventCrfId: number, userId: number): Promise<{
    allowed: boolean;
    reason?: string;
    entryType?: 'first' | 'second';
}>;
/**
 * Mark first entry as complete
 * Updates LibreClinica's completion_status_id to 3 (initial_data_entry_complete)
 */
export declare function markFirstEntryComplete(eventCrfId: number, userId: number): Promise<DDEStatus>;
/**
 * Submit second entry data
 * Stores second entry values as annotations and updates validator_id
 */
export declare function submitSecondEntry(request: DDEEntryRequest): Promise<DDEStatus>;
/**
 * Compare first and second entries
 * Creates discrepancy_notes for mismatches using LibreClinica's native query system
 */
export declare function compareEntries(eventCrfId: number): Promise<DDEComparison>;
/**
 * Resolve a discrepancy
 * Uses LibreClinica's native discrepancy_note resolution
 */
export declare function resolveDiscrepancy(resolution: DDEResolution): Promise<void>;
/**
 * Finalize DDE (all discrepancies must be resolved)
 */
export declare function finalizeDDE(eventCrfId: number, userId: number): Promise<DDEStatus>;
/**
 * Get DDE dashboard items (pending work)
 * Uses LibreClinica's native completion_status to determine DDE state
 */
export declare function getDDEDashboard(userId: number, siteId?: number): Promise<{
    pendingSecondEntry: DDEDashboardItem[];
    pendingResolution: DDEDashboardItem[];
    stats: {
        total: number;
        pending: number;
        discrepancies: number;
        complete: number;
    };
}>;
declare const _default: {
    isDDERequired: typeof isDDERequired;
    getDDEStatus: typeof getDDEStatus;
    canUserPerformDDE: typeof canUserPerformDDE;
    markFirstEntryComplete: typeof markFirstEntryComplete;
    submitSecondEntry: typeof submitSecondEntry;
    compareEntries: typeof compareEntries;
    resolveDiscrepancy: typeof resolveDiscrepancy;
    finalizeDDE: typeof finalizeDDE;
    getDDEDashboard: typeof getDDEDashboard;
};
export default _default;
//# sourceMappingURL=dde.service.d.ts.map