"use strict";
/**
 * Data SOAP Service
 *
 * Handles clinical data entry via LibreClinica SOAP API
 * - Import CRF data using ODM XML
 * - Build ODM XML from form data
 * - Validate data entries
 * - Support electronic signatures
 *
 * SOAP Endpoint: http://localhost:8080/LibreClinica/ws/data/v1
 * Uses ODM 1.3 standard for data interchange
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateOdmStructure = exports.buildItemDataOdm = exports.parseImportResponse = exports.buildOdmXml = exports.importData = void 0;
const soapClient_1 = require("./soapClient");
const logger_1 = require("../../config/logger");
const xml2js_1 = __importDefault(require("xml2js"));
/**
 * Import clinical data via SOAP
 * Main method for saving CRF data
 */
const importData = async (request, userId, username) => {
    logger_1.logger.info('Importing clinical data via SOAP', {
        studyId: request.studyId,
        subjectId: request.subjectId,
        crfId: request.crfId,
        userId,
        username
    });
    try {
        // Build ODM XML from form data
        const odmXml = await (0, exports.buildOdmXml)(request);
        logger_1.logger.debug('ODM XML built for data import', {
            subjectId: request.subjectId,
            odmLength: odmXml.length
        });
        // Execute SOAP request
        const soapClient = (0, soapClient_1.getSoapClient)();
        const response = await soapClient.executeRequest({
            serviceName: 'data',
            methodName: 'importODM',
            parameters: {
                odm: odmXml
            },
            userId,
            username
        });
        if (!response.success) {
            logger_1.logger.error('Data import failed', {
                error: response.error,
                subjectId: request.subjectId
            });
            return {
                success: false,
                message: response.error || 'Data import failed'
            };
        }
        // Parse response for validation errors
        const parsedResponse = await (0, exports.parseImportResponse)(response.data);
        if (parsedResponse.validationErrors && parsedResponse.validationErrors.length > 0) {
            logger_1.logger.warn('Data import completed with validation errors', {
                subjectId: request.subjectId,
                errorCount: parsedResponse.validationErrors.length
            });
            return {
                success: false,
                message: 'Data import failed validation',
                data: parsedResponse
            };
        }
        logger_1.logger.info('Data imported successfully', {
            subjectId: request.subjectId,
            eventCrfId: parsedResponse.eventCrfId
        });
        return {
            success: true,
            data: parsedResponse,
            message: 'Data imported successfully'
        };
    }
    catch (error) {
        logger_1.logger.error('Data import error', {
            error: error.message,
            subjectId: request.subjectId
        });
        return {
            success: false,
            message: `Data import failed: ${error.message}`
        };
    }
};
exports.importData = importData;
/**
 * Build ODM XML from form data request
 * Converts JSON form data to ODM 1.3 XML format
 */
const buildOdmXml = async (request) => {
    const { studyId, subjectId, studyEventDefinitionId, crfId, formData, electronicSignature } = request;
    // Get study and subject OIDs (you may need to query these from database)
    const studyOid = `S_${studyId}`;
    const subjectOid = `SS_${subjectId}`;
    const eventOid = `SE_${studyEventDefinitionId}`;
    const formOid = `F_${crfId}`;
    const timestamp = new Date().toISOString();
    let odmXml = `<?xml version="1.0" encoding="UTF-8"?>
<ODM xmlns="http://www.cdisc.org/ns/odm/v1.3"
     xmlns:OpenClinica="http://www.openclinica.org/ns/odm_ext_v130/v3.1"
     ODMVersion="1.3"
     FileType="Transactional"
     FileOID="ODM-${Date.now()}"
     CreationDateTime="${timestamp}">
  <ClinicalData StudyOID="${studyOid}" MetaDataVersionOID="v1.0.0">
    <SubjectData SubjectKey="${subjectOid}">
      <StudyEventData StudyEventOID="${eventOid}" StudyEventRepeatKey="1">
        <FormData FormOID="${formOid}">`;
    // Build item groups and items from form data
    for (const [itemGroupOid, items] of Object.entries(formData)) {
        if (typeof items === 'object' && items !== null) {
            odmXml += `
          <ItemGroupData ItemGroupOID="${itemGroupOid}" ItemGroupRepeatKey="1">`;
            for (const [itemOid, value] of Object.entries(items)) {
                const escapedValue = escapeXml(String(value));
                odmXml += `
            <ItemData ItemOID="${itemOid}" Value="${escapedValue}"/>`;
            }
            odmXml += `
          </ItemGroupData>`;
        }
    }
    odmXml += `
        </FormData>`;
    // Add electronic signature if provided
    if (electronicSignature) {
        odmXml += buildElectronicSignatureXml(electronicSignature, timestamp);
    }
    odmXml += `
      </StudyEventData>
    </SubjectData>
  </ClinicalData>
</ODM>`;
    return odmXml;
};
exports.buildOdmXml = buildOdmXml;
/**
 * Build electronic signature XML section
 */
function buildElectronicSignatureXml(signature, timestamp) {
    const { username, meaning } = signature;
    return `
        <AuditRecord>
          <UserRef UserOID="${username}"/>
          <LocationRef LocationOID="API"/>
          <DateTimeStamp>${timestamp}</DateTimeStamp>
          <ReasonForChange>Electronic Signature: ${meaning}</ReasonForChange>
          <SourceID>${username}</SourceID>
        </AuditRecord>`;
}
/**
 * Parse data import response from SOAP
 */
const parseImportResponse = async (responseData) => {
    try {
        const result = {
            success: true,
            validationErrors: [],
            warnings: []
        };
        // If response is string (ODM XML), parse it
        if (typeof responseData === 'string') {
            result.odmResponse = responseData;
            // Parse for errors and warnings
            const parser = new xml2js_1.default.Parser();
            const parsed = await parser.parseStringPromise(responseData);
            // Check for validation errors in response
            if (parsed.ODM?.ClinicalData) {
                const clinicalData = parsed.ODM.ClinicalData[0];
                // Extract event CRF ID if available
                if (clinicalData.SubjectData?.[0]?.StudyEventData?.[0]?.FormData?.[0]?.$?.EventCRFOID) {
                    result.eventCrfId = parseInt(clinicalData.SubjectData[0].StudyEventData[0].FormData[0].$.EventCRFOID.replace('EC_', ''));
                }
                // Check for errors
                if (clinicalData.Errors) {
                    result.validationErrors = parseValidationErrors(clinicalData.Errors);
                }
                // Check for warnings
                if (clinicalData.Warnings) {
                    result.warnings = parseWarnings(clinicalData.Warnings);
                }
            }
        }
        else if (responseData.result) {
            result.success = responseData.result === 'Success';
            result.eventCrfId = responseData.eventCrfId;
        }
        return result;
    }
    catch (error) {
        logger_1.logger.error('Failed to parse import response', { error: error.message });
        return {
            success: false,
            validationErrors: [{
                    itemOid: 'unknown',
                    message: 'Failed to parse response',
                    severity: 'error'
                }]
        };
    }
};
exports.parseImportResponse = parseImportResponse;
/**
 * Parse validation errors from ODM response
 */
function parseValidationErrors(errors) {
    const validationErrors = [];
    try {
        if (Array.isArray(errors)) {
            for (const error of errors) {
                validationErrors.push({
                    itemOid: error.ItemOID || 'unknown',
                    message: error.Message || error.message || 'Validation error',
                    severity: 'error'
                });
            }
        }
        else if (errors.Error) {
            const errorList = Array.isArray(errors.Error) ? errors.Error : [errors.Error];
            for (const error of errorList) {
                validationErrors.push({
                    itemOid: error.$.ItemOID || 'unknown',
                    message: error._ || error.Message || 'Validation error',
                    severity: 'error'
                });
            }
        }
    }
    catch (error) {
        logger_1.logger.error('Failed to parse validation errors', { error: error.message });
    }
    return validationErrors;
}
/**
 * Parse warnings from ODM response
 */
function parseWarnings(warnings) {
    const warningList = [];
    try {
        if (Array.isArray(warnings)) {
            warningList.push(...warnings.map(w => w.Message || w.toString()));
        }
        else if (warnings.Warning) {
            const warnArray = Array.isArray(warnings.Warning) ? warnings.Warning : [warnings.Warning];
            warningList.push(...warnArray.map((w) => w._ || w.Message || w.toString()));
        }
    }
    catch (error) {
        logger_1.logger.error('Failed to parse warnings', { error: error.message });
    }
    return warningList;
}
/**
 * Escape XML special characters
 */
function escapeXml(unsafe) {
    return unsafe
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');
}
/**
 * Build ODM XML for a single item data entry
 */
const buildItemDataOdm = (studyOid, subjectOid, eventOid, formOid, itemGroupOid, itemOid, value) => {
    const timestamp = new Date().toISOString();
    const escapedValue = escapeXml(value);
    return `<?xml version="1.0" encoding="UTF-8"?>
<ODM xmlns="http://www.cdisc.org/ns/odm/v1.3"
     ODMVersion="1.3"
     FileType="Transactional"
     FileOID="ODM-${Date.now()}"
     CreationDateTime="${timestamp}">
  <ClinicalData StudyOID="${studyOid}" MetaDataVersionOID="v1.0.0">
    <SubjectData SubjectKey="${subjectOid}">
      <StudyEventData StudyEventOID="${eventOid}" StudyEventRepeatKey="1">
        <FormData FormOID="${formOid}">
          <ItemGroupData ItemGroupOID="${itemGroupOid}" ItemGroupRepeatKey="1">
            <ItemData ItemOID="${itemOid}" Value="${escapedValue}"/>
          </ItemGroupData>
        </FormData>
      </StudyEventData>
    </SubjectData>
  </ClinicalData>
</ODM>`;
};
exports.buildItemDataOdm = buildItemDataOdm;
/**
 * Validate ODM XML structure
 */
const validateOdmStructure = (odmXml) => {
    const errors = [];
    // Check for required elements
    if (!odmXml.includes('<ODM')) {
        errors.push('Missing ODM root element');
    }
    if (!odmXml.includes('<ClinicalData')) {
        errors.push('Missing ClinicalData element');
    }
    if (!odmXml.includes('<SubjectData')) {
        errors.push('Missing SubjectData element');
    }
    // Check for well-formed XML
    try {
        const parser = new xml2js_1.default.Parser();
        parser.parseString(odmXml, (err) => {
            if (err) {
                errors.push(`XML parsing error: ${err.message}`);
            }
        });
    }
    catch (error) {
        errors.push(`Invalid XML structure: ${error.message}`);
    }
    return {
        isValid: errors.length === 0,
        errors
    };
};
exports.validateOdmStructure = validateOdmStructure;
exports.default = {
    importData: exports.importData,
    buildOdmXml: exports.buildOdmXml,
    parseImportResponse: exports.parseImportResponse,
    buildItemDataOdm: exports.buildItemDataOdm,
    validateOdmStructure: exports.validateOdmStructure
};
//# sourceMappingURL=dataSoap.service.js.map