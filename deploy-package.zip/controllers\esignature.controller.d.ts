/**
 * Electronic Signature Controller
 *
 * Implements 21 CFR Part 11 compliant electronic signature functionality
 *
 * Key compliance requirements:
 * - §11.10(e) - Use of audit trails
 * - §11.50 - Signature manifestations
 * - §11.100 - General requirements for electronic signatures
 * - §11.200 - Electronic signature components and controls
 */
import { Request, Response } from 'express';
/**
 * Verify user's password for electronic signature
 * 21 CFR Part 11 §11.200(a)(1) - Two distinct identification components
 */
export declare const verifyPassword: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Apply electronic signature to an entity
 * 21 CFR Part 11 §11.50 - Signature manifestations
 */
export declare const applySignature: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get signature status for an entity
 */
export declare const getSignatureStatus: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get signature history for an entity
 */
export declare const getSignatureHistory: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get pending signatures for current user
 */
export declare const getPendingSignatures: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * User certification that electronic signature is legally binding
 * 21 CFR Part 11 §11.100(c)
 */
export declare const certifySignature: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get e-signature requirements for a study
 * Returns which forms/events require electronic signatures
 */
export declare const getStudyRequirements: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    verifyPassword: (req: Request, res: Response, next: import("express").NextFunction) => void;
    applySignature: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getSignatureStatus: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getSignatureHistory: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getPendingSignatures: (req: Request, res: Response, next: import("express").NextFunction) => void;
    certifySignature: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getStudyRequirements: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=esignature.controller.d.ts.map