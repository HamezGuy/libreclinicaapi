/**
 * CSV to ODM Converter Service
 *
 * Converts CSV data to ODM XML format that can be imported via
 * EXISTING dataSoap.service.ts (LibreClinica SOAP Data endpoint)
 *
 * LibreClinica Models Used:
 * - SubjectDataBean (submit/crfdata/SubjectDataBean.java)
 * - StudyEventDataBean (submit/crfdata/StudyEventDataBean.java)
 * - FormDataBean (submit/crfdata/FormDataBean.java)
 * - ImportItemGroupDataBean (submit/crfdata/ImportItemGroupDataBean.java)
 * - ImportItemDataBean (submit/crfdata/ImportItemDataBean.java)
 */
/**
 * Column mapping configuration
 */
export interface CSVMapping {
    subjectIdColumn: string;
    eventOIDColumn?: string;
    formOIDColumn?: string;
    itemGroupOIDColumn?: string;
    repeatKeyColumn?: string;
    defaultEventOID: string;
    defaultFormOID: string;
    defaultItemGroupOID: string;
    columnToItemOID: Record<string, string>;
}
export interface CSVImportConfig {
    studyOID: string;
    metaDataVersionOID: string;
    mapping: CSVMapping;
}
export interface CSVParseResult {
    headers: string[];
    rows: Record<string, string>[];
    rowCount: number;
}
export interface ValidationResult {
    isValid: boolean;
    errors: string[];
    warnings: string[];
}
/**
 * Parse CSV content to structured data
 */
export declare const parseCSV: (csvContent: string) => CSVParseResult;
/**
 * Validate CSV against mapping before import
 */
export declare const validateCSV: (csvContent: string, mapping: CSVMapping) => ValidationResult;
/**
 * Convert CSV data to ODM XML format
 * Matches LibreClinica's ODMContainer structure for import
 */
export declare const convertCSVToODM: (csvContent: string, config: CSVImportConfig) => string;
/**
 * Get preview of import data
 */
export declare const getImportPreview: (csvContent: string, mapping: CSVMapping, maxRows?: number) => {
    headers: string[];
    previewRows: Record<string, string>[];
    totalRows: number;
    mappedItems: {
        column: string;
        itemOID: string;
    }[];
};
/**
 * Auto-suggest column mappings based on header names
 */
export declare const suggestColumnMappings: (headers: string[]) => {
    subjectIdColumn?: string;
    suggestions: Record<string, string>;
};
declare const _default: {
    parseCSV: (csvContent: string) => CSVParseResult;
    validateCSV: (csvContent: string, mapping: CSVMapping) => ValidationResult;
    convertCSVToODM: (csvContent: string, config: CSVImportConfig) => string;
    getImportPreview: (csvContent: string, mapping: CSVMapping, maxRows?: number) => {
        headers: string[];
        previewRows: Record<string, string>[];
        totalRows: number;
        mappedItems: {
            column: string;
            itemOID: string;
        }[];
    };
    suggestColumnMappings: (headers: string[]) => {
        subjectIdColumn?: string;
        suggestions: Record<string, string>;
    };
};
export default _default;
//# sourceMappingURL=csv-to-odm.service.d.ts.map