/**
 * Query Controller
 */
import { Request, Response } from 'express';
export declare const list: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const get: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const create: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const respond: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const updateStatus: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Close query with electronic signature (password verification)
 * 21 CFR Part 11 compliant
 */
export declare const closeWithSignature: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get query audit trail
 */
export declare const getAuditTrail: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const stats: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get query types
 */
export declare const getQueryTypes: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get resolution statuses
 */
export declare const getResolutionStatuses: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get queries for a specific form
 */
export declare const getFormQueries: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Reassign query
 */
export declare const reassign: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get query count by status
 */
export declare const countByStatus: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get query count by type
 */
export declare const countByType: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get query thread (conversation)
 */
export declare const getThread: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get overdue queries
 */
export declare const getOverdue: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get my assigned queries
 */
export declare const getMyAssigned: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    list: (req: Request, res: Response, next: import("express").NextFunction) => void;
    get: (req: Request, res: Response, next: import("express").NextFunction) => void;
    create: (req: Request, res: Response, next: import("express").NextFunction) => void;
    respond: (req: Request, res: Response, next: import("express").NextFunction) => void;
    updateStatus: (req: Request, res: Response, next: import("express").NextFunction) => void;
    closeWithSignature: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getAuditTrail: (req: Request, res: Response, next: import("express").NextFunction) => void;
    stats: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getQueryTypes: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getResolutionStatuses: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getFormQueries: (req: Request, res: Response, next: import("express").NextFunction) => void;
    reassign: (req: Request, res: Response, next: import("express").NextFunction) => void;
    countByStatus: (req: Request, res: Response, next: import("express").NextFunction) => void;
    countByType: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getThread: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getOverdue: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getMyAssigned: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=query.controller.d.ts.map