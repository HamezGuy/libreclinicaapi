/**
 * Form Layout Service
 *
 * Manages form field layout for multi-column display in CRFs.
 * Uses LibreClinica's item_form_metadata.column_number for field positions.
 *
 * Features:
 * - Configure forms for 1, 2, or 3 column layout
 * - Drag-and-drop field positioning
 * - Row-based grouping for alignment
 * - Persist layout in database
 */
export interface FormLayoutConfig {
    crfVersionId: number;
    crfId: number;
    crfName: string;
    columnCount: 1 | 2 | 3;
    fields: FormFieldLayout[];
    sections: FormSectionLayout[];
}
export interface FormFieldLayout {
    itemId: number;
    itemFormMetadataId: number;
    name: string;
    label: string;
    type: string;
    columnNumber: number;
    rowNumber: number;
    ordinal: number;
    width: 'auto' | 'full' | 'half' | 'third';
    required: boolean;
    sectionId?: number;
    sectionName?: string;
}
export interface FormSectionLayout {
    sectionId: number;
    label: string;
    title: string;
    ordinal: number;
    columnSpan: 1 | 2 | 3;
}
export interface UpdateFieldLayoutRequest {
    itemFormMetadataId: number;
    columnNumber: number;
    rowNumber?: number;
    ordinal?: number;
}
export interface SaveLayoutRequest {
    crfVersionId: number;
    columnCount: 1 | 2 | 3;
    fields: UpdateFieldLayoutRequest[];
}
/**
 * Get the current layout configuration for a form (CRF version)
 */
export declare const getFormLayout: (crfVersionId: number) => Promise<{
    success: boolean;
    data?: FormLayoutConfig;
    message?: string;
}>;
/**
 * Save layout configuration for a form
 */
export declare const saveFormLayout: (request: SaveLayoutRequest, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Update a single field's layout position
 */
export declare const updateFieldLayout: (itemFormMetadataId: number, columnNumber: number, ordinal: number, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Get layout for rendering a form (used by form preview/fill)
 * Returns fields organized by columns and rows
 */
export declare const getFormLayoutForRendering: (crfVersionId: number) => Promise<{
    success: boolean;
    data?: {
        columnCount: number;
        rows: Array<{
            rowNumber: number;
            columns: Array<FormFieldLayout | null>;
        }>;
    };
    message?: string;
}>;
declare const _default: {
    getFormLayout: (crfVersionId: number) => Promise<{
        success: boolean;
        data?: FormLayoutConfig;
        message?: string;
    }>;
    saveFormLayout: (request: SaveLayoutRequest, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    updateFieldLayout: (itemFormMetadataId: number, columnNumber: number, ordinal: number, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    getFormLayoutForRendering: (crfVersionId: number) => Promise<{
        success: boolean;
        data?: {
            columnCount: number;
            rows: Array<{
                rowNumber: number;
                columns: Array<FormFieldLayout | null>;
            }>;
        };
        message?: string;
    }>;
};
export default _default;
//# sourceMappingURL=form-layout.service.d.ts.map