/**
 * Site/Location Management Service
 *
 * Manages study sites (locations) for multi-site clinical trials.
 * In LibreClinica, sites are stored as child studies with parent_study_id.
 *
 * Features:
 * - CRUD operations for sites
 * - Patient-to-site assignment
 * - Site enrollment tracking
 * - Site staff management
 *
 * Database Tables Used:
 * - study: Sites are child records with parent_study_id set
 * - study_subject: Patients are linked to sites via study_id
 * - study_user_role: Site staff assignments
 */
export interface Site {
    id: number;
    siteNumber: string;
    siteName: string;
    description?: string;
    parentStudyId: number;
    parentStudyName?: string;
    status: 'active' | 'pending' | 'frozen' | 'locked' | 'completed';
    statusId: number;
    principalInvestigator?: string;
    facilityName?: string;
    facilityCity?: string;
    facilityState?: string;
    facilityZip?: string;
    facilityCountry?: string;
    facilityRecruitmentStatus?: string;
    contactName?: string;
    contactDegree?: string;
    contactEmail?: string;
    contactPhone?: string;
    targetEnrollment: number;
    actualEnrollment: number;
    enrollmentPercentage: number;
    dateCreated: Date;
    dateUpdated?: Date;
    ocOid?: string;
}
export interface CreateSiteRequest {
    parentStudyId: number;
    siteNumber: string;
    siteName: string;
    description?: string;
    principalInvestigator?: string;
    targetEnrollment?: number;
    facilityName?: string;
    facilityCity?: string;
    facilityState?: string;
    facilityZip?: string;
    facilityCountry?: string;
    facilityRecruitmentStatus?: string;
    contactName?: string;
    contactDegree?: string;
    contactEmail?: string;
    contactPhone?: string;
}
export interface UpdateSiteRequest {
    siteName?: string;
    description?: string;
    principalInvestigator?: string;
    targetEnrollment?: number;
    statusId?: number;
    facilityName?: string;
    facilityCity?: string;
    facilityState?: string;
    facilityZip?: string;
    facilityCountry?: string;
    facilityRecruitmentStatus?: string;
    contactName?: string;
    contactDegree?: string;
    contactEmail?: string;
    contactPhone?: string;
}
export interface SitePatient {
    studySubjectId: number;
    label: string;
    secondaryLabel?: string;
    enrollmentDate?: string;
    status: string;
    currentPhase?: string;
    progress: number;
}
export interface SiteStaff {
    userId: number;
    username: string;
    firstName: string;
    lastName: string;
    email: string;
    role: string;
    assignedDate: Date;
    status: string;
}
/**
 * Get all sites for a study
 */
export declare const getSitesForStudy: (parentStudyId: number, options?: {
    status?: string;
    includeStats?: boolean;
}) => Promise<{
    success: boolean;
    data?: Site[];
    message?: string;
}>;
/**
 * Get a single site by ID
 */
export declare const getSiteById: (siteId: number) => Promise<{
    success: boolean;
    data?: Site;
    message?: string;
}>;
/**
 * Create a new site (child study)
 */
export declare const createSite: (request: CreateSiteRequest, userId: number) => Promise<{
    success: boolean;
    siteId?: number;
    message?: string;
}>;
/**
 * Update a site
 */
export declare const updateSite: (siteId: number, updates: UpdateSiteRequest, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Delete (soft-delete) a site
 */
export declare const deleteSite: (siteId: number, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Get patients for a specific site
 */
export declare const getSitePatients: (siteId: number, options?: {
    status?: string;
    page?: number;
    limit?: number;
}) => Promise<{
    success: boolean;
    data?: SitePatient[];
    total?: number;
    message?: string;
}>;
/**
 * Transfer a patient to a different site
 */
export declare const transferPatientToSite: (studySubjectId: number, targetSiteId: number, reason: string, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Get site staff/users
 */
export declare const getSiteStaff: (siteId: number) => Promise<{
    success: boolean;
    data?: SiteStaff[];
    message?: string;
}>;
/**
 * Assign staff to a site
 */
export declare const assignStaffToSite: (siteId: number, username: string, roleName: string, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Remove staff from a site
 */
export declare const removeStaffFromSite: (siteId: number, username: string, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Get aggregated statistics for all sites in a study
 */
export declare const getSiteStatistics: (parentStudyId: number) => Promise<{
    success: boolean;
    data?: any;
    message?: string;
}>;
declare const _default: {
    getSitesForStudy: (parentStudyId: number, options?: {
        status?: string;
        includeStats?: boolean;
    }) => Promise<{
        success: boolean;
        data?: Site[];
        message?: string;
    }>;
    getSiteById: (siteId: number) => Promise<{
        success: boolean;
        data?: Site;
        message?: string;
    }>;
    createSite: (request: CreateSiteRequest, userId: number) => Promise<{
        success: boolean;
        siteId?: number;
        message?: string;
    }>;
    updateSite: (siteId: number, updates: UpdateSiteRequest, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    deleteSite: (siteId: number, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    getSitePatients: (siteId: number, options?: {
        status?: string;
        page?: number;
        limit?: number;
    }) => Promise<{
        success: boolean;
        data?: SitePatient[];
        total?: number;
        message?: string;
    }>;
    transferPatientToSite: (studySubjectId: number, targetSiteId: number, reason: string, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    getSiteStaff: (siteId: number) => Promise<{
        success: boolean;
        data?: SiteStaff[];
        message?: string;
    }>;
    assignStaffToSite: (siteId: number, username: string, roleName: string, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    removeStaffFromSite: (siteId: number, username: string, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    getSiteStatistics: (parentStudyId: number) => Promise<{
        success: boolean;
        data?: any;
        message?: string;
    }>;
};
export default _default;
//# sourceMappingURL=site.service.d.ts.map