"use strict";
/**
 * Audit Routes
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const controller = __importStar(require("../controllers/audit.controller"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const authorization_middleware_1 = require("../middleware/authorization.middleware");
const validation_middleware_1 = require("../middleware/validation.middleware");
const rateLimiter_middleware_1 = require("../middleware/rateLimiter.middleware");
const router = express_1.default.Router();
router.use(auth_middleware_1.authMiddleware);
// List and query
router.get('/', (0, validation_middleware_1.validate)({ query: validation_middleware_1.auditSchemas.query }), controller.get);
router.get('/recent', controller.getRecent);
router.get('/stats', controller.getStats);
router.get('/summary', controller.getSummary);
// Login history (21 CFR Part 11 compliance)
router.get('/login-history', controller.getLoginHistory);
router.get('/login-stats', controller.getLoginStats);
// Metadata
router.get('/event-types', controller.getEventTypes);
router.get('/tables', controller.getTables);
// Entity-specific audit
router.get('/subject/:id', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.getSubjectAudit);
router.get('/form/:eventCrfId', controller.getFormAudit);
// Reports and exports
router.get('/export', (0, authorization_middleware_1.requireRole)('admin', 'monitor'), rateLimiter_middleware_1.auditExportRateLimiter, (0, validation_middleware_1.validate)({ query: validation_middleware_1.auditSchemas.export }), controller.exportCsv);
router.get('/compliance-report', (0, authorization_middleware_1.requireRole)('admin', 'monitor'), controller.getComplianceReport);
exports.default = router;
//# sourceMappingURL=audit.routes.js.map