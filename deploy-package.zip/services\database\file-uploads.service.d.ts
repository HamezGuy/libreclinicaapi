/**
 * File Uploads Service
 *
 * Manages file uploads for CRF fields (response_type = 4)
 * Files are stored locally and referenced in the file_uploads table.
 * Also integrates with LibreClinica's crf_version_media table.
 *
 * 21 CFR Part 11 Compliant:
 * - Audit trail for uploads/deletions
 * - File integrity verification (checksum)
 * - User tracking
 */
export interface UploadedFile {
    fileId: string;
    originalName: string;
    storedName: string;
    filePath: string;
    mimeType: string;
    fileSize: number;
    checksum: string;
    crfVersionId?: number;
    itemId?: number;
    crfVersionMediaId?: number;
    uploadedBy: number;
    uploadedAt: Date;
}
/**
 * Initialize the file_uploads table if it doesn't exist
 */
export declare const initializeFileUploadsTable: () => Promise<boolean>;
/**
 * Get all files for an item
 */
export declare const getFilesForItem: (itemId: number) => Promise<UploadedFile[]>;
/**
 * Get all files for a CRF version
 */
export declare const getFilesForCrfVersion: (crfVersionId: number) => Promise<UploadedFile[]>;
/**
 * Get file by ID
 */
export declare const getFileById: (fileId: string) => Promise<UploadedFile | null>;
/**
 * Soft delete a file
 */
export declare const softDeleteFile: (fileId: string, deletedBy: number) => Promise<boolean>;
/**
 * Verify file integrity by checksum
 */
export declare const verifyFileIntegrity: (fileId: string, checksum: string) => Promise<boolean>;
//# sourceMappingURL=file-uploads.service.d.ts.map