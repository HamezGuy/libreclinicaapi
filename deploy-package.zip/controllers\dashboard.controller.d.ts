/**
 * Dashboard Controller
 */
import { Request, Response } from 'express';
/**
 * Get dashboard summary (combined stats for frontend)
 * Returns empty data gracefully if study has no data
 */
export declare const getSummary: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get dashboard stats (alias for summary, for frontend compatibility)
 */
export declare const getStats: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getEnrollment: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getCompletion: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getQueries: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getActivity: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get enrollment trend over time
 */
export declare const getEnrollmentTrend: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get completion trend over time
 */
export declare const getCompletionTrend: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get site performance metrics
 */
export declare const getSitePerformance: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get form completion rates
 */
export declare const getFormCompletionRates: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get data quality metrics
 */
export declare const getDataQualityMetrics: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get subject status distribution
 */
export declare const getSubjectStatusDistribution: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get activity feed
 */
export declare const getActivityFeed: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get study health score
 */
export declare const getStudyHealthScore: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get detailed user analytics
 * Includes: login patterns, activity metrics, role breakdown, top performers
 */
export declare const getUserAnalytics: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get top performers (most active users)
 */
export declare const getTopPerformers: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    getSummary: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getStats: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getEnrollment: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getCompletion: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getQueries: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getActivity: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getEnrollmentTrend: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getCompletionTrend: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getSitePerformance: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getFormCompletionRates: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getDataQualityMetrics: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getSubjectStatusDistribution: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getActivityFeed: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getStudyHealthScore: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getUserAnalytics: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getTopPerformers: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=dashboard.controller.d.ts.map