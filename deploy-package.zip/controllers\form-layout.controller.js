"use strict";
/**
 * Form Layout Controller
 *
 * Handles API requests for form layout management including:
 * - Get layout configuration for a form
 * - Save/update layout with column positions
 * - Update individual field positions
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateFieldLayout = exports.saveFormLayout = exports.getFormLayoutForRendering = exports.getFormLayout = void 0;
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const formLayoutService = __importStar(require("../services/database/form-layout.service"));
const logger_1 = require("../config/logger");
/**
 * Get form layout configuration
 * GET /api/form-layout/:crfVersionId
 */
exports.getFormLayout = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { crfVersionId } = req.params;
    logger_1.logger.info('📐 Get form layout request', { crfVersionId });
    const result = await formLayoutService.getFormLayout(parseInt(crfVersionId));
    if (!result.success) {
        res.status(404).json(result);
        return;
    }
    res.json(result);
});
/**
 * Get form layout optimized for rendering
 * GET /api/form-layout/:crfVersionId/render
 */
exports.getFormLayoutForRendering = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { crfVersionId } = req.params;
    logger_1.logger.info('📐 Get form layout for rendering', { crfVersionId });
    const result = await formLayoutService.getFormLayoutForRendering(parseInt(crfVersionId));
    if (!result.success) {
        res.status(404).json(result);
        return;
    }
    res.json(result);
});
/**
 * Save form layout configuration
 * POST /api/form-layout
 */
exports.saveFormLayout = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    logger_1.logger.info('📐 Save form layout request', {
        body: req.body,
        userId: user.userId
    });
    const { crfVersionId, columnCount, fields } = req.body;
    if (!crfVersionId || !columnCount || !fields) {
        res.status(400).json({
            success: false,
            message: 'crfVersionId, columnCount, and fields are required'
        });
        return;
    }
    if (![1, 2, 3].includes(columnCount)) {
        res.status(400).json({
            success: false,
            message: 'columnCount must be 1, 2, or 3'
        });
        return;
    }
    const result = await formLayoutService.saveFormLayout({
        crfVersionId: parseInt(crfVersionId),
        columnCount,
        fields
    }, user.userId);
    res.json(result);
});
/**
 * Update a single field's layout position
 * PUT /api/form-layout/field/:itemFormMetadataId
 */
exports.updateFieldLayout = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { itemFormMetadataId } = req.params;
    const { columnNumber, ordinal } = req.body;
    logger_1.logger.info('📐 Update field layout request', {
        itemFormMetadataId,
        columnNumber,
        ordinal,
        userId: user.userId
    });
    if (columnNumber === undefined) {
        res.status(400).json({
            success: false,
            message: 'columnNumber is required'
        });
        return;
    }
    const result = await formLayoutService.updateFieldLayout(parseInt(itemFormMetadataId), columnNumber, ordinal || 0, user.userId);
    res.json(result);
});
exports.default = {
    getFormLayout: exports.getFormLayout,
    getFormLayoutForRendering: exports.getFormLayoutForRendering,
    saveFormLayout: exports.saveFormLayout,
    updateFieldLayout: exports.updateFieldLayout
};
//# sourceMappingURL=form-layout.controller.js.map