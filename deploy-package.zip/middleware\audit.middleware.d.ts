/**
 * Audit Middleware
 *
 * Implements comprehensive audit logging for 21 CFR Part 11 compliance
 * - Logs all API requests to database
 * - Tracks user actions, timestamps, IP addresses
 * - Captures request/response data for audit trail
 * - Supports electronic signature requirements
 *
 * Compliance: 21 CFR Part 11 §11.10(e) - Audit Trail
 */
import { Request, Response, NextFunction } from 'express';
/**
 * Extended Express Request with audit information
 */
export interface AuditRequest extends Request {
    auditId?: string;
    userId?: number;
    username?: string;
    userRole?: string;
    startTime?: number;
}
/**
 * Audit event types based on LibreClinica audit_log_event table
 */
export declare enum AuditEventType {
    LOGIN = "User Login",
    LOGOUT = "User Logout",
    SUBJECT_CREATED = "Subject Created",
    SUBJECT_UPDATED = "Subject Updated",
    DATA_ENTERED = "Data Entry",
    DATA_UPDATED = "Data Updated",
    QUERY_CREATED = "Query Created",
    QUERY_RESPONDED = "Query Responded",
    QUERY_CLOSED = "Query Closed",
    FORM_SUBMITTED = "Form Submitted",
    STUDY_ACCESSED = "Study Accessed",
    REPORT_GENERATED = "Report Generated",
    USER_CREATED = "User Created",
    USER_UPDATED = "User Updated",
    ROLE_CHANGED = "Role Changed",
    PASSWORD_CHANGED = "Password Changed",
    FAILED_LOGIN = "Failed Login Attempt"
}
/**
 * Main audit logging middleware
 * Logs all incoming requests and responses to database and file
 */
export declare const auditMiddleware: (req: AuditRequest, res: Response, next: NextFunction) => Promise<void>;
/**
 * Log specific audit events to database
 * Uses LibreClinica's ACTUAL audit_log_event schema:
 * - audit_id (SERIAL - auto-generated)
 * - audit_date, audit_table, user_id, entity_id, entity_name
 * - old_value, new_value, reason_for_change
 * - audit_log_event_type_id (FK to audit_log_event_type)
 * - study_id, event_crf_id, study_event_id
 */
export declare const logAuditEvent: (eventType: AuditEventType, userId: number, username: string, details: {
    entityName?: string;
    entityId?: number;
    oldValue?: string;
    newValue?: string;
    reasonForChange?: string;
    studyId?: number;
    eventCrfId?: number;
    studyEventId?: number;
    ipAddress?: string;
}) => Promise<void>;
/**
 * Audit middleware for electronic signatures
 * Validates and logs electronic signatures per 21 CFR Part 11 §11.50
 */
export declare const electronicSignatureMiddleware: (req: AuditRequest, res: Response, next: NextFunction) => Promise<void>;
export default auditMiddleware;
//# sourceMappingURL=audit.middleware.d.ts.map