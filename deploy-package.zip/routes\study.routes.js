"use strict";
/**
 * Study Routes
 *
 * API endpoints for study management including:
 * - CRUD operations
 * - Metadata, forms, sites, events
 * - Statistics and users
 *
 * 21 CFR Part 11 Compliance:
 * - All study modifications require electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const controller = __importStar(require("../controllers/study.controller"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const authorization_middleware_1 = require("../middleware/authorization.middleware");
const validation_middleware_1 = require("../middleware/validation.middleware");
const part11_middleware_1 = require("../middleware/part11.middleware");
const router = express_1.default.Router();
router.use(auth_middleware_1.authMiddleware);
// Read operations - all authenticated users (no signature required)
router.get('/', (0, validation_middleware_1.validate)({ query: validation_middleware_1.studySchemas.list }), controller.list);
router.get('/:id', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.get);
router.get('/:id/metadata', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.getMetadata);
router.get('/:id/forms', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.getForms);
router.get('/:id/sites', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.getSites);
router.get('/:id/events', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.getEvents);
router.get('/:id/stats', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.getStats);
router.get('/:id/users', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.getUsers);
// Create/Update/Delete - require admin or coordinator role + electronic signature
router.post('/', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, validation_middleware_1.validate)({ body: validation_middleware_1.studySchemas.create }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.STUDY_CREATE), controller.create);
router.put('/:id', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam, body: validation_middleware_1.studySchemas.update }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.STUDY_UPDATE), controller.update);
router.delete('/:id', (0, authorization_middleware_1.requireRole)('admin'), (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.STUDY_DELETE), controller.remove);
exports.default = router;
//# sourceMappingURL=study.routes.js.map