export declare const config: {
    server: {
        port: number;
        env: string;
        apiVersion: string;
    };
    demoMode: boolean;
    libreclinica: {
        soapUrl: string;
        soapUsername: string;
        soapPassword: string;
        soapEnabled: boolean;
        database: {
            host: string;
            port: number;
            database: string;
            user: string;
            password: string;
            max: number;
            idleTimeoutMillis: number;
            connectionTimeoutMillis: number;
            ssl: boolean | {
                rejectUnauthorized: boolean;
                ca: string | undefined;
                cert: string | undefined;
                key: string | undefined;
            };
        };
    };
    jwt: {
        secret: string;
        expiresIn: string;
        refreshExpiresIn: string;
    };
    google: {
        clientId: string;
        clientSecret: string;
    };
    part11: {
        passwordExpiryDays: number;
        passwordMinLength: number;
        passwordRequireUppercase: boolean;
        passwordRequireLowercase: boolean;
        passwordRequireNumber: boolean;
        passwordRequireSpecial: boolean;
        maxLoginAttempts: number;
        accountLockoutDurationMinutes: number;
        sessionTimeoutMinutes: number;
        requireMfa: boolean;
        auditLogRetentionDays: number;
    };
    security: {
        httpsOnly: boolean;
        allowedOrigins: string[];
        rateLimitWindowMs: number;
        rateLimitMaxRequests: number;
    };
    logging: {
        level: string;
        filePath: string;
    };
    woundScanner: {
        appDomain: string;
        urlScheme: string;
        captureTokenExpiry: string;
        s3Bucket: string;
        s3Region: string;
        enableAuditChain: boolean;
    };
    encryption: {
        masterKey: string;
        salt: string;
        enableFieldEncryption: boolean;
        encryptedTables: string[];
    };
};
//# sourceMappingURL=environment.d.ts.map