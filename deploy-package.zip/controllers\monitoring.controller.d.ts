/**
 * Monitoring Controller
 * System-level monitoring with REAL query/SDV/validation counts
 */
import { Request, Response } from 'express';
export declare const getStats: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getAlerts: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getMetrics: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    getStats: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getAlerts: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getMetrics: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=monitoring.controller.d.ts.map