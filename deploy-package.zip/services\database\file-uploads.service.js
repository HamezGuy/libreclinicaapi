"use strict";
/**
 * File Uploads Service
 *
 * Manages file uploads for CRF fields (response_type = 4)
 * Files are stored locally and referenced in the file_uploads table.
 * Also integrates with LibreClinica's crf_version_media table.
 *
 * 21 CFR Part 11 Compliant:
 * - Audit trail for uploads/deletions
 * - File integrity verification (checksum)
 * - User tracking
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyFileIntegrity = exports.softDeleteFile = exports.getFileById = exports.getFilesForCrfVersion = exports.getFilesForItem = exports.initializeFileUploadsTable = void 0;
const database_1 = require("../../config/database");
const logger_1 = require("../../config/logger");
// Track if table has been initialized
let tableInitialized = false;
/**
 * Initialize the file_uploads table if it doesn't exist
 */
const initializeFileUploadsTable = async () => {
    if (tableInitialized) {
        return true;
    }
    // First check if table exists
    const checkQuery = `
    SELECT EXISTS (
      SELECT FROM information_schema.tables 
      WHERE table_name = 'file_uploads'
    );
  `;
    try {
        const checkResult = await database_1.pool.query(checkQuery);
        if (checkResult.rows[0].exists) {
            tableInitialized = true;
            logger_1.logger.info('file_uploads table already exists');
            return true;
        }
    }
    catch (e) {
        // Continue to try creating
    }
    // Create table
    const createTableQuery = `
    CREATE TABLE IF NOT EXISTS file_uploads (
      file_id VARCHAR(64) PRIMARY KEY,
      original_name VARCHAR(512) NOT NULL,
      stored_name VARCHAR(512) NOT NULL,
      file_path VARCHAR(1024) NOT NULL,
      mime_type VARCHAR(128) NOT NULL,
      file_size INTEGER NOT NULL,
      checksum VARCHAR(64) NOT NULL,
      crf_version_id INTEGER,
      item_id INTEGER,
      crf_version_media_id INTEGER,
      uploaded_by INTEGER NOT NULL DEFAULT 1,
      uploaded_at TIMESTAMP NOT NULL DEFAULT NOW(),
      deleted_at TIMESTAMP,
      deleted_by INTEGER,
      UNIQUE(file_id)
    );
    
    CREATE INDEX IF NOT EXISTS idx_file_uploads_crf_version ON file_uploads(crf_version_id);
    CREATE INDEX IF NOT EXISTS idx_file_uploads_item ON file_uploads(item_id);
    CREATE INDEX IF NOT EXISTS idx_file_uploads_checksum ON file_uploads(checksum);
  `;
    try {
        await database_1.pool.query(createTableQuery);
        tableInitialized = true;
        logger_1.logger.info('Created file_uploads table');
        return true;
    }
    catch (error) {
        logger_1.logger.error('Failed to create file_uploads table', { error: error.message });
        return false;
    }
};
exports.initializeFileUploadsTable = initializeFileUploadsTable;
/**
 * Get all files for an item
 */
const getFilesForItem = async (itemId) => {
    await (0, exports.initializeFileUploadsTable)();
    const result = await database_1.pool.query(`
    SELECT * FROM file_uploads
    WHERE item_id = $1 AND deleted_at IS NULL
    ORDER BY uploaded_at DESC
  `, [itemId]);
    return result.rows.map(row => ({
        fileId: row.file_id,
        originalName: row.original_name,
        storedName: row.stored_name,
        filePath: row.file_path,
        mimeType: row.mime_type,
        fileSize: row.file_size,
        checksum: row.checksum,
        crfVersionId: row.crf_version_id,
        itemId: row.item_id,
        crfVersionMediaId: row.crf_version_media_id,
        uploadedBy: row.uploaded_by,
        uploadedAt: row.uploaded_at
    }));
};
exports.getFilesForItem = getFilesForItem;
/**
 * Get all files for a CRF version
 */
const getFilesForCrfVersion = async (crfVersionId) => {
    await (0, exports.initializeFileUploadsTable)();
    const result = await database_1.pool.query(`
    SELECT * FROM file_uploads
    WHERE crf_version_id = $1 AND deleted_at IS NULL
    ORDER BY uploaded_at DESC
  `, [crfVersionId]);
    return result.rows.map(row => ({
        fileId: row.file_id,
        originalName: row.original_name,
        storedName: row.stored_name,
        filePath: row.file_path,
        mimeType: row.mime_type,
        fileSize: row.file_size,
        checksum: row.checksum,
        crfVersionId: row.crf_version_id,
        itemId: row.item_id,
        crfVersionMediaId: row.crf_version_media_id,
        uploadedBy: row.uploaded_by,
        uploadedAt: row.uploaded_at
    }));
};
exports.getFilesForCrfVersion = getFilesForCrfVersion;
/**
 * Get file by ID
 */
const getFileById = async (fileId) => {
    await (0, exports.initializeFileUploadsTable)();
    const result = await database_1.pool.query(`
    SELECT * FROM file_uploads
    WHERE file_id = $1 AND deleted_at IS NULL
  `, [fileId]);
    if (result.rows.length === 0) {
        return null;
    }
    const row = result.rows[0];
    return {
        fileId: row.file_id,
        originalName: row.original_name,
        storedName: row.stored_name,
        filePath: row.file_path,
        mimeType: row.mime_type,
        fileSize: row.file_size,
        checksum: row.checksum,
        crfVersionId: row.crf_version_id,
        itemId: row.item_id,
        crfVersionMediaId: row.crf_version_media_id,
        uploadedBy: row.uploaded_by,
        uploadedAt: row.uploaded_at
    };
};
exports.getFileById = getFileById;
/**
 * Soft delete a file
 */
const softDeleteFile = async (fileId, deletedBy) => {
    await (0, exports.initializeFileUploadsTable)();
    const result = await database_1.pool.query(`
    UPDATE file_uploads
    SET deleted_at = NOW(), deleted_by = $2
    WHERE file_id = $1
    RETURNING file_id
  `, [fileId, deletedBy]);
    return result.rows.length > 0;
};
exports.softDeleteFile = softDeleteFile;
/**
 * Verify file integrity by checksum
 */
const verifyFileIntegrity = async (fileId, checksum) => {
    await (0, exports.initializeFileUploadsTable)();
    const result = await database_1.pool.query(`
    SELECT checksum FROM file_uploads
    WHERE file_id = $1 AND deleted_at IS NULL
  `, [fileId]);
    if (result.rows.length === 0) {
        return false;
    }
    return result.rows[0].checksum === checksum;
};
exports.verifyFileIntegrity = verifyFileIntegrity;
// Initialize table on module load
(0, exports.initializeFileUploadsTable)().catch(err => {
    logger_1.logger.error('Failed to initialize file_uploads table on startup', { error: err.message });
});
//# sourceMappingURL=file-uploads.service.js.map