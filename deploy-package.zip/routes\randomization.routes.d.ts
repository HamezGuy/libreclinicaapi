/**
 * Randomization Routes
 *
 * 21 CFR Part 11 Compliance:
 * - Randomization requires electronic signature (§11.50)
 * - Unblinding requires electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=randomization.routes.d.ts.map