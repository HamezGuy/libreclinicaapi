/**
 * Validation Middleware
 *
 * Implements request validation using Joi schemas
 * - Validates request body, query params, and URL params
 * - Provides detailed validation error messages
 * - Ensures data integrity before processing
 *
 * Compliance: 21 CFR Part 11 §11.10(f) - Operational System Checks
 */
import { Request, Response, NextFunction } from 'express';
import Joi from 'joi';
/**
 * Generic validation middleware factory
 * Creates middleware that validates specific parts of the request
 */
export declare const validate: (schema: {
    body?: Joi.ObjectSchema;
    query?: Joi.ObjectSchema;
    params?: Joi.ObjectSchema;
}) => (req: Request, res: Response, next: NextFunction) => Promise<void>;
/**
 * ============================================================================
 * VALIDATION SCHEMAS
 * ============================================================================
 */
/**
 * Authentication Schemas
 */
export declare const authSchemas: {
    login: Joi.ObjectSchema<any>;
    googleAuth: Joi.ObjectSchema<any>;
    refreshToken: Joi.ObjectSchema<any>;
    changePassword: Joi.ObjectSchema<any>;
};
/**
 * Subject (Patient) Schemas
 */
export declare const subjectSchemas: {
    create: Joi.ObjectSchema<any>;
    list: Joi.ObjectSchema<any>;
    getById: Joi.ObjectSchema<any>;
};
/**
 * Form/CRF Schemas
 */
export declare const formSchemas: {
    saveData: Joi.ObjectSchema<any>;
    getData: Joi.ObjectSchema<any>;
    listForms: Joi.ObjectSchema<any>;
};
/**
 * Study Schemas
 */
export declare const studySchemas: {
    list: Joi.ObjectSchema<any>;
    getById: Joi.ObjectSchema<any>;
    create: Joi.ObjectSchema<any>;
    update: Joi.ObjectSchema<any>;
};
/**
 * Query/Discrepancy Note Schemas
 */
export declare const querySchemas: {
    create: Joi.ObjectSchema<any>;
    respond: Joi.ObjectSchema<any>;
    updateStatus: Joi.ObjectSchema<any>;
    close: Joi.ObjectSchema<any>;
    list: Joi.ObjectSchema<any>;
};
/**
 * Audit Trail Schemas
 */
export declare const auditSchemas: {
    query: Joi.ObjectSchema<any>;
    export: Joi.ObjectSchema<any>;
};
/**
 * Dashboard Schemas
 */
export declare const dashboardSchemas: {
    enrollment: Joi.ObjectSchema<any>;
    completion: Joi.ObjectSchema<any>;
    queries: Joi.ObjectSchema<any>;
    activity: Joi.ObjectSchema<any>;
};
/**
 * User Management Schemas
 */
export declare const userSchemas: {
    create: Joi.ObjectSchema<any>;
    update: Joi.ObjectSchema<any>;
    list: Joi.ObjectSchema<any>;
};
/**
 * Report Schemas
 */
export declare const reportSchemas: {
    enrollment: Joi.ObjectSchema<any>;
    dataCompletion: Joi.ObjectSchema<any>;
    queries: Joi.ObjectSchema<any>;
};
/**
 * Event Scheduling Schemas
 */
export declare const eventSchemas: {
    schedule: Joi.ObjectSchema<any>;
    create: Joi.ObjectSchema<any>;
    update: Joi.ObjectSchema<any>;
    list: Joi.ObjectSchema<any>;
};
/**
 * Common parameter schemas
 */
export declare const commonSchemas: {
    idParam: Joi.ObjectSchema<any>;
    studyIdParam: Joi.ObjectSchema<any>;
    subjectIdParam: Joi.ObjectSchema<any>;
    pagination: Joi.ObjectSchema<any>;
};
export default validate;
//# sourceMappingURL=validation.middleware.d.ts.map