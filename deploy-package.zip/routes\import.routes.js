"use strict";
/**
 * Data Import Routes
 * Uses EXISTING LibreClinica SOAP APIs for Part 11 compliance
 * CSV is converted to ODM XML and imported via dataSoap.service
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const csvToOdm = __importStar(require("../services/import/csv-to-odm.service"));
const soapClient_1 = require("../services/soap/soapClient");
const logger_1 = require("../config/logger");
const router = (0, express_1.Router)();
const upload = (0, multer_1.default)({
    storage: multer_1.default.memoryStorage(),
    limits: { fileSize: 50 * 1024 * 1024 } // 50MB max
});
/**
 * POST /api/import/validate
 * Validate import file before execution
 */
router.post('/validate', upload.single('file'), (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const file = req.file;
    if (!file) {
        return res.status(400).json({
            success: false,
            message: 'No file uploaded'
        });
    }
    const content = file.buffer.toString('utf-8');
    const isODM = content.trim().startsWith('<?xml') || content.includes('<ODM');
    if (isODM) {
        // ODM XML - validate structure
        const hasStudyOID = content.includes('StudyOID=');
        const hasSubjectData = content.includes('<SubjectData');
        const hasClinicalData = content.includes('<ClinicalData');
        const errors = [];
        if (!hasStudyOID)
            errors.push('Missing StudyOID attribute');
        if (!hasClinicalData)
            errors.push('Missing ClinicalData element');
        if (!hasSubjectData)
            errors.push('Missing SubjectData element');
        return res.json({
            success: true,
            data: {
                format: 'odm',
                isValid: errors.length === 0,
                errors,
                warnings: []
            }
        });
    }
    // CSV - validate with mapping if provided
    let mapping;
    try {
        mapping = req.body.mapping ? JSON.parse(req.body.mapping) : null;
    }
    catch {
        return res.status(400).json({
            success: false,
            message: 'Invalid mapping JSON'
        });
    }
    if (!mapping) {
        // Return headers for mapping UI
        const { headers, rowCount } = csvToOdm.parseCSV(content);
        const suggestions = csvToOdm.suggestColumnMappings(headers);
        return res.json({
            success: true,
            data: {
                format: 'csv',
                needsMapping: true,
                headers,
                rowCount,
                suggestions
            }
        });
    }
    // Validate with mapping
    const validation = csvToOdm.validateCSV(content, mapping);
    res.json({
        success: true,
        data: {
            format: 'csv',
            ...validation
        }
    });
}));
/**
 * POST /api/import/preview
 * Get preview of data to be imported
 */
router.post('/preview', upload.single('file'), (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const file = req.file;
    if (!file) {
        return res.status(400).json({
            success: false,
            message: 'No file uploaded'
        });
    }
    const content = file.buffer.toString('utf-8');
    let mapping;
    try {
        mapping = req.body.mapping ? JSON.parse(req.body.mapping) : null;
    }
    catch {
        return res.status(400).json({
            success: false,
            message: 'Invalid mapping JSON'
        });
    }
    if (!mapping) {
        return res.status(400).json({
            success: false,
            message: 'Mapping is required for preview'
        });
    }
    const preview = csvToOdm.getImportPreview(content, mapping, 10);
    res.json({
        success: true,
        data: preview
    });
}));
/**
 * POST /api/import/convert
 * Convert CSV to ODM XML (for download/review)
 */
router.post('/convert', upload.single('file'), (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const file = req.file;
    const { studyOID, metaDataVersionOID, mapping } = req.body;
    if (!file) {
        return res.status(400).json({
            success: false,
            message: 'No file uploaded'
        });
    }
    if (!studyOID || !mapping) {
        return res.status(400).json({
            success: false,
            message: 'studyOID and mapping are required'
        });
    }
    let parsedMapping;
    try {
        parsedMapping = typeof mapping === 'string' ? JSON.parse(mapping) : mapping;
    }
    catch {
        return res.status(400).json({
            success: false,
            message: 'Invalid mapping JSON'
        });
    }
    const content = file.buffer.toString('utf-8');
    const odmXml = csvToOdm.convertCSVToODM(content, {
        studyOID,
        metaDataVersionOID: metaDataVersionOID || 'v1.0.0',
        mapping: parsedMapping
    });
    res.setHeader('Content-Type', 'application/xml');
    res.setHeader('Content-Disposition', `attachment; filename="import_${Date.now()}.xml"`);
    res.send(odmXml);
}));
/**
 * POST /api/import/execute
 * Execute import via LibreClinica SOAP
 */
router.post('/execute', upload.single('file'), (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const file = req.file;
    const { studyOID, metaDataVersionOID, mapping, odmXml: providedOdm } = req.body;
    const userId = req.user?.userId || 1;
    const username = req.user?.username || 'api';
    let odmXml;
    if (providedOdm) {
        // ODM XML provided directly
        odmXml = providedOdm;
    }
    else if (file) {
        const content = file.buffer.toString('utf-8');
        const isODM = content.trim().startsWith('<?xml') || content.includes('<ODM');
        if (isODM) {
            odmXml = content;
        }
        else {
            // CSV - convert to ODM
            if (!studyOID || !mapping) {
                return res.status(400).json({
                    success: false,
                    message: 'studyOID and mapping are required for CSV import'
                });
            }
            let parsedMapping;
            try {
                parsedMapping = typeof mapping === 'string' ? JSON.parse(mapping) : mapping;
            }
            catch {
                return res.status(400).json({
                    success: false,
                    message: 'Invalid mapping JSON'
                });
            }
            odmXml = csvToOdm.convertCSVToODM(content, {
                studyOID,
                metaDataVersionOID: metaDataVersionOID || 'v1.0.0',
                mapping: parsedMapping
            });
        }
    }
    else {
        return res.status(400).json({
            success: false,
            message: 'No file or ODM data provided'
        });
    }
    logger_1.logger.info('Executing import via LibreClinica SOAP', {
        username,
        odmLength: odmXml.length
    });
    // Import via EXISTING SOAP endpoint (Part 11 compliant!)
    const soapClient = (0, soapClient_1.getSoapClient)();
    const result = await soapClient.executeRequest({
        serviceName: 'data',
        methodName: 'import',
        parameters: {
            odm: odmXml
        },
        userId,
        username
    });
    if (!result.success) {
        logger_1.logger.error('Import failed', { error: result.error });
        return res.status(500).json({
            success: false,
            message: result.error || 'Import failed',
            soapFault: result.soapFault
        });
    }
    logger_1.logger.info('Import successful', { result: result.data });
    res.json({
        success: true,
        message: 'Data imported successfully via LibreClinica',
        data: result.data
    });
}));
/**
 * POST /api/import/auto-map
 * Suggest column mappings based on headers
 */
router.post('/auto-map', upload.single('file'), (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const file = req.file;
    if (!file) {
        return res.status(400).json({
            success: false,
            message: 'No file uploaded'
        });
    }
    const content = file.buffer.toString('utf-8');
    const { headers } = csvToOdm.parseCSV(content);
    const suggestions = csvToOdm.suggestColumnMappings(headers);
    res.json({
        success: true,
        data: {
            headers,
            ...suggestions
        }
    });
}));
exports.default = router;
//# sourceMappingURL=import.routes.js.map