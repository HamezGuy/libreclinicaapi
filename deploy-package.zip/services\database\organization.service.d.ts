/**
 * Organization Service
 *
 * Handles organization management, invite codes, access requests, and invitations
 * Integrates with LibreClinica's user_account and study tables
 */
export interface Organization {
    organizationId: number;
    name: string;
    type: string;
    status: string;
    email: string;
    phone?: string;
    website?: string;
    street?: string;
    city?: string;
    state?: string;
    postalCode?: string;
    country?: string;
    ownerId?: number;
    approvedBy?: number;
    approvedAt?: Date;
    dateCreated: Date;
    dateUpdated: Date;
}
export interface OrganizationMembership {
    membershipId: number;
    organizationId: number;
    userId: number;
    role: string;
    status: string;
    invitedBy?: number;
    dateCreated: Date;
}
export interface OrganizationCode {
    codeId: number;
    code: string;
    organizationId: number;
    organizationName?: string;
    maxUses?: number;
    currentUses: number;
    expiresAt?: Date;
    defaultRole: string;
    isActive: boolean;
    createdBy?: number;
    dateCreated: Date;
}
export interface AccessRequest {
    requestId: number;
    email: string;
    firstName: string;
    lastName: string;
    phone?: string;
    organizationName?: string;
    professionalTitle?: string;
    credentials?: string;
    reason?: string;
    organizationId?: number;
    requestedRole: string;
    status: string;
    reviewedBy?: number;
    reviewedAt?: Date;
    reviewNotes?: string;
    userId?: number;
    dateCreated: Date;
}
export interface UserInvitation {
    invitationId: number;
    email: string;
    token: string;
    organizationId?: number;
    studyId?: number;
    role: string;
    status: string;
    expiresAt: Date;
    invitedBy?: number;
    message?: string;
    acceptedBy?: number;
    acceptedAt?: Date;
    dateCreated: Date;
}
export interface CreateOrganizationDto {
    name: string;
    type: string;
    email: string;
    phone?: string;
    website?: string;
    street?: string;
    city?: string;
    state?: string;
    postalCode?: string;
    country?: string;
}
export interface CreateAdminDto {
    firstName: string;
    lastName: string;
    email: string;
    phone?: string;
    professionalTitle?: string;
    credentials?: string;
    password: string;
}
/**
 * Create a new organization with admin user
 * This is used for self-registration - creates org + first admin user in one transaction
 */
export declare const createOrganizationWithAdmin: (orgData: CreateOrganizationDto, adminData: CreateAdminDto) => Promise<{
    success: boolean;
    organizationId?: number;
    userId?: number;
    message?: string;
}>;
/**
 * Get organization by ID
 */
export declare const getOrganizationById: (organizationId: number) => Promise<Organization | null>;
/**
 * Get organizations with optional filters
 */
export declare const getOrganizations: (filters: {
    status?: string;
    type?: string;
    page?: number;
    limit?: number;
}) => Promise<{
    data: Organization[];
    total: number;
}>;
/**
 * Update organization status (approve/reject/suspend)
 */
export declare const updateOrganizationStatus: (organizationId: number, status: "active" | "suspended" | "inactive", approvedBy: number, notes?: string) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Get user's organizations
 */
export declare const getUserOrganizations: (userId: number) => Promise<{
    organizationId: number;
    name: string;
    role: string;
    status: string;
}[]>;
/**
 * Generate a new organization invite code
 */
export declare const generateOrganizationCode: (organizationId: number, createdBy: number, options?: {
    maxUses?: number;
    expiresAt?: Date;
    defaultRole?: string;
}) => Promise<{
    success: boolean;
    code?: string;
    codeId?: number;
    message?: string;
}>;
/**
 * Validate an organization code
 */
export declare const validateOrganizationCode: (code: string) => Promise<{
    isValid: boolean;
    organizationId?: number;
    organizationName?: string;
    defaultRole?: string;
    message?: string;
}>;
/**
 * Register a new user with an organization code
 */
export declare const registerWithCode: (code: string, userData: {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    phone?: string;
}, ipAddress?: string) => Promise<{
    success: boolean;
    userId?: number;
    organizationId?: number;
    message?: string;
}>;
/**
 * Get organization codes
 */
export declare const getOrganizationCodes: (organizationId: number) => Promise<OrganizationCode[]>;
/**
 * Deactivate an organization code
 */
export declare const deactivateOrganizationCode: (codeId: number, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Create an access request
 */
export declare const createAccessRequest: (data: {
    email: string;
    firstName: string;
    lastName: string;
    phone?: string;
    organizationName?: string;
    professionalTitle?: string;
    credentials?: string;
    reason?: string;
    organizationId?: number;
    requestedRole?: string;
}) => Promise<{
    success: boolean;
    requestId?: number;
    message?: string;
}>;
/**
 * Get access requests with filters
 */
export declare const getAccessRequests: (filters: {
    status?: string;
    organizationId?: number;
    page?: number;
    limit?: number;
}) => Promise<{
    data: AccessRequest[];
    total: number;
}>;
/**
 * Review an access request (approve or reject)
 */
export declare const reviewAccessRequest: (requestId: number, reviewedBy: number, decision: "approved" | "rejected", notes?: string, password?: string) => Promise<{
    success: boolean;
    userId?: number;
    message?: string;
}>;
/**
 * Create a user invitation
 */
export declare const createInvitation: (email: string, invitedBy: number, options?: {
    organizationId?: number;
    studyId?: number;
    role?: string;
    message?: string;
    expiresInDays?: number;
}) => Promise<{
    success: boolean;
    token?: string;
    invitationId?: number;
    message?: string;
}>;
/**
 * Validate an invitation token
 */
export declare const validateInvitation: (token: string) => Promise<{
    isValid: boolean;
    email?: string;
    organizationId?: number;
    organizationName?: string;
    studyId?: number;
    studyName?: string;
    role?: string;
    inviterName?: string;
    message?: string;
}>;
/**
 * Accept an invitation and create user account
 */
export declare const acceptInvitation: (token: string, userData: {
    password: string;
    firstName: string;
    lastName: string;
    phone?: string;
}) => Promise<{
    success: boolean;
    userId?: number;
    message?: string;
}>;
declare const _default: {
    createOrganizationWithAdmin: (orgData: CreateOrganizationDto, adminData: CreateAdminDto) => Promise<{
        success: boolean;
        organizationId?: number;
        userId?: number;
        message?: string;
    }>;
    getOrganizationById: (organizationId: number) => Promise<Organization | null>;
    getOrganizations: (filters: {
        status?: string;
        type?: string;
        page?: number;
        limit?: number;
    }) => Promise<{
        data: Organization[];
        total: number;
    }>;
    updateOrganizationStatus: (organizationId: number, status: "active" | "suspended" | "inactive", approvedBy: number, notes?: string) => Promise<{
        success: boolean;
        message?: string;
    }>;
    getUserOrganizations: (userId: number) => Promise<{
        organizationId: number;
        name: string;
        role: string;
        status: string;
    }[]>;
    generateOrganizationCode: (organizationId: number, createdBy: number, options?: {
        maxUses?: number;
        expiresAt?: Date;
        defaultRole?: string;
    }) => Promise<{
        success: boolean;
        code?: string;
        codeId?: number;
        message?: string;
    }>;
    validateOrganizationCode: (code: string) => Promise<{
        isValid: boolean;
        organizationId?: number;
        organizationName?: string;
        defaultRole?: string;
        message?: string;
    }>;
    registerWithCode: (code: string, userData: {
        email: string;
        password: string;
        firstName: string;
        lastName: string;
        phone?: string;
    }, ipAddress?: string) => Promise<{
        success: boolean;
        userId?: number;
        organizationId?: number;
        message?: string;
    }>;
    getOrganizationCodes: (organizationId: number) => Promise<OrganizationCode[]>;
    deactivateOrganizationCode: (codeId: number, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    createAccessRequest: (data: {
        email: string;
        firstName: string;
        lastName: string;
        phone?: string;
        organizationName?: string;
        professionalTitle?: string;
        credentials?: string;
        reason?: string;
        organizationId?: number;
        requestedRole?: string;
    }) => Promise<{
        success: boolean;
        requestId?: number;
        message?: string;
    }>;
    getAccessRequests: (filters: {
        status?: string;
        organizationId?: number;
        page?: number;
        limit?: number;
    }) => Promise<{
        data: AccessRequest[];
        total: number;
    }>;
    reviewAccessRequest: (requestId: number, reviewedBy: number, decision: "approved" | "rejected", notes?: string, password?: string) => Promise<{
        success: boolean;
        userId?: number;
        message?: string;
    }>;
    createInvitation: (email: string, invitedBy: number, options?: {
        organizationId?: number;
        studyId?: number;
        role?: string;
        message?: string;
        expiresInDays?: number;
    }) => Promise<{
        success: boolean;
        token?: string;
        invitationId?: number;
        message?: string;
    }>;
    validateInvitation: (token: string) => Promise<{
        isValid: boolean;
        email?: string;
        organizationId?: number;
        organizationName?: string;
        studyId?: number;
        studyName?: string;
        role?: string;
        inviterName?: string;
        message?: string;
    }>;
    acceptInvitation: (token: string, userData: {
        password: string;
        firstName: string;
        lastName: string;
        phone?: string;
    }) => Promise<{
        success: boolean;
        userId?: number;
        message?: string;
    }>;
};
export default _default;
//# sourceMappingURL=organization.service.d.ts.map