/**
 * Express Application Setup
 *
 * Main application configuration with all middleware and routes
 * - Security (Helmet, CORS)
 * - Body parsing
 * - Audit logging
 * - Rate limiting
 * - Routes
 * - Error handling
 */
declare const app: import("express-serve-static-core").Express;
export default app;
//# sourceMappingURL=app.d.ts.map