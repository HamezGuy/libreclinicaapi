"use strict";
/**
 * Notification Triggers
 *
 * Handles automatic email notifications triggered by system events.
 * Checks user preferences before sending notifications.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.triggerQueryOpened = triggerQueryOpened;
exports.triggerQueryResponse = triggerQueryResponse;
exports.triggerQueryClosed = triggerQueryClosed;
exports.triggerSignatureRequired = triggerSignatureRequired;
exports.triggerFormSubmitted = triggerFormSubmitted;
exports.triggerSDVStatusChange = triggerSDVStatusChange;
exports.triggerSubjectEnrolled = triggerSubjectEnrolled;
exports.triggerVisitOverdue = triggerVisitOverdue;
exports.triggerProtocolDeviation = triggerProtocolDeviation;
exports.triggerStudyLockChange = triggerStudyLockChange;
exports.triggerRoleAssigned = triggerRoleAssigned;
const database_1 = require("../../config/database");
const logger_1 = require("../../config/logger");
const email_service_1 = require("./email.service");
/**
 * Get user email by ID
 */
async function getUserEmail(userId) {
    try {
        const result = await database_1.pool.query('SELECT email FROM user_account WHERE user_id = $1', [userId]);
        return result.rows[0]?.email || null;
    }
    catch (error) {
        return null;
    }
}
/**
 * Get user name by ID
 */
async function getUserName(userId) {
    try {
        const result = await database_1.pool.query('SELECT first_name, last_name FROM user_account WHERE user_id = $1', [userId]);
        if (result.rows[0]) {
            return `${result.rows[0].first_name} ${result.rows[0].last_name}`;
        }
        return 'Unknown User';
    }
    catch (error) {
        return 'Unknown User';
    }
}
/**
 * Get study name by ID
 */
async function getStudyName(studyId) {
    try {
        const result = await database_1.pool.query('SELECT name FROM study WHERE study_id = $1', [studyId]);
        return result.rows[0]?.name || 'Unknown Study';
    }
    catch (error) {
        return 'Unknown Study';
    }
}
/**
 * Get subject label by ID
 */
async function getSubjectLabel(subjectId) {
    try {
        const result = await database_1.pool.query('SELECT label FROM study_subject WHERE study_subject_id = $1', [subjectId]);
        return result.rows[0]?.label || 'Unknown Subject';
    }
    catch (error) {
        return 'Unknown Subject';
    }
}
/**
 * Get site name by ID
 */
async function getSiteName(siteId) {
    try {
        const result = await database_1.pool.query('SELECT name FROM study WHERE study_id = $1', [siteId]);
        return result.rows[0]?.name || 'Unknown Site';
    }
    catch (error) {
        return 'Unknown Site';
    }
}
/**
 * Get users assigned to a study with a specific role
 */
async function getStudyUsersByRole(studyId, roleId) {
    try {
        const result = await database_1.pool.query(`
      SELECT DISTINCT sur.user_id
      FROM study_user_role sur
      WHERE sur.study_id = $1 AND sur.role_id = $2 AND sur.status_id = 1
    `, [studyId, roleId]);
        return result.rows.map(r => r.user_id);
    }
    catch (error) {
        return [];
    }
}
/**
 * Get users assigned to a site
 */
async function getSiteUsers(siteId) {
    try {
        const result = await database_1.pool.query(`
      SELECT DISTINCT sur.user_id
      FROM study_user_role sur
      WHERE sur.study_id = $1 AND sur.status_id = 1
    `, [siteId]);
        return result.rows.map(r => r.user_id);
    }
    catch (error) {
        return [];
    }
}
/**
 * Trigger: New query opened
 */
async function triggerQueryOpened(queryId, studyId, siteId, subjectId, createdByUserId, assignedToUserId, queryText) {
    logger_1.logger.info('Triggering query opened notification', { queryId });
    try {
        // Check if assigned user wants email notifications
        const shouldSend = await (0, email_service_1.shouldSendEmail)(assignedToUserId, 'query_created', studyId);
        if (!shouldSend) {
            logger_1.logger.info('User opted out of query opened emails', { userId: assignedToUserId });
            return;
        }
        const email = await getUserEmail(assignedToUserId);
        if (!email) {
            logger_1.logger.warn('No email found for user', { userId: assignedToUserId });
            return;
        }
        const [createdByName, studyName, subjectLabel] = await Promise.all([
            getUserName(createdByUserId),
            getStudyName(studyId),
            getSubjectLabel(subjectId)
        ]);
        await (0, email_service_1.queueEmail)({
            templateName: 'query_opened',
            recipientEmail: email,
            recipientUserId: assignedToUserId,
            studyId,
            entityType: 'query',
            entityId: queryId,
            priority: 3, // Higher priority for queries
            variables: {
                queryId,
                queryText,
                subjectLabel,
                studyName,
                createdByName,
                dashboardUrl: `${process.env.FRONTEND_URL}/study/${studyId}/queries`
            }
        });
    }
    catch (error) {
        logger_1.logger.error('Error triggering query opened notification', { error: error.message });
    }
}
/**
 * Trigger: Query response received
 */
async function triggerQueryResponse(queryId, studyId, respondedByUserId, originalCreatorUserId, responseText) {
    logger_1.logger.info('Triggering query response notification', { queryId });
    try {
        const shouldSend = await (0, email_service_1.shouldSendEmail)(originalCreatorUserId, 'query_response', studyId);
        if (!shouldSend) {
            return;
        }
        const email = await getUserEmail(originalCreatorUserId);
        if (!email)
            return;
        const [respondedByName, studyName] = await Promise.all([
            getUserName(respondedByUserId),
            getStudyName(studyId)
        ]);
        await (0, email_service_1.queueEmail)({
            templateName: 'query_response',
            recipientEmail: email,
            recipientUserId: originalCreatorUserId,
            studyId,
            entityType: 'query',
            entityId: queryId,
            priority: 3,
            variables: {
                queryId,
                responseText,
                studyName,
                respondedByName,
                dashboardUrl: `${process.env.FRONTEND_URL}/study/${studyId}/queries/${queryId}`
            }
        });
    }
    catch (error) {
        logger_1.logger.error('Error triggering query response notification', { error: error.message });
    }
}
/**
 * Trigger: Query closed
 */
async function triggerQueryClosed(queryId, studyId, closedByUserId, notifyUserIds) {
    logger_1.logger.info('Triggering query closed notification', { queryId });
    try {
        const [closedByName, studyName] = await Promise.all([
            getUserName(closedByUserId),
            getStudyName(studyId)
        ]);
        for (const userId of notifyUserIds) {
            if (userId === closedByUserId)
                continue; // Don't notify the closer
            const shouldSend = await (0, email_service_1.shouldSendEmail)(userId, 'query_closed', studyId);
            if (!shouldSend)
                continue;
            const email = await getUserEmail(userId);
            if (!email)
                continue;
            await (0, email_service_1.queueEmail)({
                templateName: 'query_closed',
                recipientEmail: email,
                recipientUserId: userId,
                studyId,
                entityType: 'query',
                entityId: queryId,
                priority: 5,
                variables: {
                    queryId,
                    studyName,
                    closedByName,
                    dashboardUrl: `${process.env.FRONTEND_URL}/study/${studyId}/queries`
                }
            });
        }
    }
    catch (error) {
        logger_1.logger.error('Error triggering query closed notification', { error: error.message });
    }
}
/**
 * Trigger: Form requires signature
 */
async function triggerSignatureRequired(eventCrfId, studyId, subjectId, formName, signerUserId) {
    logger_1.logger.info('Triggering signature required notification', { eventCrfId });
    try {
        const shouldSend = await (0, email_service_1.shouldSendEmail)(signerUserId, 'signature_required', studyId);
        if (!shouldSend)
            return;
        const email = await getUserEmail(signerUserId);
        if (!email)
            return;
        const [studyName, subjectLabel] = await Promise.all([
            getStudyName(studyId),
            getSubjectLabel(subjectId)
        ]);
        await (0, email_service_1.queueEmail)({
            templateName: 'signature_required',
            recipientEmail: email,
            recipientUserId: signerUserId,
            studyId,
            entityType: 'event_crf',
            entityId: eventCrfId,
            priority: 2, // High priority
            variables: {
                formName,
                subjectLabel,
                studyName,
                signatureUrl: `${process.env.FRONTEND_URL}/study/${studyId}/subject/${subjectId}/form/${eventCrfId}`
            }
        });
    }
    catch (error) {
        logger_1.logger.error('Error triggering signature required notification', { error: error.message });
    }
}
/**
 * Trigger: Form submitted
 */
async function triggerFormSubmitted(eventCrfId, studyId, siteId, subjectId, formName, submittedByUserId) {
    logger_1.logger.info('Triggering form submitted notification', { eventCrfId });
    try {
        // Notify study monitors (role_id = 6 typically)
        const monitorIds = await getStudyUsersByRole(studyId, 6);
        const [submittedByName, studyName, subjectLabel] = await Promise.all([
            getUserName(submittedByUserId),
            getStudyName(studyId),
            getSubjectLabel(subjectId)
        ]);
        for (const userId of monitorIds) {
            const shouldSend = await (0, email_service_1.shouldSendEmail)(userId, 'form_overdue', studyId);
            if (!shouldSend)
                continue;
            const email = await getUserEmail(userId);
            if (!email)
                continue;
            await (0, email_service_1.queueEmail)({
                templateName: 'form_submitted',
                recipientEmail: email,
                recipientUserId: userId,
                studyId,
                entityType: 'event_crf',
                entityId: eventCrfId,
                priority: 7, // Lower priority
                variables: {
                    formName,
                    subjectLabel,
                    studyName,
                    submittedByName,
                    reviewUrl: `${process.env.FRONTEND_URL}/study/${studyId}/subject/${subjectId}/form/${eventCrfId}`
                }
            });
        }
    }
    catch (error) {
        logger_1.logger.error('Error triggering form submitted notification', { error: error.message });
    }
}
/**
 * Trigger: SDV status changed
 */
async function triggerSDVStatusChange(eventCrfId, studyId, subjectId, formName, newStatus, verifiedByUserId, dataEntryUserId) {
    logger_1.logger.info('Triggering SDV status change notification', { eventCrfId, newStatus });
    try {
        const shouldSend = await (0, email_service_1.shouldSendEmail)(dataEntryUserId, 'sdv_required', studyId);
        if (!shouldSend || newStatus !== 'verified')
            return;
        const email = await getUserEmail(dataEntryUserId);
        if (!email)
            return;
        const [verifiedByName, studyName, subjectLabel] = await Promise.all([
            getUserName(verifiedByUserId),
            getStudyName(studyId),
            getSubjectLabel(subjectId)
        ]);
        await (0, email_service_1.queueEmail)({
            templateName: 'sdv_complete',
            recipientEmail: email,
            recipientUserId: dataEntryUserId,
            studyId,
            entityType: 'event_crf',
            entityId: eventCrfId,
            priority: 5,
            variables: {
                formName,
                subjectLabel,
                studyName,
                verifiedByName
            }
        });
    }
    catch (error) {
        logger_1.logger.error('Error triggering SDV status change notification', { error: error.message });
    }
}
/**
 * Trigger: Subject enrolled
 */
async function triggerSubjectEnrolled(subjectId, studyId, siteId, subjectLabel, enrolledByUserId) {
    logger_1.logger.info('Triggering subject enrolled notification', { subjectId });
    try {
        // Notify study coordinators and monitors
        const coordinatorIds = await getStudyUsersByRole(studyId, 4); // Coordinator role
        const monitorIds = await getStudyUsersByRole(studyId, 6); // Monitor role
        const notifyUserIds = [...new Set([...coordinatorIds, ...monitorIds])];
        const [enrolledByName, studyName, siteName] = await Promise.all([
            getUserName(enrolledByUserId),
            getStudyName(studyId),
            getSiteName(siteId)
        ]);
        for (const userId of notifyUserIds) {
            if (userId === enrolledByUserId)
                continue;
            const shouldSend = await (0, email_service_1.shouldSendEmail)(userId, 'subject_enrolled', studyId);
            if (!shouldSend)
                continue;
            const email = await getUserEmail(userId);
            if (!email)
                continue;
            await (0, email_service_1.queueEmail)({
                templateName: 'subject_enrolled',
                recipientEmail: email,
                recipientUserId: userId,
                studyId,
                entityType: 'study_subject',
                entityId: subjectId,
                priority: 5,
                variables: {
                    subjectLabel,
                    studyName,
                    siteName,
                    enrolledByName,
                    subjectUrl: `${process.env.FRONTEND_URL}/study/${studyId}/subject/${subjectId}`
                }
            });
        }
    }
    catch (error) {
        logger_1.logger.error('Error triggering subject enrolled notification', { error: error.message });
    }
}
/**
 * Trigger: Visit overdue
 */
async function triggerVisitOverdue(studyEventId, studyId, siteId, subjectId, visitName, daysOverdue) {
    logger_1.logger.info('Triggering visit overdue notification', { studyEventId });
    try {
        // Get site coordinators
        const siteUsers = await getSiteUsers(siteId);
        const [studyName, subjectLabel] = await Promise.all([
            getStudyName(studyId),
            getSubjectLabel(subjectId)
        ]);
        for (const userId of siteUsers) {
            const shouldSend = await (0, email_service_1.shouldSendEmail)(userId, 'form_overdue', studyId);
            if (!shouldSend)
                continue;
            const email = await getUserEmail(userId);
            if (!email)
                continue;
            await (0, email_service_1.queueEmail)({
                templateName: 'visit_overdue',
                recipientEmail: email,
                recipientUserId: userId,
                studyId,
                entityType: 'study_event',
                entityId: studyEventId,
                priority: 2, // High priority
                variables: {
                    visitName,
                    subjectLabel,
                    studyName,
                    daysOverdue,
                    subjectUrl: `${process.env.FRONTEND_URL}/study/${studyId}/subject/${subjectId}`
                }
            });
        }
    }
    catch (error) {
        logger_1.logger.error('Error triggering visit overdue notification', { error: error.message });
    }
}
/**
 * Trigger: Protocol deviation detected
 */
async function triggerProtocolDeviation(studyId, siteId, subjectId, deviationType, description, detectedByUserId) {
    logger_1.logger.info('Triggering protocol deviation notification', { subjectId, deviationType });
    try {
        // Notify PIs and study coordinators
        const piIds = await getStudyUsersByRole(studyId, 2); // PI role
        const coordinatorIds = await getStudyUsersByRole(studyId, 4);
        const notifyUserIds = [...new Set([...piIds, ...coordinatorIds])];
        const [detectedByName, studyName, subjectLabel] = await Promise.all([
            getUserName(detectedByUserId),
            getStudyName(studyId),
            getSubjectLabel(subjectId)
        ]);
        for (const userId of notifyUserIds) {
            const shouldSend = await (0, email_service_1.shouldSendEmail)(userId, 'study_milestone', studyId);
            if (!shouldSend)
                continue;
            const email = await getUserEmail(userId);
            if (!email)
                continue;
            await (0, email_service_1.queueEmail)({
                templateName: 'protocol_deviation',
                recipientEmail: email,
                recipientUserId: userId,
                studyId,
                entityType: 'study_subject',
                entityId: subjectId,
                priority: 1, // Highest priority
                variables: {
                    deviationType,
                    description,
                    subjectLabel,
                    studyName,
                    detectedByName,
                    subjectUrl: `${process.env.FRONTEND_URL}/study/${studyId}/subject/${subjectId}`
                }
            });
        }
    }
    catch (error) {
        logger_1.logger.error('Error triggering protocol deviation notification', { error: error.message });
    }
}
/**
 * Trigger: Study lock/unlock
 */
async function triggerStudyLockChange(studyId, isLocked, changedByUserId) {
    logger_1.logger.info('Triggering study lock change notification', { studyId, isLocked });
    try {
        // Notify all study users
        const result = await database_1.pool.query(`
      SELECT DISTINCT user_id FROM study_user_role
      WHERE study_id = $1 AND status_id = 1
    `, [studyId]);
        const userIds = result.rows.map(r => r.user_id);
        const [changedByName, studyName] = await Promise.all([
            getUserName(changedByUserId),
            getStudyName(studyId)
        ]);
        for (const userId of userIds) {
            if (userId === changedByUserId)
                continue;
            const shouldSend = await (0, email_service_1.shouldSendEmail)(userId, 'study_milestone', studyId);
            if (!shouldSend)
                continue;
            const email = await getUserEmail(userId);
            if (!email)
                continue;
            await (0, email_service_1.queueEmail)({
                templateName: isLocked ? 'study_locked' : 'study_unlocked',
                recipientEmail: email,
                recipientUserId: userId,
                studyId,
                entityType: 'study',
                entityId: studyId,
                priority: 2,
                variables: {
                    studyName,
                    changedByName,
                    action: isLocked ? 'locked' : 'unlocked',
                    studyUrl: `${process.env.FRONTEND_URL}/study/${studyId}`
                }
            });
        }
    }
    catch (error) {
        logger_1.logger.error('Error triggering study lock change notification', { error: error.message });
    }
}
/**
 * Trigger: User role assigned
 */
async function triggerRoleAssigned(userId, studyId, roleName, assignedByUserId) {
    logger_1.logger.info('Triggering role assigned notification', { userId, studyId, roleName });
    try {
        const email = await getUserEmail(userId);
        if (!email)
            return;
        const [assignedByName, studyName] = await Promise.all([
            getUserName(assignedByUserId),
            getStudyName(studyId)
        ]);
        await (0, email_service_1.queueEmail)({
            templateName: 'role_assigned',
            recipientEmail: email,
            recipientUserId: userId,
            studyId,
            entityType: 'user',
            entityId: userId,
            priority: 3,
            variables: {
                roleName,
                studyName,
                assignedByName,
                studyUrl: `${process.env.FRONTEND_URL}/study/${studyId}`
            }
        });
    }
    catch (error) {
        logger_1.logger.error('Error triggering role assigned notification', { error: error.message });
    }
}
exports.default = {
    triggerQueryOpened,
    triggerQueryResponse,
    triggerQueryClosed,
    triggerSignatureRequired,
    triggerFormSubmitted,
    triggerSDVStatusChange,
    triggerSubjectEnrolled,
    triggerVisitOverdue,
    triggerProtocolDeviation,
    triggerStudyLockChange,
    triggerRoleAssigned
};
//# sourceMappingURL=notification-triggers.js.map