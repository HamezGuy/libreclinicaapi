/**
 * Subject Service (Hybrid)
 *
 * RESPONSIBILITY SEPARATION:
 * ═══════════════════════════════════════════════════════════════
 * SOAP (Part 11 Compliant) - USE THESE:
 *   - createSubject() - Enroll subject via studySubject/create
 *   - isSubjectExists() - Check via studySubject/isStudySubject
 *   - listSubjects() - Get list via studySubject/listAllByStudy
 *
 * Database (Stats/Enrichment Only):
 *   - Add progress tracking (form completion %)
 *   - Add statistics (events, queries)
 *   - Fallback when SOAP unavailable
 * ═══════════════════════════════════════════════════════════════
 */
import { StudySubjectWithDetails, SubjectProgress, ApiResponse, PaginatedResponse } from '../../types/libreclinica-models';
/**
 * Request type for creating a subject
 *
 * Database Schema Reference:
 * ═══════════════════════════════════════════════════════════════════
 * SUBJECT TABLE (12 columns):
 *   - subject_id (PK), father_id (FK), mother_id (FK), status_id
 *   - date_of_birth, gender (char 1: 'm', 'f', '')
 *   - unique_identifier (varchar 255) - Person ID for cross-study linking
 *   - date_created, owner_id, date_updated, update_id, dob_collected
 *
 * STUDY_SUBJECT TABLE (13 columns):
 *   - study_subject_id (PK), label (varchar 30), secondary_label (varchar 30)
 *   - subject_id (FK), study_id (FK), status_id, enrollment_date
 *   - date_created, date_updated, owner_id, update_id
 *   - oc_oid (varchar 40), time_zone (varchar 255)
 * ═══════════════════════════════════════════════════════════════════
 */
export interface SubjectCreateRequest {
    studyId: number;
    studySubjectId: string;
    secondaryId?: string;
    enrollmentDate?: string;
    timeZone?: string;
    gender?: string;
    dateOfBirth?: string;
    personId?: string;
    fatherId?: number;
    motherId?: number;
    groupAssignments?: {
        studyGroupClassId: number;
        studyGroupId: number;
        notes?: string;
    }[];
    scheduleEvent?: {
        studyEventDefinitionId: number;
        location?: string;
        startDate?: string;
    };
}
/**
 * Create subject via SOAP or direct database (depending on config)
 */
export declare const createSubject: (request: SubjectCreateRequest, userId: number, username: string) => Promise<ApiResponse<any>>;
/**
 * Get subject list - SOAP PRIMARY, DB for stats enrichment
 *
 * Strategy:
 * 1. Try SOAP studySubject/listAllByStudy first (Part 11 compliant)
 * 2. Enrich with DB stats (progress, events)
 * 3. Fallback to pure DB if SOAP unavailable
 */
export declare const getSubjectList: (studyId: number, filters: {
    status?: string;
    page?: number;
    limit?: number;
}, userId?: number, username?: string) => Promise<PaginatedResponse<any>>;
/**
 * Get subject by ID with full details
 */
export declare const getSubjectById: (subjectId: number) => Promise<StudySubjectWithDetails | null>;
/**
 * Get subject progress/completion statistics
 */
export declare const getSubjectProgress: (subjectId: number) => Promise<SubjectProgress | null>;
declare const _default: {
    createSubject: (request: SubjectCreateRequest, userId: number, username: string) => Promise<ApiResponse<any>>;
    getSubjectList: (studyId: number, filters: {
        status?: string;
        page?: number;
        limit?: number;
    }, userId?: number, username?: string) => Promise<PaginatedResponse<any>>;
    getSubjectById: (subjectId: number) => Promise<StudySubjectWithDetails | null>;
    getSubjectProgress: (subjectId: number) => Promise<SubjectProgress | null>;
};
export default _default;
//# sourceMappingURL=subject.service.d.ts.map