/**
 * Wound Controller
 *
 * Handles HTTP requests for wound capture sessions
 * Integrates with WoundScanner iOS app
 */
import { Request, Response } from 'express';
export declare const uploadMiddleware: import("express").RequestHandler<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
/**
 * POST /api/wounds/sessions
 * Create a new wound capture session
 */
export declare const createSession: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * GET /api/wounds/sessions/:id
 * Get session by ID
 */
export declare const getSession: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * GET /api/wounds/patients/:patientId/sessions
 * Get all sessions for a patient
 */
export declare const getPatientSessions: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * POST /api/wounds/sessions/:id/images
 * Upload wound image
 */
export declare const uploadImage: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * GET /api/wounds/sessions/:id/images
 * Get images for a session
 */
export declare const getSessionImages: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * POST /api/wounds/sessions/:id/measurements
 * Submit wound measurements
 */
export declare const submitMeasurements: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * GET /api/wounds/sessions/:id/measurements
 * Get measurements for a session
 */
export declare const getSessionMeasurements: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * PUT /api/wounds/sessions/:id/sign
 * Apply electronic signature to session
 */
export declare const signSession: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * POST /api/wounds/sessions/:id/submit
 * Submit session to LibreClinica
 */
export declare const submitToLibreClinica: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * POST /api/wounds/audit/log
 * Submit audit entries from iOS app
 */
export declare const submitAuditEntries: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * POST /api/wounds/sync/batch
 * Batch sync offline sessions
 */
export declare const syncBatch: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * GET /api/wounds/sync/status
 * Get sync status
 */
export declare const getSyncStatus: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    createSession: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getSession: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getPatientSessions: (req: Request, res: Response, next: import("express").NextFunction) => void;
    uploadImage: (req: Request, res: Response, next: import("express").NextFunction) => void;
    uploadMiddleware: import("express").RequestHandler<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
    getSessionImages: (req: Request, res: Response, next: import("express").NextFunction) => void;
    submitMeasurements: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getSessionMeasurements: (req: Request, res: Response, next: import("express").NextFunction) => void;
    signSession: (req: Request, res: Response, next: import("express").NextFunction) => void;
    submitToLibreClinica: (req: Request, res: Response, next: import("express").NextFunction) => void;
    submitAuditEntries: (req: Request, res: Response, next: import("express").NextFunction) => void;
    syncBatch: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getSyncStatus: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=wound.controller.d.ts.map