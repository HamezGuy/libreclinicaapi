/**
 * 21 CFR Part 11 Compliance Service
 *
 * This service ensures proper integration with LibreClinica's compliance features:
 * - Uses LibreClinica's audit_log_event table and event types
 * - Properly logs electronic signatures
 * - Ensures audit trail integrity
 *
 * IMPORTANT: LibreClinica uses DATABASE TRIGGERS to automatically log changes.
 * These triggers fire when data is modified in:
 * - item_data (form field values)
 * - event_crf (form instances)
 * - study_event (visits)
 * - study_subject (subjects)
 * - subject (global subject records)
 * - subject_group_map (randomization)
 * - dn_item_data_map (discrepancy notes)
 * - event_definition_crf (form definitions)
 *
 * This service handles operations NOT covered by triggers:
 * - Electronic signatures with password verification
 * - API-level audit entries
 * - Custom compliance logging
 */
/**
 * LibreClinica Audit Event Types
 * These are the EXACT event types from LibreClinica's audit_log_event_type table
 */
export declare enum LibreClinicaAuditEventType {
    ITEM_DATA_VALUE_UPDATED = 1,
    STUDY_SUBJECT_CREATED = 2,
    STUDY_SUBJECT_STATUS_CHANGED = 3,
    STUDY_SUBJECT_VALUE_CHANGED = 4,
    SUBJECT_CREATED = 5,
    SUBJECT_STATUS_CHANGED = 6,
    SUBJECT_GLOBAL_VALUE_CHANGED = 7,
    EVENT_CRF_MARKED_COMPLETE = 8,
    EVENT_CRF_PROPERTIES_CHANGED = 9,
    EVENT_CRF_IDE_COMPLETE = 10,// Initial Data Entry complete
    EVENT_CRF_DDE_COMPLETE = 11,// Double Data Entry complete
    ITEM_DATA_STATUS_CHANGED = 12,
    ITEM_DATA_DELETED = 13,
    EVENT_CRF_COMPLETE_WITH_PASSWORD = 14,
    EVENT_CRF_IDE_COMPLETE_WITH_PASSWORD = 15,
    EVENT_CRF_DDE_COMPLETE_WITH_PASSWORD = 16,
    STUDY_EVENT_SCHEDULED = 17,
    STUDY_EVENT_DATA_ENTRY_STARTED = 18,
    STUDY_EVENT_COMPLETED = 19,
    STUDY_EVENT_STOPPED = 20,
    STUDY_EVENT_SKIPPED = 21,
    STUDY_EVENT_LOCKED = 22,
    STUDY_EVENT_REMOVED = 23,
    STUDY_EVENT_START_DATE_CHANGED = 24,
    STUDY_EVENT_END_DATE_CHANGED = 25,
    STUDY_EVENT_LOCATION_CHANGED = 26,
    SUBJECT_SITE_ASSIGNMENT = 27,
    SUBJECT_GROUP_ASSIGNMENT = 28,
    SUBJECT_GROUP_CHANGED = 29,
    ITEM_DATA_REPEATING_ROW_INSERTED = 30,
    STUDY_EVENT_SIGNED = 31,// ELECTRONIC SIGNATURE FOR STUDY EVENT
    EVENT_CRF_SDV_STATUS = 32,
    CHANGE_CRF_VERSION = 33,
    STUDY_EVENT_RESTORED = 35,
    EVENT_CRF_DELETED = 40,
    EVENT_CRF_STARTED = 41
}
/**
 * Signature meaning types for 21 CFR Part 11 §11.50
 */
export type SignatureMeaning = 'authorship' | 'approval' | 'responsibility' | 'review' | 'verification';
/**
 * Log an audit event using LibreClinica's audit_log_event table
 * This uses the EXACT schema and event types from LibreClinica
 */
export declare const logLibreClinicaAuditEvent: (eventTypeId: LibreClinicaAuditEventType, userId: number, params: {
    auditTable: string;
    entityId?: number;
    entityName?: string;
    oldValue?: string;
    newValue?: string;
    reasonForChange?: string;
    eventCrfId?: number;
    studyEventId?: number;
    eventCrfVersionId?: number;
}) => Promise<{
    success: boolean;
    auditId?: number;
    error?: string;
}>;
/**
 * Log Electronic Signature with proper 21 CFR Part 11 compliance
 *
 * This uses LibreClinica's e-signature event types:
 * - Event CRF complete with password (14)
 * - Study Event signed (31)
 */
export declare const logElectronicSignature: (userId: number, username: string, params: {
    entityType: "event_crf" | "study_event";
    entityId: number;
    entityName: string;
    meaning: SignatureMeaning;
    eventCrfId?: number;
    studyEventId?: number;
}) => Promise<{
    success: boolean;
    auditId?: number;
    error?: string;
}>;
/**
 * Log SDV (Source Data Verification) completion
 * Uses LibreClinica's EVENT_CRF_SDV_STATUS (32) event type
 */
export declare const logSDVVerification: (userId: number, params: {
    eventCrfId: number;
    entityName: string;
    verified: boolean;
    studyEventId?: number;
}) => Promise<{
    success: boolean;
    auditId?: number;
    error?: string;
}>;
/**
 * Log Study Event Lock/Unlock
 * Uses LibreClinica's STUDY_EVENT_LOCKED (22) event type
 */
export declare const logStudyEventLock: (userId: number, params: {
    studyEventId: number;
    entityName: string;
    locked: boolean;
    reason: string;
}) => Promise<{
    success: boolean;
    auditId?: number;
    error?: string;
}>;
/**
 * Verify password for electronic signature
 * Uses MD5 hash for LibreClinica compatibility
 */
export declare const verifyPasswordForCompliance: (userId: number, password: string) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Get audit trail for an entity
 * Returns LibreClinica audit log entries
 */
export declare const getAuditTrail: (entityType: "event_crf" | "study_event" | "study_subject" | "item_data", entityId: number, limit?: number) => Promise<{
    success: boolean;
    data?: any[];
    error?: string;
}>;
/**
 * Check 21 CFR Part 11 compliance status
 * Returns a summary of compliance features
 */
export declare const getComplianceStatus: () => Promise<{
    success: boolean;
    data?: {
        auditTrailEnabled: boolean;
        triggersActive: number;
        recentAuditEntries: number;
        electronicSignaturesConfigured: boolean;
        passwordHashingMethod: string;
    };
}>;
declare const _default: {
    logLibreClinicaAuditEvent: (eventTypeId: LibreClinicaAuditEventType, userId: number, params: {
        auditTable: string;
        entityId?: number;
        entityName?: string;
        oldValue?: string;
        newValue?: string;
        reasonForChange?: string;
        eventCrfId?: number;
        studyEventId?: number;
        eventCrfVersionId?: number;
    }) => Promise<{
        success: boolean;
        auditId?: number;
        error?: string;
    }>;
    logElectronicSignature: (userId: number, username: string, params: {
        entityType: "event_crf" | "study_event";
        entityId: number;
        entityName: string;
        meaning: SignatureMeaning;
        eventCrfId?: number;
        studyEventId?: number;
    }) => Promise<{
        success: boolean;
        auditId?: number;
        error?: string;
    }>;
    logSDVVerification: (userId: number, params: {
        eventCrfId: number;
        entityName: string;
        verified: boolean;
        studyEventId?: number;
    }) => Promise<{
        success: boolean;
        auditId?: number;
        error?: string;
    }>;
    logStudyEventLock: (userId: number, params: {
        studyEventId: number;
        entityName: string;
        locked: boolean;
        reason: string;
    }) => Promise<{
        success: boolean;
        auditId?: number;
        error?: string;
    }>;
    verifyPasswordForCompliance: (userId: number, password: string) => Promise<{
        success: boolean;
        message?: string;
    }>;
    getAuditTrail: (entityType: "event_crf" | "study_event" | "study_subject" | "item_data", entityId: number, limit?: number) => Promise<{
        success: boolean;
        data?: any[];
        error?: string;
    }>;
    getComplianceStatus: () => Promise<{
        success: boolean;
        data?: {
            auditTrailEnabled: boolean;
            triggersActive: number;
            recentAuditEntries: number;
            electronicSignaturesConfigured: boolean;
            passwordHashingMethod: string;
        };
    }>;
    LibreClinicaAuditEventType: typeof LibreClinicaAuditEventType;
};
export default _default;
//# sourceMappingURL=compliance.service.d.ts.map