"use strict";
/**
 * Event Routes
 *
 * Study Event (Phase) management routes
 * Includes CRF (Template) assignment to events
 *
 * 21 CFR Part 11 Compliance:
 * - Event creation/modification requires electronic signature (§11.50)
 * - CRF assignment requires electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const controller = __importStar(require("../controllers/event.controller"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const authorization_middleware_1 = require("../middleware/authorization.middleware");
const validation_middleware_1 = require("../middleware/validation.middleware");
const rateLimiter_middleware_1 = require("../middleware/rateLimiter.middleware");
const part11_middleware_1 = require("../middleware/part11.middleware");
const router = express_1.default.Router();
router.use(auth_middleware_1.authMiddleware);
// Root route - returns events filtered by query params (for frontend compatibility)
router.get('/', controller.listEvents);
// Read operations - all authenticated users (no signature required)
router.get('/study/:studyId', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.studyIdParam }), controller.getStudyEvents);
router.get('/:id', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.getEvent);
router.get('/:id/crfs', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.getEventCRFs);
router.get('/subject/:subjectId', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.subjectIdParam }), controller.getSubjectEvents);
// Get patient's event_crfs for a specific study_event instance (editable copies)
router.get('/instance/:studyEventId/crfs', controller.getPatientEventCRFs);
// Create/Update/Delete - require coordinator or admin role + signature
router.post('/', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, validation_middleware_1.validate)({ body: validation_middleware_1.eventSchemas.create }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.EVENT_CREATE), controller.create);
router.put('/:id', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam, body: validation_middleware_1.eventSchemas.update }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.EVENT_UPDATE), controller.update);
router.delete('/:id', (0, authorization_middleware_1.requireRole)('admin'), (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.EVENT_DELETE), controller.remove);
// Schedule event - require data entry or coordinator role + signature
router.post('/schedule', (0, authorization_middleware_1.requireRole)('coordinator', 'data_entry', 'investigator'), rateLimiter_middleware_1.soapRateLimiter, (0, validation_middleware_1.validate)({ body: validation_middleware_1.eventSchemas.schedule }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.EVENT_SCHEDULE), controller.scheduleEvent);
// ============================================
// EVENT CRF ASSIGNMENT ROUTES
// ============================================
// Get available CRFs that can be assigned to an event (no signature required)
router.get('/study/:studyId/event/:eventId/available-crfs', controller.getAvailableCrfs);
// Assign CRF to event (signature required)
router.post('/:eventId/crfs', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.CRF_ASSIGN), controller.assignCrf);
// Update CRF assignment settings (signature required)
router.put('/crf-assignment/:crfAssignmentId', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.CRF_UPDATE), controller.updateEventCrf);
// Remove CRF from event (signature required)
router.delete('/crf-assignment/:crfAssignmentId', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.CRF_DELETE), controller.removeCrf);
// Reorder CRFs within an event (signature required)
router.put('/:eventId/crfs/reorder', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.CRF_UPDATE), controller.reorderCrfs);
// Bulk assign CRFs to event (signature required)
router.post('/:eventId/crfs/bulk', (0, authorization_middleware_1.requireRole)('admin', 'coordinator'), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.CRF_ASSIGN), controller.bulkAssignCrfs);
exports.default = router;
//# sourceMappingURL=event.routes.js.map