"use strict";
/**
 * 21 CFR Part 11 Compliance Routes
 *
 * Endpoints for checking and managing compliance status
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const auth_middleware_1 = require("../middleware/auth.middleware");
const complianceService = __importStar(require("../services/database/compliance.service"));
const router = express_1.default.Router();
// All compliance routes require authentication
router.use(auth_middleware_1.authMiddleware);
/**
 * GET /api/compliance/status
 * Get 21 CFR Part 11 compliance status
 */
router.get('/status', (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const result = await complianceService.getComplianceStatus();
    res.json(result);
}));
/**
 * GET /api/compliance/audit-trail/:entityType/:entityId
 * Get audit trail for an entity
 */
router.get('/audit-trail/:entityType/:entityId', (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { entityType, entityId } = req.params;
    const limit = parseInt(req.query.limit) || 50;
    const validTypes = ['event_crf', 'study_event', 'study_subject', 'item_data'];
    if (!validTypes.includes(entityType)) {
        res.status(400).json({
            success: false,
            message: `Invalid entityType. Must be one of: ${validTypes.join(', ')}`
        });
        return;
    }
    const result = await complianceService.getAuditTrail(entityType, parseInt(entityId), limit);
    res.json(result);
}));
/**
 * GET /api/compliance/event-types
 * Get list of LibreClinica audit event types
 */
router.get('/event-types', (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const eventTypes = Object.entries(complianceService.LibreClinicaAuditEventType)
        .filter(([key]) => isNaN(Number(key)))
        .map(([name, id]) => ({ id, name }));
    res.json({
        success: true,
        data: eventTypes
    });
}));
exports.default = router;
//# sourceMappingURL=compliance.routes.js.map