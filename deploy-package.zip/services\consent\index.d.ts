/**
 * Consent Services Index
 */
export * from './consent.types';
export * from './consent.service';
//# sourceMappingURL=index.d.ts.map