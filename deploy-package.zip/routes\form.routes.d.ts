/**
 * Form Routes
 *
 * CRUD operations for form templates (CRFs) and form data
 *
 * 21 CFR Part 11 Compliance:
 * - All data modifications require electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=form.routes.d.ts.map