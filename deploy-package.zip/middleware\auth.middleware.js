"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.optionalAuthMiddleware = exports.authMiddleware = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const environment_1 = require("../config/environment");
const logger_1 = require("../config/logger");
/**
 * JWT Authentication Middleware (21 CFR Part 11 §11.10(d))
 * Verifies JWT token and enforces session timeout
 */
const authMiddleware = (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        logger_1.logger.warn('Missing or invalid authorization header', {
            path: req.path,
            ip: req.ip
        });
        res.status(401).json({
            success: false,
            error: {
                code: 'UNAUTHORIZED',
                message: 'Authentication required'
            }
        });
        return;
    }
    const token = authHeader.substring(7); // Remove 'Bearer '
    try {
        const decoded = jsonwebtoken_1.default.verify(token, environment_1.config.jwt.secret);
        // Check token expiration (session timeout - §11.300)
        const tokenAge = Date.now() - (decoded.iat * 1000);
        const maxAge = environment_1.config.part11.sessionTimeoutMinutes * 60 * 1000;
        if (tokenAge > maxAge) {
            logger_1.logger.warn('Token expired (session timeout)', {
                userId: decoded.userId,
                tokenAge: Math.round(tokenAge / 1000 / 60),
                maxAge: environment_1.config.part11.sessionTimeoutMinutes
            });
            res.status(401).json({
                success: false,
                error: {
                    code: 'SESSION_EXPIRED',
                    message: 'Session has expired. Please log in again.'
                }
            });
            return;
        }
        // Attach user to request (including role for permission checks)
        req.user = {
            userId: decoded.userId,
            userName: decoded.userName,
            email: decoded.email,
            userType: decoded.userType,
            role: decoded.role || decoded.userType, // Use role from token, fallback to userType
            studyIds: decoded.studyIds
        };
        logger_1.logger.debug('User authenticated', {
            userId: decoded.userId,
            userName: decoded.userName,
            path: req.path
        });
        next();
    }
    catch (error) {
        logger_1.logger.warn('Invalid JWT token', {
            error: error.message,
            ip: req.ip,
            path: req.path
        });
        res.status(401).json({
            success: false,
            error: {
                code: 'INVALID_TOKEN',
                message: 'Invalid authentication token'
            }
        });
    }
};
exports.authMiddleware = authMiddleware;
/**
 * Optional authentication - doesn't fail if no token
 */
const optionalAuthMiddleware = (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
        const token = authHeader.substring(7);
        try {
            const decoded = jsonwebtoken_1.default.verify(token, environment_1.config.jwt.secret);
            req.user = {
                userId: decoded.userId,
                userName: decoded.userName,
                email: decoded.email,
                userType: decoded.userType,
                role: decoded.role || decoded.userType,
                studyIds: decoded.studyIds
            };
        }
        catch (error) {
            // Ignore errors for optional auth
        }
    }
    next();
};
exports.optionalAuthMiddleware = optionalAuthMiddleware;
//# sourceMappingURL=auth.middleware.js.map