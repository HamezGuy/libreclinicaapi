/**
 * Workflow Controller
 *
 * Handles workflow/task management API endpoints.
 * Uses the workflow service for all database operations.
 *
 * Real EDC Workflow Patterns Supported:
 * - Automatic task creation on form submission, SDV, signatures
 * - Manual task creation by coordinators/monitors
 * - Task state transitions with audit logging
 * - Role-based task assignment
 *
 * 21 CFR Part 11 Compliance:
 * - All actions are audit logged
 * - User authentication required
 * - Status transitions are tracked
 */
import { Request, Response, NextFunction } from 'express';
export declare class WorkflowController {
    /**
     * Get all workflows (admin/coordinator view)
     * GET /api/workflows
     */
    getAllWorkflows(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Get workflows for specific user
     * GET /api/workflows/user/:userId
     */
    getUserWorkflows(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Get user task summary with organized task arrays
     * GET /api/workflows/user/:userId/summary
     */
    getUserTaskSummary(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Create new workflow task
     * POST /api/workflows
     */
    createWorkflow(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Update workflow status
     * PUT /api/workflows/:id/status
     */
    updateWorkflowStatus(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Complete workflow task
     * POST /api/workflows/:id/complete
     */
    completeWorkflow(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Approve workflow task
     * POST /api/workflows/:id/approve
     */
    approveWorkflow(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Reject workflow task
     * POST /api/workflows/:id/reject
     */
    rejectWorkflow(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Handoff workflow task to another user/role
     * POST /api/workflows/:id/handoff
     */
    handoffWorkflow(req: Request, res: Response, next: NextFunction): Promise<void>;
}
export default WorkflowController;
//# sourceMappingURL=workflow.controller.d.ts.map