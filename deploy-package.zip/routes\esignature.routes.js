"use strict";
/**
 * Electronic Signature Routes
 *
 * 21 CFR Part 11 Compliant Electronic Signatures
 *
 * §11.100 - General requirements:
 * (a) Each electronic signature shall be unique to one individual and shall not be reused
 * (b) Before establishing, assigning, certifying, or otherwise sanctioning electronic signatures,
 *     verify the identity of the individual
 * (c) Persons using electronic signatures shall, prior to or at the time of use, certify to the
 *     agency that the signatures are the legally binding equivalent of traditional handwritten signatures
 *
 * §11.200 - Electronic signature components and controls:
 * (a)(1) Employ at least two distinct identification components such as identification code and password
 * (a)(2) Be used only by their genuine owners
 * (a)(3) Be administered and executed to ensure only the genuine owners can use them
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const controller = __importStar(require("../controllers/esignature.controller"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const router = express_1.default.Router();
// All e-signature routes require authentication
router.use(auth_middleware_1.authMiddleware);
/**
 * POST /api/esignature/verify-password
 * Verify user's password for e-signature (21 CFR Part 11 §11.200)
 * Used before applying electronic signature
 */
router.post('/verify-password', controller.verifyPassword);
/**
 * POST /api/esignature/sign
 * Apply electronic signature to an entity
 * Requires password re-entry per 21 CFR Part 11 §11.200
 */
router.post('/sign', controller.applySignature);
/**
 * GET /api/esignature/status/:entityType/:entityId
 * Get e-signature status for an entity
 */
router.get('/status/:entityType/:entityId', controller.getSignatureStatus);
/**
 * GET /api/esignature/history/:entityType/:entityId
 * Get signature history for an entity
 */
router.get('/history/:entityType/:entityId', controller.getSignatureHistory);
/**
 * GET /api/esignature/pending
 * Get all entities pending signature for current user
 */
router.get('/pending', controller.getPendingSignatures);
/**
 * POST /api/esignature/certify
 * User certification that e-signature is legally binding (21 CFR Part 11 §11.100(c))
 */
router.post('/certify', controller.certifySignature);
/**
 * GET /api/esignature/requirements/:studyId
 * Get e-signature requirements for a study (which forms require signatures)
 */
router.get('/requirements/:studyId', controller.getStudyRequirements);
exports.default = router;
//# sourceMappingURL=esignature.routes.js.map