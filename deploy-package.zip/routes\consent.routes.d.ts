/**
 * Consent Routes
 *
 * API endpoints for eConsent management.
 *
 * 21 CFR Part 11 Compliance:
 * - Consent recording requires electronic signature (§11.50)
 * - Consent withdrawal requires electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=consent.routes.d.ts.map