"use strict";
/**
 * Query Routes
 *
 * 21 CFR Part 11 Compliance:
 * - Query creation requires electronic signature (§11.50)
 * - Query responses require electronic signature (§11.50)
 * - Query closure requires electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const controller = __importStar(require("../controllers/query.controller"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const authorization_middleware_1 = require("../middleware/authorization.middleware");
const validation_middleware_1 = require("../middleware/validation.middleware");
const part11_middleware_1 = require("../middleware/part11.middleware");
const router = express_1.default.Router();
router.use(auth_middleware_1.authMiddleware);
// List and statistics (no signature required)
router.get('/', (0, validation_middleware_1.validate)({ query: validation_middleware_1.querySchemas.list }), controller.list);
router.get('/stats', controller.stats);
router.get('/types', controller.getQueryTypes);
router.get('/statuses', controller.getResolutionStatuses);
router.get('/count-by-status', controller.countByStatus);
router.get('/count-by-type', controller.countByType);
router.get('/overdue', controller.getOverdue);
router.get('/my-assigned', controller.getMyAssigned);
// Form-specific queries (no signature required for reading)
router.get('/form/:eventCrfId', controller.getFormQueries);
// Single query operations (no signature required for reading)
router.get('/:id', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.get);
router.get('/:id/thread', controller.getThread);
router.get('/:id/audit-trail', controller.getAuditTrail);
// Create and update operations (signature required per §11.50)
router.post('/', (0, authorization_middleware_1.requireRole)('admin', 'coordinator', 'data_entry', 'investigator', 'monitor'), (0, validation_middleware_1.validate)({ body: validation_middleware_1.querySchemas.create }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.QUERY_CREATE), controller.create);
router.post('/:id/respond', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam, body: validation_middleware_1.querySchemas.respond }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.QUERY_RESPOND), controller.respond);
router.put('/:id/status', (0, authorization_middleware_1.requireRole)('monitor', 'coordinator', 'admin'), (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam, body: validation_middleware_1.querySchemas.updateStatus }), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.QUERY_CLOSE), controller.updateStatus);
router.put('/:id/reassign', (0, authorization_middleware_1.requireRole)('coordinator', 'admin'), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.AUTHORIZE), controller.reassign);
// Close with electronic signature (21 CFR Part 11 compliant)
router.post('/:id/close-with-signature', (0, authorization_middleware_1.requireRole)('monitor', 'coordinator', 'admin', 'investigator'), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.QUERY_CLOSE), controller.closeWithSignature);
exports.default = router;
//# sourceMappingURL=query.routes.js.map