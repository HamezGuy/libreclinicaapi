"use strict";
/**
 * Workflow Controller
 *
 * Handles workflow/task management API endpoints.
 * Uses the workflow service for all database operations.
 *
 * Real EDC Workflow Patterns Supported:
 * - Automatic task creation on form submission, SDV, signatures
 * - Manual task creation by coordinators/monitors
 * - Task state transitions with audit logging
 * - Role-based task assignment
 *
 * 21 CFR Part 11 Compliance:
 * - All actions are audit logged
 * - User authentication required
 * - Status transitions are tracked
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.WorkflowController = void 0;
const logger_1 = require("../config/logger");
const workflowService = __importStar(require("../services/database/workflow.service"));
class WorkflowController {
    /**
     * Get all workflows (admin/coordinator view)
     * GET /api/workflows
     */
    async getAllWorkflows(req, res, next) {
        try {
            const { status, priority, assignedTo, studyId, type, limit, offset } = req.query;
            const result = await workflowService.getAllWorkflows({
                status: status,
                priority: priority,
                assignedTo: assignedTo,
                studyId: studyId ? parseInt(studyId) : undefined,
                type: type,
                limit: limit ? parseInt(limit) : 100,
                offset: offset ? parseInt(offset) : 0
            });
            const response = {
                success: true,
                data: result.data,
                message: 'Workflows retrieved successfully'
            };
            res.json(response);
        }
        catch (error) {
            logger_1.logger.error('Error fetching workflows:', error);
            next(error);
        }
    }
    /**
     * Get workflows for specific user
     * GET /api/workflows/user/:userId
     */
    async getUserWorkflows(req, res, next) {
        try {
            const { userId } = req.params;
            const result = await workflowService.getUserWorkflows(userId);
            const response = {
                success: true,
                data: result.data
            };
            res.json(response);
        }
        catch (error) {
            logger_1.logger.error('Error fetching user workflows:', error);
            next(error);
        }
    }
    /**
     * Get user task summary with organized task arrays
     * GET /api/workflows/user/:userId/summary
     */
    async getUserTaskSummary(req, res, next) {
        try {
            const { userId } = req.params;
            const result = await workflowService.getUserTaskSummary(userId);
            const response = {
                success: true,
                data: result.data
            };
            res.json(response);
        }
        catch (error) {
            logger_1.logger.error('Error fetching user task summary:', error);
            next(error);
        }
    }
    /**
     * Create new workflow task
     * POST /api/workflows
     */
    async createWorkflow(req, res, next) {
        try {
            const { title, description, studyId, entityType, entityId, assignedTo, type, priority, dueDate, requiresApproval, requiresSignature, eventCrfId } = req.body;
            const user = req.user;
            const userId = user?.userId || user?.user_id;
            const username = user?.username || user?.user_name || 'system';
            // Validate required fields
            if (!title) {
                res.status(400).json({ success: false, message: 'Title is required' });
                return;
            }
            const result = await workflowService.createWorkflow({
                title,
                description,
                type: type || 'custom',
                priority: priority || 'medium',
                assignedTo: Array.isArray(assignedTo) ? assignedTo : [assignedTo].filter(Boolean),
                dueDate: dueDate ? new Date(dueDate) : undefined,
                studyId: studyId || 1,
                entityType: entityType || 'patient',
                entityId: entityId ? parseInt(entityId) : undefined,
                eventCrfId: eventCrfId ? parseInt(eventCrfId) : undefined,
                requiresApproval: requiresApproval || false,
                requiresSignature: requiresSignature || false
            }, userId, username);
            res.status(201).json(result);
        }
        catch (error) {
            logger_1.logger.error('Error creating workflow:', error);
            next(error);
        }
    }
    /**
     * Update workflow status
     * PUT /api/workflows/:id/status
     */
    async updateWorkflowStatus(req, res, next) {
        try {
            const { id } = req.params;
            const { status } = req.body;
            const user = req.user;
            const userId = user?.userId || user?.user_id;
            if (!status) {
                res.status(400).json({ success: false, message: 'Status is required' });
                return;
            }
            const result = await workflowService.updateWorkflowStatus(id, status, userId);
            res.json(result);
        }
        catch (error) {
            logger_1.logger.error('Error updating workflow status:', error);
            next(error);
        }
    }
    /**
     * Complete workflow task
     * POST /api/workflows/:id/complete
     */
    async completeWorkflow(req, res, next) {
        try {
            const { id } = req.params;
            const { signature } = req.body;
            const user = req.user;
            const userId = user?.userId || user?.user_id;
            const result = await workflowService.completeWorkflow(id, userId, signature);
            res.json(result);
        }
        catch (error) {
            logger_1.logger.error('Error completing workflow:', error);
            next(error);
        }
    }
    /**
     * Approve workflow task
     * POST /api/workflows/:id/approve
     */
    async approveWorkflow(req, res, next) {
        try {
            const { id } = req.params;
            const { reason } = req.body;
            const user = req.user;
            const userId = user?.userId || user?.user_id;
            if (!reason) {
                res.status(400).json({ success: false, message: 'Reason is required for approval' });
                return;
            }
            const result = await workflowService.approveWorkflow(id, userId, reason);
            res.json(result);
        }
        catch (error) {
            logger_1.logger.error('Error approving workflow:', error);
            next(error);
        }
    }
    /**
     * Reject workflow task
     * POST /api/workflows/:id/reject
     */
    async rejectWorkflow(req, res, next) {
        try {
            const { id } = req.params;
            const { reason } = req.body;
            const user = req.user;
            const userId = user?.userId || user?.user_id;
            if (!reason) {
                res.status(400).json({ success: false, message: 'Reason is required for rejection' });
                return;
            }
            const result = await workflowService.rejectWorkflow(id, userId, reason);
            res.json(result);
        }
        catch (error) {
            logger_1.logger.error('Error rejecting workflow:', error);
            next(error);
        }
    }
    /**
     * Handoff workflow task to another user/role
     * POST /api/workflows/:id/handoff
     */
    async handoffWorkflow(req, res, next) {
        try {
            const { id } = req.params;
            const { toUserId, reason } = req.body;
            const user = req.user;
            const currentUserId = user?.userId || user?.user_id;
            if (!toUserId) {
                res.status(400).json({ success: false, message: 'Target user is required' });
                return;
            }
            const result = await workflowService.handoffWorkflow(id, toUserId, reason || 'Reassigned', currentUserId);
            res.json(result);
        }
        catch (error) {
            logger_1.logger.error('Error handing off workflow:', error);
            next(error);
        }
    }
}
exports.WorkflowController = WorkflowController;
exports.default = WorkflowController;
//# sourceMappingURL=workflow.controller.js.map