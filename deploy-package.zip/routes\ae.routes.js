"use strict";
/**
 * Adverse Event (AE/SAE) Routes
 * Uses EXISTING LibreClinica SOAP APIs for Part 11 compliance
 * AEs are CRF forms - imported via dataSoap.service
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const aeService = __importStar(require("../services/ae/adverse-event.service"));
const logger_1 = require("../config/logger");
const router = (0, express_1.Router)();
/**
 * GET /api/ae/summary/:studyId
 * Get AE summary statistics for dashboard
 */
router.get('/summary/:studyId', (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const studyId = parseInt(req.params.studyId);
    if (isNaN(studyId)) {
        return res.status(400).json({
            success: false,
            message: 'Invalid studyId'
        });
    }
    const summary = await aeService.getAESummary(studyId);
    res.json({
        success: true,
        data: summary
    });
}));
/**
 * GET /api/ae/subject/:studyId/:subjectId
 * Get AEs for a specific subject
 */
router.get('/subject/:studyId/:subjectId', (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const studyId = parseInt(req.params.studyId);
    const subjectId = parseInt(req.params.subjectId);
    if (isNaN(studyId) || isNaN(subjectId)) {
        return res.status(400).json({
            success: false,
            message: 'Invalid studyId or subjectId'
        });
    }
    const aes = await aeService.getSubjectAEs(studyId, subjectId);
    res.json({
        success: true,
        data: aes
    });
}));
/**
 * POST /api/ae/report
 * Report a new Adverse Event via LibreClinica SOAP
 */
router.post('/report', (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyOID, subjectOID, aeTerm, meddraCode, onsetDate, resolutionDate, severity, isSerious, seriousnessCriteria, causalityAssessment, outcome, actionTaken, aeConfig } = req.body;
    const userId = req.user?.userId || 1;
    const username = req.user?.username || 'api';
    // Validation
    if (!studyOID || !subjectOID || !aeTerm || !onsetDate || !severity) {
        return res.status(400).json({
            success: false,
            message: 'Required fields: studyOID, subjectOID, aeTerm, onsetDate, severity'
        });
    }
    const validSeverities = ['Mild', 'Moderate', 'Severe'];
    if (!validSeverities.includes(severity)) {
        return res.status(400).json({
            success: false,
            message: `severity must be one of: ${validSeverities.join(', ')}`
        });
    }
    logger_1.logger.info('AE report request', {
        studyOID,
        subjectOID,
        aeTerm,
        isSerious,
        username
    });
    const result = await aeService.reportAdverseEvent(studyOID, {
        subjectOID,
        aeTerm,
        meddraCode,
        onsetDate,
        resolutionDate,
        severity,
        isSerious: isSerious === true || isSerious === 'true',
        seriousnessCriteria,
        causalityAssessment,
        outcome,
        actionTaken
    }, userId, username, aeConfig);
    if (!result.success) {
        return res.status(500).json(result);
    }
    res.json(result);
}));
/**
 * GET /api/ae/config
 * Get default AE form configuration
 */
router.get('/config', (0, errorHandler_middleware_1.asyncHandler)(async (_req, res) => {
    res.json({
        success: true,
        data: {
            defaultConfig: aeService.DEFAULT_AE_CONFIG,
            severityOptions: ['Mild', 'Moderate', 'Severe'],
            causalityOptions: ['Not Related', 'Unlikely', 'Possible', 'Probable', 'Definite'],
            outcomeOptions: ['Recovered', 'Recovering', 'Not Recovered', 'Recovered with Sequelae', 'Fatal', 'Unknown'],
            actionOptions: ['None', 'Dose Reduced', 'Drug Interrupted', 'Drug Withdrawn', 'Other']
        }
    });
}));
exports.default = router;
//# sourceMappingURL=ae.routes.js.map