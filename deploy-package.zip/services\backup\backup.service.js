"use strict";
/**
 * Backup Service - 21 CFR Part 11 Compliant
 *
 * SIMPLE, WORKING database backup using Docker PostgreSQL
 *
 * This service runs pg_dump INSIDE the Docker container where PostgreSQL
 * tools are guaranteed to be available.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.restoreBackup = exports.getBackupStats = exports.cleanupOldBackups = exports.verifyBackup = exports.getBackup = exports.listBackups = exports.performBackup = exports.getBackupConfig = exports.BackupStatus = exports.BackupType = void 0;
const child_process_1 = require("child_process");
const util_1 = require("util");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const crypto = __importStar(require("crypto"));
const environment_1 = require("../../config/environment");
const logger_1 = require("../../config/logger");
const database_1 = require("../../config/database");
const execAsync = (0, util_1.promisify)(child_process_1.exec);
var BackupType;
(function (BackupType) {
    BackupType["FULL"] = "full";
    BackupType["INCREMENTAL"] = "incremental";
    BackupType["TRANSACTION_LOG"] = "transaction_log";
})(BackupType || (exports.BackupType = BackupType = {}));
var BackupStatus;
(function (BackupStatus) {
    BackupStatus["PENDING"] = "pending";
    BackupStatus["IN_PROGRESS"] = "in_progress";
    BackupStatus["COMPLETED"] = "completed";
    BackupStatus["FAILED"] = "failed";
    BackupStatus["VERIFIED"] = "verified";
})(BackupStatus || (exports.BackupStatus = BackupStatus = {}));
const defaultConfig = {
    backupDir: process.env.BACKUP_DIR || path.join(process.cwd(), 'backups'),
    containerName: process.env.BACKUP_CONTAINER || 'libreclinica-postgres',
    retentionDays: {
        full: 28,
        incremental: 7,
        transactionLog: 1
    },
    schedules: {
        full: '0 2 * * 0',
        incremental: '0 2 * * 1-6',
        transactionLog: '0 * * * *'
    }
};
const getBackupConfig = () => ({ ...defaultConfig });
exports.getBackupConfig = getBackupConfig;
const generateBackupId = (type) => {
    const now = new Date();
    return `BKP-${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}-${type.toUpperCase()}-${now.getTime()}`;
};
const calculateChecksum = async (filePath) => {
    return new Promise((resolve, reject) => {
        const hash = crypto.createHash('sha256');
        const stream = fs.createReadStream(filePath);
        stream.on('data', (data) => hash.update(data));
        stream.on('end', () => resolve(hash.digest('hex')));
        stream.on('error', reject);
    });
};
const ensureBackupDir = (backupDir) => {
    ['full', 'incremental', 'transaction_log', 'metadata'].forEach(subDir => {
        const dir = path.join(backupDir, subDir);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
    });
};
/**
 * Check if Docker is available and container is running
 */
const checkDockerContainer = async (containerName) => {
    try {
        const { stdout } = await execAsync(`docker inspect -f "{{.State.Running}}" ${containerName}`);
        return stdout.trim() === 'true';
    }
    catch {
        return false;
    }
};
/**
 * Perform backup using pg_dump INSIDE Docker container
 */
const performBackup = async (type, userId = 0, username = 'system') => {
    const startTime = Date.now();
    const backupId = generateBackupId(type);
    const backupConfig = (0, exports.getBackupConfig)();
    const dbConfig = environment_1.config.libreclinica.database;
    logger_1.logger.info('Starting backup', { backupId, type });
    try {
        ensureBackupDir(backupConfig.backupDir);
        // Check if Docker container is running
        const containerRunning = await checkDockerContainer(backupConfig.containerName);
        if (!containerRunning) {
            throw new Error(`Docker container '${backupConfig.containerName}' is not running. Start it with: docker-compose -f docker-compose.libreclinica.yml up -d`);
        }
        // Generate file paths
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const subDir = type === BackupType.FULL ? 'full' : type === BackupType.INCREMENTAL ? 'incremental' : 'transaction_log';
        const filename = `${backupId}_${dbConfig.database}_${timestamp}.sql.gz`;
        const outputPath = path.join(backupConfig.backupDir, subDir, filename);
        // Run pg_dump INSIDE the Docker container
        logger_1.logger.info('Running pg_dump in Docker container', { container: backupConfig.containerName });
        let pgDumpCommand;
        if (type === BackupType.TRANSACTION_LOG) {
            // Only backup audit tables for transaction log
            pgDumpCommand = `pg_dump -U ${dbConfig.user} -d ${dbConfig.database} --data-only -t audit_log_event -t audit_user_login | gzip`;
        }
        else {
            // Full database dump
            pgDumpCommand = `pg_dump -U ${dbConfig.user} -d ${dbConfig.database} | gzip`;
        }
        // Execute inside container and write to host
        const dockerCmd = `docker exec ${backupConfig.containerName} sh -c "${pgDumpCommand}" > "${outputPath}"`;
        await execAsync(dockerCmd, { timeout: 600000 }); // 10 min timeout
        // Verify file was created
        if (!fs.existsSync(outputPath)) {
            throw new Error('Backup file was not created');
        }
        const stats = fs.statSync(outputPath);
        if (stats.size < 100) {
            // File too small - likely empty or error
            const content = fs.readFileSync(outputPath, 'utf-8');
            fs.unlinkSync(outputPath);
            throw new Error(`Backup file is too small (${stats.size} bytes). Content: ${content.substring(0, 200)}`);
        }
        // Calculate checksum
        const checksum = await calculateChecksum(outputPath);
        // Calculate retention date
        const retentionDays = type === BackupType.FULL ? backupConfig.retentionDays.full :
            type === BackupType.INCREMENTAL ? backupConfig.retentionDays.incremental :
                backupConfig.retentionDays.transactionLog;
        const retentionUntil = new Date();
        retentionUntil.setDate(retentionUntil.getDate() + retentionDays);
        const duration = Date.now() - startTime;
        const backupRecord = {
            backupId,
            backupType: type,
            backupDateTime: new Date(),
            backupSize: stats.size,
            backupDuration: duration,
            backupLocation: outputPath,
            checksum,
            checksumAlgorithm: 'SHA-256',
            verificationStatus: BackupStatus.VERIFIED,
            retentionUntil,
            databaseName: dbConfig.database,
            databaseHost: dbConfig.host,
            userId,
            username
        };
        // Save metadata
        const metadataPath = path.join(backupConfig.backupDir, 'metadata', `${backupId}.json`);
        fs.writeFileSync(metadataPath, JSON.stringify(backupRecord, null, 2));
        // Log to database for audit trail
        try {
            await database_1.pool.query(`
        INSERT INTO audit_log_event (audit_log_event_type_id, audit_date, audit_table, entity_id, entity_name, user_id, new_value, reason_for_change)
        VALUES (1, NOW(), 'system_backup', 0, $1, $2, $3, $4)
      `, [backupId, userId, JSON.stringify({ type, status: 'completed', size: stats.size }), `Backup completed - checksum: ${checksum.substring(0, 16)}`]);
        }
        catch (e) {
            logger_1.logger.warn('Could not log backup to audit trail');
        }
        logger_1.logger.info('Backup completed', { backupId, size: stats.size, duration, checksum: checksum.substring(0, 16) });
        return {
            success: true,
            data: backupRecord,
            message: `Backup ${backupId} completed successfully (${(stats.size / 1024).toFixed(2)} KB)`
        };
    }
    catch (error) {
        const duration = Date.now() - startTime;
        logger_1.logger.error('Backup failed', { backupId, error: error.message, duration });
        return {
            success: false,
            data: {
                backupId,
                backupType: type,
                backupDateTime: new Date(),
                backupSize: 0,
                backupDuration: duration,
                backupLocation: '',
                checksum: '',
                checksumAlgorithm: 'SHA-256',
                verificationStatus: BackupStatus.FAILED,
                retentionUntil: new Date(),
                databaseName: dbConfig.database,
                databaseHost: dbConfig.host,
                userId,
                username,
                error: error.message
            },
            message: `Backup failed: ${error.message}`
        };
    }
};
exports.performBackup = performBackup;
const listBackups = async (type, limit = 50) => {
    const backupConfig = (0, exports.getBackupConfig)();
    const metadataDir = path.join(backupConfig.backupDir, 'metadata');
    const records = [];
    if (fs.existsSync(metadataDir)) {
        const files = fs.readdirSync(metadataDir).filter(f => f.endsWith('.json'));
        for (const file of files) {
            try {
                const record = JSON.parse(fs.readFileSync(path.join(metadataDir, file), 'utf-8'));
                if (!type || record.backupType === type) {
                    if (fs.existsSync(record.backupLocation)) {
                        records.push(record);
                    }
                }
            }
            catch { }
        }
    }
    records.sort((a, b) => new Date(b.backupDateTime).getTime() - new Date(a.backupDateTime).getTime());
    return { success: true, data: records.slice(0, limit), message: `Found ${records.length} backups` };
};
exports.listBackups = listBackups;
const getBackup = async (backupId) => {
    const backupConfig = (0, exports.getBackupConfig)();
    const metadataPath = path.join(backupConfig.backupDir, 'metadata', `${backupId}.json`);
    if (fs.existsSync(metadataPath)) {
        return { success: true, data: JSON.parse(fs.readFileSync(metadataPath, 'utf-8')) };
    }
    return { success: false, message: `Backup ${backupId} not found` };
};
exports.getBackup = getBackup;
const verifyBackup = async (backupId, userId, username) => {
    const result = await (0, exports.getBackup)(backupId);
    if (!result.success || !result.data) {
        return { success: false, message: `Backup ${backupId} not found` };
    }
    if (!fs.existsSync(result.data.backupLocation)) {
        return { success: false, message: `Backup file not found` };
    }
    const currentChecksum = await calculateChecksum(result.data.backupLocation);
    const verified = currentChecksum === result.data.checksum;
    return {
        success: true,
        data: { verified, checksum: currentChecksum },
        message: verified ? 'Backup integrity verified' : 'Checksum mismatch - backup may be corrupted'
    };
};
exports.verifyBackup = verifyBackup;
const cleanupOldBackups = async (userId = 0, username = 'system') => {
    const backupConfig = (0, exports.getBackupConfig)();
    const metadataDir = path.join(backupConfig.backupDir, 'metadata');
    let deleted = 0, freed = 0;
    if (!fs.existsSync(metadataDir)) {
        return { success: true, data: { deleted: 0, freed: 0 }, message: 'No backups to clean' };
    }
    const now = new Date();
    const files = fs.readdirSync(metadataDir).filter(f => f.endsWith('.json'));
    for (const file of files) {
        try {
            const metaPath = path.join(metadataDir, file);
            const record = JSON.parse(fs.readFileSync(metaPath, 'utf-8'));
            if (new Date(record.retentionUntil) < now) {
                if (fs.existsSync(record.backupLocation)) {
                    freed += fs.statSync(record.backupLocation).size;
                    fs.unlinkSync(record.backupLocation);
                }
                fs.unlinkSync(metaPath);
                deleted++;
                logger_1.logger.info('Deleted expired backup', { backupId: record.backupId });
            }
        }
        catch { }
    }
    return { success: true, data: { deleted, freed }, message: `Deleted ${deleted} backups, freed ${(freed / 1024 / 1024).toFixed(2)} MB` };
};
exports.cleanupOldBackups = cleanupOldBackups;
const getBackupStats = async () => {
    const result = await (0, exports.listBackups)();
    const backups = result.data || [];
    const totalSize = backups.reduce((sum, b) => sum + b.backupSize, 0);
    const lastBackup = backups.length > 0 ? backups[0] : null;
    const byType = { full: 0, incremental: 0, transaction_log: 0 };
    let lastFull = null;
    for (const b of backups) {
        byType[b.backupType]++;
        if (b.backupType === BackupType.FULL && !lastFull) {
            lastFull = new Date(b.backupDateTime);
        }
    }
    const warnings = [];
    if (!lastFull)
        warnings.push('No full backups found');
    else if ((Date.now() - lastFull.getTime()) / 86400000 > 7) {
        warnings.push(`Last full backup was ${Math.floor((Date.now() - lastFull.getTime()) / 86400000)} days ago`);
    }
    return {
        success: true,
        data: {
            totalBackups: backups.length,
            totalSize,
            lastBackup,
            backupsByType: byType,
            status: { healthy: warnings.length === 0, lastFullBackup: lastFull, warnings }
        }
    };
};
exports.getBackupStats = getBackupStats;
const restoreBackup = async (backupId, userId, username) => {
    const result = await (0, exports.getBackup)(backupId);
    if (!result.success)
        return result;
    // Verify checksum first
    const verify = await (0, exports.verifyBackup)(backupId, userId, username);
    if (!verify.data?.verified) {
        return { success: false, message: 'Backup integrity check failed' };
    }
    return {
        success: true,
        data: { backupId, location: result.data.backupLocation },
        message: `To restore, run: gunzip -c "${result.data.backupLocation}" | docker exec -i libreclinica-postgres psql -U libreclinica -d libreclinica`
    };
};
exports.restoreBackup = restoreBackup;
exports.default = {
    performBackup: exports.performBackup, listBackups: exports.listBackups, getBackup: exports.getBackup, verifyBackup: exports.verifyBackup, cleanupOldBackups: exports.cleanupOldBackups, getBackupStats: exports.getBackupStats, restoreBackup: exports.restoreBackup, getBackupConfig: exports.getBackupConfig,
    BackupType, BackupStatus
};
//# sourceMappingURL=backup.service.js.map