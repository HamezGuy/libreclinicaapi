/**
 * AI Assistant Controller
 * Placeholder - will integrate full AI service later
 */
import { Request, Response } from 'express';
export declare const chat: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getHistory: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const clearHistory: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    chat: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getHistory: (req: Request, res: Response, next: import("express").NextFunction) => void;
    clearHistory: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=ai.controller.d.ts.map