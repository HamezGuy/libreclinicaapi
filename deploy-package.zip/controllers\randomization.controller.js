"use strict";
/**
 * Randomization Controller
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.unblind = exports.getUnblindingEvents = exports.remove = exports.getSubjectRandomization = exports.canRandomize = exports.getStats = exports.getGroups = exports.create = exports.list = void 0;
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const randomizationService = __importStar(require("../services/database/randomization.service"));
exports.list = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, page, limit } = req.query;
    const result = await randomizationService.getRandomizations({
        studyId: studyId ? parseInt(studyId) : undefined,
        page: parseInt(page) || 1,
        limit: parseInt(limit) || 20
    });
    res.json(result);
});
exports.create = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { studySubjectId, studyGroupId } = req.body;
    const result = await randomizationService.createRandomization({ studySubjectId, studyGroupId }, user.userId);
    res.status(201).json(result);
});
exports.getGroups = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.params;
    const result = await randomizationService.getGroupsByStudy(parseInt(studyId));
    res.json(result);
});
/**
 * Get randomization statistics for a study
 */
exports.getStats = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.query;
    if (!studyId) {
        res.status(400).json({ success: false, message: 'studyId is required' });
        return;
    }
    const result = await randomizationService.getRandomizationStats(parseInt(studyId));
    res.json(result);
});
/**
 * Check if subject can be randomized
 */
exports.canRandomize = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { subjectId } = req.params;
    const result = await randomizationService.canRandomize(parseInt(subjectId));
    res.json(result);
});
/**
 * Get subject's randomization info
 */
exports.getSubjectRandomization = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { subjectId } = req.params;
    const result = await randomizationService.getSubjectRandomization(parseInt(subjectId));
    res.json(result);
});
/**
 * Remove randomization
 */
exports.remove = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { subjectId } = req.params;
    const result = await randomizationService.removeRandomization(parseInt(subjectId), user.userId);
    res.json(result);
});
/**
 * Get unblinding events
 */
exports.getUnblindingEvents = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.query;
    if (!studyId) {
        res.status(400).json({ success: false, message: 'studyId is required' });
        return;
    }
    const result = await randomizationService.getUnblindingEvents(parseInt(studyId));
    res.json(result);
});
/**
 * Unblind a subject
 */
exports.unblind = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { subjectId } = req.params;
    const { reason } = req.body;
    if (!reason) {
        res.status(400).json({ success: false, message: 'Reason is required for unblinding' });
        return;
    }
    const result = await randomizationService.unblindSubject(parseInt(subjectId), user.userId, reason);
    res.json(result);
});
exports.default = {
    list: exports.list,
    create: exports.create,
    getGroups: exports.getGroups,
    getStats: exports.getStats,
    canRandomize: exports.canRandomize,
    getSubjectRandomization: exports.getSubjectRandomization,
    remove: exports.remove,
    getUnblindingEvents: exports.getUnblindingEvents,
    unblind: exports.unblind
};
//# sourceMappingURL=randomization.controller.js.map