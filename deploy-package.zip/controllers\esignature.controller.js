"use strict";
/**
 * Electronic Signature Controller
 *
 * Implements 21 CFR Part 11 compliant electronic signature functionality
 *
 * Key compliance requirements:
 * - §11.10(e) - Use of audit trails
 * - §11.50 - Signature manifestations
 * - §11.100 - General requirements for electronic signatures
 * - §11.200 - Electronic signature components and controls
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getStudyRequirements = exports.certifySignature = exports.getPendingSignatures = exports.getSignatureHistory = exports.getSignatureStatus = exports.applySignature = exports.verifyPassword = void 0;
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const esignatureService = __importStar(require("../services/database/esignature.service"));
const logger_1 = require("../config/logger");
/**
 * Verify user's password for electronic signature
 * 21 CFR Part 11 §11.200(a)(1) - Two distinct identification components
 */
exports.verifyPassword = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { password } = req.body;
    if (!password) {
        res.status(400).json({
            success: false,
            message: 'Password is required for electronic signature verification'
        });
        return;
    }
    const result = await esignatureService.verifyPasswordForSignature(user.userId, user.username, password);
    // Log verification attempt (success or failure) for audit trail
    logger_1.logger.info('E-signature password verification attempt', {
        userId: user.userId,
        username: user.username,
        success: result.success,
        timestamp: new Date().toISOString()
    });
    res.json(result);
});
/**
 * Apply electronic signature to an entity
 * 21 CFR Part 11 §11.50 - Signature manifestations
 */
exports.applySignature = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { entityType, entityId, password, meaning, reasonForSigning } = req.body;
    // Validate required fields
    if (!entityType || !entityId || !password || !meaning) {
        res.status(400).json({
            success: false,
            message: 'entityType, entityId, password, and meaning are required'
        });
        return;
    }
    // Validate entity type
    const validEntityTypes = ['event_crf', 'study_event', 'study_subject', 'discrepancy_note', 'data_lock'];
    if (!validEntityTypes.includes(entityType)) {
        res.status(400).json({
            success: false,
            message: `Invalid entityType. Must be one of: ${validEntityTypes.join(', ')}`
        });
        return;
    }
    // Validate meaning (21 CFR Part 11 §11.50)
    const validMeanings = [
        'authorship', // I am the author of this data
        'approval', // I approve this data
        'responsibility', // I take responsibility for this data
        'review', // I have reviewed this data
        'verification', // I verify this data against source documents
        'acknowledgment' // I acknowledge this information
    ];
    if (!validMeanings.includes(meaning)) {
        res.status(400).json({
            success: false,
            message: `Invalid meaning. Must be one of: ${validMeanings.join(', ')}`
        });
        return;
    }
    const result = await esignatureService.applyElectronicSignature({
        userId: user.userId,
        username: user.username,
        userFullName: `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.username,
        entityType,
        entityId: parseInt(entityId),
        password,
        meaning,
        reasonForSigning: reasonForSigning || `Electronic signature: ${meaning}`
    });
    if (result.success) {
        logger_1.logger.info('Electronic signature applied', {
            userId: user.userId,
            username: user.username,
            entityType,
            entityId,
            meaning,
            signatureId: result.data?.signatureId,
            timestamp: new Date().toISOString()
        });
    }
    res.status(result.success ? 200 : 400).json(result);
});
/**
 * Get signature status for an entity
 */
exports.getSignatureStatus = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { entityType, entityId } = req.params;
    if (!entityType || !entityId) {
        res.status(400).json({
            success: false,
            message: 'entityType and entityId are required'
        });
        return;
    }
    const result = await esignatureService.getSignatureStatus(entityType, parseInt(entityId));
    res.json(result);
});
/**
 * Get signature history for an entity
 */
exports.getSignatureHistory = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { entityType, entityId } = req.params;
    if (!entityType || !entityId) {
        res.status(400).json({
            success: false,
            message: 'entityType and entityId are required'
        });
        return;
    }
    const result = await esignatureService.getSignatureHistory(entityType, parseInt(entityId));
    res.json(result);
});
/**
 * Get pending signatures for current user
 */
exports.getPendingSignatures = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { studyId } = req.query;
    const result = await esignatureService.getPendingSignatures(user.userId, studyId ? parseInt(studyId) : undefined);
    res.json(result);
});
/**
 * User certification that electronic signature is legally binding
 * 21 CFR Part 11 §11.100(c)
 */
exports.certifySignature = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { password, acknowledgment } = req.body;
    // Required acknowledgment text per 21 CFR Part 11 §11.100(c)
    const requiredAcknowledgment = 'I certify that my electronic signature is the legally binding equivalent of my traditional handwritten signature';
    if (!password || !acknowledgment) {
        res.status(400).json({
            success: false,
            message: 'Password and acknowledgment are required'
        });
        return;
    }
    if (acknowledgment !== requiredAcknowledgment) {
        res.status(400).json({
            success: false,
            message: 'Acknowledgment text must match the required certification statement'
        });
        return;
    }
    const result = await esignatureService.certifyUser(user.userId, user.username, password, acknowledgment);
    res.json(result);
});
/**
 * Get e-signature requirements for a study
 * Returns which forms/events require electronic signatures
 */
exports.getStudyRequirements = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.params;
    if (!studyId) {
        res.status(400).json({
            success: false,
            message: 'studyId is required'
        });
        return;
    }
    const result = await esignatureService.getStudySignatureRequirements(parseInt(studyId));
    res.json(result);
});
exports.default = {
    verifyPassword: exports.verifyPassword,
    applySignature: exports.applySignature,
    getSignatureStatus: exports.getSignatureStatus,
    getSignatureHistory: exports.getSignatureHistory,
    getPendingSignatures: exports.getPendingSignatures,
    certifySignature: exports.certifySignature,
    getStudyRequirements: exports.getStudyRequirements
};
//# sourceMappingURL=esignature.controller.js.map