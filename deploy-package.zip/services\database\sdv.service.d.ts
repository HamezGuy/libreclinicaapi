/**
 * SDV (Source Data Verification) Service
 * Queries event_crf.sdv_status from LibreClinica
 *
 * Integrated with Workflow Service for real EDC patterns:
 * - When SDV is completed, related workflow tasks are auto-closed
 */
export declare const getSDVRecords: (filters: {
    studyId?: number;
    subjectId?: number;
    status?: string;
    page?: number;
    limit?: number;
}) => Promise<{
    success: boolean;
    data: any[];
    pagination: {
        page: number;
        limit: number;
        total: number;
    };
}>;
export declare const getSDVById: (eventCrfId: number) => Promise<any>;
/**
 * Get form data for SDV preview
 * Returns all item_data for a given event_crf
 */
export declare const getSDVFormData: (eventCrfId: number) => Promise<{
    success: boolean;
    data: {
        itemDataId: any;
        itemId: any;
        name: any;
        description: any;
        oid: any;
        dataType: any;
        value: any;
        statusId: any;
        section: any;
        group: any;
        ordinal: any;
        required: any;
        dateCreated: any;
        dateUpdated: any;
    }[];
    error?: undefined;
} | {
    success: boolean;
    data: never[];
    error: any;
}>;
export declare const verifySDV: (eventCrfId: number, userId: number) => Promise<{
    success: boolean;
    data: any;
}>;
/**
 * Bulk verify multiple SDV records
 */
export declare const bulkVerifySDV: (eventCrfIds: number[], userId: number) => Promise<{
    success: boolean;
    verified: number;
    failed: number;
    errors: any[];
}>;
/**
 * Get SDV status for a specific subject
 */
export declare const getSubjectSDVStatus: (subjectId: number) => Promise<{
    success: boolean;
    data: {
        subjectId: number;
        totalForms: number;
        verifiedForms: number;
        pendingForms: number;
        completionRate: number;
    };
}>;
/**
 * Get SDV statistics for a study
 */
export declare const getSDVStats: (studyId: number) => Promise<{
    success: boolean;
    data: {
        total: number;
        verified: number;
        pending: number;
        verificationRate: number;
    };
}>;
/**
 * Get SDV by visit/event
 */
export declare const getSDVByVisit: (studyId: number) => Promise<{
    success: boolean;
    data: {
        eventId: any;
        eventName: any;
        totalForms: number;
        verifiedForms: number;
        verificationRate: number;
    }[];
}>;
/**
 * Unverify SDV (undo verification)
 */
export declare const unverifySDV: (eventCrfId: number, userId: number) => Promise<{
    success: boolean;
    data: any;
}>;
//# sourceMappingURL=sdv.service.d.ts.map