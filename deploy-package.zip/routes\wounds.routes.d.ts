/**
 * Wound Scanner Routes
 *
 * API routes for WoundScanner iOS app integration
 *
 * Endpoints:
 * - GET    /health                      - Health check
 * - POST   /sessions                    - Create capture session
 * - GET    /sessions/:id                - Get session details
 * - POST   /sessions/:id/images         - Upload wound image
 * - GET    /sessions/:id/images         - Get session images
 * - POST   /sessions/:id/measurements   - Submit measurements
 * - GET    /sessions/:id/measurements   - Get measurements
 * - PUT    /sessions/:id/sign           - Apply e-signature
 * - POST   /sessions/:id/submit         - Submit to LibreClinica
 * - GET    /patients/:patientId/wounds  - Get patient wound history
 * - POST   /audit/log                   - Submit audit entries
 * - POST   /sync/batch                  - Batch sync offline data
 * - GET    /sync/status                 - Get sync status
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=wounds.routes.d.ts.map