"use strict";
/**
 * Query Controller
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMyAssigned = exports.getOverdue = exports.getThread = exports.countByType = exports.countByStatus = exports.reassign = exports.getFormQueries = exports.getResolutionStatuses = exports.getQueryTypes = exports.stats = exports.getAuditTrail = exports.closeWithSignature = exports.updateStatus = exports.respond = exports.create = exports.get = exports.list = void 0;
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const queryService = __importStar(require("../services/database/query.service"));
exports.list = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, subjectId, status, page, limit } = req.query;
    const result = await queryService.getQueries({
        studyId: studyId ? parseInt(studyId) : undefined,
        subjectId: subjectId ? parseInt(subjectId) : undefined,
        status: status,
        page: parseInt(page) || 1,
        limit: parseInt(limit) || 20
    });
    res.json(result);
});
exports.get = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const result = await queryService.getQueryById(parseInt(id));
    if (!result) {
        res.status(404).json({ success: false, message: 'Query not found' });
        return;
    }
    res.json({ success: true, data: result });
});
exports.create = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const result = await queryService.createQuery(req.body, user.userId);
    // Return proper HTTP status codes
    let statusCode = 201;
    if (!result.success) {
        if (result.message?.includes('not found')) {
            statusCode = 404;
        }
        else if (result.message?.includes('required') || result.message?.includes('invalid')) {
            statusCode = 400;
        }
        else {
            statusCode = 500; // Server error for database issues
        }
    }
    res.status(statusCode).json(result);
});
exports.respond = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { id } = req.params;
    const { response, description, detailedNotes, newStatusId } = req.body;
    // Validate that we have a response/description
    if (!response && !description) {
        res.status(400).json({ success: false, message: 'Response text is required' });
        return;
    }
    const result = await queryService.addQueryResponse(parseInt(id), {
        description: response || description,
        detailedNotes,
        newStatusId
    }, user.userId);
    // Return proper HTTP status codes
    let statusCode = 200;
    if (!result.success) {
        if (result.message?.includes('not found')) {
            statusCode = 404;
        }
        else {
            statusCode = 500; // Server error for database issues
        }
    }
    res.status(statusCode).json(result);
});
exports.updateStatus = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { id } = req.params;
    const { statusId, reason } = req.body;
    // Validate statusId
    if (statusId === undefined || statusId === null) {
        res.status(400).json({ success: false, message: 'statusId is required' });
        return;
    }
    const result = await queryService.updateQueryStatus(parseInt(id), statusId, user.userId, { reason });
    // Return proper HTTP status codes
    let statusCode = 200;
    if (!result.success) {
        if (result.message?.includes('not found')) {
            statusCode = 404;
        }
        else {
            statusCode = 500; // Server error for database issues
        }
    }
    res.status(statusCode).json(result);
});
/**
 * Close query with electronic signature (password verification)
 * 21 CFR Part 11 compliant
 */
exports.closeWithSignature = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { id } = req.params;
    const { password, reason, meaning } = req.body;
    if (!password) {
        res.status(400).json({ success: false, message: 'Password is required for electronic signature' });
        return;
    }
    if (!reason) {
        res.status(400).json({ success: false, message: 'Reason is required for closing a query' });
        return;
    }
    const result = await queryService.closeQueryWithSignature(parseInt(id), user.userId, { password, reason, meaning });
    // Return 401 ONLY for password/authentication failures, not for other errors
    // This prevents the frontend interceptor from logging the user out on server errors
    let statusCode = 200;
    if (!result.success) {
        if (result.message?.includes('Invalid password') || result.message?.includes('signature verification failed')) {
            statusCode = 401; // Authentication failure
        }
        else if (result.message?.includes('not found')) {
            statusCode = 404; // Not found
        }
        else {
            statusCode = 500; // Server error for database issues etc.
        }
    }
    res.status(statusCode).json(result);
});
/**
 * Get query audit trail
 */
exports.getAuditTrail = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const result = await queryService.getQueryAuditTrail(parseInt(id));
    res.json({ success: true, data: result });
});
exports.stats = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.query;
    if (!studyId) {
        res.status(400).json({ success: false, message: 'studyId is required' });
        return;
    }
    const result = await queryService.getQueryStats(parseInt(studyId));
    res.json({ success: true, data: result });
});
/**
 * Get query types
 */
exports.getQueryTypes = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const result = await queryService.getQueryTypes();
    res.json({ success: true, data: result });
});
/**
 * Get resolution statuses
 */
exports.getResolutionStatuses = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const result = await queryService.getResolutionStatuses();
    res.json({ success: true, data: result });
});
/**
 * Get queries for a specific form
 */
exports.getFormQueries = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { eventCrfId } = req.params;
    const result = await queryService.getFormQueries(parseInt(eventCrfId));
    res.json({ success: true, data: result });
});
/**
 * Reassign query
 */
exports.reassign = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { id } = req.params;
    const { assignedUserId } = req.body;
    if (!assignedUserId) {
        res.status(400).json({ success: false, message: 'assignedUserId is required' });
        return;
    }
    const result = await queryService.reassignQuery(parseInt(id), assignedUserId, user.userId);
    // Return proper HTTP status codes
    let statusCode = 200;
    if (!result.success) {
        if (result.message?.includes('not found')) {
            statusCode = 404;
        }
        else {
            statusCode = 500; // Server error for database issues
        }
    }
    res.status(statusCode).json(result);
});
/**
 * Get query count by status
 */
exports.countByStatus = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.query;
    if (!studyId) {
        res.status(400).json({ success: false, message: 'studyId is required' });
        return;
    }
    const result = await queryService.getQueryCountByStatus(parseInt(studyId));
    res.json({ success: true, data: result });
});
/**
 * Get query count by type
 */
exports.countByType = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.query;
    if (!studyId) {
        res.status(400).json({ success: false, message: 'studyId is required' });
        return;
    }
    const result = await queryService.getQueryCountByType(parseInt(studyId));
    res.json({ success: true, data: result });
});
/**
 * Get query thread (conversation)
 */
exports.getThread = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const result = await queryService.getQueryThread(parseInt(id));
    res.json({ success: true, data: result });
});
/**
 * Get overdue queries
 */
exports.getOverdue = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, days } = req.query;
    if (!studyId) {
        res.status(400).json({ success: false, message: 'studyId is required' });
        return;
    }
    const result = await queryService.getOverdueQueries(parseInt(studyId), parseInt(days) || 7);
    res.json({ success: true, data: result });
});
/**
 * Get my assigned queries
 */
exports.getMyAssigned = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { studyId } = req.query;
    const result = await queryService.getMyAssignedQueries(user.userId, studyId ? parseInt(studyId) : undefined);
    res.json({ success: true, data: result });
});
exports.default = {
    list: exports.list,
    get: exports.get,
    create: exports.create,
    respond: exports.respond,
    updateStatus: exports.updateStatus,
    closeWithSignature: exports.closeWithSignature,
    getAuditTrail: exports.getAuditTrail,
    stats: exports.stats,
    getQueryTypes: exports.getQueryTypes,
    getResolutionStatuses: exports.getResolutionStatuses,
    getFormQueries: exports.getFormQueries,
    reassign: exports.reassign,
    countByStatus: exports.countByStatus,
    countByType: exports.countByType,
    getThread: exports.getThread,
    getOverdue: exports.getOverdue,
    getMyAssigned: exports.getMyAssigned
};
//# sourceMappingURL=query.controller.js.map