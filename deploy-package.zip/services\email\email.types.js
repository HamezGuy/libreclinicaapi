"use strict";
/**
 * Email Service Types
 *
 * Types for email notifications and queue management
 */
Object.defineProperty(exports, "__esModule", { value: true });
// Types are exported inline above
//# sourceMappingURL=email.types.js.map