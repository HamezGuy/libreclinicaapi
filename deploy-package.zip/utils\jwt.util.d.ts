/**
 * JWT Utility
 *
 * JSON Web Token generation and verification
 * - Generate access and refresh tokens
 * - Verify and decode tokens
 * - Token refresh mechanism
 * - Session management
 *
 * Compliance: 21 CFR Part 11 §11.10(d) - Access Controls
 */
/**
 * JWT Payload interface
 */
export interface JwtPayload {
    userId: number;
    username: string;
    userName?: string;
    email: string;
    role: string;
    userType?: string;
    studyIds?: number[];
}
/**
 * Token pair interface
 */
export interface TokenPair {
    accessToken: string;
    refreshToken: string;
    expiresIn: number;
}
/**
 * Decoded token interface
 */
export interface DecodedToken extends JwtPayload {
    iat: number;
    exp: number;
    type: 'access' | 'refresh';
}
/**
 * Generate access token
 * Short-lived token for API access (30 minutes default)
 */
export declare const generateAccessToken: (payload: JwtPayload) => string;
/**
 * Generate refresh token
 * Long-lived token for refreshing access tokens (7 days default)
 */
export declare const generateRefreshToken: (payload: JwtPayload) => string;
/**
 * Generate both access and refresh tokens
 */
export declare const generateTokenPair: (payload: JwtPayload) => TokenPair;
/**
 * Verify access token
 * Validates token signature and expiration
 */
export declare const verifyAccessToken: (token: string) => DecodedToken | null;
/**
 * Verify refresh token
 * Validates refresh token for token refresh operations
 */
export declare const verifyRefreshToken: (token: string) => DecodedToken | null;
/**
 * Decode token without verification
 * Useful for extracting payload without validating signature
 */
export declare const decodeToken: (token: string) => DecodedToken | null;
/**
 * Check if token is expired
 * Returns true if token is expired, false otherwise
 */
export declare const isTokenExpired: (token: string) => boolean;
/**
 * Get token expiration time
 * Returns expiration timestamp in seconds
 */
export declare const getTokenExpiration: (token: string) => number | null;
/**
 * Get time until token expires
 * Returns remaining time in seconds
 */
export declare const getTokenTimeRemaining: (token: string) => number | null;
/**
 * Refresh access token using refresh token
 * Returns new token pair if refresh token is valid
 */
export declare const refreshAccessToken: (refreshToken: string, getUserData: (userId: number) => Promise<JwtPayload | null>) => Promise<TokenPair | null>;
/**
 * Extract token from Authorization header
 * Supports "Bearer <token>" format
 */
export declare const extractTokenFromHeader: (authHeader?: string) => string | null;
/**
 * Create session identifier
 * Used for tracking user sessions
 */
export declare const createSessionId: (userId: number, username: string) => string;
/**
 * Validate token payload
 * Ensures all required fields are present
 */
export declare const validateTokenPayload: (payload: any) => payload is JwtPayload;
declare const _default: {
    generateAccessToken: (payload: JwtPayload) => string;
    generateRefreshToken: (payload: JwtPayload) => string;
    generateTokenPair: (payload: JwtPayload) => TokenPair;
    verifyAccessToken: (token: string) => DecodedToken | null;
    verifyRefreshToken: (token: string) => DecodedToken | null;
    decodeToken: (token: string) => DecodedToken | null;
    isTokenExpired: (token: string) => boolean;
    getTokenExpiration: (token: string) => number | null;
    getTokenTimeRemaining: (token: string) => number | null;
    refreshAccessToken: (refreshToken: string, getUserData: (userId: number) => Promise<JwtPayload | null>) => Promise<TokenPair | null>;
    extractTokenFromHeader: (authHeader?: string) => string | null;
    createSessionId: (userId: number, username: string) => string;
    validateTokenPayload: (payload: any) => payload is JwtPayload;
};
export default _default;
//# sourceMappingURL=jwt.util.d.ts.map