/**
 * Password Utility
 *
 * Password hashing, validation, and complexity checks
 * - MD5 hashing for LibreClinica legacy compatibility (SOAP WS-Security)
 * - bcrypt for new password storage (Part 11 compliant)
 * - Dual-authentication support for migration period
 * - Password complexity validation (21 CFR Part 11)
 * - Password expiration checking
 * - Account lockout management
 *
 * Compliance: 21 CFR Part 11 §11.300 - Password Controls
 *
 * MD5 LEGACY DOCUMENTATION:
 * -------------------------
 * LibreClinica's SOAP WS-Security requires MD5 password hashes.
 * This is a known limitation of the LibreClinica platform.
 *
 * Mitigation:
 * 1. All NEW passwords are stored with bcrypt (secure)
 * 2. MD5 hash is ONLY used for SOAP authentication to LibreClinica
 * 3. Passwords are never stored as plaintext
 * 4. Strong password policies compensate for MD5 weakness
 * 5. Account lockout prevents brute-force attacks
 *
 * Migration Path:
 * - When user logs in with MD5 password, upgrade to bcrypt
 * - Store bcrypt hash in extended user table
 * - Use bcrypt for API auth, MD5 only for SOAP proxy
 */
/**
 * Password hash type identifier
 */
export declare enum PasswordHashType {
    MD5 = "md5",// Legacy LibreClinica (32 hex chars)
    BCRYPT = "bcrypt",// Secure bcrypt ($2a$, $2b$, $2y$ prefix)
    UNKNOWN = "unknown"
}
/**
 * Password validation result
 */
export interface PasswordValidationResult {
    isValid: boolean;
    errors: string[];
}
/**
 * Password policy configuration
 */
export interface PasswordPolicy {
    minLength: number;
    requireUppercase: boolean;
    requireLowercase: boolean;
    requireNumber: boolean;
    requireSpecialChar: boolean;
    expirationDays: number;
    preventReuse: number;
}
/**
 * Hash password using MD5 (LibreClinica compatibility)
 * LibreClinica uses MD5 for password storage
 *
 * Note: MD5 is not recommended for new systems, but we need
 * compatibility with existing LibreClinica authentication
 */
export declare const hashPasswordMD5: (password: string) => string;
/**
 * Hash password using bcrypt (for new/extended features)
 * More secure than MD5, use for additional API security
 */
export declare const hashPasswordBcrypt: (password: string) => Promise<string>;
/**
 * Compare password with MD5 hash
 * For LibreClinica authentication
 */
export declare const comparePasswordMD5: (password: string, hash: string) => boolean;
/**
 * Compare password with bcrypt hash
 * For additional API authentication
 */
export declare const comparePasswordBcrypt: (password: string, hash: string) => Promise<boolean>;
/**
 * Detect the hash type from a stored password hash
 */
export declare const detectHashType: (hash: string) => PasswordHashType;
/**
 * Compare password with any hash type (auto-detect)
 * Supports both MD5 (legacy) and bcrypt (secure)
 */
export declare const comparePasswordAny: (password: string, hash: string) => Promise<{
    valid: boolean;
    hashType: PasswordHashType;
    needsUpgrade: boolean;
}>;
/**
 * Upgrade a password from MD5 to bcrypt
 * Call this after successful MD5 authentication
 *
 * @returns Object with both hashes (MD5 for SOAP, bcrypt for API)
 */
export declare const upgradePasswordHash: (password: string) => Promise<{
    md5Hash: string;
    bcryptHash: string;
}>;
/**
 * Hash password for dual storage (both MD5 and bcrypt)
 * - MD5 hash is used ONLY for LibreClinica SOAP authentication
 * - bcrypt hash is used for API authentication
 *
 * @returns Object with both hashes
 */
export declare const hashPasswordDual: (password: string) => Promise<{
    md5Hash: string;
    bcryptHash: string;
}>;
/**
 * Verify password and return both hash types for storage upgrade
 * Use this during login to transparently upgrade MD5 to bcrypt
 */
export declare const verifyAndUpgrade: (password: string, storedHash: string, storedBcryptHash?: string | null) => Promise<{
    valid: boolean;
    upgradedBcryptHash?: string;
    shouldUpdateDatabase: boolean;
}>;
/**
 * Validate password against policy
 * Returns validation result with specific error messages
 * SIMPLIFIED - Only basic length check by default
 */
export declare const validatePassword: (password: string, policy?: PasswordPolicy) => PasswordValidationResult;
/**
 * Check if password is expired
 * Based on password change date and policy expiration days
 */
export declare const isPasswordExpired: (passwordChangedDate: Date, policy?: PasswordPolicy) => boolean;
/**
 * Get days until password expires
 */
export declare const getDaysUntilPasswordExpires: (passwordChangedDate: Date, policy?: PasswordPolicy) => number;
/**
 * Check if password was previously used
 * Prevents password reuse
 */
export declare const isPasswordPreviouslyUsed: (password: string, previousPasswordHashes: string[]) => boolean;
/**
 * Generate random password
 * Useful for temporary passwords or password reset
 */
export declare const generateRandomPassword: (length?: number, includeSpecialChars?: boolean) => string;
/**
 * Check account lockout status
 * Returns true if account should be locked due to failed login attempts
 */
export declare const shouldLockAccount: (failedAttempts: number, maxAttempts?: number) => boolean;
/**
 * Calculate lockout duration
 * Returns lockout duration in minutes based on failed attempts
 */
export declare const calculateLockoutDuration: (failedAttempts: number) => number;
/**
 * Check if account lockout has expired
 */
export declare const isLockoutExpired: (lockoutUntil: Date | null) => boolean;
/**
 * Sanitize password for logging
 * Never log actual passwords
 */
export declare const sanitizePasswordForLog: (password: string) => string;
/**
 * Calculate password strength
 * Returns score from 0 (weak) to 100 (strong)
 */
export declare const calculatePasswordStrength: (password: string) => number;
/**
 * Get password strength label
 */
export declare const getPasswordStrengthLabel: (score: number) => string;
declare const _default: {
    PasswordHashType: typeof PasswordHashType;
    detectHashType: (hash: string) => PasswordHashType;
    hashPasswordMD5: (password: string) => string;
    comparePasswordMD5: (password: string, hash: string) => boolean;
    hashPasswordBcrypt: (password: string) => Promise<string>;
    comparePasswordBcrypt: (password: string, hash: string) => Promise<boolean>;
    comparePasswordAny: (password: string, hash: string) => Promise<{
        valid: boolean;
        hashType: PasswordHashType;
        needsUpgrade: boolean;
    }>;
    hashPasswordDual: (password: string) => Promise<{
        md5Hash: string;
        bcryptHash: string;
    }>;
    upgradePasswordHash: (password: string) => Promise<{
        md5Hash: string;
        bcryptHash: string;
    }>;
    verifyAndUpgrade: (password: string, storedHash: string, storedBcryptHash?: string | null) => Promise<{
        valid: boolean;
        upgradedBcryptHash?: string;
        shouldUpdateDatabase: boolean;
    }>;
    validatePassword: (password: string, policy?: PasswordPolicy) => PasswordValidationResult;
    isPasswordExpired: (passwordChangedDate: Date, policy?: PasswordPolicy) => boolean;
    getDaysUntilPasswordExpires: (passwordChangedDate: Date, policy?: PasswordPolicy) => number;
    isPasswordPreviouslyUsed: (password: string, previousPasswordHashes: string[]) => boolean;
    generateRandomPassword: (length?: number, includeSpecialChars?: boolean) => string;
    shouldLockAccount: (failedAttempts: number, maxAttempts?: number) => boolean;
    calculateLockoutDuration: (failedAttempts: number) => number;
    isLockoutExpired: (lockoutUntil: Date | null) => boolean;
    calculatePasswordStrength: (password: string) => number;
    getPasswordStrengthLabel: (score: number) => string;
};
export default _default;
//# sourceMappingURL=password.util.d.ts.map