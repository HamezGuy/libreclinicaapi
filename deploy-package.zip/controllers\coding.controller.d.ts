/**
 * Medical Coding Controller
 * Placeholder for external coding system integration (MedDRA, WHO Drug)
 */
import { Request, Response } from 'express';
export declare const list: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const code: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    list: (req: Request, res: Response, next: import("express").NextFunction) => void;
    code: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=coding.controller.d.ts.map