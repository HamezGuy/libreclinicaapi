"use strict";
/**
 * Error Handler Middleware
 *
 * Global error handling for the API
 * - Catches and formats all errors
 * - Prevents sensitive data exposure
 * - Provides user-friendly error messages
 * - Logs errors for debugging
 *
 * Compliance: 21 CFR Part 11 §11.10(c) - Protection of Records
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.asyncHandler = exports.notFoundHandler = exports.errorHandler = exports.ServiceUnavailableError = exports.InternalServerError = exports.ValidationError = exports.ConflictError = exports.NotFoundError = exports.ForbiddenError = exports.UnauthorizedError = exports.BadRequestError = exports.ApiError = void 0;
const logger_1 = require("../config/logger");
/**
 * Custom error class with additional properties
 */
class ApiError extends Error {
    constructor(statusCode, message, isOperational = true, details, stack = '') {
        super(message);
        this.statusCode = statusCode;
        this.isOperational = isOperational;
        this.details = details;
        if (stack) {
            this.stack = stack;
        }
        else {
            Error.captureStackTrace(this, this.constructor);
        }
    }
}
exports.ApiError = ApiError;
/**
 * Common API errors
 */
class BadRequestError extends ApiError {
    constructor(message = 'Bad Request', details) {
        super(400, message, true, details);
    }
}
exports.BadRequestError = BadRequestError;
class UnauthorizedError extends ApiError {
    constructor(message = 'Unauthorized') {
        super(401, message, true);
    }
}
exports.UnauthorizedError = UnauthorizedError;
class ForbiddenError extends ApiError {
    constructor(message = 'Forbidden') {
        super(403, message, true);
    }
}
exports.ForbiddenError = ForbiddenError;
class NotFoundError extends ApiError {
    constructor(message = 'Resource not found') {
        super(404, message, true);
    }
}
exports.NotFoundError = NotFoundError;
class ConflictError extends ApiError {
    constructor(message = 'Conflict', details) {
        super(409, message, true, details);
    }
}
exports.ConflictError = ConflictError;
class ValidationError extends ApiError {
    constructor(message = 'Validation Error', details) {
        super(422, message, true, details);
    }
}
exports.ValidationError = ValidationError;
class InternalServerError extends ApiError {
    constructor(message = 'Internal Server Error') {
        super(500, message, false);
    }
}
exports.InternalServerError = InternalServerError;
class ServiceUnavailableError extends ApiError {
    constructor(message = 'Service Unavailable') {
        super(503, message, false);
    }
}
exports.ServiceUnavailableError = ServiceUnavailableError;
/**
 * Convert error to API error format
 */
const convertToApiError = (err) => {
    // Already an API error
    if (err instanceof ApiError) {
        return err;
    }
    // Database errors
    if (err.code) {
        switch (err.code) {
            case '23505': // Unique violation
                return new ConflictError('Duplicate entry found', { field: err.constraint });
            case '23503': // Foreign key violation
                return new BadRequestError('Referenced resource not found', { field: err.constraint });
            case '23502': // Not null violation
                return new BadRequestError('Required field missing', { field: err.column });
            case '22P02': // Invalid text representation
                return new BadRequestError('Invalid data format');
            case 'ECONNREFUSED':
                return new ServiceUnavailableError('Database connection refused');
            default:
                logger_1.logger.error('Unhandled database error', { code: err.code, message: err.message });
                return new InternalServerError('Database error');
        }
    }
    // SOAP/Network errors
    if (err.code === 'ECONNREFUSED') {
        return new ServiceUnavailableError('LibreClinica service unavailable');
    }
    if (err.code === 'ETIMEDOUT') {
        return new ServiceUnavailableError('Request timeout');
    }
    // JWT errors
    if (err.name === 'JsonWebTokenError') {
        return new UnauthorizedError('Invalid token');
    }
    if (err.name === 'TokenExpiredError') {
        return new UnauthorizedError('Token expired');
    }
    // Default to internal server error
    return new InternalServerError(err.message || 'An unexpected error occurred');
};
/**
 * Global error handler middleware
 * Must be the last middleware in the chain
 */
const errorHandler = (err, req, res, next) => {
    const apiError = convertToApiError(err);
    // Log error details
    const errorLog = {
        message: apiError.message,
        statusCode: apiError.statusCode,
        path: req.path,
        method: req.method,
        ip: req.ip,
        userId: req.user?.userId,
        username: req.user?.username,
        stack: apiError.stack,
        details: apiError.details
    };
    if (apiError.statusCode >= 500) {
        logger_1.logger.error('Server error', errorLog);
    }
    else if (apiError.statusCode >= 400) {
        logger_1.logger.warn('Client error', errorLog);
    }
    // Prepare response
    const response = {
        success: false,
        message: apiError.message,
        statusCode: apiError.statusCode
    };
    // Include details for client errors (4xx) in development
    if (apiError.statusCode < 500 && apiError.details) {
        response.details = apiError.details;
    }
    // Include stack trace in development mode only
    if (process.env.NODE_ENV === 'development' && apiError.stack) {
        response.stack = apiError.stack;
    }
    // Send response
    res.status(apiError.statusCode).json(response);
};
exports.errorHandler = errorHandler;
/**
 * 404 handler for undefined routes
 */
const notFoundHandler = (req, res, next) => {
    const error = new NotFoundError(`Route ${req.method} ${req.path} not found`);
    next(error);
};
exports.notFoundHandler = notFoundHandler;
/**
 * Async handler wrapper
 * Catches errors in async route handlers
 */
const asyncHandler = (fn) => {
    return (req, res, next) => {
        Promise.resolve(fn(req, res, next)).catch(next);
    };
};
exports.asyncHandler = asyncHandler;
exports.default = exports.errorHandler;
//# sourceMappingURL=errorHandler.middleware.js.map