/**
 * Double Data Entry (DDE) Routes
 *
 * API endpoints for DDE workflow including:
 * - Status checks
 * - Second entry submission
 * - Comparison retrieval
 * - Discrepancy resolution
 * - Finalization
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=dde.routes.d.ts.map