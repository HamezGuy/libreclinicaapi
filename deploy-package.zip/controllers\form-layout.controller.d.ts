/**
 * Form Layout Controller
 *
 * Handles API requests for form layout management including:
 * - Get layout configuration for a form
 * - Save/update layout with column positions
 * - Update individual field positions
 */
import { Request, Response } from 'express';
/**
 * Get form layout configuration
 * GET /api/form-layout/:crfVersionId
 */
export declare const getFormLayout: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get form layout optimized for rendering
 * GET /api/form-layout/:crfVersionId/render
 */
export declare const getFormLayoutForRendering: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Save form layout configuration
 * POST /api/form-layout
 */
export declare const saveFormLayout: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Update a single field's layout position
 * PUT /api/form-layout/field/:itemFormMetadataId
 */
export declare const updateFieldLayout: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    getFormLayout: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getFormLayoutForRendering: (req: Request, res: Response, next: import("express").NextFunction) => void;
    saveFormLayout: (req: Request, res: Response, next: import("express").NextFunction) => void;
    updateFieldLayout: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=form-layout.controller.d.ts.map