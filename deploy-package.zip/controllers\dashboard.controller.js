"use strict";
/**
 * Dashboard Controller
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTopPerformers = exports.getUserAnalytics = exports.getStudyHealthScore = exports.getActivityFeed = exports.getSubjectStatusDistribution = exports.getDataQualityMetrics = exports.getFormCompletionRates = exports.getSitePerformance = exports.getCompletionTrend = exports.getEnrollmentTrend = exports.getActivity = exports.getQueries = exports.getCompletion = exports.getEnrollment = exports.getStats = exports.getSummary = void 0;
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const dashboardService = __importStar(require("../services/database/dashboard.service"));
/**
 * Get dashboard summary (combined stats for frontend)
 * Returns empty data gracefully if study has no data
 */
exports.getSummary = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.query;
    const sid = parseInt(studyId) || 1;
    try {
        const [enrollment, completion, queries] = await Promise.all([
            dashboardService.getEnrollmentStats(sid).catch(() => ({
                totalSubjects: 0,
                activeSubjects: 0,
                completedSubjects: 0,
                withdrawnSubjects: 0,
                screenedSubjects: 0,
                enrollmentByMonth: [],
                enrollmentRate: 0,
                targetEnrollment: null
            })),
            dashboardService.getCompletionStats(sid).catch(() => ({
                totalCRFs: 0,
                completedCRFs: 0,
                incompleteCRFs: 0,
                completionPercentage: 0,
                completionByForm: [],
                averageCompletionTime: 0
            })),
            dashboardService.getQueryStatistics(sid, 'month').catch(() => ({
                totalQueries: 0,
                openQueries: 0,
                closedQueries: 0,
                queriesByType: [],
                queriesByStatus: [],
                averageResolutionTime: 0,
                queryRate: 0
            }))
        ]);
        res.json({
            success: true,
            data: {
                studyId: sid,
                enrollment,
                completion,
                queries,
                lastUpdated: new Date()
            }
        });
    }
    catch (error) {
        // Return empty summary on error
        res.json({
            success: true,
            data: {
                studyId: sid,
                enrollment: { totalSubjects: 0, activeSubjects: 0, completedSubjects: 0, withdrawnSubjects: 0, screenedSubjects: 0, enrollmentByMonth: [], enrollmentRate: 0, targetEnrollment: null },
                completion: { totalCRFs: 0, completedCRFs: 0, incompleteCRFs: 0, completionPercentage: 0, completionByForm: [], averageCompletionTime: 0 },
                queries: { totalQueries: 0, openQueries: 0, closedQueries: 0, queriesByType: [], queriesByStatus: [], averageResolutionTime: 0, queryRate: 0 },
                lastUpdated: new Date()
            }
        });
    }
});
/**
 * Get dashboard stats (alias for summary, for frontend compatibility)
 */
exports.getStats = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.query;
    const sid = parseInt(studyId) || 1;
    try {
        const healthScore = await dashboardService.getStudyHealthScore(sid).catch(() => ({
            score: 0,
            factors: { enrollment: 0, dataCompletion: 0, queryResolution: 0, protocolCompliance: 0 }
        }));
        const dataQuality = await dashboardService.getDataQualityMetrics(sid).catch(() => ({
            totalQueries: 0,
            openQueries: 0,
            resolvedQueries: 0,
            queryResolutionRate: 100,
            sdvVerified: 0,
            totalCRFs: 0,
            sdvRate: 0,
            auditEvents30Days: 0
        }));
        res.json({
            success: true,
            data: {
                studyId: sid,
                healthScore,
                dataQuality,
                lastUpdated: new Date()
            }
        });
    }
    catch (error) {
        res.json({
            success: true,
            data: {
                studyId: sid,
                healthScore: { score: 0, factors: {} },
                dataQuality: {},
                lastUpdated: new Date()
            }
        });
    }
});
exports.getEnrollment = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, startDate, endDate } = req.query;
    const result = await dashboardService.getEnrollmentStats(parseInt(studyId), startDate ? new Date(startDate) : undefined, endDate ? new Date(endDate) : undefined);
    res.json({ success: true, data: result });
});
exports.getCompletion = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.query;
    const result = await dashboardService.getCompletionStats(parseInt(studyId));
    res.json({ success: true, data: result });
});
exports.getQueries = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, timeframe } = req.query;
    const result = await dashboardService.getQueryStatistics(parseInt(studyId), timeframe || 'month');
    res.json({ success: true, data: result });
});
exports.getActivity = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, days } = req.query;
    const result = await dashboardService.getUserActivityStats(parseInt(studyId), parseInt(days) || 30);
    res.json({ success: true, data: result });
});
/**
 * Get enrollment trend over time
 */
exports.getEnrollmentTrend = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, days } = req.query;
    const result = await dashboardService.getEnrollmentTrend(parseInt(studyId), parseInt(days) || 30);
    res.json({ success: true, data: result });
});
/**
 * Get completion trend over time
 */
exports.getCompletionTrend = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, days } = req.query;
    const result = await dashboardService.getCompletionTrend(parseInt(studyId), parseInt(days) || 30);
    res.json({ success: true, data: result });
});
/**
 * Get site performance metrics
 */
exports.getSitePerformance = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.query;
    const result = await dashboardService.getSitePerformance(parseInt(studyId));
    res.json({ success: true, data: result });
});
/**
 * Get form completion rates
 */
exports.getFormCompletionRates = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.query;
    const result = await dashboardService.getFormCompletionRates(parseInt(studyId));
    res.json({ success: true, data: result });
});
/**
 * Get data quality metrics
 */
exports.getDataQualityMetrics = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.query;
    const result = await dashboardService.getDataQualityMetrics(parseInt(studyId));
    res.json({ success: true, data: result });
});
/**
 * Get subject status distribution
 */
exports.getSubjectStatusDistribution = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.query;
    const result = await dashboardService.getSubjectStatusDistribution(parseInt(studyId));
    res.json({ success: true, data: result });
});
/**
 * Get activity feed
 */
exports.getActivityFeed = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, limit } = req.query;
    const result = await dashboardService.getActivityFeed(parseInt(studyId), parseInt(limit) || 20);
    res.json({ success: true, data: result });
});
/**
 * Get study health score
 */
exports.getStudyHealthScore = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.query;
    const result = await dashboardService.getStudyHealthScore(parseInt(studyId));
    res.json({ success: true, data: result });
});
/**
 * Get detailed user analytics
 * Includes: login patterns, activity metrics, role breakdown, top performers
 */
exports.getUserAnalytics = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, days } = req.query;
    const result = await dashboardService.getUserAnalytics(parseInt(studyId) || 1, parseInt(days) || 30);
    res.json({ success: true, data: result });
});
/**
 * Get top performers (most active users)
 */
exports.getTopPerformers = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, days, limit } = req.query;
    const result = await dashboardService.getTopPerformers(parseInt(studyId) || 1, parseInt(days) || 30, parseInt(limit) || 10);
    res.json({ success: true, data: result });
});
exports.default = {
    getSummary: exports.getSummary,
    getStats: exports.getStats,
    getEnrollment: exports.getEnrollment,
    getCompletion: exports.getCompletion,
    getQueries: exports.getQueries,
    getActivity: exports.getActivity,
    getEnrollmentTrend: exports.getEnrollmentTrend,
    getCompletionTrend: exports.getCompletionTrend,
    getSitePerformance: exports.getSitePerformance,
    getFormCompletionRates: exports.getFormCompletionRates,
    getDataQualityMetrics: exports.getDataQualityMetrics,
    getSubjectStatusDistribution: exports.getSubjectStatusDistribution,
    getActivityFeed: exports.getActivityFeed,
    getStudyHealthScore: exports.getStudyHealthScore,
    getUserAnalytics: exports.getUserAnalytics,
    getTopPerformers: exports.getTopPerformers
};
//# sourceMappingURL=dashboard.controller.js.map