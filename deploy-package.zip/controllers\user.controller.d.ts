/**
 * User Controller
 */
import { Request, Response } from 'express';
export declare const list: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const get: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const create: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const update: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const remove: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get available roles
 */
export declare const getRoles: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Assign user to study with role
 */
export declare const assignToStudy: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get user's role for a specific study
 */
export declare const getUserRole: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    list: (req: Request, res: Response, next: import("express").NextFunction) => void;
    get: (req: Request, res: Response, next: import("express").NextFunction) => void;
    create: (req: Request, res: Response, next: import("express").NextFunction) => void;
    update: (req: Request, res: Response, next: import("express").NextFunction) => void;
    remove: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getRoles: (req: Request, res: Response, next: import("express").NextFunction) => void;
    assignToStudy: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getUserRole: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=user.controller.d.ts.map