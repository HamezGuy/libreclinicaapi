/**
 * SOAP Client
 *
 * Custom SOAP client for LibreClinica Web Services
 * - Uses raw HTTP with WS-Security headers (LibreClinica specific)
 * - Handles authentication with MD5-hashed passwords
 * - Provides retry logic and error handling
 *
 * LibreClinica SOAP Web Services (at /libreclinica-ws/ws):
 * - Study Service: Uses v1:listAllRequest, v1:getMetadataRequest
 * - StudySubject Service: Uses v1:createRequest, v1:listAllByStudyRequest
 * - Data Service: Uses v1:importRequest
 * - Event Service: Uses v1:scheduleRequest
 *
 * IMPORTANT: LibreClinica requires WS-Security UsernameToken with MD5-hashed password!
 */
/**
 * SOAP request options
 */
interface SoapRequestOptions {
    serviceName: 'study' | 'studySubject' | 'data' | 'event';
    methodName: string;
    parameters: any;
    userId?: number;
    username?: string;
}
/**
 * SOAP response wrapper
 */
interface SoapResponse<T = any> {
    success: boolean;
    data?: T;
    error?: string;
    soapFault?: any;
}
/**
 * SOAP Client Class
 * Custom implementation for LibreClinica's WS-Security requirements
 */
export declare class SoapClient {
    private config;
    private httpClient;
    constructor();
    /**
     * Build WS-Security SOAP envelope
     */
    private buildSoapEnvelope;
    /**
     * Convert parameters object to XML elements
     */
    private buildParametersXml;
    /**
     * Escape special XML characters
     */
    private escapeXml;
    /**
     * Parse SOAP response
     */
    private parseSoapResponse;
    /**
     * Execute SOAP request with retry logic
     */
    executeRequest<T>(options: SoapRequestOptions): Promise<SoapResponse<T>>;
    /**
     * Test SOAP connection
     * Uses appropriate method for each service type
     */
    testConnection(serviceName?: string): Promise<boolean>;
    /**
     * Clear any cached state (for reconnection)
     */
    clearClients(): void;
    /**
     * Delay helper for retry logic
     */
    private delay;
    /**
     * Parse SOAP error
     */
    parseSoapError(error: any): string;
    /**
     * Get configuration (for diagnostics)
     */
    getConfig(): {
        baseUrl: string;
        username: string;
        passwordSet: boolean;
    };
}
/**
 * Get SOAP client singleton
 */
export declare const getSoapClient: () => SoapClient;
/**
 * Reset SOAP client singleton (useful for testing/reconnection)
 */
export declare const resetSoapClient: () => void;
export default getSoapClient;
//# sourceMappingURL=soapClient.d.ts.map