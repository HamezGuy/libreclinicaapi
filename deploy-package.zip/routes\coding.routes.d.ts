/**
 * Medical Coding Routes
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=coding.routes.d.ts.map