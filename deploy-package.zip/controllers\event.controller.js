"use strict";
/**
 * Event Controller
 *
 * Handles study event (phase) operations
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.bulkAssignCrfs = exports.reorderCrfs = exports.removeCrf = exports.updateEventCrf = exports.assignCrf = exports.getAvailableCrfs = exports.remove = exports.update = exports.create = exports.scheduleEvent = exports.getPatientEventCRFs = exports.getEventCRFs = exports.getSubjectEvents = exports.getEvent = exports.getStudyEvents = exports.listEvents = void 0;
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const eventService = __importStar(require("../services/hybrid/event.service"));
/**
 * List events - accepts studyId as query param for frontend compatibility
 */
exports.listEvents = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, subjectId } = req.query;
    if (subjectId) {
        const result = await eventService.getSubjectEvents(parseInt(subjectId));
        res.json({ success: true, data: result, total: result.length });
        return;
    }
    if (studyId) {
        const result = await eventService.getStudyEvents(parseInt(studyId));
        res.json({ success: true, data: result, total: result.length });
        return;
    }
    // Return empty array if no filters provided
    res.json({ success: true, data: [], total: 0 });
});
exports.getStudyEvents = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.params;
    const result = await eventService.getStudyEvents(parseInt(studyId));
    res.json({
        success: true,
        data: result,
        total: result.length
    });
});
exports.getEvent = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const result = await eventService.getStudyEventById(parseInt(id));
    if (!result) {
        res.status(404).json({ success: false, message: 'Event not found' });
        return;
    }
    res.json({ success: true, data: result });
});
exports.getSubjectEvents = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { subjectId } = req.params;
    const result = await eventService.getSubjectEvents(parseInt(subjectId));
    res.json({
        success: true,
        data: result,
        total: result.length
    });
});
exports.getEventCRFs = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const result = await eventService.getEventCRFs(parseInt(id));
    res.json({
        success: true,
        data: result,
        total: result.length
    });
});
/**
 * Get patient's event_crfs for a specific study_event instance
 * These are the editable copies of templates for this patient's phase
 */
exports.getPatientEventCRFs = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyEventId } = req.params;
    const result = await eventService.getPatientEventCRFs(parseInt(studyEventId));
    res.json({
        success: true,
        data: result,
        total: result.length
    });
});
exports.scheduleEvent = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const result = await eventService.scheduleSubjectEvent(req.body, user.userId, user.username);
    res.status(result.success ? 201 : 400).json(result);
});
exports.create = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const result = await eventService.createStudyEvent(req.body, user.userId);
    res.status(result.success ? 201 : 400).json(result);
});
exports.update = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { id } = req.params;
    const result = await eventService.updateStudyEvent(parseInt(id), req.body, user.userId);
    res.json(result);
});
exports.remove = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { id } = req.params;
    const result = await eventService.deleteStudyEvent(parseInt(id), user.userId);
    res.json(result);
});
// ============================================
// EVENT CRF ASSIGNMENT ENDPOINTS
// ============================================
/**
 * Get available CRFs that can be assigned to an event
 */
exports.getAvailableCrfs = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, eventId } = req.params;
    const result = await eventService.getAvailableCrfsForEvent(parseInt(studyId), parseInt(eventId));
    res.json({
        success: true,
        data: result,
        total: result.length
    });
});
/**
 * Assign a CRF to a study event
 */
exports.assignCrf = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { eventId } = req.params;
    const result = await eventService.assignCrfToEvent({
        studyEventDefinitionId: parseInt(eventId),
        crfId: req.body.crfId,
        crfVersionId: req.body.crfVersionId,
        required: req.body.required,
        doubleEntry: req.body.doubleEntry,
        hideCrf: req.body.hideCrf,
        ordinal: req.body.ordinal,
        electronicSignature: req.body.electronicSignature
    }, user.userId);
    res.status(result.success ? 201 : 400).json(result);
});
/**
 * Update CRF settings for an event
 */
exports.updateEventCrf = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { crfAssignmentId } = req.params;
    const result = await eventService.updateEventCrf(parseInt(crfAssignmentId), {
        required: req.body.required,
        doubleEntry: req.body.doubleEntry,
        hideCrf: req.body.hideCrf,
        ordinal: req.body.ordinal,
        defaultVersionId: req.body.defaultVersionId,
        electronicSignature: req.body.electronicSignature
    }, user.userId);
    res.json(result);
});
/**
 * Remove CRF from event
 */
exports.removeCrf = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { crfAssignmentId } = req.params;
    const result = await eventService.removeCrfFromEvent(parseInt(crfAssignmentId), user.userId);
    res.json(result);
});
/**
 * Reorder CRFs within an event
 */
exports.reorderCrfs = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { eventId } = req.params;
    const result = await eventService.reorderEventCrfs(parseInt(eventId), req.body.orderedCrfIds, user.userId);
    res.json(result);
});
/**
 * Bulk assign CRFs to event
 */
exports.bulkAssignCrfs = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { eventId } = req.params;
    const result = await eventService.bulkAssignCrfsToEvent(parseInt(eventId), req.body.crfAssignments, user.userId);
    res.status(result.success ? 201 : 400).json(result);
});
exports.default = {
    getStudyEvents: exports.getStudyEvents,
    getEvent: exports.getEvent,
    getSubjectEvents: exports.getSubjectEvents,
    getEventCRFs: exports.getEventCRFs,
    scheduleEvent: exports.scheduleEvent,
    create: exports.create,
    update: exports.update,
    remove: exports.remove,
    // Event CRF assignment
    getAvailableCrfs: exports.getAvailableCrfs,
    assignCrf: exports.assignCrf,
    updateEventCrf: exports.updateEventCrf,
    removeCrf: exports.removeCrf,
    reorderCrfs: exports.reorderCrfs,
    bulkAssignCrfs: exports.bulkAssignCrfs
};
//# sourceMappingURL=event.controller.js.map