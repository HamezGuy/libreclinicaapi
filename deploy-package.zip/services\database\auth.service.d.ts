/**
 * Authentication Service
 *
 * Handles user authentication and authorization
 * - Username/password login (LibreClinica compatibility)
 * - Google OAuth 2.0 login
 * - User role retrieval
 * - Password validation and management
 * - Login attempt tracking
 *
 * Compliance: 21 CFR Part 11 §11.300 - Password Controls
 */
import { JwtPayload } from '../../utils/jwt.util';
import { User, ApiResponse } from '../../types';
import { LibreClinicaRole } from '../../constants/roles';
/**
 * Authenticate user with username and password
 * Uses LibreClinica's MD5 password hashing
 *
 * Demo Mode: If DEMO_MODE=true, allows any credentials to login as admin
 */
export declare const authenticateUser: (username: string, password: string, ipAddress: string) => Promise<ApiResponse<User>>;
/**
 * Authenticate user with Google OAuth 2.0
 */
export declare const authenticateWithGoogle: (idToken: string, ipAddress: string) => Promise<ApiResponse<User>>;
/**
 * Get user roles and permissions for a study
 * Note: LibreClinica does NOT have a separate user_role table
 * role_name is stored directly in study_user_role as a string
 */
export declare const getUserRoles: (userId: number, studyId?: number) => Promise<string[]>;
/**
 * Get user's accessible studies
 */
export declare const getUserStudies: (userId: number) => Promise<number[]>;
/**
 * Build JWT payload from user data
 */
export declare const buildJwtPayload: (user: User) => Promise<JwtPayload>;
/**
 * Get user role details with permissions
 */
export declare const getUserRoleDetails: (userId: number, studyId?: number) => Promise<{
    roles: LibreClinicaRole[];
    highestRole: LibreClinicaRole;
}>;
/**
 * Check if user has specific permission
 */
export declare const userHasPermission: (userId: number, studyId: number, permission: "submitData" | "extractData" | "manageStudy" | "monitor") => Promise<boolean>;
/**
 * Check if user is system admin
 */
export declare const isUserAdmin: (userId: number) => Promise<boolean>;
/**
 * Log user logout to LibreClinica's native audit_user_login table
 */
export declare function logUserLogout(userId: number, username: string, ipAddress: string): Promise<void>;
declare const _default: {
    authenticateUser: (username: string, password: string, ipAddress: string) => Promise<ApiResponse<User>>;
    authenticateWithGoogle: (idToken: string, ipAddress: string) => Promise<ApiResponse<User>>;
    getUserRoles: (userId: number, studyId?: number) => Promise<string[]>;
    getUserStudies: (userId: number) => Promise<number[]>;
    buildJwtPayload: (user: User) => Promise<JwtPayload>;
    getUserRoleDetails: (userId: number, studyId?: number) => Promise<{
        roles: LibreClinicaRole[];
        highestRole: LibreClinicaRole;
    }>;
    userHasPermission: (userId: number, studyId: number, permission: "submitData" | "extractData" | "manageStudy" | "monitor") => Promise<boolean>;
    isUserAdmin: (userId: number) => Promise<boolean>;
    logUserLogout: typeof logUserLogout;
};
export default _default;
//# sourceMappingURL=auth.service.d.ts.map