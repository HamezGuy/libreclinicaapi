"use strict";
/**
 * Wound Scanner Routes
 *
 * API routes for WoundScanner iOS app integration
 *
 * Endpoints:
 * - GET    /health                      - Health check
 * - POST   /sessions                    - Create capture session
 * - GET    /sessions/:id                - Get session details
 * - POST   /sessions/:id/images         - Upload wound image
 * - GET    /sessions/:id/images         - Get session images
 * - POST   /sessions/:id/measurements   - Submit measurements
 * - GET    /sessions/:id/measurements   - Get measurements
 * - PUT    /sessions/:id/sign           - Apply e-signature
 * - POST   /sessions/:id/submit         - Submit to LibreClinica
 * - GET    /patients/:patientId/wounds  - Get patient wound history
 * - POST   /audit/log                   - Submit audit entries
 * - POST   /sync/batch                  - Batch sync offline data
 * - GET    /sync/status                 - Get sync status
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const controller = __importStar(require("../controllers/wound.controller"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const router = express_1.default.Router();
// ============================================================================
// HEALTH CHECK (No auth required)
// ============================================================================
router.get('/health', (req, res) => {
    res.json({
        success: true,
        service: 'wound-scanner',
        status: 'healthy',
        timestamp: new Date().toISOString(),
        version: '1.0.0'
    });
});
// All routes require authentication
router.use(auth_middleware_1.authMiddleware);
// ============================================================================
// SESSION ROUTES
// ============================================================================
// Create new wound capture session
router.post('/sessions', controller.createSession);
// Get session by ID
router.get('/sessions/:id', controller.getSession);
// ============================================================================
// IMAGE ROUTES
// ============================================================================
// Upload wound image (multipart/form-data)
router.post('/sessions/:id/images', controller.uploadMiddleware, controller.uploadImage);
// Get session images
router.get('/sessions/:id/images', controller.getSessionImages);
// ============================================================================
// MEASUREMENT ROUTES
// ============================================================================
// Submit measurements
router.post('/sessions/:id/measurements', controller.submitMeasurements);
// Get session measurements
router.get('/sessions/:id/measurements', controller.getSessionMeasurements);
// ============================================================================
// SIGNATURE ROUTES
// ============================================================================
// Apply electronic signature
router.put('/sessions/:id/sign', controller.signSession);
// ============================================================================
// SUBMISSION ROUTES
// ============================================================================
// Submit to LibreClinica
router.post('/sessions/:id/submit', controller.submitToLibreClinica);
// ============================================================================
// PATIENT ROUTES
// ============================================================================
// Get patient wound history
router.get('/patients/:patientId/wounds', controller.getPatientSessions);
router.get('/patients/:patientId/sessions', controller.getPatientSessions); // Alias
// ============================================================================
// AUDIT ROUTES
// ============================================================================
// Submit audit entries from iOS
router.post('/audit/log', controller.submitAuditEntries);
// ============================================================================
// SYNC ROUTES
// ============================================================================
// Batch sync offline data
router.post('/sync/batch', controller.syncBatch);
// Get sync status
router.get('/sync/status', controller.getSyncStatus);
exports.default = router;
//# sourceMappingURL=wounds.routes.js.map