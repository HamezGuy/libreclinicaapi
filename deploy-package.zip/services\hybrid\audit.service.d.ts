/**
 * Hybrid Audit Service
 *
 * Combines SOAP and Database operations for audit trail management
 * 21 CFR Part 11 §11.10(e) - Audit Trail Compliance
 *
 * Strategy:
 * - SOAP: Used for recording audit events when LibreClinica is available
 *         Ensures native LibreClinica audit logging is maintained
 * - Database: Used for querying audit data and as fallback when SOAP unavailable
 *            Direct access is faster for reads
 *
 * This dual-mode approach ensures:
 * 1. Full audit trail is maintained in LibreClinica's native format
 * 2. Fast query access for dashboard and reporting
 * 3. System continues to work when SOAP is unavailable
 */
import { ApiResponse } from '../../types';
/**
 * Audit query parameters
 */
export interface AuditQueryParams {
    studyId?: number;
    subjectId?: number;
    eventCrfId?: number;
    userId?: number;
    eventType?: string;
    startDate?: string;
    endDate?: string;
    limit?: number;
    offset?: number;
    page?: number;
}
/**
 * Record an audit event
 * Uses SOAP when available for GxP compliance, falls back to database
 */
export declare const recordAuditEvent: (record: {
    auditTable: string;
    entityId: number;
    entityName?: string;
    userId: number;
    username: string;
    eventTypeId: number;
    oldValue?: string;
    newValue?: string;
    reasonForChange?: string;
}) => Promise<ApiResponse<{
    auditId: number;
}>>;
/**
 * Get audit logs with filtering
 * Uses database for fast queries
 */
export declare const getAuditLogs: (params: AuditQueryParams) => Promise<ApiResponse<any>>;
/**
 * Get subject audit trail
 * Tries SOAP first for complete ODM audit data, falls back to database
 */
export declare const getSubjectAuditTrail: (studyId: number, subjectId: number, userId: number, username: string) => Promise<ApiResponse<any>>;
/**
 * Get form audit trail
 * Tries SOAP first, falls back to database
 */
export declare const getFormAuditTrail: (eventCrfId: number, userId: number, username: string) => Promise<ApiResponse<any>>;
/**
 * Record electronic signature
 * Must use SOAP for proper LibreClinica integration (falls back to database)
 */
export declare const recordElectronicSignature: (entityType: "crf" | "subject" | "event", entityId: number, signature: {
    username: string;
    password: string;
    meaning: string;
    reasonForChange?: string;
}, userId: number, authenticatedUsername: string) => Promise<ApiResponse<{
    signatureId: number;
}>>;
/**
 * Get audit statistics
 * Uses database for aggregation queries
 */
export declare const getAuditStats: (days?: number) => Promise<ApiResponse<any>>;
/**
 * Export audit logs
 * Uses database for complete data export
 */
export declare const exportAuditLogs: (params: AuditQueryParams, format?: "csv" | "json") => Promise<ApiResponse<any>>;
/**
 * Get compliance report
 * Uses database for report generation
 */
export declare const getComplianceReport: (studyId: number, startDate: string, endDate: string) => Promise<ApiResponse<any>>;
/**
 * Get SOAP/Database mode status
 */
export declare const getServiceStatus: () => {
    soapEnabled: boolean;
    mode: "soap_primary" | "database_only";
    description: string;
};
declare const _default: {
    recordAuditEvent: (record: {
        auditTable: string;
        entityId: number;
        entityName?: string;
        userId: number;
        username: string;
        eventTypeId: number;
        oldValue?: string;
        newValue?: string;
        reasonForChange?: string;
    }) => Promise<ApiResponse<{
        auditId: number;
    }>>;
    getAuditLogs: (params: AuditQueryParams) => Promise<ApiResponse<any>>;
    getSubjectAuditTrail: (studyId: number, subjectId: number, userId: number, username: string) => Promise<ApiResponse<any>>;
    getFormAuditTrail: (eventCrfId: number, userId: number, username: string) => Promise<ApiResponse<any>>;
    recordElectronicSignature: (entityType: "crf" | "subject" | "event", entityId: number, signature: {
        username: string;
        password: string;
        meaning: string;
        reasonForChange?: string;
    }, userId: number, authenticatedUsername: string) => Promise<ApiResponse<{
        signatureId: number;
    }>>;
    getAuditStats: (days?: number) => Promise<ApiResponse<any>>;
    exportAuditLogs: (params: AuditQueryParams, format?: "csv" | "json") => Promise<ApiResponse<any>>;
    getComplianceReport: (studyId: number, startDate: string, endDate: string) => Promise<ApiResponse<any>>;
    getServiceStatus: () => {
        soapEnabled: boolean;
        mode: "soap_primary" | "database_only";
        description: string;
    };
};
export default _default;
//# sourceMappingURL=audit.service.d.ts.map