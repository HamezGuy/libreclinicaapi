/**
 * Skip Logic Routes
 *
 * API endpoints for skip logic rules, form linking, and conditional field visibility.
 *
 * Features:
 * - CRUD for skip logic rules
 * - CRUD for form links
 * - Skip logic evaluation endpoint
 *
 * 21 CFR Part 11 Compliance:
 * - All modifications require authentication (§11.10(d))
 * - All changes logged to audit trail (§11.10(e))
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=skip-logic.routes.d.ts.map