/**
 * Transfer Routes
 *
 * API endpoints for subject transfer between sites.
 * Includes e-signature requirements for 21 CFR Part 11 compliance.
 *
 * 21 CFR Part 11 Compliance:
 * - §11.10(e): Full audit trail for all transfer operations
 * - §11.50: Electronic signature required for transfer approval
 * - §11.10(k): UTC timestamps for all events
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=transfer.routes.d.ts.map