/**
 * Randomization Service
 * Queries subject_group_map, study_group, study_group_class from LibreClinica
 */
export declare const getRandomizations: (filters: {
    studyId?: number;
    page?: number;
    limit?: number;
}) => Promise<{
    success: boolean;
    data: any[];
    pagination: {
        page: number;
        limit: number;
        total: number;
    };
}>;
export declare const getGroupsByStudy: (studyId: number) => Promise<{
    success: boolean;
    data: any[];
}>;
export declare const createRandomization: (data: {
    studySubjectId: number;
    studyGroupId: number;
}, userId: number) => Promise<{
    success: boolean;
    data: any;
}>;
/**
 * Get randomization statistics for a study
 */
export declare const getRandomizationStats: (studyId: number) => Promise<{
    success: boolean;
    data: {
        totalRandomized: any;
        groups: {
            groupId: any;
            groupName: any;
            className: any;
            subjectCount: number;
            percentage: number;
        }[];
    };
}>;
/**
 * Check if subject can be randomized
 */
export declare const canRandomize: (subjectId: number) => Promise<{
    success: boolean;
    data: {
        canRandomize: boolean;
        alreadyRandomized: boolean;
        isActive: boolean;
        reason: string | null;
    };
}>;
/**
 * Get subject's randomization info
 */
export declare const getSubjectRandomization: (subjectId: number) => Promise<{
    success: boolean;
    data: null;
    message: string;
} | {
    success: boolean;
    data: any;
    message?: undefined;
}>;
/**
 * Remove randomization (for corrections)
 */
export declare const removeRandomization: (subjectId: number, userId: number) => Promise<{
    success: boolean;
    message: string;
}>;
/**
 * Get unblinded subjects (for unblinding functionality)
 */
export declare const getUnblindingEvents: (studyId: number) => Promise<{
    success: boolean;
    data: any[];
}>;
/**
 * Unblind a subject
 */
export declare const unblindSubject: (subjectId: number, userId: number, reason: string) => Promise<{
    success: boolean;
    data: {
        subjectId: number;
        groupName: any;
        className: any;
        unblindedAt: Date;
        reason: string;
    };
}>;
//# sourceMappingURL=randomization.service.d.ts.map