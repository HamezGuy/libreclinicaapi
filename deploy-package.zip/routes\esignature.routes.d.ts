/**
 * Electronic Signature Routes
 *
 * 21 CFR Part 11 Compliant Electronic Signatures
 *
 * §11.100 - General requirements:
 * (a) Each electronic signature shall be unique to one individual and shall not be reused
 * (b) Before establishing, assigning, certifying, or otherwise sanctioning electronic signatures,
 *     verify the identity of the individual
 * (c) Persons using electronic signatures shall, prior to or at the time of use, certify to the
 *     agency that the signatures are the legally binding equivalent of traditional handwritten signatures
 *
 * §11.200 - Electronic signature components and controls:
 * (a)(1) Employ at least two distinct identification components such as identification code and password
 * (a)(2) Be used only by their genuine owners
 * (a)(3) Be administered and executed to ensure only the genuine owners can use them
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=esignature.routes.d.ts.map