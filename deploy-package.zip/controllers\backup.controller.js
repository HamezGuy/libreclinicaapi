"use strict";
/**
 * Backup Controller - 21 CFR Part 11 Compliant
 *
 * REST API endpoints for backup management with full audit trail.
 * Implements SOP-008 Section 7.3 (Record Backup) requirements.
 *
 * All operations require administrative privileges and are fully audited.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getBackupConfig = exports.cleanupBackups = exports.getSchedulerStatus = exports.stopScheduler = exports.startScheduler = exports.restoreBackup = exports.verifyBackup = exports.triggerBackup = exports.getBackup = exports.listBackups = exports.getBackupStatus = void 0;
const logger_1 = require("../config/logger");
const backupService = __importStar(require("../services/backup/backup.service"));
const schedulerService = __importStar(require("../services/backup/backup-scheduler.service"));
const backup_service_1 = require("../services/backup/backup.service");
/**
 * Get backup system status and statistics
 * GET /api/backup/status
 */
const getBackupStatus = async (req, res) => {
    try {
        const [statsResult, schedulerStatus] = await Promise.all([
            backupService.getBackupStats(),
            Promise.resolve(schedulerService.getSchedulerStatus())
        ]);
        res.json({
            success: true,
            data: {
                statistics: statsResult.data,
                scheduler: schedulerStatus,
                config: backupService.getBackupConfig()
            }
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to get backup status', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Failed to get backup status',
            error: error.message
        });
    }
};
exports.getBackupStatus = getBackupStatus;
/**
 * List all backups
 * GET /api/backup/list
 * Query params: type (full|incremental|transaction_log), limit
 */
const listBackups = async (req, res) => {
    try {
        const type = req.query.type;
        const limit = parseInt(req.query.limit) || 50;
        const result = await backupService.listBackups(type, limit);
        res.json({
            success: result.success,
            data: result.data,
            message: result.message
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to list backups', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Failed to list backups',
            error: error.message
        });
    }
};
exports.listBackups = listBackups;
/**
 * Get specific backup details
 * GET /api/backup/:backupId
 */
const getBackup = async (req, res) => {
    try {
        const { backupId } = req.params;
        const result = await backupService.getBackup(backupId);
        if (!result.success) {
            res.status(404).json({
                success: false,
                message: result.message
            });
            return;
        }
        res.json({
            success: true,
            data: result.data
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to get backup', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Failed to get backup',
            error: error.message
        });
    }
};
exports.getBackup = getBackup;
/**
 * Trigger manual backup
 * POST /api/backup/trigger
 * Body: { type: 'full' | 'incremental' | 'transaction_log' }
 */
const triggerBackup = async (req, res) => {
    try {
        const { type } = req.body;
        const userId = req.user?.id || 0;
        const username = req.user?.username || 'api_user';
        if (!type || !Object.values(backup_service_1.BackupType).includes(type)) {
            res.status(400).json({
                success: false,
                message: `Invalid backup type. Must be one of: ${Object.values(backup_service_1.BackupType).join(', ')}`
            });
            return;
        }
        logger_1.logger.info('Manual backup triggered via API', { type, userId, username });
        const result = await schedulerService.triggerImmediateBackup(type, userId, username);
        res.json({
            success: result.success,
            data: {
                backupId: result.backupId
            },
            message: result.message
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to trigger backup', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Failed to trigger backup',
            error: error.message
        });
    }
};
exports.triggerBackup = triggerBackup;
/**
 * Verify backup integrity
 * POST /api/backup/:backupId/verify
 */
const verifyBackup = async (req, res) => {
    try {
        const { backupId } = req.params;
        const userId = req.user?.id || 0;
        const username = req.user?.username || 'api_user';
        const result = await backupService.verifyBackup(backupId, userId, username);
        res.json({
            success: result.success,
            data: result.data,
            message: result.message
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to verify backup', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Failed to verify backup',
            error: error.message
        });
    }
};
exports.verifyBackup = verifyBackup;
/**
 * Initiate backup restore (requires confirmation)
 * POST /api/backup/:backupId/restore
 * Body: { targetDatabase?: string, confirmRestore: boolean }
 */
const restoreBackup = async (req, res) => {
    try {
        const { backupId } = req.params;
        const { targetDatabase, confirmRestore } = req.body;
        const userId = req.user?.id || 0;
        const username = req.user?.username || 'api_user';
        if (!confirmRestore) {
            res.status(400).json({
                success: false,
                message: 'Restore operation requires explicit confirmation. Set confirmRestore: true to proceed.',
                warning: 'This operation will restore data from the specified backup. Ensure you understand the implications.'
            });
            return;
        }
        logger_1.logger.warn('Backup restore initiated', { backupId, targetDatabase, userId, username });
        const result = await backupService.restoreBackup(backupId, userId, username);
        res.json({
            success: result.success,
            data: result.data,
            message: result.message
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to restore backup', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Failed to restore backup',
            error: error.message
        });
    }
};
exports.restoreBackup = restoreBackup;
/**
 * Start backup scheduler
 * POST /api/backup/scheduler/start
 */
const startScheduler = async (req, res) => {
    try {
        const config = backupService.getBackupConfig();
        await schedulerService.startScheduler(config.schedules.full, config.schedules.incremental, config.schedules.transactionLog);
        res.json({
            success: true,
            data: schedulerService.getSchedulerStatus(),
            message: 'Backup scheduler started'
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to start scheduler', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Failed to start scheduler',
            error: error.message
        });
    }
};
exports.startScheduler = startScheduler;
/**
 * Stop backup scheduler
 * POST /api/backup/scheduler/stop
 */
const stopScheduler = async (req, res) => {
    try {
        await schedulerService.stopScheduler();
        res.json({
            success: true,
            data: schedulerService.getSchedulerStatus(),
            message: 'Backup scheduler stopped'
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to stop scheduler', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Failed to stop scheduler',
            error: error.message
        });
    }
};
exports.stopScheduler = stopScheduler;
/**
 * Get scheduler status
 * GET /api/backup/scheduler/status
 */
const getSchedulerStatus = async (req, res) => {
    try {
        const status = schedulerService.getSchedulerStatus();
        res.json({
            success: true,
            data: status
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to get scheduler status', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Failed to get scheduler status',
            error: error.message
        });
    }
};
exports.getSchedulerStatus = getSchedulerStatus;
/**
 * Run cleanup of expired backups
 * POST /api/backup/cleanup
 */
const cleanupBackups = async (req, res) => {
    try {
        const userId = req.user?.id || 0;
        const username = req.user?.username || 'api_user';
        const result = await backupService.cleanupOldBackups(userId, username);
        res.json({
            success: result.success,
            data: result.data,
            message: result.message
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to cleanup backups', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Failed to cleanup backups',
            error: error.message
        });
    }
};
exports.cleanupBackups = cleanupBackups;
/**
 * Get backup configuration
 * GET /api/backup/config
 */
const getBackupConfig = async (req, res) => {
    try {
        const config = backupService.getBackupConfig();
        // Return config safely
        const safeConfig = {
            ...config
        };
        res.json({
            success: true,
            data: safeConfig
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to get backup config', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Failed to get backup config',
            error: error.message
        });
    }
};
exports.getBackupConfig = getBackupConfig;
exports.default = {
    getBackupStatus: exports.getBackupStatus,
    listBackups: exports.listBackups,
    getBackup: exports.getBackup,
    triggerBackup: exports.triggerBackup,
    verifyBackup: exports.verifyBackup,
    restoreBackup: exports.restoreBackup,
    startScheduler: exports.startScheduler,
    stopScheduler: exports.stopScheduler,
    getSchedulerStatus: exports.getSchedulerStatus,
    cleanupBackups: exports.cleanupBackups,
    getBackupConfig: exports.getBackupConfig
};
//# sourceMappingURL=backup.controller.js.map