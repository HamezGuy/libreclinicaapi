/**
 * Print Routes
 *
 * API endpoints for PDF generation and printing:
 * - Form PDF generation (completed forms)
 * - Blank form PDF generation (templates)
 * - Casebook generation (all forms for a subject)
 * - Audit trail PDF generation
 *
 * 21 CFR Part 11: All print events are logged to audit trail
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=print.routes.d.ts.map