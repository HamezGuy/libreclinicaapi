"use strict";
/**
 * Data Export Types - Using LibreClinica Models
 * Matches DatasetBean, ExportFormatBean, and ODM export structures
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EXPORT_FORMAT_MIME = void 0;
exports.EXPORT_FORMAT_MIME = {
    csv: 'text/csv',
    excel: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    odm: 'application/xml',
    json: 'application/json',
    sas: 'application/x-sas'
};
//# sourceMappingURL=export.types.js.map