/**
 * Subject SOAP Service
 *
 * Handles subject (patient) enrollment via LibreClinica SOAP API
 * - Create new subjects (study participants)
 * - List subjects via SOAP
 * - Check subject existence
 *
 * SOAP Endpoint: http://localhost:8090/libreclinica-ws/ws/studySubject/v1
 * Service: studySubject (v1)
 *
 * CRITICAL: LibreClinica requires:
 * - WS-Security UsernameToken with MD5-hashed password
 * - Specific XML element structure for studySubject service
 * - Full service path including /studySubject/v1
 */
import { SubjectCreateRequest, ApiResponse } from '../../types';
/**
 * SOAP Subject response
 */
interface SoapSubjectResponse {
    result: string;
    label?: string;
    error?: string;
    warnings?: string[];
}
/**
 * Subject enrollment via SOAP
 * Uses the studySubject/create operation
 */
export declare const createSubject: (request: SubjectCreateRequest, userId: number, username: string) => Promise<ApiResponse<SoapSubjectResponse>>;
/**
 * Check if subject exists via SOAP
 */
export declare const isSubjectExists: (studyOid: string, subjectLabel: string, userId: number, username: string) => Promise<boolean>;
/**
 * List subjects in study via SOAP
 */
export declare const listSubjects: (studyIdentifier: string, userId: number, username: string) => Promise<ApiResponse<any[]>>;
/**
 * Parse subject list from ODM XML response
 */
export declare function parseSubjectListOdm(odmXml: string): any[];
declare const _default: {
    createSubject: (request: SubjectCreateRequest, userId: number, username: string) => Promise<ApiResponse<SoapSubjectResponse>>;
    isSubjectExists: (studyOid: string, subjectLabel: string, userId: number, username: string) => Promise<boolean>;
    listSubjects: (studyIdentifier: string, userId: number, username: string) => Promise<ApiResponse<any[]>>;
    parseSubjectListOdm: typeof parseSubjectListOdm;
};
export default _default;
//# sourceMappingURL=subjectSoap.service.d.ts.map