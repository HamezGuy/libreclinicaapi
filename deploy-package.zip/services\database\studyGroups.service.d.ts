/**
 * Study Groups Service
 *
 * Manages study group classes and groups for randomization/treatment arm assignment.
 *
 * Database Tables:
 * - study_group_class: Categories of groups (Arm, Family/Pedigree, Demographic, Other)
 * - study_group: Individual groups within a class
 * - subject_group_map: Assignment of subjects to groups
 * - group_class_types: Reference table for group class types
 */
export type GroupClassType = 'Arm' | 'Family/Pedigree' | 'Demographic' | 'Other';
export interface StudyGroupClass {
    studyGroupClassId: number;
    name: string;
    studyId: number;
    groupClassTypeId: number;
    groupClassTypeName: string;
    subjectAssignment: 'Required' | 'Optional';
    statusId: number;
    statusName: string;
    groups: StudyGroup[];
    dateCreated: Date;
    ownerId: number;
}
export interface StudyGroup {
    studyGroupId: number;
    name: string;
    description?: string;
    studyGroupClassId: number;
}
export interface SubjectGroupAssignment {
    subjectGroupMapId: number;
    studySubjectId: number;
    studyGroupClassId: number;
    studyGroupId: number;
    notes?: string;
    dateCreated: Date;
}
/**
 * Get all group class types (reference data)
 */
export declare const getGroupClassTypes: () => Promise<{
    id: number;
    name: string;
}[]>;
/**
 * Get all active study group classes for a study with their groups
 */
export declare const getStudyGroupClasses: (studyId: number) => Promise<StudyGroupClass[]>;
/**
 * Create a new study group class
 */
export declare const createStudyGroupClass: (data: {
    studyId: number;
    name: string;
    groupClassTypeId: number;
    subjectAssignment?: "Required" | "Optional";
}, userId: number) => Promise<{
    success: boolean;
    studyGroupClassId?: number;
    message?: string;
}>;
/**
 * Create a new group within a class
 */
export declare const createStudyGroup: (data: {
    studyGroupClassId: number;
    name: string;
    description?: string;
}) => Promise<{
    success: boolean;
    studyGroupId?: number;
    message?: string;
}>;
/**
 * Assign a subject to groups
 */
export declare const assignSubjectToGroups: (studySubjectId: number, assignments: {
    studyGroupClassId: number;
    studyGroupId: number;
    notes?: string;
}[], userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Get subject's group assignments
 */
export declare const getSubjectGroupAssignments: (studySubjectId: number) => Promise<SubjectGroupAssignment[]>;
/**
 * Get subjects in a specific group
 */
export declare const getSubjectsInGroup: (studyGroupId: number) => Promise<{
    studySubjectId: number;
    label: string;
    notes?: string;
}[]>;
//# sourceMappingURL=studyGroups.service.d.ts.map