/**
 * Study Routes
 *
 * API endpoints for study management including:
 * - CRUD operations
 * - Metadata, forms, sites, events
 * - Statistics and users
 *
 * 21 CFR Part 11 Compliance:
 * - All study modifications require electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=study.routes.d.ts.map