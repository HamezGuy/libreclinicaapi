/**
 * PDF Generation Service
 *
 * 21 CFR Part 11 Compliant PDF Generation for:
 * - Form printing (blank and completed)
 * - Casebook generation (all forms for a subject)
 * - Audit trail export
 *
 * Uses HTML templates rendered to PDF for flexibility
 */
import { PDFGenerationOptions, PrintableForm, PrintableCasebook, PrintableAuditTrail, PDFGenerationResult } from './pdf.types';
/**
 * Get form data for printing (completed form)
 */
export declare function getFormDataForPrint(eventCrfId: number): Promise<PrintableForm | null>;
/**
 * Get blank form data for printing (template only)
 */
export declare function getBlankFormDataForPrint(crfVersionId: number): Promise<PrintableForm | null>;
/**
 * Get casebook data for printing (all forms for a subject)
 */
export declare function getCasebookDataForPrint(studySubjectId: number, username: string): Promise<PrintableCasebook | null>;
/**
 * Get audit trail for printing
 */
export declare function getAuditTrailForPrint(entityType: string, entityId: number, username: string): Promise<PrintableAuditTrail | null>;
/**
 * Generate HTML for form PDF
 */
export declare function generateFormHtml(form: PrintableForm, options: PDFGenerationOptions): string;
/**
 * Generate HTML for casebook PDF
 */
export declare function generateCasebookHtml(casebook: PrintableCasebook, options: PDFGenerationOptions): string;
/**
 * Generate HTML for audit trail PDF
 */
export declare function generateAuditTrailHtml(auditTrail: PrintableAuditTrail, options: PDFGenerationOptions): string;
/**
 * Generate PDF from HTML using built-in approach (for environments without puppeteer)
 * Returns HTML that can be rendered by the browser for printing
 */
export declare function generateFormPDF(eventCrfId: number, options: Partial<PDFGenerationOptions> | undefined, userId: number, username: string): Promise<PDFGenerationResult>;
/**
 * Generate blank form PDF
 */
export declare function generateBlankFormPDF(crfVersionId: number, options: Partial<PDFGenerationOptions> | undefined, userId: number, username: string): Promise<PDFGenerationResult>;
/**
 * Generate casebook PDF
 */
export declare function generateCasebookPDF(studySubjectId: number, options: Partial<PDFGenerationOptions> | undefined, userId: number, username: string): Promise<PDFGenerationResult>;
/**
 * Generate audit trail PDF
 */
export declare function generateAuditTrailPDF(entityType: string, entityId: number, options: Partial<PDFGenerationOptions> | undefined, userId: number, username: string): Promise<PDFGenerationResult>;
declare const _default: {
    getFormDataForPrint: typeof getFormDataForPrint;
    getBlankFormDataForPrint: typeof getBlankFormDataForPrint;
    getCasebookDataForPrint: typeof getCasebookDataForPrint;
    getAuditTrailForPrint: typeof getAuditTrailForPrint;
    generateFormPDF: typeof generateFormPDF;
    generateBlankFormPDF: typeof generateBlankFormPDF;
    generateCasebookPDF: typeof generateCasebookPDF;
    generateAuditTrailPDF: typeof generateAuditTrailPDF;
    generateFormHtml: typeof generateFormHtml;
    generateCasebookHtml: typeof generateCasebookHtml;
    generateAuditTrailHtml: typeof generateAuditTrailHtml;
};
export default _default;
//# sourceMappingURL=pdf.service.d.ts.map