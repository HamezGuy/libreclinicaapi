"use strict";
/**
 * Data Export Routes
 * Uses EXISTING LibreClinica SOAP APIs for Part 11 compliance
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const exportService = __importStar(require("../services/export/export.service"));
const logger_1 = require("../config/logger");
const router = (0, express_1.Router)();
/**
 * GET /api/export/metadata/:studyOID
 * Get study metadata for export configuration
 */
router.get('/metadata/:studyOID', (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyOID } = req.params;
    const username = req.user?.username || 'api';
    logger_1.logger.info('Export metadata request', { studyOID, username });
    const metadata = await exportService.getStudyMetadataForExport(studyOID, username);
    res.json({
        success: true,
        data: metadata
    });
}));
/**
 * GET /api/export/subjects/:studyOID
 * Get subject list for export preview
 */
router.get('/subjects/:studyOID', (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyOID } = req.params;
    const username = req.user?.username || 'api';
    const subjects = await exportService.getSubjectsForExport(studyOID, username);
    res.json({
        success: true,
        data: {
            subjects,
            count: subjects.length
        }
    });
}));
/**
 * POST /api/export/execute
 * Execute data export
 */
router.post('/execute', (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { datasetConfig, format } = req.body;
    const username = req.user?.username || 'api';
    if (!datasetConfig?.studyOID) {
        return res.status(400).json({
            success: false,
            message: 'studyOID is required in datasetConfig'
        });
    }
    logger_1.logger.info('Export execute request', {
        studyOID: datasetConfig.studyOID,
        format,
        username
    });
    const result = await exportService.executeExport(datasetConfig, format || 'csv', username);
    if (!result.success) {
        return res.status(500).json({
            success: false,
            message: result.error || 'Export failed'
        });
    }
    // Set headers for file download
    res.setHeader('Content-Type', result.data.mimeType);
    res.setHeader('Content-Disposition', `attachment; filename="${result.data.filename}"`);
    res.send(result.data.content);
}));
/**
 * POST /api/export/preview
 * Preview export data (first N records)
 */
router.post('/preview', (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { datasetConfig, format, limit = 10 } = req.body;
    const username = req.user?.username || 'api';
    if (!datasetConfig?.studyOID) {
        return res.status(400).json({
            success: false,
            message: 'studyOID is required in datasetConfig'
        });
    }
    const result = await exportService.executeExport(datasetConfig, format || 'csv', username);
    if (!result.success) {
        return res.status(500).json(result);
    }
    // Return preview (limited content)
    const content = result.data.content.toString();
    const lines = content.split('\n');
    const previewLines = lines.slice(0, limit + 1); // +1 for header
    res.json({
        success: true,
        data: {
            preview: previewLines.join('\n'),
            totalRecords: result.data.recordCount,
            format,
            filename: result.data.filename
        }
    });
}));
/**
 * POST /api/export/dataset
 * Create a saved dataset configuration (uses LibreClinica's dataset table)
 */
router.post('/dataset', (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { datasetConfig } = req.body;
    const userId = req.user?.userId || 1;
    if (!datasetConfig?.studyOID) {
        return res.status(400).json({
            success: false,
            message: 'studyOID is required in datasetConfig'
        });
    }
    logger_1.logger.info('Creating dataset', { studyOID: datasetConfig.studyOID });
    const result = await exportService.createDataset(datasetConfig, userId);
    if (!result.success) {
        return res.status(500).json({
            success: false,
            message: result.error || 'Failed to create dataset'
        });
    }
    res.json({
        success: true,
        data: {
            datasetId: result.datasetId
        }
    });
}));
/**
 * GET /api/export/datasets/:studyOID
 * Get all saved datasets for a study
 */
router.get('/datasets/:studyOID', (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyOID } = req.params;
    logger_1.logger.info('Getting datasets', { studyOID });
    const datasets = await exportService.getDatasets(studyOID);
    res.json({
        success: true,
        data: datasets
    });
}));
/**
 * GET /api/export/archived/:datasetId
 * Get archived exports for a dataset
 */
router.get('/archived/:datasetId', (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const datasetId = parseInt(req.params.datasetId);
    if (isNaN(datasetId)) {
        return res.status(400).json({
            success: false,
            message: 'Invalid datasetId'
        });
    }
    const archives = await exportService.getArchivedExports(datasetId);
    res.json({
        success: true,
        data: archives
    });
}));
/**
 * POST /api/export/cdisc
 * Full CDISC ODM export with all clinical data
 */
router.post('/cdisc', (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { datasetConfig } = req.body;
    const username = req.user?.username || 'api';
    const userId = req.user?.userId || 1;
    if (!datasetConfig?.studyOID) {
        return res.status(400).json({
            success: false,
            message: 'studyOID is required'
        });
    }
    logger_1.logger.info('Full CDISC ODM export request', { studyOID: datasetConfig.studyOID });
    try {
        // Create dataset record for audit trail
        const datasetResult = await exportService.createDataset({
            ...datasetConfig,
            name: datasetConfig.name || `CDISC_Export_${Date.now()}`,
            description: 'CDISC ODM Export'
        }, userId);
        // Build full ODM
        const odmXml = await exportService.buildFullOdmExport(datasetConfig, username);
        const filename = `${datasetConfig.studyOID}_CDISC_${Date.now()}.xml`;
        // Archive the export if dataset was created
        if (datasetResult.success && datasetResult.datasetId) {
            await exportService.archiveExportedFile(datasetResult.datasetId, filename, '', 'odm', userId);
        }
        // Return the ODM XML
        res.setHeader('Content-Type', 'application/xml');
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.send(odmXml);
    }
    catch (error) {
        logger_1.logger.error('CDISC export failed', { error: error.message });
        res.status(500).json({
            success: false,
            message: error.message || 'CDISC export failed'
        });
    }
}));
exports.default = router;
//# sourceMappingURL=export.routes.js.map