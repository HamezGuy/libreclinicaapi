"use strict";
/**
 * Dashboard Routes
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const controller = __importStar(require("../controllers/dashboard.controller"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const validation_middleware_1 = require("../middleware/validation.middleware");
const router = express_1.default.Router();
router.use(auth_middleware_1.authMiddleware);
// Summary endpoint - returns combined stats (alias for frontend compatibility)
router.get('/summary', controller.getSummary);
router.get('/stats', controller.getStats);
router.get('/enrollment', (0, validation_middleware_1.validate)({ query: validation_middleware_1.dashboardSchemas.enrollment }), controller.getEnrollment);
router.get('/completion', (0, validation_middleware_1.validate)({ query: validation_middleware_1.dashboardSchemas.completion }), controller.getCompletion);
router.get('/queries', (0, validation_middleware_1.validate)({ query: validation_middleware_1.dashboardSchemas.queries }), controller.getQueries);
router.get('/activity', (0, validation_middleware_1.validate)({ query: validation_middleware_1.dashboardSchemas.activity }), controller.getActivity);
// New enhanced dashboard endpoints
router.get('/enrollment-trend', controller.getEnrollmentTrend);
router.get('/completion-trend', controller.getCompletionTrend);
router.get('/site-performance', controller.getSitePerformance);
router.get('/form-completion-rates', controller.getFormCompletionRates);
router.get('/data-quality', controller.getDataQualityMetrics);
router.get('/subject-status-distribution', controller.getSubjectStatusDistribution);
router.get('/activity-feed', controller.getActivityFeed);
router.get('/health-score', controller.getStudyHealthScore);
// User Analytics endpoints
router.get('/user-analytics', controller.getUserAnalytics);
router.get('/top-performers', controller.getTopPerformers);
exports.default = router;
//# sourceMappingURL=dashboard.routes.js.map