"use strict";
/**
 * Transfer Routes
 *
 * API endpoints for subject transfer between sites.
 * Includes e-signature requirements for 21 CFR Part 11 compliance.
 *
 * 21 CFR Part 11 Compliance:
 * - §11.10(e): Full audit trail for all transfer operations
 * - §11.50: Electronic signature required for transfer approval
 * - §11.10(k): UTC timestamps for all events
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_middleware_1 = require("../middleware/auth.middleware");
const logger_1 = require("../config/logger");
const transfer_service_1 = require("../services/database/transfer.service");
const part11_middleware_1 = require("../middleware/part11.middleware");
const router = (0, express_1.Router)();
/**
 * Require admin or investigator role
 */
const requireTransferRole = async (req, res, next) => {
    const user = req.user;
    if (!user) {
        return res.status(401).json({ success: false, message: 'Not authenticated' });
    }
    const allowedRoles = ['admin', 'investigator', 'clinical_research_coordinator'];
    if (!allowedRoles.includes(user.role)) {
        return res.status(403).json({
            success: false,
            message: 'Transfer operations require admin or investigator role'
        });
    }
    next();
};
// ============================================================================
// Transfer Operations
// ============================================================================
/**
 * POST /api/transfers/initiate
 * Initiate a subject transfer
 *
 * 21 CFR Part 11 Compliance:
 * - §11.10(e): Records transfer initiation with full audit trail
 */
router.post('/initiate', auth_middleware_1.authMiddleware, requireTransferRole, async (req, res) => {
    try {
        const { studySubjectId, destinationSiteId, reasonForTransfer, notes, requiresApprovals } = req.body;
        const userId = req.user?.userId || 0;
        const userName = req.user?.userName || 'system';
        if (!studySubjectId || !destinationSiteId || !reasonForTransfer) {
            return res.status(400).json({
                success: false,
                message: 'studySubjectId, destinationSiteId, and reasonForTransfer are required'
            });
        }
        const transfer = await (0, transfer_service_1.initiateTransfer)({
            studySubjectId,
            destinationSiteId,
            reasonForTransfer,
            notes,
            initiatedBy: userId,
            requiresApprovals: requiresApprovals !== false
        });
        // Part 11 Audit: Record transfer initiation (§11.10(e))
        await (0, part11_middleware_1.recordPart11Audit)(userId, userName, part11_middleware_1.Part11EventTypes.TRANSFER_INITIATED, 'acc_transfer_log', transfer.transferId, `Transfer for subject ${studySubjectId}`, null, {
            studySubjectId,
            destinationSiteId,
            reasonForTransfer,
            status: 'pending',
            initiatedAt: (0, part11_middleware_1.formatPart11Timestamp)()
        }, reasonForTransfer, { ipAddress: req.ip });
        res.json({ success: true, data: transfer });
    }
    catch (error) {
        logger_1.logger.error('Error initiating transfer', { error: error.message });
        res.status(400).json({ success: false, message: error.message });
    }
});
/**
 * POST /api/transfers/:transferId/approve
 * Approve a transfer (source or destination site)
 *
 * 21 CFR Part 11 Compliance:
 * - §11.50: REQUIRES electronic signature (password verification)
 * - §11.10(e): Records approval with signature details
 */
router.post('/:transferId/approve', auth_middleware_1.authMiddleware, part11_middleware_1.requireSignature, async (req, res) => {
    try {
        const transferId = parseInt(req.params.transferId);
        const { approvalType } = req.body;
        const userId = req.user?.userId || 0;
        const userName = req.user?.userName || 'system';
        if (!approvalType) {
            return res.status(400).json({
                success: false,
                message: 'approvalType is required'
            });
        }
        if (!['source', 'destination'].includes(approvalType)) {
            return res.status(400).json({
                success: false,
                message: 'approvalType must be "source" or "destination"'
            });
        }
        // Get transfer details before approval
        const transferBefore = await (0, transfer_service_1.getTransferDetails)(transferId);
        const transfer = await (0, transfer_service_1.approveTransfer)({
            transferId,
            approvalType,
            approvedBy: userId,
            password: req.body.password // Already verified by requireSignature middleware
        });
        // Part 11 Audit: Record transfer approval with e-signature (§11.10(e), §11.50)
        await (0, part11_middleware_1.recordPart11Audit)(userId, userName, part11_middleware_1.Part11EventTypes.TRANSFER_APPROVED, 'acc_transfer_log', transferId, `Transfer ${transferId} - ${approvalType} approval`, { status: transferBefore?.transferStatus }, {
            status: transfer.transferStatus,
            approvalType,
            approvedAt: (0, part11_middleware_1.formatPart11Timestamp)(),
            electronicSignature: true,
            signatureMeaning: req.body.signatureMeaning || `Approved ${approvalType} site transfer`
        }, `${approvalType} site approved transfer with electronic signature`, { ipAddress: req.ip, signatureMeaning: req.body.signatureMeaning });
        res.json({ success: true, data: transfer });
    }
    catch (error) {
        logger_1.logger.error('Error approving transfer', { error: error.message });
        res.status(400).json({ success: false, message: error.message });
    }
});
/**
 * POST /api/transfers/:transferId/complete
 * Complete a transfer (move subject to new site)
 *
 * 21 CFR Part 11 Compliance:
 * - §11.10(e): Records transfer completion with full audit trail
 */
router.post('/:transferId/complete', auth_middleware_1.authMiddleware, requireTransferRole, async (req, res) => {
    try {
        const transferId = parseInt(req.params.transferId);
        const userId = req.user?.userId || 0;
        const userName = req.user?.userName || 'system';
        // Get transfer details before completion
        const transferBefore = await (0, transfer_service_1.getTransferDetails)(transferId);
        const transfer = await (0, transfer_service_1.completeTransfer)(transferId, userId);
        // Part 11 Audit: Record transfer completion (§11.10(e))
        await (0, part11_middleware_1.recordPart11Audit)(userId, userName, part11_middleware_1.Part11EventTypes.TRANSFER_COMPLETED, 'acc_transfer_log', transferId, `Transfer ${transferId} completed`, { status: transferBefore?.transferStatus }, {
            status: 'completed',
            completedAt: (0, part11_middleware_1.formatPart11Timestamp)(),
            studySubjectId: transfer.studySubjectId,
            newSiteId: transfer.destinationSiteId
        }, 'Subject transfer completed - subject moved to new site', { ipAddress: req.ip });
        res.json({ success: true, data: transfer });
    }
    catch (error) {
        logger_1.logger.error('Error completing transfer', { error: error.message });
        res.status(400).json({ success: false, message: error.message });
    }
});
/**
 * POST /api/transfers/:transferId/cancel
 * Cancel a pending transfer
 *
 * 21 CFR Part 11 Compliance:
 * - §11.10(e): Records transfer cancellation with reason
 */
router.post('/:transferId/cancel', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const transferId = parseInt(req.params.transferId);
        const { cancelReason } = req.body;
        const userId = req.user?.userId || 0;
        const userName = req.user?.userName || 'system';
        if (!cancelReason) {
            return res.status(400).json({
                success: false,
                message: 'cancelReason is required'
            });
        }
        // Get transfer details before cancellation
        const transferBefore = await (0, transfer_service_1.getTransferDetails)(transferId);
        const transfer = await (0, transfer_service_1.cancelTransfer)({
            transferId,
            cancelledBy: userId,
            cancelReason
        });
        // Part 11 Audit: Record transfer cancellation (§11.10(e))
        await (0, part11_middleware_1.recordPart11Audit)(userId, userName, part11_middleware_1.Part11EventTypes.TRANSFER_CANCELLED, 'acc_transfer_log', transferId, `Transfer ${transferId} cancelled`, { status: transferBefore?.transferStatus }, {
            status: 'cancelled',
            cancelledAt: (0, part11_middleware_1.formatPart11Timestamp)(),
            cancelReason
        }, cancelReason, { ipAddress: req.ip });
        res.json({ success: true, data: transfer });
    }
    catch (error) {
        logger_1.logger.error('Error cancelling transfer', { error: error.message });
        res.status(400).json({ success: false, message: error.message });
    }
});
// ============================================================================
// Transfer Queries
// ============================================================================
/**
 * GET /api/transfers/:transferId
 * Get transfer details
 */
router.get('/:transferId', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const transferId = parseInt(req.params.transferId);
        const transfer = await (0, transfer_service_1.getTransferDetails)(transferId);
        res.json({ success: true, data: transfer });
    }
    catch (error) {
        logger_1.logger.error('Error getting transfer details', { error: error.message });
        res.status(404).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/transfers/pending/site/:siteId
 * Get pending transfers for a site
 */
router.get('/pending/site/:siteId', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const siteId = parseInt(req.params.siteId);
        const transfers = await (0, transfer_service_1.getPendingTransfers)(siteId);
        res.json({ success: true, data: transfers });
    }
    catch (error) {
        logger_1.logger.error('Error getting pending transfers', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/transfers/history/subject/:studySubjectId
 * Get transfer history for a subject
 */
router.get('/history/subject/:studySubjectId', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const studySubjectId = parseInt(req.params.studySubjectId);
        const transfers = await (0, transfer_service_1.getTransferHistory)(studySubjectId);
        res.json({ success: true, data: transfers });
    }
    catch (error) {
        logger_1.logger.error('Error getting transfer history', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/transfers/check/:studySubjectId
 * Check if subject has a pending transfer
 */
router.get('/check/:studySubjectId', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const studySubjectId = parseInt(req.params.studySubjectId);
        const hasPending = await (0, transfer_service_1.hasPendingTransfer)(studySubjectId);
        res.json({ success: true, data: { hasPendingTransfer: hasPending } });
    }
    catch (error) {
        logger_1.logger.error('Error checking pending transfer', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/transfers/available-sites/:studySubjectId
 * Get available destination sites for transfer
 */
router.get('/available-sites/:studySubjectId', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const studySubjectId = parseInt(req.params.studySubjectId);
        const userId = req.user?.userId;
        const sites = await (0, transfer_service_1.getAvailableSites)(studySubjectId, userId);
        res.json({ success: true, data: sites });
    }
    catch (error) {
        logger_1.logger.error('Error getting available sites', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
exports.default = router;
//# sourceMappingURL=transfer.routes.js.map