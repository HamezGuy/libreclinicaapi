"use strict";
/**
 * Skip Logic Types
 *
 * Advanced skip logic, branching rules, and form linking for EDC forms.
 * Supports:
 * - Field visibility conditions (show/hide based on other field values)
 * - Conditional required fields
 * - Form branching (link to other forms based on answers)
 * - Section show/hide
 * - Calculated field triggers
 *
 * 21 CFR Part 11 §11.10(h) - Device checks (validation and logic rules)
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.COMMON_LINK_TRIGGERS = void 0;
/**
 * Common trigger patterns for form linking
 */
exports.COMMON_LINK_TRIGGERS = {
    YES_ANSWER: { operator: 'equals', value: 'yes' },
    NO_ANSWER: { operator: 'equals', value: 'no' },
    TRUE_ANSWER: { operator: 'is_true', value: true },
    FALSE_ANSWER: { operator: 'is_false', value: false },
    NOT_EMPTY: { operator: 'is_not_empty', value: null },
    VALUE_SELECTED: (value) => ({ operator: 'equals', value }),
    VALUE_IN_RANGE: (min, max) => ({
        operator: 'between',
        value: min,
        value2: max
    })
};
//# sourceMappingURL=skip-logic.types.js.map