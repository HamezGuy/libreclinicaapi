/**
 * Data Import Routes
 * Uses EXISTING LibreClinica SOAP APIs for Part 11 compliance
 * CSV is converted to ODM XML and imported via dataSoap.service
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=import.routes.d.ts.map