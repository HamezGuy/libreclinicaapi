"use strict";
/**
 * Email Worker
 *
 * Background worker that processes the email queue.
 * Should be run as a separate process or scheduled task.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.startEmailWorker = startEmailWorker;
exports.stopEmailWorker = stopEmailWorker;
exports.forceProcessQueue = forceProcessQueue;
exports.forceSendDigest = forceSendDigest;
const logger_1 = require("../../config/logger");
const email_service_1 = require("./email.service");
const database_1 = require("../../config/database");
// Worker configuration
const BATCH_SIZE = parseInt(process.env.EMAIL_BATCH_SIZE || '10');
const PROCESS_INTERVAL_MS = parseInt(process.env.EMAIL_PROCESS_INTERVAL || '30000'); // 30 seconds
const DIGEST_HOUR = parseInt(process.env.EMAIL_DIGEST_HOUR || '8'); // 8 AM
let isProcessing = false;
let workerInterval = null;
let digestInterval = null;
/**
 * Start the email worker
 */
function startEmailWorker() {
    logger_1.logger.info('Starting email worker', {
        batchSize: BATCH_SIZE,
        intervalMs: PROCESS_INTERVAL_MS
    });
    // Process queue immediately on start
    processQueue();
    // Set up interval for processing
    workerInterval = setInterval(processQueue, PROCESS_INTERVAL_MS);
    // Set up daily digest processing
    scheduleDailyDigest();
    logger_1.logger.info('Email worker started');
}
/**
 * Stop the email worker
 */
function stopEmailWorker() {
    logger_1.logger.info('Stopping email worker');
    if (workerInterval) {
        clearInterval(workerInterval);
        workerInterval = null;
    }
    if (digestInterval) {
        clearInterval(digestInterval);
        digestInterval = null;
    }
    logger_1.logger.info('Email worker stopped');
}
/**
 * Process the queue
 */
async function processQueue() {
    if (isProcessing) {
        logger_1.logger.debug('Email queue already being processed, skipping');
        return;
    }
    isProcessing = true;
    try {
        const status = await (0, email_service_1.getQueueStatus)();
        if (status.pending === 0) {
            logger_1.logger.debug('No pending emails in queue');
            return;
        }
        logger_1.logger.info('Processing email queue', { pending: status.pending });
        const result = await (0, email_service_1.processEmailQueue)(BATCH_SIZE);
        logger_1.logger.info('Email queue processing complete', {
            processed: result.processed,
            sent: result.sent,
            failed: result.failed
        });
    }
    catch (error) {
        logger_1.logger.error('Error in email worker', { error: error.message });
    }
    finally {
        isProcessing = false;
    }
}
/**
 * Schedule daily digest processing
 */
function scheduleDailyDigest() {
    // Calculate ms until next digest time
    const now = new Date();
    const nextDigest = new Date(now);
    nextDigest.setHours(DIGEST_HOUR, 0, 0, 0);
    if (nextDigest <= now) {
        nextDigest.setDate(nextDigest.getDate() + 1);
    }
    const msUntilDigest = nextDigest.getTime() - now.getTime();
    logger_1.logger.info('Scheduling daily digest', {
        nextDigest: nextDigest.toISOString(),
        msUntilDigest
    });
    // Schedule first digest
    setTimeout(() => {
        processDigest();
        // Then schedule daily
        digestInterval = setInterval(processDigest, 24 * 60 * 60 * 1000);
    }, msUntilDigest);
}
/**
 * Process and send daily digest emails
 */
async function processDigest() {
    logger_1.logger.info('Processing daily digest emails');
    try {
        // Get users who have digest enabled
        const usersResult = await database_1.pool.query(`
      SELECT DISTINCT np.user_id
      FROM acc_notification_preference np
      WHERE np.digest_enabled = true
    `);
        for (const row of usersResult.rows) {
            await sendDigestToUser(row.user_id);
        }
        logger_1.logger.info('Daily digest processing complete', {
            usersProcessed: usersResult.rows.length
        });
    }
    catch (error) {
        logger_1.logger.error('Error processing daily digest', { error: error.message });
    }
}
/**
 * Send digest to a specific user
 */
async function sendDigestToUser(userId) {
    try {
        // Get user email
        const userResult = await database_1.pool.query('SELECT email, first_name FROM user_account WHERE user_id = $1', [userId]);
        if (!userResult.rows[0]?.email) {
            return;
        }
        const { email, first_name } = userResult.rows[0];
        // Get digest-eligible notifications from the last 24 hours
        const digestData = await getDigestData(userId);
        if (!digestData.hasContent) {
            logger_1.logger.debug('No digest content for user', { userId });
            return;
        }
        // Send digest email
        const { queueEmail } = await Promise.resolve().then(() => __importStar(require('./email.service')));
        await queueEmail({
            templateName: 'daily_digest',
            recipientEmail: email,
            recipientUserId: userId,
            priority: 8, // Lower priority
            variables: {
                firstName: first_name,
                ...digestData
            }
        });
        logger_1.logger.info('Digest email queued for user', { userId, email });
    }
    catch (error) {
        logger_1.logger.error('Error sending digest to user', { error: error.message, userId });
    }
}
/**
 * Get digest data for a user
 */
async function getDigestData(userId) {
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - 1);
    try {
        // Get user's study assignments
        const studiesResult = await database_1.pool.query(`
      SELECT DISTINCT study_id FROM study_user_role
      WHERE user_id = $1 AND status_id = 1
    `, [userId]);
        const studyIds = studiesResult.rows.map(r => r.study_id);
        if (studyIds.length === 0) {
            return {
                hasContent: false,
                queryCount: 0,
                formCount: 0,
                subjectCount: 0,
                summaryItems: []
            };
        }
        // Get recent queries
        const queriesResult = await database_1.pool.query(`
      SELECT COUNT(*) as count
      FROM discrepancy_note dn
      JOIN event_crf ec ON dn.event_crf_id = ec.event_crf_id
      JOIN study_event se ON ec.study_event_id = se.study_event_id
      JOIN study_subject ss ON se.study_subject_id = ss.study_subject_id
      WHERE ss.study_id = ANY($1)
        AND dn.date_created >= $2
    `, [studyIds, cutoff]);
        // Get recent form submissions
        const formsResult = await database_1.pool.query(`
      SELECT COUNT(*) as count
      FROM event_crf ec
      JOIN study_event se ON ec.study_event_id = se.study_event_id
      JOIN study_subject ss ON se.study_subject_id = ss.study_subject_id
      WHERE ss.study_id = ANY($1)
        AND ec.date_completed >= $2
    `, [studyIds, cutoff]);
        // Get recent enrollments
        const subjectsResult = await database_1.pool.query(`
      SELECT COUNT(*) as count
      FROM study_subject
      WHERE study_id = ANY($1)
        AND date_created >= $2
    `, [studyIds, cutoff]);
        const queryCount = parseInt(queriesResult.rows[0]?.count || '0');
        const formCount = parseInt(formsResult.rows[0]?.count || '0');
        const subjectCount = parseInt(subjectsResult.rows[0]?.count || '0');
        return {
            hasContent: queryCount > 0 || formCount > 0 || subjectCount > 0,
            queryCount,
            formCount,
            subjectCount,
            summaryItems: [
                ...(queryCount > 0 ? [{
                        type: 'queries',
                        description: `${queryCount} new ${queryCount === 1 ? 'query' : 'queries'}`,
                        time: 'Last 24 hours'
                    }] : []),
                ...(formCount > 0 ? [{
                        type: 'forms',
                        description: `${formCount} ${formCount === 1 ? 'form' : 'forms'} completed`,
                        time: 'Last 24 hours'
                    }] : []),
                ...(subjectCount > 0 ? [{
                        type: 'subjects',
                        description: `${subjectCount} new ${subjectCount === 1 ? 'subject' : 'subjects'} enrolled`,
                        time: 'Last 24 hours'
                    }] : [])
            ]
        };
    }
    catch (error) {
        logger_1.logger.error('Error getting digest data', { error: error.message, userId });
        return {
            hasContent: false,
            queryCount: 0,
            formCount: 0,
            subjectCount: 0,
            summaryItems: []
        };
    }
}
/**
 * Force process queue immediately (for testing/admin)
 */
async function forceProcessQueue() {
    return await (0, email_service_1.processEmailQueue)(BATCH_SIZE);
}
/**
 * Force send digest (for testing/admin)
 */
async function forceSendDigest(userId) {
    if (userId) {
        await sendDigestToUser(userId);
    }
    else {
        await processDigest();
    }
}
exports.default = {
    startEmailWorker,
    stopEmailWorker,
    forceProcessQueue,
    forceSendDigest
};
//# sourceMappingURL=email-worker.js.map