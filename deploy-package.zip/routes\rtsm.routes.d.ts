/**
 * RTSM (Randomization and Trial Supply Management) Routes
 *
 * Endpoints for managing investigational product kits, shipments, and dispensing.
 * Integrates with LibreClinica's randomization and subject data.
 *
 * 21 CFR Part 11 Compliance:
 * - §11.10(e): Full audit trail for all kit, shipment, and dispensing operations
 * - §11.10(k): UTC timestamps for all events
 * - §11.50: Electronic signature required for dispensing (GxP critical)
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=rtsm.routes.d.ts.map