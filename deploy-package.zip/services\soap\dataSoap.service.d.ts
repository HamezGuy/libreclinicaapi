/**
 * Data SOAP Service
 *
 * Handles clinical data entry via LibreClinica SOAP API
 * - Import CRF data using ODM XML
 * - Build ODM XML from form data
 * - Validate data entries
 * - Support electronic signatures
 *
 * SOAP Endpoint: http://localhost:8080/LibreClinica/ws/data/v1
 * Uses ODM 1.3 standard for data interchange
 */
import { FormDataRequest, ApiResponse, ValidationError } from '../../types';
/**
 * Data import response
 */
interface DataImportResponse {
    success: boolean;
    eventCrfId?: number;
    validationErrors?: ValidationError[];
    warnings?: string[];
    odmResponse?: string;
}
/**
 * Import clinical data via SOAP
 * Main method for saving CRF data
 */
export declare const importData: (request: FormDataRequest, userId: number, username: string) => Promise<ApiResponse<DataImportResponse>>;
/**
 * Build ODM XML from form data request
 * Converts JSON form data to ODM 1.3 XML format
 */
export declare const buildOdmXml: (request: FormDataRequest) => Promise<string>;
/**
 * Parse data import response from SOAP
 */
export declare const parseImportResponse: (responseData: any) => Promise<DataImportResponse>;
/**
 * Build ODM XML for a single item data entry
 */
export declare const buildItemDataOdm: (studyOid: string, subjectOid: string, eventOid: string, formOid: string, itemGroupOid: string, itemOid: string, value: string) => string;
/**
 * Validate ODM XML structure
 */
export declare const validateOdmStructure: (odmXml: string) => {
    isValid: boolean;
    errors: string[];
};
declare const _default: {
    importData: (request: FormDataRequest, userId: number, username: string) => Promise<ApiResponse<DataImportResponse>>;
    buildOdmXml: (request: FormDataRequest) => Promise<string>;
    parseImportResponse: (responseData: any) => Promise<DataImportResponse>;
    buildItemDataOdm: (studyOid: string, subjectOid: string, eventOid: string, formOid: string, itemGroupOid: string, itemOid: string, value: string) => string;
    validateOdmStructure: (odmXml: string) => {
        isValid: boolean;
        errors: string[];
    };
};
export default _default;
//# sourceMappingURL=dataSoap.service.d.ts.map