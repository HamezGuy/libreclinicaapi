/**
 * Subject Routes
 *
 * API endpoints for subject/patient management including:
 * - List and search subjects
 * - CRUD operations
 * - Progress tracking
 * - Events and forms
 *
 * 21 CFR Part 11 Compliance:
 * - Subject enrollment requires electronic signature (§11.50)
 * - Subject modifications require electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=subject.routes.d.ts.map