import { Pool, PoolClient, QueryResult } from 'pg';
declare class DatabaseConnection {
    pool: Pool;
    constructor();
    private testConnection;
    query(text: string, params?: any[]): Promise<QueryResult>;
    connect(): Promise<PoolClient>;
    end(): Promise<void>;
    getClient(): Promise<PoolClient>;
    transaction<T>(callback: (client: PoolClient) => Promise<T>): Promise<T>;
    close(): Promise<void>;
}
export declare const db: DatabaseConnection;
export declare const pool: DatabaseConnection;
export {};
//# sourceMappingURL=database.d.ts.map