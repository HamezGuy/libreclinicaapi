"use strict";
/**
 * Validation Middleware
 *
 * Implements request validation using Joi schemas
 * - Validates request body, query params, and URL params
 * - Provides detailed validation error messages
 * - Ensures data integrity before processing
 *
 * Compliance: 21 CFR Part 11 §11.10(f) - Operational System Checks
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.commonSchemas = exports.eventSchemas = exports.reportSchemas = exports.userSchemas = exports.dashboardSchemas = exports.auditSchemas = exports.querySchemas = exports.studySchemas = exports.formSchemas = exports.subjectSchemas = exports.authSchemas = exports.validate = void 0;
const joi_1 = __importDefault(require("joi"));
const logger_1 = require("../config/logger");
/**
 * Validation schema options
 */
const validationOptions = {
    abortEarly: false, // Return all errors, not just first
    allowUnknown: true, // Allow unknown properties
    stripUnknown: true // Remove unknown properties
};
/**
 * Generic validation middleware factory
 * Creates middleware that validates specific parts of the request
 */
const validate = (schema) => {
    return async (req, res, next) => {
        try {
            // Validate request body
            if (schema.body) {
                const { error, value } = schema.body.validate(req.body, validationOptions);
                if (error) {
                    logger_1.logger.warn('Request body validation failed', {
                        path: req.path,
                        errors: error.details.map(d => ({ field: d.path.join('.'), message: d.message }))
                    });
                    res.status(400).json({
                        success: false,
                        message: 'Validation failed',
                        errors: error.details.map(detail => ({
                            field: detail.path.join('.'),
                            message: detail.message,
                            type: detail.type
                        }))
                    });
                    return;
                }
                req.body = value;
            }
            // Validate query parameters
            if (schema.query) {
                const { error, value } = schema.query.validate(req.query, validationOptions);
                if (error) {
                    logger_1.logger.warn('Query parameter validation failed', {
                        path: req.path,
                        errors: error.details.map(d => ({ field: d.path.join('.'), message: d.message }))
                    });
                    res.status(400).json({
                        success: false,
                        message: 'Query parameter validation failed',
                        errors: error.details.map(detail => ({
                            field: detail.path.join('.'),
                            message: detail.message
                        }))
                    });
                    return;
                }
                req.query = value;
            }
            // Validate URL parameters
            if (schema.params) {
                const { error, value } = schema.params.validate(req.params, validationOptions);
                if (error) {
                    logger_1.logger.warn('URL parameter validation failed', {
                        path: req.path,
                        errors: error.details.map(d => ({ field: d.path.join('.'), message: d.message }))
                    });
                    res.status(400).json({
                        success: false,
                        message: 'URL parameter validation failed',
                        errors: error.details.map(detail => ({
                            field: detail.path.join('.'),
                            message: detail.message
                        }))
                    });
                    return;
                }
                req.params = value;
            }
            next();
        }
        catch (error) {
            logger_1.logger.error('Validation middleware error', { error: error.message });
            res.status(500).json({
                success: false,
                message: 'Internal validation error'
            });
        }
    };
};
exports.validate = validate;
/**
 * ============================================================================
 * VALIDATION SCHEMAS
 * ============================================================================
 */
/**
 * Authentication Schemas
 */
exports.authSchemas = {
    login: joi_1.default.object({
        username: joi_1.default.string().required().min(3).max(255)
            .messages({
            'string.empty': 'Username is required',
            'string.min': 'Username must be at least 3 characters',
            'string.max': 'Username must not exceed 255 characters'
        }),
        password: joi_1.default.string().required().min(1)
            .messages({
            'string.empty': 'Password is required'
        })
    }),
    googleAuth: joi_1.default.object({
        idToken: joi_1.default.string().required()
            .messages({
            'string.empty': 'Google ID token is required'
        })
    }),
    refreshToken: joi_1.default.object({
        refreshToken: joi_1.default.string().required()
            .messages({
            'string.empty': 'Refresh token is required'
        })
    }),
    changePassword: joi_1.default.object({
        oldPassword: joi_1.default.string().required(),
        newPassword: joi_1.default.string().required()
            .min(12)
            .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
            .messages({
            'string.empty': 'New password is required',
            'string.min': 'Password must be at least 12 characters',
            'string.pattern.base': 'Password must contain uppercase, lowercase, number, and special character'
        })
    })
};
/**
 * Subject (Patient) Schemas
 */
exports.subjectSchemas = {
    create: joi_1.default.object({
        studyId: joi_1.default.number().integer().positive().required()
            .messages({
            'number.base': 'Study ID must be a number',
            'number.positive': 'Study ID must be positive',
            'any.required': 'Study ID is required'
        }),
        studySubjectId: joi_1.default.string().required().max(30)
            .messages({
            'string.empty': 'Subject ID is required',
            'string.max': 'Subject ID must not exceed 30 characters'
        }),
        secondaryId: joi_1.default.string().optional().allow('').max(30),
        enrollmentDate: joi_1.default.date().iso().optional(),
        gender: joi_1.default.string().valid('m', 'f', 'Male', 'Female', '').optional(),
        dateOfBirth: joi_1.default.date().iso().optional()
    }),
    list: joi_1.default.object({
        studyId: joi_1.default.number().integer().positive().required(),
        status: joi_1.default.string().valid('available', 'enrolled', 'completed', 'withdrawn').optional(),
        page: joi_1.default.number().integer().min(1).default(1),
        limit: joi_1.default.number().integer().min(1).max(1000).default(20),
        search: joi_1.default.string().optional().allow('')
    }),
    getById: joi_1.default.object({
        id: joi_1.default.number().integer().positive().required()
    })
};
/**
 * Form/CRF Schemas
 */
exports.formSchemas = {
    saveData: joi_1.default.object({
        // Study ID - required
        studyId: joi_1.default.number().integer().positive().required(),
        // Subject ID - required
        subjectId: joi_1.default.number().integer().positive().required(),
        // Event ID - accept both frontend and backend naming conventions
        eventId: joi_1.default.number().integer().positive().optional(),
        studyEventDefinitionId: joi_1.default.number().integer().positive().optional(),
        studyEventId: joi_1.default.number().integer().positive().optional(),
        eventCrfId: joi_1.default.number().integer().positive().optional(),
        // Form ID - accept both frontend and backend naming conventions
        formId: joi_1.default.number().integer().positive().optional(),
        crfId: joi_1.default.number().integer().positive().optional(),
        crfVersionId: joi_1.default.number().integer().positive().optional(),
        // Form data - accept both frontend and backend naming conventions
        data: joi_1.default.object().optional(),
        formData: joi_1.default.object().optional(),
        // Interview information
        interviewDate: joi_1.default.string().isoDate().optional().allow('', null),
        interviewerName: joi_1.default.string().optional().allow('', null),
        // Electronic signature
        electronicSignature: joi_1.default.object({
            username: joi_1.default.string().required(),
            password: joi_1.default.string().required(),
            meaning: joi_1.default.string().required().valid('Data Entry', 'Review', 'Approval')
        }).optional()
    }).or('eventId', 'studyEventDefinitionId', 'studyEventId', 'eventCrfId') // At least one event identifier
        .or('formId', 'crfId', 'crfVersionId') // At least one form identifier
        .or('data', 'formData'), // At least one data object
    getData: joi_1.default.object({
        subjectId: joi_1.default.number().integer().positive().required(),
        eventCrfId: joi_1.default.number().integer().positive().required()
    }),
    listForms: joi_1.default.object({
        studyId: joi_1.default.number().integer().positive().required()
    })
};
/**
 * Study Schemas
 */
exports.studySchemas = {
    list: joi_1.default.object({
        page: joi_1.default.number().integer().min(1).default(1),
        limit: joi_1.default.number().integer().min(1).max(100).default(20),
        status: joi_1.default.string().valid('available', 'pending', 'frozen', 'locked').optional()
    }),
    getById: joi_1.default.object({
        id: joi_1.default.number().integer().positive().required()
    }),
    create: joi_1.default.object({
        // Required fields for clinical trial compliance
        name: joi_1.default.string().required().min(3).max(255)
            .messages({
            'string.min': 'Study name must be at least 3 characters',
            'string.max': 'Study name cannot exceed 255 characters',
            'any.required': 'Study name is required'
        }),
        uniqueIdentifier: joi_1.default.string().required().min(3).max(255)
            .pattern(/^[a-zA-Z0-9_-]+$/)
            .messages({
            'string.pattern.base': 'Study identifier can only contain letters, numbers, hyphens, and underscores',
            'any.required': 'Protocol number is required'
        }),
        principalInvestigator: joi_1.default.string().required().max(255)
            .messages({
            'any.required': 'Principal Investigator is required for clinical trials'
        }),
        sponsor: joi_1.default.string().required().max(255)
            .messages({
            'any.required': 'Sponsor is required for clinical trials'
        }),
        phase: joi_1.default.string().required().valid('I', 'II', 'III', 'IV', 'N/A', 'i', 'ii', 'iii', 'iv', 'phase_i', 'phase_ii', 'phase_iii', 'phase_iv')
            .messages({
            'any.required': 'Study phase is required',
            'any.only': 'Phase must be I, II, III, IV, or N/A'
        }),
        expectedTotalEnrollment: joi_1.default.number().integer().min(1).required()
            .messages({
            'any.required': 'Expected enrollment is required',
            'number.min': 'Expected enrollment must be at least 1'
        }),
        datePlannedStart: joi_1.default.alternatives().try(joi_1.default.date().iso(), joi_1.default.string().min(1)).required()
            .messages({
            'any.required': 'Planned start date is required'
        }),
        // Optional fields
        description: joi_1.default.string().optional().max(2000).allow(''),
        summary: joi_1.default.string().optional().max(2000).allow(''),
        protocolType: joi_1.default.string().optional().valid('interventional', 'observational'),
        targetEnrollment: joi_1.default.number().integer().min(0).optional(), // Allow frontend variation
        datePlannedEnd: joi_1.default.alternatives().try(joi_1.default.date().iso(), joi_1.default.string().allow('')).optional(),
        parentStudyId: joi_1.default.number().integer().positive().optional(),
        // Additional optional fields from frontend
        officialTitle: joi_1.default.string().optional().max(255).allow(''),
        secondaryIdentifier: joi_1.default.string().optional().max(255).allow(''),
        collaborators: joi_1.default.string().optional().max(1000).allow(''),
        facilityName: joi_1.default.string().optional().max(255).allow(''),
        facilityCity: joi_1.default.string().optional().max(255).allow(''),
        facilityState: joi_1.default.string().optional().max(20).allow(''),
        facilityZip: joi_1.default.string().optional().max(64).allow(''),
        facilityCountry: joi_1.default.string().optional().max(64).allow(''),
        facilityRecruitmentStatus: joi_1.default.string().optional().max(60).allow(''),
        facilityContactName: joi_1.default.string().optional().max(255).allow(''),
        facilityContactDegree: joi_1.default.string().optional().max(255).allow(''),
        facilityContactPhone: joi_1.default.string().optional().max(255).allow(''),
        facilityContactEmail: joi_1.default.string().optional().max(255).email().allow(''),
        protocolDescription: joi_1.default.string().optional().max(1000).allow(''),
        protocolDateVerification: joi_1.default.string().optional().allow(''),
        medlineIdentifier: joi_1.default.string().optional().max(255).allow(''),
        url: joi_1.default.string().optional().max(255).allow(''),
        urlDescription: joi_1.default.string().optional().max(255).allow(''),
        resultsReference: joi_1.default.boolean().optional(),
        conditions: joi_1.default.string().optional().max(500).allow(''),
        keywords: joi_1.default.string().optional().max(255).allow(''),
        interventions: joi_1.default.string().optional().max(1000).allow(''),
        eligibility: joi_1.default.string().optional().max(500).allow(''),
        gender: joi_1.default.string().optional().allow(''),
        ageMin: joi_1.default.string().optional().max(3).allow(''),
        ageMax: joi_1.default.string().optional().max(3).allow(''),
        healthyVolunteerAccepted: joi_1.default.boolean().optional(),
        purpose: joi_1.default.string().optional().max(64).allow(''),
        allocation: joi_1.default.string().optional().max(64).allow(''),
        masking: joi_1.default.string().optional().max(30).allow(''),
        control: joi_1.default.string().optional().max(30).allow(''),
        assignment: joi_1.default.string().optional().max(30).allow(''),
        endpoint: joi_1.default.string().optional().max(64).allow(''),
        duration: joi_1.default.string().optional().max(30).allow(''),
        selection: joi_1.default.string().optional().max(30).allow(''),
        timing: joi_1.default.string().optional().max(30).allow(''),
        // Event definitions (phases) with CRF assignments
        eventDefinitions: joi_1.default.array().items(joi_1.default.object({
            name: joi_1.default.string().required().max(255),
            description: joi_1.default.string().optional().max(2000).allow(''),
            category: joi_1.default.string().optional().allow(''),
            type: joi_1.default.string().valid('scheduled', 'unscheduled', 'common').default('scheduled'),
            ordinal: joi_1.default.number().integer().min(1).optional(),
            repeating: joi_1.default.boolean().default(false),
            crfAssignments: joi_1.default.array().items(joi_1.default.object({
                crfId: joi_1.default.number().integer().positive().required(),
                required: joi_1.default.boolean().default(true),
                doubleDataEntry: joi_1.default.boolean().default(false),
                electronicSignature: joi_1.default.boolean().default(false),
                hideCrf: joi_1.default.boolean().default(false),
                ordinal: joi_1.default.number().integer().min(1).default(1)
            })).optional()
        })).optional(),
        // Group classes
        groupClasses: joi_1.default.array().items(joi_1.default.object({
            name: joi_1.default.string().required().max(255),
            type: joi_1.default.number().integer().min(1).max(4).default(1),
            subjectAssignment: joi_1.default.string().optional().allow(''),
            groups: joi_1.default.array().items(joi_1.default.object({
                name: joi_1.default.string().required().max(255),
                description: joi_1.default.string().optional().max(1000).allow('')
            })).optional()
        })).optional(),
        // Sites (child studies)
        sites: joi_1.default.array().items(joi_1.default.object({
            name: joi_1.default.string().required().max(255),
            uniqueIdentifier: joi_1.default.string().required().max(255),
            facilityName: joi_1.default.string().optional().max(255).allow(''),
            facilityCity: joi_1.default.string().optional().max(255).allow(''),
            facilityCountry: joi_1.default.string().optional().max(64).allow(''),
            principalInvestigator: joi_1.default.string().optional().max(255).allow(''),
            expectedTotalEnrollment: joi_1.default.number().integer().min(0).optional(),
            inheritFromParent: joi_1.default.boolean().default(true)
        })).optional(),
        // Study parameters
        collectDob: joi_1.default.string().optional().valid('1', '2', '3'),
        genderRequired: joi_1.default.string().optional(),
        subjectPersonIdRequired: joi_1.default.string().optional(),
        subjectIdGeneration: joi_1.default.string().optional().valid('manual', 'auto_editable', 'auto_non_editable'),
        subjectIdPrefix: joi_1.default.string().optional().allow(''),
        subjectIdSuffix: joi_1.default.string().optional().allow(''),
        studySubjectIdLabel: joi_1.default.string().optional().allow(''),
        secondaryIdLabel: joi_1.default.string().optional().allow(''),
        personIdShownOnCrf: joi_1.default.string().optional(),
        secondaryLabelViewable: joi_1.default.boolean().optional(),
        eventLocationRequired: joi_1.default.boolean().optional(),
        dateOfEnrollmentForStudyRequired: joi_1.default.string().optional(),
        discrepancyManagement: joi_1.default.boolean().optional(),
        allowAdministrativeEditing: joi_1.default.boolean().optional(),
        mailNotification: joi_1.default.string().optional().allow(''),
        contactEmail: joi_1.default.string().optional().email().allow('')
    }),
    update: joi_1.default.object({
        name: joi_1.default.string().optional().min(3).max(255),
        description: joi_1.default.string().optional().max(2000),
        principalInvestigator: joi_1.default.string().optional().max(255),
        sponsor: joi_1.default.string().optional().max(255),
        phase: joi_1.default.string().optional().valid('I', 'II', 'III', 'IV', 'N/A'),
        expectedTotalEnrollment: joi_1.default.number().integer().min(0).optional(),
        datePlannedStart: joi_1.default.date().iso().optional(),
        datePlannedEnd: joi_1.default.date().iso().optional()
    })
};
/**
 * Query/Discrepancy Note Schemas
 */
exports.querySchemas = {
    create: joi_1.default.object({
        entityType: joi_1.default.string().required().valid('itemData', 'eventCrf', 'studySubject', 'studyEvent'),
        entityId: joi_1.default.number().integer().positive().required(),
        description: joi_1.default.string().required().min(10).max(1000)
            .messages({
            'string.min': 'Query description must be at least 10 characters',
            'string.max': 'Query description must not exceed 1000 characters'
        }),
        detailedNotes: joi_1.default.string().optional().max(2000),
        queryType: joi_1.default.string().valid('Query', 'Failed Validation Check', 'Annotation', 'Reason for Change').required(),
        studyId: joi_1.default.number().integer().positive().required(),
        subjectId: joi_1.default.number().integer().positive().optional()
    }),
    respond: joi_1.default.object({
        description: joi_1.default.string().required().min(10).max(1000)
            .messages({
            'string.min': 'Response must be at least 10 characters',
            'string.max': 'Response must not exceed 1000 characters'
        }),
        detailedNotes: joi_1.default.string().optional().max(2000)
    }),
    updateStatus: joi_1.default.object({
        statusId: joi_1.default.number().integer().min(1).max(10).required()
    }),
    close: joi_1.default.object({
        queryId: joi_1.default.number().integer().positive().required(),
        resolution: joi_1.default.string().required().max(500)
    }),
    list: joi_1.default.object({
        studyId: joi_1.default.number().integer().positive().optional(),
        subjectId: joi_1.default.number().integer().positive().optional(),
        status: joi_1.default.string().valid('New', 'Updated', 'Resolved', 'Closed', 'Not Applicable').optional(),
        page: joi_1.default.number().integer().min(1).default(1),
        limit: joi_1.default.number().integer().min(1).max(100).default(20)
    })
};
/**
 * Audit Trail Schemas
 */
exports.auditSchemas = {
    query: joi_1.default.object({
        studyId: joi_1.default.number().integer().positive().optional(),
        subjectId: joi_1.default.number().integer().positive().optional(),
        userId: joi_1.default.number().integer().positive().optional(),
        eventType: joi_1.default.string().optional(),
        startDate: joi_1.default.date().iso().optional(),
        endDate: joi_1.default.date().iso().optional(),
        page: joi_1.default.number().integer().min(1).default(1),
        limit: joi_1.default.number().integer().min(1).max(500).default(50)
    }),
    export: joi_1.default.object({
        studyId: joi_1.default.number().integer().positive().required(),
        startDate: joi_1.default.date().iso().required(),
        endDate: joi_1.default.date().iso().required(),
        format: joi_1.default.string().valid('csv', 'pdf', 'json').default('csv')
    })
};
/**
 * Dashboard Schemas
 */
exports.dashboardSchemas = {
    enrollment: joi_1.default.object({
        studyId: joi_1.default.number().integer().positive().required(),
        startDate: joi_1.default.date().iso().optional(),
        endDate: joi_1.default.date().iso().optional()
    }),
    completion: joi_1.default.object({
        studyId: joi_1.default.number().integer().positive().required()
    }),
    queries: joi_1.default.object({
        studyId: joi_1.default.number().integer().positive().required(),
        timeframe: joi_1.default.string().valid('week', 'month', 'quarter', 'year').default('month')
    }),
    activity: joi_1.default.object({
        studyId: joi_1.default.number().integer().positive().required(),
        days: joi_1.default.number().integer().min(1).max(90).default(30)
    })
};
/**
 * User Management Schemas
 */
exports.userSchemas = {
    create: joi_1.default.object({
        username: joi_1.default.string().required().min(3).max(64)
            .pattern(/^[a-zA-Z0-9_]+$/)
            .messages({
            'string.pattern.base': 'Username can only contain letters, numbers, and underscores'
        }),
        firstName: joi_1.default.string().required().max(50),
        lastName: joi_1.default.string().required().max(50),
        email: joi_1.default.string().email().required().max(120),
        institutionalAffiliation: joi_1.default.string().optional().max(255),
        phone: joi_1.default.string().optional().max(40),
        password: joi_1.default.string().required()
            .min(8)
            .pattern(/.*[@$!%*?&#^()_+=\-].*/)
            .messages({
            'string.min': 'Password must be at least 8 characters',
            'string.pattern.base': 'Password must contain at least one special character'
        }),
        role: joi_1.default.string().required().valid('admin', 'coordinator', 'investigator', 'monitor', 'data_entry')
    }),
    update: joi_1.default.object({
        userId: joi_1.default.number().integer().positive().optional(), // Optional in body since it's in URL
        firstName: joi_1.default.string().optional().max(50),
        lastName: joi_1.default.string().optional().max(50),
        email: joi_1.default.string().email().optional().max(120),
        institutionalAffiliation: joi_1.default.string().optional().max(255),
        phone: joi_1.default.string().optional().max(40),
        role: joi_1.default.string().optional().valid('admin', 'coordinator', 'investigator', 'monitor', 'data_entry'),
        enabled: joi_1.default.boolean().optional()
    }),
    list: joi_1.default.object({
        studyId: joi_1.default.number().integer().positive().optional(),
        role: joi_1.default.string().optional(),
        enabled: joi_1.default.boolean().optional(),
        page: joi_1.default.number().integer().min(1).default(1),
        limit: joi_1.default.number().integer().min(1).max(100).default(20)
    })
};
/**
 * Report Schemas
 */
exports.reportSchemas = {
    enrollment: joi_1.default.object({
        studyId: joi_1.default.number().integer().positive().required(),
        startDate: joi_1.default.date().iso().required(),
        endDate: joi_1.default.date().iso().required(),
        format: joi_1.default.string().valid('csv', 'pdf', 'xlsx').default('pdf')
    }),
    dataCompletion: joi_1.default.object({
        studyId: joi_1.default.number().integer().positive().required(),
        includeSubjects: joi_1.default.boolean().default(true),
        format: joi_1.default.string().valid('csv', 'pdf', 'xlsx').default('pdf')
    }),
    queries: joi_1.default.object({
        studyId: joi_1.default.number().integer().positive().required(),
        status: joi_1.default.string().valid('open', 'closed', 'all').default('all'),
        format: joi_1.default.string().valid('csv', 'pdf', 'xlsx').default('pdf')
    })
};
/**
 * Event Scheduling Schemas
 */
exports.eventSchemas = {
    schedule: joi_1.default.object({
        studySubjectId: joi_1.default.number().integer().positive().required(),
        studyEventDefinitionId: joi_1.default.number().integer().positive().required(),
        startDate: joi_1.default.date().iso().optional(),
        endDate: joi_1.default.date().iso().optional(),
        location: joi_1.default.string().optional().max(255)
    }),
    create: joi_1.default.object({
        studyId: joi_1.default.number().integer().positive().required(),
        name: joi_1.default.string().required().min(3).max(255),
        description: joi_1.default.string().optional().max(1000),
        ordinal: joi_1.default.number().integer().min(1).required(),
        type: joi_1.default.string().optional().valid('scheduled', 'unscheduled', 'common'),
        repeating: joi_1.default.boolean().optional(),
        category: joi_1.default.string().optional().max(100)
    }),
    update: joi_1.default.object({
        name: joi_1.default.string().optional().min(3).max(255),
        description: joi_1.default.string().optional().max(1000),
        ordinal: joi_1.default.number().integer().min(1).optional(),
        type: joi_1.default.string().optional().valid('scheduled', 'unscheduled', 'common'),
        repeating: joi_1.default.boolean().optional(),
        category: joi_1.default.string().optional().max(100)
    }),
    list: joi_1.default.object({
        studyId: joi_1.default.number().integer().positive().required(),
        subjectId: joi_1.default.number().integer().positive().optional(),
        status: joi_1.default.string().valid('scheduled', 'data_entry_started', 'completed', 'stopped', 'skipped').optional()
    })
};
/**
 * Common parameter schemas
 */
exports.commonSchemas = {
    idParam: joi_1.default.object({
        id: joi_1.default.number().integer().positive().required()
            .messages({
            'number.base': 'ID must be a number',
            'number.positive': 'ID must be positive',
            'any.required': 'ID is required'
        })
    }),
    studyIdParam: joi_1.default.object({
        studyId: joi_1.default.number().integer().positive().required()
            .messages({
            'number.base': 'Study ID must be a number',
            'number.positive': 'Study ID must be positive',
            'any.required': 'Study ID is required'
        })
    }),
    subjectIdParam: joi_1.default.object({
        subjectId: joi_1.default.number().integer().positive().required()
            .messages({
            'number.base': 'Subject ID must be a number',
            'number.positive': 'Subject ID must be positive',
            'any.required': 'Subject ID is required'
        })
    }),
    pagination: joi_1.default.object({
        page: joi_1.default.number().integer().min(1).default(1),
        limit: joi_1.default.number().integer().min(1).max(100).default(20),
        sortBy: joi_1.default.string().optional(),
        sortOrder: joi_1.default.string().valid('asc', 'desc').default('asc')
    })
};
exports.default = exports.validate;
//# sourceMappingURL=validation.middleware.js.map