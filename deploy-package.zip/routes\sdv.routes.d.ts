/**
 * SDV (Source Data Verification) Routes
 *
 * Provides endpoints for Source Data Verification in LibreClinica.
 * SDV is at the FORM level (event_crf), not field level.
 *
 * 21 CFR Part 11 Compliance:
 * - SDV verification requires electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 *
 * Key endpoints:
 * - GET /api/sdv - List SDV records with filters
 * - GET /api/sdv/stats - Get SDV statistics for a study
 * - GET /api/sdv/by-visit - Get SDV grouped by visit/event
 * - GET /api/sdv/:id - Get specific SDV record
 * - GET /api/sdv/:id/form-data - Get form data for SDV preview
 * - PUT /api/sdv/:id/verify - Verify an SDV item
 * - PUT /api/sdv/:id/unverify - Unverify an SDV item
 * - POST /api/sdv/bulk-verify - Bulk verify multiple items
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=sdv.routes.d.ts.map