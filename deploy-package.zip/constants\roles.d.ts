/**
 * LibreClinica Role Constants
 *
 * These role definitions match the LibreClinica Role.java constants exactly.
 * Roles are stored in study_user_role.role_name as strings.
 *
 * Source: org.akaza.openclinica.bean.core.Role
 */
/**
 * Role interface matching LibreClinica structure
 */
export interface LibreClinicaRole {
    id: number;
    name: string;
    description: string;
    canSubmitData: boolean;
    canExtractData: boolean;
    canManageStudy: boolean;
    canMonitor: boolean;
}
/**
 * LibreClinica role definitions
 * These match the Role.java constants exactly
 */
export declare const ROLES: {
    INVALID: LibreClinicaRole;
    ADMIN: LibreClinicaRole;
    COORDINATOR: LibreClinicaRole;
    STUDYDIRECTOR: LibreClinicaRole;
    INVESTIGATOR: LibreClinicaRole;
    RESEARCHASSISTANT: LibreClinicaRole;
    MONITOR: LibreClinicaRole;
    RESEARCHASSISTANT2: LibreClinicaRole;
};
/**
 * Site-level role name mappings (used for sites/child studies)
 * Maps role ID to site-specific role name
 */
export declare const SITE_ROLE_MAP: Record<number, string>;
/**
 * Study-level role name mappings (used for parent studies)
 * Maps role ID to study-specific role name
 */
export declare const STUDY_ROLE_MAP: Record<number, string>;
/**
 * All roles as array (excluding INVALID)
 */
export declare const ALL_ROLES: LibreClinicaRole[];
/**
 * Get role by ID
 */
export declare const getRoleById: (id: number) => LibreClinicaRole;
/**
 * Get role by name (matches role_name column in study_user_role)
 * Handles both study and site role names
 */
export declare const getRoleByName: (name: string) => LibreClinicaRole;
/**
 * Get the highest privilege role from a list of role names
 * Lower ID = higher privilege (admin=1 is highest)
 */
export declare const getHighestRole: (roleNames: string[]) => LibreClinicaRole;
/**
 * Check if a role has a specific permission
 */
export declare const roleHasPermission: (roleName: string, permission: "submitData" | "extractData" | "manageStudy" | "monitor") => boolean;
/**
 * Check if user is admin
 */
export declare const isAdmin: (roleName: string) => boolean;
/**
 * Check if user can manage studies (Coordinator, Director, or Admin)
 */
export declare const canManageStudy: (roleName: string) => boolean;
/**
 * Check if user can submit data (most roles except monitor and invalid)
 */
export declare const canSubmitData: (roleName: string) => boolean;
declare const _default: {
    ROLES: {
        INVALID: LibreClinicaRole;
        ADMIN: LibreClinicaRole;
        COORDINATOR: LibreClinicaRole;
        STUDYDIRECTOR: LibreClinicaRole;
        INVESTIGATOR: LibreClinicaRole;
        RESEARCHASSISTANT: LibreClinicaRole;
        MONITOR: LibreClinicaRole;
        RESEARCHASSISTANT2: LibreClinicaRole;
    };
    ALL_ROLES: LibreClinicaRole[];
    SITE_ROLE_MAP: Record<number, string>;
    STUDY_ROLE_MAP: Record<number, string>;
    getRoleById: (id: number) => LibreClinicaRole;
    getRoleByName: (name: string) => LibreClinicaRole;
    getHighestRole: (roleNames: string[]) => LibreClinicaRole;
    roleHasPermission: (roleName: string, permission: "submitData" | "extractData" | "manageStudy" | "monitor") => boolean;
    isAdmin: (roleName: string) => boolean;
    canManageStudy: (roleName: string) => boolean;
    canSubmitData: (roleName: string) => boolean;
};
export default _default;
//# sourceMappingURL=roles.d.ts.map