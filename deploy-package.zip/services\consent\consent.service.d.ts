/**
 * eConsent Service
 *
 * Electronic consent management with 21 CFR Part 11 compliance.
 * Integrates with esignature.service.ts for signature verification.
 *
 * Features:
 * - Consent document and version management
 * - Subject consent capture and tracking
 * - Re-consent workflow
 * - Consent withdrawal
 * - Dashboard and reporting
 */
import { ConsentDocument, ConsentDocumentCreate, ConsentVersion, ConsentVersionCreate, SubjectConsent, SubjectConsentCreate, ReconsentRequest, ReconsentRequestCreate, ConsentDashboard } from './consent.types';
/**
 * Create a new consent document
 */
export declare function createConsentDocument(doc: ConsentDocumentCreate): Promise<ConsentDocument>;
/**
 * Get consent document by ID
 */
export declare function getConsentDocument(documentId: number): Promise<ConsentDocument | null>;
/**
 * List consent documents for a study
 */
export declare function listConsentDocuments(studyId: number): Promise<ConsentDocument[]>;
/**
 * Update consent document
 */
export declare function updateConsentDocument(documentId: number, updates: Partial<ConsentDocumentCreate>): Promise<ConsentDocument | null>;
/**
 * Create a new consent version
 */
export declare function createConsentVersion(version: ConsentVersionCreate): Promise<ConsentVersion>;
/**
 * Get consent version by ID
 */
export declare function getConsentVersion(versionId: number): Promise<ConsentVersion | null>;
/**
 * Get active version for a document
 */
export declare function getActiveVersion(documentId: number): Promise<ConsentVersion | null>;
/**
 * Activate a consent version
 */
export declare function activateConsentVersion(versionId: number, userId: number): Promise<ConsentVersion>;
/**
 * Record subject consent
 */
export declare function recordConsent(consent: SubjectConsentCreate): Promise<SubjectConsent>;
/**
 * Get subject consent by ID
 */
export declare function getSubjectConsentById(consentId: number): Promise<SubjectConsent | null>;
/**
 * Get consent history for a subject
 */
export declare function getSubjectConsent(studySubjectId: number): Promise<SubjectConsent[]>;
/**
 * Check if subject has valid consent
 */
export declare function hasValidConsent(studySubjectId: number): Promise<boolean>;
/**
 * Withdraw consent
 */
export declare function withdrawConsent(consentId: number, reason: string, userId: number): Promise<SubjectConsent>;
/**
 * Request re-consent for a subject
 */
export declare function requestReconsent(request: ReconsentRequestCreate): Promise<ReconsentRequest>;
/**
 * Get re-consent request by ID
 */
export declare function getReconsentRequest(requestId: number): Promise<ReconsentRequest | null>;
/**
 * Get pending re-consent requests for a study
 */
export declare function getPendingReconsents(studyId: number): Promise<ReconsentRequest[]>;
/**
 * Get consent dashboard for a study
 */
export declare function getConsentDashboard(studyId: number): Promise<ConsentDashboard>;
declare const _default: {
    createConsentDocument: typeof createConsentDocument;
    getConsentDocument: typeof getConsentDocument;
    listConsentDocuments: typeof listConsentDocuments;
    updateConsentDocument: typeof updateConsentDocument;
    createConsentVersion: typeof createConsentVersion;
    getConsentVersion: typeof getConsentVersion;
    getActiveVersion: typeof getActiveVersion;
    activateConsentVersion: typeof activateConsentVersion;
    recordConsent: typeof recordConsent;
    getSubjectConsentById: typeof getSubjectConsentById;
    getSubjectConsent: typeof getSubjectConsent;
    hasValidConsent: typeof hasValidConsent;
    withdrawConsent: typeof withdrawConsent;
    requestReconsent: typeof requestReconsent;
    getReconsentRequest: typeof getReconsentRequest;
    getPendingReconsents: typeof getPendingReconsents;
    getConsentDashboard: typeof getConsentDashboard;
};
export default _default;
//# sourceMappingURL=consent.service.d.ts.map