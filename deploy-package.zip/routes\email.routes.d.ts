/**
 * Email Routes
 *
 * API endpoints for email management and notification preferences.
 * Uses LibreClinica database for user preferences and audit logging.
 *
 * 21 CFR Part 11 Compliance:
 * - §11.10(e): Full audit trail for template changes and email operations
 * - §11.10(k): UTC timestamps for all email events
 * - Template versioning for change tracking
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=email.routes.d.ts.map