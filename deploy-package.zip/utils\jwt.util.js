"use strict";
/**
 * JWT Utility
 *
 * JSON Web Token generation and verification
 * - Generate access and refresh tokens
 * - Verify and decode tokens
 * - Token refresh mechanism
 * - Session management
 *
 * Compliance: 21 CFR Part 11 §11.10(d) - Access Controls
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateTokenPayload = exports.createSessionId = exports.extractTokenFromHeader = exports.refreshAccessToken = exports.getTokenTimeRemaining = exports.getTokenExpiration = exports.isTokenExpired = exports.decodeToken = exports.verifyRefreshToken = exports.verifyAccessToken = exports.generateTokenPair = exports.generateRefreshToken = exports.generateAccessToken = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const environment_1 = require("../config/environment");
const logger_1 = require("../config/logger");
/**
 * Generate access token
 * Short-lived token for API access (30 minutes default)
 */
const generateAccessToken = (payload) => {
    const secret = environment_1.config.jwt.secret;
    const expiresIn = environment_1.config.jwt.expiresIn || '30m';
    const signOptions = {
        expiresIn: expiresIn,
        issuer: 'libreclinica-api',
        audience: 'libreclinica-client'
    };
    const token = jsonwebtoken_1.default.sign({
        ...payload,
        type: 'access'
    }, secret, signOptions);
    logger_1.logger.debug('Access token generated', {
        userId: payload.userId,
        username: payload.username,
        expiresIn
    });
    return token;
};
exports.generateAccessToken = generateAccessToken;
/**
 * Generate refresh token
 * Long-lived token for refreshing access tokens (7 days default)
 */
const generateRefreshToken = (payload) => {
    const secret = environment_1.config.jwt.secret;
    const expiresIn = environment_1.config.jwt.refreshExpiresIn || '7d';
    const signOptions = {
        expiresIn: expiresIn,
        issuer: 'libreclinica-api',
        audience: 'libreclinica-client'
    };
    const token = jsonwebtoken_1.default.sign({
        userId: payload.userId,
        username: payload.username,
        type: 'refresh'
    }, secret, signOptions);
    logger_1.logger.debug('Refresh token generated', {
        userId: payload.userId,
        username: payload.username,
        expiresIn
    });
    return token;
};
exports.generateRefreshToken = generateRefreshToken;
/**
 * Generate both access and refresh tokens
 */
const generateTokenPair = (payload) => {
    const accessToken = (0, exports.generateAccessToken)(payload);
    const refreshToken = (0, exports.generateRefreshToken)(payload);
    // Calculate expiry time in seconds
    const expiresIn = environment_1.config.part11.sessionTimeoutMinutes * 60; // Convert minutes to seconds
    return {
        accessToken,
        refreshToken,
        expiresIn
    };
};
exports.generateTokenPair = generateTokenPair;
/**
 * Verify access token
 * Validates token signature and expiration
 */
const verifyAccessToken = (token) => {
    try {
        const secret = environment_1.config.jwt.secret;
        const decoded = jsonwebtoken_1.default.verify(token, secret, {
            issuer: 'libreclinica-api',
            audience: 'libreclinica-client'
        });
        // Verify it's an access token
        if (decoded.type !== 'access') {
            logger_1.logger.warn('Invalid token type', { type: decoded.type, expected: 'access' });
            return null;
        }
        return decoded;
    }
    catch (error) {
        if (error.name === 'TokenExpiredError') {
            logger_1.logger.debug('Access token expired', { expiredAt: error.expiredAt });
        }
        else if (error.name === 'JsonWebTokenError') {
            logger_1.logger.warn('Invalid access token', { error: error.message });
        }
        else {
            logger_1.logger.error('Token verification error', { error: error.message });
        }
        return null;
    }
};
exports.verifyAccessToken = verifyAccessToken;
/**
 * Verify refresh token
 * Validates refresh token for token refresh operations
 */
const verifyRefreshToken = (token) => {
    try {
        const secret = environment_1.config.jwt.secret;
        const decoded = jsonwebtoken_1.default.verify(token, secret, {
            issuer: 'libreclinica-api',
            audience: 'libreclinica-client'
        });
        // Verify it's a refresh token
        if (decoded.type !== 'refresh') {
            logger_1.logger.warn('Invalid token type', { type: decoded.type, expected: 'refresh' });
            return null;
        }
        return decoded;
    }
    catch (error) {
        if (error.name === 'TokenExpiredError') {
            logger_1.logger.debug('Refresh token expired', { expiredAt: error.expiredAt });
        }
        else if (error.name === 'JsonWebTokenError') {
            logger_1.logger.warn('Invalid refresh token', { error: error.message });
        }
        else {
            logger_1.logger.error('Refresh token verification error', { error: error.message });
        }
        return null;
    }
};
exports.verifyRefreshToken = verifyRefreshToken;
/**
 * Decode token without verification
 * Useful for extracting payload without validating signature
 */
const decodeToken = (token) => {
    try {
        const decoded = jsonwebtoken_1.default.decode(token);
        return decoded;
    }
    catch (error) {
        logger_1.logger.error('Token decode error', { error: error.message });
        return null;
    }
};
exports.decodeToken = decodeToken;
/**
 * Check if token is expired
 * Returns true if token is expired, false otherwise
 */
const isTokenExpired = (token) => {
    const decoded = (0, exports.decodeToken)(token);
    if (!decoded || !decoded.exp) {
        return true;
    }
    const currentTime = Math.floor(Date.now() / 1000);
    return decoded.exp < currentTime;
};
exports.isTokenExpired = isTokenExpired;
/**
 * Get token expiration time
 * Returns expiration timestamp in seconds
 */
const getTokenExpiration = (token) => {
    const decoded = (0, exports.decodeToken)(token);
    return decoded?.exp || null;
};
exports.getTokenExpiration = getTokenExpiration;
/**
 * Get time until token expires
 * Returns remaining time in seconds
 */
const getTokenTimeRemaining = (token) => {
    const exp = (0, exports.getTokenExpiration)(token);
    if (!exp) {
        return null;
    }
    const currentTime = Math.floor(Date.now() / 1000);
    const remaining = exp - currentTime;
    return remaining > 0 ? remaining : 0;
};
exports.getTokenTimeRemaining = getTokenTimeRemaining;
/**
 * Refresh access token using refresh token
 * Returns new token pair if refresh token is valid
 */
const refreshAccessToken = async (refreshToken, getUserData) => {
    // Verify refresh token
    const decoded = (0, exports.verifyRefreshToken)(refreshToken);
    if (!decoded) {
        logger_1.logger.warn('Invalid refresh token provided');
        return null;
    }
    try {
        // Get current user data (may have changed since token was issued)
        const userData = await getUserData(decoded.userId);
        if (!userData) {
            logger_1.logger.warn('User not found for refresh token', { userId: decoded.userId });
            return null;
        }
        // Generate new token pair
        const tokens = (0, exports.generateTokenPair)(userData);
        logger_1.logger.info('Access token refreshed', {
            userId: userData.userId,
            username: userData.username
        });
        return tokens;
    }
    catch (error) {
        logger_1.logger.error('Token refresh error', { error: error.message, userId: decoded.userId });
        return null;
    }
};
exports.refreshAccessToken = refreshAccessToken;
/**
 * Extract token from Authorization header
 * Supports "Bearer <token>" format
 */
const extractTokenFromHeader = (authHeader) => {
    if (!authHeader) {
        return null;
    }
    const parts = authHeader.split(' ');
    if (parts.length !== 2 || parts[0] !== 'Bearer') {
        logger_1.logger.warn('Invalid authorization header format', { header: authHeader });
        return null;
    }
    return parts[1];
};
exports.extractTokenFromHeader = extractTokenFromHeader;
/**
 * Create session identifier
 * Used for tracking user sessions
 */
const createSessionId = (userId, username) => {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(7);
    return `${userId}_${username}_${timestamp}_${random}`;
};
exports.createSessionId = createSessionId;
/**
 * Validate token payload
 * Ensures all required fields are present
 */
const validateTokenPayload = (payload) => {
    return (typeof payload.userId === 'number' &&
        typeof payload.username === 'string' &&
        typeof payload.email === 'string' &&
        typeof payload.role === 'string');
};
exports.validateTokenPayload = validateTokenPayload;
exports.default = {
    generateAccessToken: exports.generateAccessToken,
    generateRefreshToken: exports.generateRefreshToken,
    generateTokenPair: exports.generateTokenPair,
    verifyAccessToken: exports.verifyAccessToken,
    verifyRefreshToken: exports.verifyRefreshToken,
    decodeToken: exports.decodeToken,
    isTokenExpired: exports.isTokenExpired,
    getTokenExpiration: exports.getTokenExpiration,
    getTokenTimeRemaining: exports.getTokenTimeRemaining,
    refreshAccessToken: exports.refreshAccessToken,
    extractTokenFromHeader: exports.extractTokenFromHeader,
    createSessionId: exports.createSessionId,
    validateTokenPayload: exports.validateTokenPayload
};
//# sourceMappingURL=jwt.util.js.map