/**
 * Study Service (Hybrid)
 *
 * ═══════════════════════════════════════════════════════════════════════════════
 * LibreClinica Integration Architecture
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * This service integrates with LibreClinica using established channels:
 *
 * SOAP API (PRIMARY for clinical operations - Part 11 Compliant):
 * ─────────────────────────────────────────────────────────────────
 *   ✓ listStudies()       - Get study list via SOAP study/listAll
 *   ✓ getStudyMetadata()  - Get ODM metadata via SOAP study/getMetadata
 *
 *   LibreClinica SOAP endpoints:
 *   - studySubject: create, isStudySubject, listAllByStudy
 *   - event: schedule, create
 *   - data: import (ODM-XML format)
 *   - study: listAll, getMetadata
 *   - crf: listAll
 *
 * DIRECT DATABASE (for admin operations NOT exposed via SOAP):
 * ─────────────────────────────────────────────────────────────────
 *   ✓ createStudy()       - Study creation (not available in SOAP API)
 *   ✓ updateStudy()       - Study updates (not available in SOAP API)
 *   ✓ getStudyStats()     - Enrollment stats, query counts
 *   ✓ getStudyUsers()     - User role assignments
 *   ✓ Audit logging       - audit_log_event table
 *
 * NOTE: LibreClinica's SOAP API is designed for clinical data operations
 * (subjects, events, CRF data). Administrative operations like study
 * creation/modification are done via the LibreClinica web UI or database.
 *
 * DATABASE: We connect to the SAME PostgreSQL database that LibreClinica uses.
 * Port 5434 = LibreClinica's production database (libreclinica-postgres)
 * Port 5433 = Unit test database only (api-test-db) - NOT for production
 * ═══════════════════════════════════════════════════════════════════════════════
 */
import { PaginatedResponse } from '../../types/libreclinica-models';
export interface StudyMetadata {
    study: any;
    events: any[];
    crfs: any[];
}
/**
 * Get studies list - SOAP PRIMARY, DB for stats enrichment
 *
 * Strategy:
 * 1. Get study list from SOAP (official source)
 * 2. Enrich with statistics from DB (enrollment, completion)
 * 3. Filter by user access from DB
 */
export declare const getStudies: (userId: number, filters: {
    status?: string;
    page?: number;
    limit?: number;
}, username?: string) => Promise<PaginatedResponse<any>>;
/**
 * Get study by ID with statistics
 */
export declare const getStudyById: (studyId: number, userId: number) => Promise<any>;
/**
 * Get study metadata (combine SOAP + DB)
 */
export declare const getStudyMetadata: (studyId: number, userId: number, username: string) => Promise<StudyMetadata | null>;
/**
 * Get study sites
 */
export declare const getStudySites: (studyId: number) => Promise<any[]>;
/**
 * Create new study
 */
/**
 * Create study - supports ALL LibreClinica database fields
 *
 * Database columns in study table:
 * - Identification: name, unique_identifier, secondary_identifier, official_title, oc_oid
 * - Description: summary, protocol_description
 * - Timeline: date_planned_start, date_planned_end, date_created, date_updated
 * - Classification: protocol_type, phase, type_id
 * - Enrollment: expected_total_enrollment
 * - Team: principal_investigator, sponsor, collaborators
 * - Facility: facility_name, facility_city, facility_state, facility_zip, facility_country,
 *             facility_recruitment_status, facility_contact_name, facility_contact_degree,
 *             facility_contact_phone, facility_contact_email
 * - Protocol: protocol_date_verification, medline_identifier, url, url_description, results_reference
 * - Eligibility: conditions, keywords, eligibility, gender, age_min, age_max, healthy_volunteer_accepted
 * - Design: purpose, allocation, masking, control, assignment, endpoint, interventions, duration, selection, timing
 */
export declare const createStudy: (data: {
    name: string;
    uniqueIdentifier: string;
    secondaryIdentifier?: string;
    officialTitle?: string;
    summary?: string;
    principalInvestigator?: string;
    sponsor?: string;
    collaborators?: string;
    phase?: string;
    protocolType?: string;
    expectedTotalEnrollment?: number;
    datePlannedStart?: string;
    datePlannedEnd?: string;
    parentStudyId?: number;
    facilityName?: string;
    facilityCity?: string;
    facilityState?: string;
    facilityZip?: string;
    facilityCountry?: string;
    facilityRecruitmentStatus?: string;
    facilityContactName?: string;
    facilityContactDegree?: string;
    facilityContactPhone?: string;
    facilityContactEmail?: string;
    protocolDescription?: string;
    protocolDateVerification?: string;
    medlineIdentifier?: string;
    url?: string;
    urlDescription?: string;
    resultsReference?: boolean;
    conditions?: string;
    keywords?: string;
    interventions?: string;
    eligibility?: string;
    gender?: string;
    ageMin?: string;
    ageMax?: string;
    healthyVolunteerAccepted?: boolean;
    purpose?: string;
    allocation?: string;
    masking?: string;
    control?: string;
    assignment?: string;
    endpoint?: string;
    duration?: string;
    selection?: string;
    timing?: string;
}, userId: number) => Promise<{
    success: boolean;
    studyId?: number;
    message?: string;
}>;
/**
 * Update study - supports ALL LibreClinica database fields
 */
export declare const updateStudy: (studyId: number, data: {
    name?: string;
    officialTitle?: string;
    secondaryIdentifier?: string;
    summary?: string;
    description?: string;
    principalInvestigator?: string;
    sponsor?: string;
    collaborators?: string;
    phase?: string;
    protocolType?: string;
    expectedTotalEnrollment?: number;
    datePlannedStart?: string;
    datePlannedEnd?: string;
    facilityName?: string;
    facilityCity?: string;
    facilityState?: string;
    facilityZip?: string;
    facilityCountry?: string;
    facilityRecruitmentStatus?: string;
    facilityContactName?: string;
    facilityContactDegree?: string;
    facilityContactPhone?: string;
    facilityContactEmail?: string;
    protocolDescription?: string;
    protocolDateVerification?: string;
    medlineIdentifier?: string;
    url?: string;
    urlDescription?: string;
    resultsReference?: boolean;
    conditions?: string;
    keywords?: string;
    interventions?: string;
    eligibility?: string;
    gender?: string;
    ageMin?: string;
    ageMax?: string;
    healthyVolunteerAccepted?: boolean;
    purpose?: string;
    allocation?: string;
    masking?: string;
    control?: string;
    assignment?: string;
    endpoint?: string;
    duration?: string;
    selection?: string;
    timing?: string;
}, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Delete study (set status to removed)
 */
export declare const deleteStudy: (studyId: number, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
export { getStudyForms } from './form.service';
declare const _default: {
    getStudies: (userId: number, filters: {
        status?: string;
        page?: number;
        limit?: number;
    }, username?: string) => Promise<PaginatedResponse<any>>;
    getStudyById: (studyId: number, userId: number) => Promise<any>;
    getStudyMetadata: (studyId: number, userId: number, username: string) => Promise<StudyMetadata | null>;
    getStudySites: (studyId: number) => Promise<any[]>;
    createStudy: (data: {
        name: string;
        uniqueIdentifier: string;
        secondaryIdentifier?: string;
        officialTitle?: string;
        summary?: string;
        principalInvestigator?: string;
        sponsor?: string;
        collaborators?: string;
        phase?: string;
        protocolType?: string;
        expectedTotalEnrollment?: number;
        datePlannedStart?: string;
        datePlannedEnd?: string;
        parentStudyId?: number;
        facilityName?: string;
        facilityCity?: string;
        facilityState?: string;
        facilityZip?: string;
        facilityCountry?: string;
        facilityRecruitmentStatus?: string;
        facilityContactName?: string;
        facilityContactDegree?: string;
        facilityContactPhone?: string;
        facilityContactEmail?: string;
        protocolDescription?: string;
        protocolDateVerification?: string;
        medlineIdentifier?: string;
        url?: string;
        urlDescription?: string;
        resultsReference?: boolean;
        conditions?: string;
        keywords?: string;
        interventions?: string;
        eligibility?: string;
        gender?: string;
        ageMin?: string;
        ageMax?: string;
        healthyVolunteerAccepted?: boolean;
        purpose?: string;
        allocation?: string;
        masking?: string;
        control?: string;
        assignment?: string;
        endpoint?: string;
        duration?: string;
        selection?: string;
        timing?: string;
    }, userId: number) => Promise<{
        success: boolean;
        studyId?: number;
        message?: string;
    }>;
    updateStudy: (studyId: number, data: {
        name?: string;
        officialTitle?: string;
        secondaryIdentifier?: string;
        summary?: string;
        description?: string;
        principalInvestigator?: string;
        sponsor?: string;
        collaborators?: string;
        phase?: string;
        protocolType?: string;
        expectedTotalEnrollment?: number;
        datePlannedStart?: string;
        datePlannedEnd?: string;
        facilityName?: string;
        facilityCity?: string;
        facilityState?: string;
        facilityZip?: string;
        facilityCountry?: string;
        facilityRecruitmentStatus?: string;
        facilityContactName?: string;
        facilityContactDegree?: string;
        facilityContactPhone?: string;
        facilityContactEmail?: string;
        protocolDescription?: string;
        protocolDateVerification?: string;
        medlineIdentifier?: string;
        url?: string;
        urlDescription?: string;
        resultsReference?: boolean;
        conditions?: string;
        keywords?: string;
        interventions?: string;
        eligibility?: string;
        gender?: string;
        ageMin?: string;
        ageMax?: string;
        healthyVolunteerAccepted?: boolean;
        purpose?: string;
        allocation?: string;
        masking?: string;
        control?: string;
        assignment?: string;
        endpoint?: string;
        duration?: string;
        selection?: string;
        timing?: string;
    }, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    deleteStudy: (studyId: number, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
};
export default _default;
//# sourceMappingURL=study.service.d.ts.map