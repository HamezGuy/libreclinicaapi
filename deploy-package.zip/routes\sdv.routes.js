"use strict";
/**
 * SDV (Source Data Verification) Routes
 *
 * Provides endpoints for Source Data Verification in LibreClinica.
 * SDV is at the FORM level (event_crf), not field level.
 *
 * 21 CFR Part 11 Compliance:
 * - SDV verification requires electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 *
 * Key endpoints:
 * - GET /api/sdv - List SDV records with filters
 * - GET /api/sdv/stats - Get SDV statistics for a study
 * - GET /api/sdv/by-visit - Get SDV grouped by visit/event
 * - GET /api/sdv/:id - Get specific SDV record
 * - GET /api/sdv/:id/form-data - Get form data for SDV preview
 * - PUT /api/sdv/:id/verify - Verify an SDV item
 * - PUT /api/sdv/:id/unverify - Unverify an SDV item
 * - POST /api/sdv/bulk-verify - Bulk verify multiple items
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const authorization_middleware_1 = require("../middleware/authorization.middleware");
const part11_middleware_1 = require("../middleware/part11.middleware");
const sdvController = __importStar(require("../controllers/sdv.controller"));
const router = express_1.default.Router();
router.use(auth_middleware_1.authMiddleware);
// List and statistics (no signature required)
router.get('/', sdvController.list);
router.get('/stats', sdvController.getStats);
router.get('/by-visit', sdvController.getByVisit);
router.get('/subject/:subjectId', sdvController.getSubjectStatus);
// Individual record with form data preview (no signature required)
router.get('/:id', sdvController.get);
router.get('/:id/form-data', sdvController.getFormData);
// Verification actions (requires monitor or admin role + signature)
router.put('/:id/verify', (0, authorization_middleware_1.requireRole)('monitor', 'admin'), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.VERIFY), sdvController.verify);
router.put('/:id/unverify', (0, authorization_middleware_1.requireRole)('monitor', 'admin'), (0, part11_middleware_1.requireSignatureFor)('I authorize removal of SDV verification'), sdvController.unverify);
router.post('/bulk-verify', (0, authorization_middleware_1.requireRole)('monitor', 'admin'), (0, part11_middleware_1.requireSignatureFor)(part11_middleware_1.SignatureMeanings.VERIFY), sdvController.bulkVerify);
exports.default = router;
//# sourceMappingURL=sdv.routes.js.map