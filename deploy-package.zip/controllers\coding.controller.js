"use strict";
/**
 * Medical Coding Controller
 * Placeholder for external coding system integration (MedDRA, WHO Drug)
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.code = exports.list = void 0;
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
exports.list = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    // Medical coding is typically handled by external systems
    // This is a placeholder for integration
    res.json({
        success: true,
        data: [],
        message: 'Medical coding integration pending - connect to MedDRA/WHO Drug'
    });
});
exports.code = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { verbatimTerm, dictionary } = req.body;
    // Placeholder for coding logic
    res.json({
        success: true,
        data: {
            verbatimTerm,
            dictionary: dictionary || 'MedDRA',
            status: 'pending',
            message: 'Coding request submitted'
        }
    });
});
exports.default = { list: exports.list, code: exports.code };
//# sourceMappingURL=coding.controller.js.map