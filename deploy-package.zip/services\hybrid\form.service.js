"use strict";
/**
 * Form Service (Hybrid)
 *
 * Form data management combining SOAP and Database
 * - Use SOAP for saving form data (GxP compliant with validation)
 * - Use Database for reading form data (faster)
 *
 * 21 CFR Part 11 §11.10(e) - Audit Trail for document actions
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.forkForm = exports.createFormVersion = exports.getFormVersions = exports.deleteForm = exports.updateForm = exports.createForm = exports.getFormById = exports.getAllForms = exports.getStudyForms = exports.validateFormData = exports.getFormStatus = exports.getFormMetadata = exports.getFormData = exports.saveFormData = void 0;
const database_1 = require("../../config/database");
const logger_1 = require("../../config/logger");
const environment_1 = require("../../config/environment");
const dataSoap = __importStar(require("../soap/dataSoap.service"));
const audit_service_1 = require("../database/audit.service");
const validationRulesService = __importStar(require("../database/validation-rules.service"));
const encryption_util_1 = require("../../utils/encryption.util");
const workflowService = __importStar(require("../database/workflow.service"));
/**
 * Save form data via SOAP (GxP compliant)
 *
 * This function now applies validation rules before saving:
 * - Hard edits (severity: 'error') will BLOCK the save
 * - Soft edits (severity: 'warning') will be returned but allow save
 *
 * Supports both frontend and backend naming conventions:
 * - Frontend: studyId, subjectId, eventId, formId, data
 * - Backend: studyId, subjectId, studyEventDefinitionId, crfId, formData
 *
 * 21 CFR Part 11 §11.10(h) - Device checks to determine validity
 */
const saveFormData = async (request, userId, username) => {
    logger_1.logger.info('Saving form data', {
        studyId: request.studyId,
        subjectId: request.subjectId,
        eventId: request.studyEventDefinitionId || request.eventId,
        crfId: request.crfId || request.formId,
        userId
    });
    // Handle both naming conventions (frontend uses formId/data/eventId, backend uses crfId/formData/studyEventDefinitionId)
    const crfId = request.crfId || request.formId;
    const formData = request.formData || request.data;
    const eventDefId = request.studyEventDefinitionId || request.eventId;
    // Validate required fields
    if (!request.studyId || !request.subjectId || !eventDefId || !crfId) {
        logger_1.logger.warn('Missing required fields for form save', {
            studyId: request.studyId,
            subjectId: request.subjectId,
            eventDefId,
            crfId
        });
        return {
            success: false,
            message: 'Missing required fields: studyId, subjectId, eventId/studyEventDefinitionId, formId/crfId'
        };
    }
    // Apply validation rules BEFORE saving
    // Create queries (discrepancy notes) for validation failures
    if (crfId && formData) {
        try {
            // First pass: validate without creating queries to check for hard errors
            const validationResult = await validationRulesService.validateFormData(crfId, formData, {
                createQueries: true, // Create queries for validation failures
                studyId: request.studyId,
                subjectId: request.subjectId,
                userId: userId
            });
            // If there are hard edit errors, block the save
            if (!validationResult.valid && validationResult.errors.length > 0) {
                logger_1.logger.warn('Form data validation failed - queries created', {
                    crfId,
                    errors: validationResult.errors,
                    queriesCreated: validationResult.queriesCreated
                });
                return {
                    success: false,
                    message: 'Validation failed',
                    errors: validationResult.errors,
                    warnings: validationResult.warnings,
                    queriesCreated: validationResult.queriesCreated
                };
            }
            // Log warnings but continue with save
            if (validationResult.warnings.length > 0) {
                logger_1.logger.info('Form data validation warnings', {
                    crfId,
                    warnings: validationResult.warnings
                });
            }
        }
        catch (validationError) {
            // Don't block save if validation service fails
            logger_1.logger.warn('Validation check failed, proceeding with save', {
                error: validationError.message
            });
        }
    }
    // Normalize request for SOAP service
    const normalizedRequest = {
        studyId: request.studyId,
        subjectId: request.subjectId,
        studyEventDefinitionId: eventDefId,
        crfId: crfId,
        formData: formData || {}
    };
    // Try SOAP service first for GxP-compliant data entry
    try {
        const soapResult = await dataSoap.importData(normalizedRequest, userId, username);
        if (soapResult.success) {
            return soapResult;
        }
        logger_1.logger.warn('SOAP import failed, falling back to database', { error: soapResult.message });
    }
    catch (soapError) {
        logger_1.logger.warn('SOAP service unavailable, falling back to database', { error: soapError.message });
    }
    // Fallback: Direct database insert for data entry
    // This maintains audit trail compliance by using the existing LibreClinica tables
    return await saveFormDataDirect(normalizedRequest, userId, username);
};
exports.saveFormData = saveFormData;
/**
 * Direct database save fallback for form data
 * Uses LibreClinica's existing tables: event_crf, item_data
 * 21 CFR Part 11 compliant with proper audit logging
 */
const saveFormDataDirect = async (request, userId, username) => {
    logger_1.logger.info('Saving form data directly to database', {
        studyId: request.studyId,
        subjectId: request.subjectId,
        crfId: request.crfId
    });
    const client = await database_1.pool.connect();
    try {
        await client.query('BEGIN');
        // 1. Find or create the study_event for this subject and event definition
        let studyEventId = null;
        const studyEventResult = await client.query(`
      SELECT se.study_event_id 
      FROM study_event se
      INNER JOIN study_subject ss ON se.study_subject_id = ss.study_subject_id
      WHERE ss.study_subject_id = $1 
        AND se.study_event_definition_id = $2
      ORDER BY se.sample_ordinal DESC
      LIMIT 1
    `, [request.subjectId, request.studyEventDefinitionId]);
        if (studyEventResult.rows.length > 0) {
            studyEventId = studyEventResult.rows[0].study_event_id;
        }
        else {
            // Create the study event
            const createEventResult = await client.query(`
        INSERT INTO study_event (
          study_event_definition_id, study_subject_id, sample_ordinal,
          date_start, owner_id, status_id, subject_event_status_id, date_created
        ) VALUES ($1, $2, 1, CURRENT_DATE, $3, 1, 3, NOW())
        RETURNING study_event_id
      `, [request.studyEventDefinitionId, request.subjectId, userId]);
            studyEventId = createEventResult.rows[0].study_event_id;
            logger_1.logger.info('Created study event', { studyEventId });
        }
        // 2. Get the CRF version
        const crfVersionResult = await client.query(`
      SELECT crf_version_id FROM crf_version
      WHERE crf_id = $1 AND status_id = 1
      ORDER BY crf_version_id DESC
      LIMIT 1
    `, [request.crfId]);
        if (crfVersionResult.rows.length === 0) {
            throw new Error(`No active version found for CRF ${request.crfId}`);
        }
        const crfVersionId = crfVersionResult.rows[0].crf_version_id;
        // 3. Find or create the event_crf
        let eventCrfId = null;
        const eventCrfResult = await client.query(`
      SELECT event_crf_id FROM event_crf
      WHERE study_event_id = $1 AND crf_version_id = $2
      LIMIT 1
    `, [studyEventId, crfVersionId]);
        if (eventCrfResult.rows.length > 0) {
            eventCrfId = eventCrfResult.rows[0].event_crf_id;
            // CHECK IF RECORD IS LOCKED - status_id = 6 means locked
            // This is critical for 21 CFR Part 11 compliance (§11.10(d))
            const lockCheckResult = await client.query(`
        SELECT status_id FROM event_crf WHERE event_crf_id = $1
      `, [eventCrfId]);
            if (lockCheckResult.rows.length > 0 && lockCheckResult.rows[0].status_id === 6) {
                await client.query('ROLLBACK');
                logger_1.logger.warn('Attempted to edit locked record', { eventCrfId, userId });
                return {
                    success: false,
                    message: 'Cannot edit data - this record is locked. Request an unlock through the Data Lock Management system.',
                    errors: ['RECORD_LOCKED']
                };
            }
        }
        else {
            // Create the event_crf
            const createEventCrfResult = await client.query(`
        INSERT INTO event_crf (
          study_event_id, crf_version_id, study_subject_id,
          date_interviewed, interviewer_name,
          completion_status_id, status_id, owner_id, date_created
        ) VALUES ($1, $2, $3, CURRENT_DATE, $4, 1, 1, $5, NOW())
        RETURNING event_crf_id
      `, [studyEventId, crfVersionId, request.subjectId, username, userId]);
            eventCrfId = createEventCrfResult.rows[0].event_crf_id;
            logger_1.logger.info('Created event_crf', { eventCrfId });
        }
        // 4. Get item mappings for this CRF version
        const itemsResult = await client.query(`
      SELECT i.item_id, i.name, i.oc_oid
      FROM item i
      INNER JOIN item_group_metadata igm ON i.item_id = igm.item_id
      WHERE igm.crf_version_id = $1
    `, [crfVersionId]);
        const itemMap = new Map();
        for (const item of itemsResult.rows) {
            itemMap.set(item.name.toLowerCase(), item.item_id);
            if (item.oc_oid) {
                itemMap.set(item.oc_oid.toLowerCase(), item.item_id);
            }
        }
        // 5. Save each form field value to item_data
        let savedCount = 0;
        const formData = request.formData || {};
        for (const [fieldName, value] of Object.entries(formData)) {
            if (value === null || value === undefined || value === '')
                continue;
            // Find the item_id for this field
            const itemId = itemMap.get(fieldName.toLowerCase());
            if (!itemId) {
                logger_1.logger.debug('Field not found in CRF, skipping', { fieldName });
                continue;
            }
            // Check if item_data already exists
            const existingResult = await client.query(`
        SELECT item_data_id, value FROM item_data
        WHERE event_crf_id = $1 AND item_id = $2
        LIMIT 1
      `, [eventCrfId, itemId]);
            let stringValue = String(value);
            // 21 CFR Part 11 §11.10(a) - Encrypt sensitive form data at rest
            // Only encrypt if field-level encryption is enabled
            if (environment_1.config.encryption?.enableFieldEncryption) {
                stringValue = (0, encryption_util_1.encryptField)(stringValue);
            }
            if (existingResult.rows.length > 0) {
                // Update existing
                const oldValue = existingResult.rows[0].value;
                if (oldValue !== stringValue) {
                    await client.query(`
            UPDATE item_data
            SET value = $1, date_updated = NOW(), update_id = $2
            WHERE item_data_id = $3
          `, [stringValue, userId, existingResult.rows[0].item_data_id]);
                    // Log change to audit trail
                    await client.query(`
            INSERT INTO audit_log_event (
              audit_date, audit_table, user_id, entity_id,
              old_value, new_value, audit_log_event_type_id,
              event_crf_id
            ) VALUES (NOW(), 'item_data', $1, $2, $3, $4, 1, $5)
          `, [userId, existingResult.rows[0].item_data_id, oldValue, stringValue, eventCrfId]);
                }
            }
            else {
                // Insert new
                const insertResult = await client.query(`
          INSERT INTO item_data (
            item_id, event_crf_id, value, status_id, owner_id, date_created, ordinal
          ) VALUES ($1, $2, $3, 1, $4, NOW(), 1)
          RETURNING item_data_id
        `, [itemId, eventCrfId, stringValue, userId]);
                // Log creation to audit trail
                await client.query(`
          INSERT INTO audit_log_event (
            audit_date, audit_table, user_id, entity_id,
            new_value, audit_log_event_type_id, event_crf_id
          ) VALUES (NOW(), 'item_data', $1, $2, $3, 4, $4)
        `, [userId, insertResult.rows[0].item_data_id, stringValue, eventCrfId]);
            }
            savedCount++;
        }
        // 6. Update event_crf completion status
        await client.query(`
      UPDATE event_crf
      SET completion_status_id = 2, date_updated = NOW(), update_id = $1
      WHERE event_crf_id = $2
    `, [userId, eventCrfId]);
        await client.query('COMMIT');
        logger_1.logger.info('Form data saved directly to database', {
            eventCrfId,
            savedCount,
            totalFields: Object.keys(formData).length
        });
        // 7. AUTO-TRIGGER WORKFLOW: Create SDV task for completed form (Real EDC workflow)
        // This automatically creates a workflow task when form data is saved
        try {
            // Get form details for workflow creation
            const formDetailsResult = await database_1.pool.query(`
        SELECT 
          c.name as form_name,
          ss.study_subject_id as subject_id
        FROM event_crf ec
        JOIN crf_version cv ON ec.crf_version_id = cv.crf_version_id
        JOIN crf c ON cv.crf_id = c.crf_id
        JOIN study_subject ss ON ec.study_subject_id = ss.study_subject_id
        WHERE ec.event_crf_id = $1
      `, [eventCrfId]);
            if (formDetailsResult.rows.length > 0) {
                const formName = formDetailsResult.rows[0].form_name;
                const subjectId = formDetailsResult.rows[0].subject_id;
                // Trigger SDV workflow automatically
                await workflowService.triggerFormSubmittedWorkflow(eventCrfId, request.studyId, subjectId, formName, userId);
                logger_1.logger.info('Auto-triggered SDV workflow for form submission', { eventCrfId, formName });
            }
        }
        catch (workflowError) {
            // Don't fail the form save if workflow creation fails
            logger_1.logger.warn('Failed to auto-create workflow for form submission', { error: workflowError.message });
        }
        return {
            success: true,
            data: { eventCrfId, savedCount },
            message: `Form data saved successfully (${savedCount} fields)`
        };
    }
    catch (error) {
        await client.query('ROLLBACK');
        logger_1.logger.error('Direct database save failed', { error: error.message });
        return {
            success: false,
            message: `Failed to save form data: ${error.message}`
        };
    }
    finally {
        client.release();
    }
};
/**
 * Get form data from database
 * Returns data along with lock status for UI to respect
 */
const getFormData = async (eventCrfId) => {
    logger_1.logger.info('Getting form data', { eventCrfId });
    try {
        // First check the lock status of the event_crf
        const lockQuery = `
      SELECT ec.status_id, ec.date_updated as lock_date, u.user_name as locked_by
      FROM event_crf ec
      LEFT JOIN user_account u ON ec.update_id = u.user_id
      WHERE ec.event_crf_id = $1
    `;
        const lockResult = await database_1.pool.query(lockQuery, [eventCrfId]);
        const isLocked = lockResult.rows.length > 0 && lockResult.rows[0].status_id === 6;
        const lockInfo = isLocked ? {
            locked: true,
            lockedAt: lockResult.rows[0].lock_date,
            lockedBy: lockResult.rows[0].locked_by
        } : { locked: false };
        const query = `
      SELECT 
        id.item_data_id,
        i.name as item_name,
        i.oc_oid as item_oid,
        id.value,
        id.status_id,
        id.date_created,
        id.date_updated,
        u.user_name as entered_by
      FROM item_data id
      INNER JOIN item i ON id.item_id = i.item_id
      LEFT JOIN user_account u ON id.owner_id = u.user_id
      WHERE id.event_crf_id = $1
        AND id.deleted = false
      ORDER BY i.name
    `;
        const result = await database_1.pool.query(query, [eventCrfId]);
        // 21 CFR Part 11 §11.10(a) - Decrypt encrypted form data
        // Transparently decrypt any encrypted values before returning
        const decryptedRows = result.rows.map(row => {
            if (row.value && (0, encryption_util_1.isEncrypted)(row.value)) {
                try {
                    return { ...row, value: (0, encryption_util_1.decryptField)(row.value) };
                }
                catch (decryptError) {
                    logger_1.logger.error('Failed to decrypt form field', {
                        itemDataId: row.item_data_id,
                        error: decryptError.message
                    });
                    // Return encrypted value with marker for troubleshooting
                    return { ...row, value: '[DECRYPTION_ERROR]', encryptedValue: row.value };
                }
            }
            return row;
        });
        // Return data with lock status for UI to respect
        return {
            data: decryptedRows,
            lockStatus: lockInfo
        };
    }
    catch (error) {
        logger_1.logger.error('Get form data error', { error: error.message });
        throw error;
    }
};
exports.getFormData = getFormData;
/**
 * Get form metadata with all field properties
 */
const getFormMetadata = async (crfId) => {
    logger_1.logger.info('Getting form metadata', { crfId });
    try {
        // Get CRF info
        const crfQuery = `
      SELECT * FROM crf WHERE crf_id = $1
    `;
        const crfResult = await database_1.pool.query(crfQuery, [crfId]);
        if (crfResult.rows.length === 0) {
            return null;
        }
        const crf = crfResult.rows[0];
        // Get latest version
        const versionQuery = `
      SELECT * FROM crf_version
      WHERE crf_id = $1
      ORDER BY crf_version_id DESC
      LIMIT 1
    `;
        const versionResult = await database_1.pool.query(versionQuery, [crfId]);
        const versionId = versionResult.rows[0]?.crf_version_id;
        // Get sections
        const sectionsQuery = `
      SELECT 
        section_id,
        label,
        title,
        subtitle,
        instructions,
        ordinal
      FROM section
      WHERE crf_version_id = $1
      ORDER BY ordinal
    `;
        const sectionsResult = await database_1.pool.query(sectionsQuery, [versionId]);
        // Get item groups
        const itemGroupsQuery = `
      SELECT DISTINCT
        ig.item_group_id,
        ig.name,
        ig.oc_oid
      FROM item_group ig
      INNER JOIN item_group_metadata igm ON ig.item_group_id = igm.item_group_id
      WHERE igm.crf_version_id = $1
      ORDER BY ig.name
    `;
        const itemGroupsResult = await database_1.pool.query(itemGroupsQuery, [versionId]);
        // Get items with their full metadata including required, default, validation, options
        const itemsQuery = `
      SELECT 
        i.item_id,
        i.name,
        i.description,
        i.units,
        i.oc_oid,
        idt.name as data_type,
        idt.code as data_type_code,
        igm.ordinal,
        ig.name as group_name,
        -- Additional metadata from item_form_metadata
        ifm.required,
        ifm.default_value,
        ifm.left_item_text as placeholder,
        ifm.regexp as validation_pattern,
        ifm.regexp_error_msg as validation_message,
        ifm.show_item,
        -- Options from response_set
        rs.options_text,
        rs.options_values,
        rt.name as response_type,
        -- Section info
        s.label as section_name
      FROM item i
      INNER JOIN item_group_metadata igm ON i.item_id = igm.item_id
      INNER JOIN item_group ig ON igm.item_group_id = ig.item_group_id
      INNER JOIN item_data_type idt ON i.item_data_type_id = idt.item_data_type_id
      LEFT JOIN item_form_metadata ifm ON i.item_id = ifm.item_id AND ifm.crf_version_id = $1
      LEFT JOIN response_set rs ON ifm.response_set_id = rs.response_set_id
      LEFT JOIN response_type rt ON rs.response_type_id = rt.response_type_id
      LEFT JOIN section s ON ifm.section_id = s.section_id
      WHERE igm.crf_version_id = $1
      ORDER BY COALESCE(ifm.ordinal, igm.ordinal)
    `;
        const itemsResult = await database_1.pool.query(itemsQuery, [versionId]);
        // Get Simple Conditional Display (SCD) metadata - LibreClinica's skip logic
        // scd_item_metadata stores show/hide conditions based on other field values
        const scdQuery = `
      SELECT 
        scd.id as scd_id,
        scd.scd_item_form_metadata_id,    -- The item to show/hide
        scd.control_item_form_metadata_id, -- The controlling item
        scd.control_item_name,             -- Name of the controlling item
        scd.option_value,                  -- Value that triggers showing
        scd.message,
        ifm_target.item_id as target_item_id,
        ifm_control.item_id as control_item_id,
        i_control.name as control_field_name
      FROM scd_item_metadata scd
      INNER JOIN item_form_metadata ifm_target ON scd.scd_item_form_metadata_id = ifm_target.item_form_metadata_id
      LEFT JOIN item_form_metadata ifm_control ON scd.control_item_form_metadata_id = ifm_control.item_form_metadata_id
      LEFT JOIN item i_control ON ifm_control.item_id = i_control.item_id
      WHERE ifm_target.crf_version_id = $1
    `;
        const scdResult = await database_1.pool.query(scdQuery, [versionId]);
        // Build a map of item_id -> SCD conditions for quick lookup
        const scdByItemId = new Map();
        for (const scd of scdResult.rows) {
            const conditions = scdByItemId.get(scd.target_item_id) || [];
            conditions.push({
                fieldId: scd.control_field_name || scd.control_item_name,
                operator: 'equals', // SCD uses simple equality check
                value: scd.option_value,
                message: scd.message
            });
            scdByItemId.set(scd.target_item_id, conditions);
        }
        // Parse items with all properties including extended props
        const items = itemsResult.rows.map(item => {
            // Parse options
            let options = null;
            if (item.options_text && item.options_values) {
                const labels = item.options_text.split(',');
                const values = item.options_values.split(',');
                options = labels.map((label, idx) => ({
                    label: label.trim(),
                    value: values[idx]?.trim() || label.trim()
                }));
            }
            // Parse description for help text and extended properties
            let helpText = item.description || '';
            let extendedProps = {};
            if (helpText.includes('---EXTENDED_PROPS---')) {
                const parts = helpText.split('---EXTENDED_PROPS---');
                helpText = parts[0].trim();
                try {
                    extendedProps = JSON.parse(parts[1].trim());
                }
                catch (e) {
                    // Ignore parse errors
                }
            }
            // Parse min/max from width_decimal if present
            let min = extendedProps.min;
            let max = extendedProps.max;
            if (item.width_decimal && item.width_decimal.includes(',')) {
                const [minVal, maxVal] = item.width_decimal.split(',');
                if (minVal && !isNaN(Number(minVal)))
                    min = Number(minVal);
                if (maxVal && !isNaN(Number(maxVal)))
                    max = Number(maxVal);
            }
            // Build validation rules array
            const validationRules = [];
            if (item.required) {
                validationRules.push({ type: 'required', message: 'This field is required' });
            }
            if (item.validation_pattern) {
                validationRules.push({
                    type: 'pattern',
                    value: item.validation_pattern,
                    message: item.validation_message || 'Invalid format'
                });
            }
            if (min !== undefined) {
                validationRules.push({ type: 'min', value: min, message: `Minimum value is ${min}` });
            }
            if (max !== undefined) {
                validationRules.push({ type: 'max', value: max, message: `Maximum value is ${max}` });
            }
            return {
                // Core identifiers
                id: item.item_id?.toString(),
                item_id: item.item_id,
                name: item.name,
                oc_oid: item.oc_oid,
                // Type info
                type: item.data_type_code?.toLowerCase() || 'text',
                data_type: item.data_type,
                data_type_code: item.data_type_code,
                // Display
                label: item.name,
                description: helpText,
                helpText: helpText,
                placeholder: item.placeholder || '',
                // State
                required: item.required || false,
                readonly: extendedProps.readonly || false,
                hidden: item.show_item === false,
                // Value
                defaultValue: item.default_value,
                // Validation
                validationRules,
                validationPattern: item.validation_pattern,
                validationMessage: item.validation_message,
                // Options
                options,
                // Layout
                ordinal: item.ordinal,
                order: item.ordinal,
                section: item.section_name,
                group_name: item.group_name,
                width: extendedProps.width,
                columnPosition: extendedProps.columnPosition,
                groupId: extendedProps.groupId,
                // Clinical
                unit: item.units || extendedProps.unit,
                units: item.units,
                min,
                max,
                format: extendedProps.format,
                // PHI and Compliance
                isPhiField: item.phi_status || extendedProps.isPhiField || false,
                phi_status: item.phi_status,
                phiClassification: extendedProps.phiClassification,
                auditRequired: extendedProps.auditRequired || false,
                criticalDataPoint: extendedProps.criticalDataPoint || false,
                auditTrail: extendedProps.auditTrail,
                // Linked/Nested
                linkedFormIds: extendedProps.linkedFormIds,
                patientDataMapping: extendedProps.patientDataMapping,
                nestedFormId: extendedProps.nestedFormId,
                allowMultiple: extendedProps.allowMultiple,
                // File upload
                allowedFileTypes: extendedProps.allowedFileTypes,
                maxFileSize: extendedProps.maxFileSize,
                maxFiles: extendedProps.maxFiles,
                // Calculated
                calculationFormula: extendedProps.calculationFormula,
                dependsOn: extendedProps.dependsOn,
                // Conditional Logic - merge from scd_item_metadata (LibreClinica skip logic) and extended props
                showWhen: scdByItemId.get(item.item_id) || extendedProps.showWhen || [],
                requiredWhen: extendedProps.requiredWhen,
                conditionalLogic: extendedProps.conditionalLogic,
                visibilityConditions: extendedProps.visibilityConditions,
                // Flag to indicate if using LibreClinica native SCD
                hasNativeScd: scdByItemId.has(item.item_id),
                // Custom
                customAttributes: extendedProps.customAttributes
            };
        });
        // Get decision conditions (forking/branching) from LibreClinica
        // decision_condition table handles form/section branching based on values
        let decisionConditions = [];
        try {
            const dcQuery = `
        SELECT 
          dc.decision_condition_id,
          dc.crf_version_id,
          dc.label,
          dc.comments,
          dc.quantity,
          dc.type,
          -- Get dc_primitive conditions
          dcp.dc_primitive_id,
          dcp.item_id,
          dcp.comparison_operator,
          dcp.value as comparison_value,
          dcp.dynamic_value_item_id,
          i.name as item_name,
          i.oc_oid as item_oid,
          -- Get dc_event actions
          dce.dc_event_id,
          -- Section events
          dcse.section_id,
          s.label as section_label,
          -- Computed events (calculations)
          dcce.dc_summary_event_id,
          dcce.item_target_id,
          -- Substitution events
          dcsu.item_id as substitution_item_id,
          dcsu.replacement_value
        FROM decision_condition dc
        LEFT JOIN dc_primitive dcp ON dc.decision_condition_id = dcp.decision_condition_id
        LEFT JOIN item i ON dcp.item_id = i.item_id
        LEFT JOIN dc_event dce ON dc.decision_condition_id = dce.decision_condition_id
        LEFT JOIN dc_section_event dcse ON dce.dc_event_id = dcse.dc_event_id
        LEFT JOIN section s ON dcse.section_id = s.section_id
        LEFT JOIN dc_computed_event dcce ON dce.dc_event_id = dcce.dc_event_id
        LEFT JOIN dc_substitution_event dcsu ON dce.dc_event_id = dcsu.dc_event_id
        WHERE dc.crf_version_id = $1 AND dc.status_id = 1
        ORDER BY dc.decision_condition_id
      `;
            const dcResult = await database_1.pool.query(dcQuery, [versionId]);
            // Group by decision_condition_id
            const dcMap = new Map();
            for (const row of dcResult.rows) {
                if (!dcMap.has(row.decision_condition_id)) {
                    dcMap.set(row.decision_condition_id, {
                        id: row.decision_condition_id,
                        label: row.label,
                        comments: row.comments,
                        quantity: row.quantity,
                        type: row.type,
                        conditions: [],
                        actions: []
                    });
                }
                const dc = dcMap.get(row.decision_condition_id);
                // Add condition primitive
                if (row.dc_primitive_id && !dc.conditions.some((c) => c.primitiveId === row.dc_primitive_id)) {
                    dc.conditions.push({
                        primitiveId: row.dc_primitive_id,
                        itemId: row.item_id,
                        itemName: row.item_name,
                        itemOid: row.item_oid,
                        operator: row.comparison_operator,
                        value: row.comparison_value,
                        dynamicValueItemId: row.dynamic_value_item_id
                    });
                }
                // Add action - section show/hide
                if (row.section_id && !dc.actions.some((a) => a.sectionId === row.section_id)) {
                    dc.actions.push({
                        type: 'section',
                        sectionId: row.section_id,
                        sectionLabel: row.section_label
                    });
                }
                // Add action - computed/calculation
                if (row.dc_summary_event_id && !dc.actions.some((a) => a.summaryEventId === row.dc_summary_event_id)) {
                    dc.actions.push({
                        type: 'calculation',
                        summaryEventId: row.dc_summary_event_id,
                        targetItemId: row.item_target_id
                    });
                }
                // Add action - substitution
                if (row.substitution_item_id && !dc.actions.some((a) => a.substitutionItemId === row.substitution_item_id)) {
                    dc.actions.push({
                        type: 'substitution',
                        substitutionItemId: row.substitution_item_id,
                        replacementValue: row.replacement_value
                    });
                }
            }
            decisionConditions = Array.from(dcMap.values());
        }
        catch (dcError) {
            // Decision condition tables might not exist in all installations
            logger_1.logger.debug('Decision conditions query failed (optional):', dcError.message);
        }
        return {
            crf,
            version: versionResult.rows[0],
            sections: sectionsResult.rows,
            itemGroups: itemGroupsResult.rows,
            items,
            // LibreClinica decision conditions for forking/branching
            decisionConditions
        };
    }
    catch (error) {
        logger_1.logger.error('Get form metadata error', { error: error.message });
        throw error;
    }
};
exports.getFormMetadata = getFormMetadata;
/**
 * Get form status
 */
const getFormStatus = async (eventCrfId) => {
    logger_1.logger.info('Getting form status', { eventCrfId });
    try {
        const query = `
      SELECT 
        ec.event_crf_id,
        ec.completion_status_id,
        cs.name as completion_status,
        ec.date_created,
        ec.date_updated,
        u1.user_name as created_by,
        u2.user_name as updated_by,
        ec.validator_id,
        u3.user_name as validated_by,
        ec.date_validate,
        ec.sdv_status
      FROM event_crf ec
      INNER JOIN completion_status cs ON ec.completion_status_id = cs.completion_status_id
      LEFT JOIN user_account u1 ON ec.owner_id = u1.user_id
      LEFT JOIN user_account u2 ON ec.update_id = u2.user_id
      LEFT JOIN user_account u3 ON ec.validator_id = u3.user_id
      WHERE ec.event_crf_id = $1
    `;
        const result = await database_1.pool.query(query, [eventCrfId]);
        if (result.rows.length === 0) {
            return null;
        }
        return result.rows[0];
    }
    catch (error) {
        logger_1.logger.error('Get form status error', { error: error.message });
        throw error;
    }
};
exports.getFormStatus = getFormStatus;
/**
 * Validate form data (business rules)
 */
const validateFormData = (formData) => {
    const errors = [];
    // Basic validation (extend as needed)
    if (!formData || Object.keys(formData).length === 0) {
        errors.push('Form data is empty');
    }
    return {
        isValid: errors.length === 0,
        errors
    };
};
exports.validateFormData = validateFormData;
/**
 * Get all CRFs (Form Templates) for a study
 */
const getStudyForms = async (studyId) => {
    logger_1.logger.info('Getting study forms', { studyId });
    try {
        const query = `
      SELECT 
        c.crf_id,
        c.name,
        c.description,
        c.oc_oid,
        c.status_id,
        s.name as status_name,
        c.date_created,
        c.date_updated,
        (SELECT COUNT(*) FROM crf_version WHERE crf_id = c.crf_id) as version_count,
        (SELECT name FROM crf_version WHERE crf_id = c.crf_id ORDER BY crf_version_id DESC LIMIT 1) as latest_version
      FROM crf c
      INNER JOIN status s ON c.status_id = s.status_id
      WHERE c.source_study_id = $1
      ORDER BY c.name
    `;
        const result = await database_1.pool.query(query, [studyId]);
        return result.rows;
    }
    catch (error) {
        logger_1.logger.error('Get study forms error', { error: error.message });
        throw error;
    }
};
exports.getStudyForms = getStudyForms;
/**
 * Get all CRFs (templates) - includes drafts and published
 * Status IDs: 1=available, 2=unavailable/locked, 5=removed
 */
const getAllForms = async () => {
    logger_1.logger.info('Getting all forms');
    try {
        const query = `
      SELECT 
        c.crf_id,
        c.name,
        c.description,
        c.oc_oid,
        c.status_id,
        s.name as status_name,
        st.name as study_name,
        st.study_id,
        c.date_created,
        c.date_updated,
        (SELECT COUNT(*) FROM crf_version WHERE crf_id = c.crf_id) as version_count,
        (SELECT MAX(revision_notes) FROM crf_version WHERE crf_id = c.crf_id) as latest_version
      FROM crf c
      INNER JOIN status s ON c.status_id = s.status_id
      LEFT JOIN study st ON c.source_study_id = st.study_id
      WHERE c.status_id IN (1, 2)
      ORDER BY c.date_created DESC, c.name
    `;
        const result = await database_1.pool.query(query);
        logger_1.logger.info('Forms retrieved', { count: result.rows.length });
        return result.rows;
    }
    catch (error) {
        logger_1.logger.error('Get all forms error', { error: error.message });
        throw error;
    }
};
exports.getAllForms = getAllForms;
/**
 * Get CRF by ID
 */
const getFormById = async (crfId) => {
    logger_1.logger.info('Getting form by ID', { crfId });
    try {
        const query = `
      SELECT 
        c.*,
        s.name as status_name,
        st.name as study_name,
        (SELECT COUNT(*) FROM crf_version WHERE crf_id = c.crf_id) as version_count
      FROM crf c
      INNER JOIN status s ON c.status_id = s.status_id
      LEFT JOIN study st ON c.source_study_id = st.study_id
      WHERE c.crf_id = $1
    `;
        const result = await database_1.pool.query(query, [crfId]);
        if (result.rows.length === 0) {
            return null;
        }
        return result.rows[0];
    }
    catch (error) {
        logger_1.logger.error('Get form by ID error', { error: error.message });
        throw error;
    }
};
exports.getFormById = getFormById;
/**
 * Map frontend field type to LibreClinica item_data_type_id
 */
const mapFieldTypeToDataType = (fieldType) => {
    const typeMap = {
        'text': 5, // ST - Character String
        'textarea': 5, // ST - Character String
        'email': 5, // ST - Character String
        'phone': 5, // ST - Character String
        'number': 6, // INT - Integer
        'integer': 6, // INT - Integer
        'decimal': 7, // REAL - Floating
        'float': 7, // REAL - Floating
        'date': 9, // DATE
        'pdate': 10, // PDATE - Partial date
        'checkbox': 1, // BL - Boolean
        'radio': 5, // ST - stored as string
        'select': 5, // ST - stored as string
        'file': 11 // FILE
    };
    return typeMap[fieldType?.toLowerCase()] || 5; // Default to ST (string)
};
/**
 * Serialize extended field properties to JSON for storage
 */
const serializeExtendedProperties = (field) => {
    const extended = {
        // PHI and Compliance
        isPhiField: field.isPhiField,
        phiClassification: field.phiClassification,
        auditRequired: field.auditRequired,
        linkedFormIds: field.linkedFormIds,
        patientDataMapping: field.patientDataMapping,
        // Nested Form
        nestedFormId: field.nestedFormId,
        allowMultiple: field.allowMultiple,
        // File Upload
        allowedFileTypes: field.allowedFileTypes,
        maxFileSize: field.maxFileSize,
        maxFiles: field.maxFiles,
        // Layout
        width: field.width,
        columnPosition: field.columnPosition,
        groupId: field.groupId,
        // Calculated
        calculationFormula: field.calculationFormula,
        dependsOn: field.dependsOn,
        // Conditional Logic
        showWhen: field.showWhen,
        requiredWhen: field.requiredWhen,
        conditionalLogic: field.conditionalLogic,
        visibilityConditions: field.visibilityConditions,
        // Clinical
        unit: field.unit,
        min: field.min,
        max: field.max,
        format: field.format,
        // Audit
        criticalDataPoint: field.criticalDataPoint,
        auditTrail: field.auditTrail,
        // Custom
        customAttributes: field.customAttributes,
        // Readonly
        readonly: field.readonly || field.isReadonly
    };
    // Remove undefined values
    Object.keys(extended).forEach(key => {
        if (extended[key] === undefined) {
            delete extended[key];
        }
    });
    return Object.keys(extended).length > 0 ? JSON.stringify(extended) : '';
};
/**
 * Map field type to LibreClinica response_type_id
 *
 * LibreClinica Response Types:
 * 1 = text
 * 2 = textarea
 * 3 = checkbox
 * 4 = file upload
 * 5 = radio
 * 6 = single-select (dropdown)
 * 7 = multi-select
 * 8 = calculation (auto-calculated field)
 * 9 = group-calculation (calculation across repeating groups)
 * 10 = instant-calculation / barcode
 */
const mapFieldTypeToResponseType = (fieldType) => {
    const typeMap = {
        // Basic types (1-7)
        'text': 1,
        'textarea': 2,
        'checkbox': 3,
        'file': 4,
        'image': 4, // images also use file response type
        'radio': 5,
        'select': 6,
        'dropdown': 6,
        'multiselect': 7,
        'multi-select': 7,
        // Calculated types (8-9)
        'calculation': 8,
        'calculated': 8,
        'bmi': 8, // BMI is a calculated field
        'bsa': 8, // Body Surface Area
        'egfr': 8, // eGFR calculation
        'age': 8, // Age calculation
        'group_calculation': 9,
        'group-calculation': 9,
        'sum': 9, // Sum across repeating group
        'average': 9, // Average across group
        // Instant/Barcode (10)
        'instant': 10,
        'barcode': 10,
        'qrcode': 10,
        // Clinical field aliases map to appropriate types
        'integer': 1,
        'decimal': 1,
        'number': 1,
        'date': 1,
        'datetime': 1,
        'time': 1,
        'email': 1,
        'phone': 1,
        'height': 1,
        'weight': 1,
        'temperature': 1,
        'heart_rate': 1,
        'blood_pressure': 1,
        'oxygen_saturation': 1,
        'respiration_rate': 1,
        'yesno': 5 // Yes/No uses radio type
    };
    return typeMap[fieldType?.toLowerCase()] || 1;
};
/**
 * Create a new form template (CRF) with fields
 */
const createForm = async (data, userId) => {
    logger_1.logger.info('Creating form template', { name: data.name, userId, fieldCount: data.fields?.length || 0 });
    const client = await database_1.pool.connect();
    try {
        await client.query('BEGIN');
        // Generate OC OID for CRF
        const timestamp = Date.now().toString().slice(-6);
        const ocOid = `F_${data.name.replace(/[^a-zA-Z0-9]/g, '_').toUpperCase().substring(0, 24)}_${timestamp}`;
        // Check if OC OID exists
        const existsCheck = await client.query(`SELECT crf_id FROM crf WHERE oc_oid = $1`, [ocOid]);
        if (existsCheck.rows.length > 0) {
            await client.query('ROLLBACK');
            return {
                success: false,
                message: 'A form with this name already exists'
            };
        }
        // Insert CRF
        const crfResult = await client.query(`
      INSERT INTO crf (
        name, description, status_id, owner_id, date_created, oc_oid, source_study_id
      ) VALUES (
        $1, $2, 1, $3, NOW(), $4, $5
      )
      RETURNING crf_id
    `, [
            data.name,
            data.description || '',
            userId,
            ocOid,
            data.studyId || null
        ]);
        const crfId = crfResult.rows[0].crf_id;
        // Create initial version
        const versionOid = `${ocOid}_V1`;
        const versionResult = await client.query(`
      INSERT INTO crf_version (
        crf_id, name, description, status_id, owner_id, date_created, oc_oid
      ) VALUES (
        $1, $2, $3, 1, $4, NOW(), $5
      )
      RETURNING crf_version_id
    `, [
            crfId,
            data.version || 'v1.0',
            data.description || 'Initial version',
            userId,
            versionOid
        ]);
        const crfVersionId = versionResult.rows[0].crf_version_id;
        // Create fields if provided
        if (data.fields && data.fields.length > 0) {
            // Create a default section for the form
            const sectionResult = await client.query(`
        INSERT INTO section (
          crf_version_id, status_id, label, title, ordinal, owner_id, date_created
        ) VALUES (
          $1, 1, $2, $3, 1, $4, NOW()
        )
        RETURNING section_id
      `, [
                crfVersionId,
                data.category || 'Form Fields',
                data.name,
                userId
            ]);
            const sectionId = sectionResult.rows[0].section_id;
            // Create a default item group for the form with unique OID
            const randomSuffix = Math.random().toString(36).substring(2, 8).toUpperCase();
            const groupOid = `IG_${ocOid.substring(2, 16)}_${randomSuffix}`;
            const itemGroupResult = await client.query(`
        INSERT INTO item_group (
          name, crf_id, status_id, owner_id, date_created, oc_oid
        ) VALUES (
          $1, $2, 1, $3, NOW(), $4
        )
        RETURNING item_group_id
      `, [
                data.category || 'Form Fields',
                crfId,
                userId,
                groupOid
            ]);
            const itemGroupId = itemGroupResult.rows[0].item_group_id;
            // Create each field as an item with full metadata
            for (let i = 0; i < data.fields.length; i++) {
                const field = data.fields[i];
                // Generate unique item OID with random suffix to avoid collisions
                const itemRandom = Math.random().toString(36).substring(2, 6).toUpperCase();
                const itemOid = `I_${ocOid.substring(2, 12)}_${i}_${itemRandom}`;
                const dataTypeId = mapFieldTypeToDataType(field.type);
                // Serialize extended properties to JSON
                const extendedProps = serializeExtendedProperties(field);
                // Build description with help text and extended properties
                let description = field.helpText || field.description || '';
                if (extendedProps) {
                    // Store extended props as JSON at end of description, marked with special delimiter
                    description = description ? `${description}\n---EXTENDED_PROPS---\n${extendedProps}` : `---EXTENDED_PROPS---\n${extendedProps}`;
                }
                // Insert item with PHI status and units
                const itemResult = await client.query(`
          INSERT INTO item (
            name, description, units, phi_status, item_data_type_id, 
            status_id, owner_id, date_created, oc_oid
          ) VALUES (
            $1, $2, $3, $4, $5, 1, $6, NOW(), $7
          )
          RETURNING item_id
        `, [
                    field.label || field.name || `Field ${i + 1}`,
                    description,
                    field.unit || '', // Clinical units
                    field.isPhiField || false, // PHI status
                    dataTypeId,
                    userId,
                    itemOid
                ]);
                const itemId = itemResult.rows[0].item_id;
                // Link item to item_group via item_group_metadata
                await client.query(`
          INSERT INTO item_group_metadata (
            item_group_id, crf_version_id, item_id, ordinal, 
            show_group, repeating_group
          ) VALUES (
            $1, $2, $3, $4, true, false
          )
        `, [
                    itemGroupId,
                    crfVersionId,
                    itemId,
                    field.order || (i + 1)
                ]);
                // Create response_set for fields with options (select, radio, checkbox)
                let responseSetId = 1; // Default to text response type
                if (field.options && field.options.length > 0) {
                    const optionsText = field.options.map(o => o.label).join(',');
                    const optionsValues = field.options.map(o => o.value).join(',');
                    const responseTypeId = mapFieldTypeToResponseType(field.type);
                    const responseSetResult = await client.query(`
            INSERT INTO response_set (
              response_type_id, label, options_text, options_values, version_id
            ) VALUES (
              $1, $2, $3, $4, $5
            )
            RETURNING response_set_id
          `, [
                        responseTypeId,
                        field.label,
                        optionsText,
                        optionsValues,
                        crfVersionId
                    ]);
                    responseSetId = responseSetResult.rows[0].response_set_id;
                }
                else {
                    // Create a basic response set for non-option fields
                    const responseSetResult = await client.query(`
            INSERT INTO response_set (
              response_type_id, label, version_id
            ) VALUES (
              $1, $2, $3
            )
            RETURNING response_set_id
          `, [
                        mapFieldTypeToResponseType(field.type),
                        field.label,
                        crfVersionId
                    ]);
                    responseSetId = responseSetResult.rows[0].response_set_id;
                }
                // Extract validation pattern and message from validation rules
                let regexpPattern = null;
                let regexpErrorMsg = null;
                let widthDecimal = null;
                if (field.validationRules && field.validationRules.length > 0) {
                    // Pattern validation
                    const patternRule = field.validationRules.find(r => r.type === 'pattern');
                    if (patternRule) {
                        regexpPattern = patternRule.value;
                        regexpErrorMsg = patternRule.message || 'Invalid format';
                    }
                    // Min/Max validation - build pattern if needed
                    const minRule = field.validationRules.find(r => r.type === 'min');
                    const maxRule = field.validationRules.find(r => r.type === 'max');
                    if ((minRule || maxRule) && !regexpPattern) {
                        const min = minRule?.value ?? '';
                        const max = maxRule?.value ?? '';
                        if (field.type === 'number' || field.type === 'integer') {
                            // Store as width_decimal format: "min,max" or similar
                            widthDecimal = `${min},${max}`;
                        }
                    }
                    // Length validation
                    const minLengthRule = field.validationRules.find(r => r.type === 'minLength');
                    const maxLengthRule = field.validationRules.find(r => r.type === 'maxLength');
                    if (maxLengthRule && !widthDecimal) {
                        widthDecimal = maxLengthRule.value?.toString();
                    }
                }
                // Also use field.min/max if defined directly
                if (!widthDecimal && (field.min !== undefined || field.max !== undefined)) {
                    widthDecimal = `${field.min ?? ''},${field.max ?? ''}`;
                }
                // Create item_form_metadata with all field properties
                await client.query(`
          INSERT INTO item_form_metadata (
            item_id, crf_version_id, section_id, response_set_id, ordinal,
            left_item_text, required, default_value, regexp, regexp_error_msg, 
            show_item, width_decimal, column_number
          ) VALUES (
            $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13
          )
        `, [
                    itemId,
                    crfVersionId,
                    sectionId,
                    responseSetId,
                    field.order || (i + 1),
                    field.placeholder || '',
                    field.required || field.isRequired || false,
                    field.defaultValue !== undefined ? String(field.defaultValue) : null,
                    regexpPattern,
                    regexpErrorMsg,
                    (field.hidden !== true && field.isHidden !== true), // show_item is opposite of hidden
                    widthDecimal,
                    field.columnPosition || field.columnNumber || 1 // column_number for multi-column layout
                ]);
                logger_1.logger.debug('Created form field with metadata', {
                    itemId,
                    label: field.label,
                    type: field.type,
                    required: field.required,
                    columnNumber: field.columnPosition || field.columnNumber || 1,
                    hasOptions: field.options?.length || 0,
                    hasValidation: field.validationRules?.length || 0
                });
            }
            // Second pass: Create scd_item_metadata (skip logic) for fields with showWhen conditions
            // This must happen after all fields are created so we can reference them
            for (let i = 0; i < data.fields.length; i++) {
                const field = data.fields[i];
                // Check if field has showWhen conditions
                if (field.showWhen && Array.isArray(field.showWhen) && field.showWhen.length > 0) {
                    // Get the target item_form_metadata_id for this field
                    const targetIfmResult = await client.query(`
            SELECT ifm.item_form_metadata_id
            FROM item_form_metadata ifm
            INNER JOIN item i ON ifm.item_id = i.item_id
            WHERE ifm.crf_version_id = $1 AND i.name = $2
            LIMIT 1
          `, [crfVersionId, field.label || field.name]);
                    if (targetIfmResult.rows.length > 0) {
                        const targetIfmId = targetIfmResult.rows[0].item_form_metadata_id;
                        for (const condition of field.showWhen) {
                            // Find the control item's item_form_metadata_id by field name
                            const controlIfmResult = await client.query(`
                SELECT ifm.item_form_metadata_id, i.name
                FROM item_form_metadata ifm
                INNER JOIN item i ON ifm.item_id = i.item_id
                WHERE ifm.crf_version_id = $1 AND i.name = $2
                LIMIT 1
              `, [crfVersionId, condition.fieldId]);
                            const controlIfmId = controlIfmResult.rows[0]?.item_form_metadata_id || null;
                            const controlItemName = condition.fieldId || '';
                            // Insert into scd_item_metadata (LibreClinica skip logic table)
                            await client.query(`
                INSERT INTO scd_item_metadata (
                  scd_item_form_metadata_id, 
                  control_item_form_metadata_id, 
                  control_item_name, 
                  option_value, 
                  message, 
                  version
                ) VALUES ($1, $2, $3, $4, $5, 1)
              `, [
                                targetIfmId,
                                controlIfmId,
                                controlItemName,
                                condition.value || '',
                                condition.message || ''
                            ]);
                            logger_1.logger.debug('Created SCD skip logic', {
                                targetField: field.label,
                                controlField: condition.fieldId,
                                triggerValue: condition.value
                            });
                        }
                    }
                }
            }
            logger_1.logger.info('Created form fields with full metadata', {
                crfId,
                fieldCount: data.fields.length
            });
        }
        await client.query('COMMIT');
        logger_1.logger.info('Form template created successfully', {
            crfId,
            name: data.name,
            fieldCount: data.fields?.length || 0
        });
        // Track document creation in audit trail (21 CFR Part 11)
        try {
            await (0, audit_service_1.trackUserAction)({
                userId,
                username: '', // Will be populated from user context
                action: 'FORM_CREATED',
                entityType: 'crf',
                entityId: crfId,
                entityName: data.name,
                details: `Created form template "${data.name}" with ${data.fields?.length || 0} fields`
            });
        }
        catch (auditError) {
            logger_1.logger.warn('Failed to record form creation audit', { error: auditError.message });
        }
        return {
            success: true,
            crfId,
            message: `Form template created successfully with ${data.fields?.length || 0} fields`
        };
    }
    catch (error) {
        await client.query('ROLLBACK');
        logger_1.logger.error('Create form error', { error: error.message });
        return {
            success: false,
            message: `Failed to create form: ${error.message}`
        };
    }
    finally {
        client.release();
    }
};
exports.createForm = createForm;
/**
 * Update a form template with fields
 */
const updateForm = async (crfId, data, userId) => {
    logger_1.logger.info('Updating form template', { crfId, data: { ...data, fields: data.fields?.length || 0 }, userId });
    const client = await database_1.pool.connect();
    try {
        await client.query('BEGIN');
        // Update basic CRF info
        const updates = [];
        const params = [];
        let paramIndex = 1;
        if (data.name) {
            updates.push(`name = $${paramIndex++}`);
            params.push(data.name);
        }
        if (data.description !== undefined) {
            updates.push(`description = $${paramIndex++}`);
            params.push(data.description);
        }
        // Handle status changes - map frontend status to LibreClinica status_id
        if (data.status) {
            const statusMap = {
                'published': 1, // available
                'draft': 2, // unavailable
                'archived': 5 // removed
            };
            const statusId = statusMap[data.status];
            if (statusId) {
                updates.push(`status_id = $${paramIndex++}`);
                params.push(statusId);
                logger_1.logger.info('Updating form status', { crfId, status: data.status, statusId });
            }
        }
        updates.push(`date_updated = NOW()`);
        updates.push(`update_id = $${paramIndex++}`);
        params.push(userId);
        params.push(crfId);
        if (updates.length > 2) { // More than just date_updated and update_id
            const query = `
        UPDATE crf
        SET ${updates.join(', ')}
        WHERE crf_id = $${paramIndex}
      `;
            await client.query(query, params);
        }
        // Update fields if provided
        if (data.fields && data.fields.length > 0) {
            logger_1.logger.info('Updating form fields', { crfId, fieldCount: data.fields.length });
            // Get the latest version
            const versionResult = await client.query(`
        SELECT crf_version_id FROM crf_version
        WHERE crf_id = $1
        ORDER BY crf_version_id DESC
        LIMIT 1
      `, [crfId]);
            if (versionResult.rows.length === 0) {
                throw new Error('No version found for this form');
            }
            const crfVersionId = versionResult.rows[0].crf_version_id;
            // Get existing section or create one
            let sectionResult = await client.query(`
        SELECT section_id FROM section
        WHERE crf_version_id = $1
        ORDER BY ordinal
        LIMIT 1
      `, [crfVersionId]);
            let sectionId;
            if (sectionResult.rows.length === 0) {
                // Create section
                const newSectionResult = await client.query(`
          INSERT INTO section (
            crf_version_id, status_id, label, title, ordinal, owner_id, date_created
          ) VALUES (
            $1, 1, $2, $3, 1, $4, NOW()
          )
          RETURNING section_id
        `, [crfVersionId, data.category || 'Form Fields', data.name || 'Form', userId]);
                sectionId = newSectionResult.rows[0].section_id;
            }
            else {
                sectionId = sectionResult.rows[0].section_id;
            }
            // Get existing item group or create one
            let itemGroupResult = await client.query(`
        SELECT ig.item_group_id FROM item_group ig
        INNER JOIN item_group_metadata igm ON ig.item_group_id = igm.item_group_id
        WHERE igm.crf_version_id = $1
        LIMIT 1
      `, [crfVersionId]);
            let itemGroupId;
            if (itemGroupResult.rows.length === 0) {
                // Get CRF OID for generating item group OID
                const crfOidResult = await client.query(`SELECT oc_oid FROM crf WHERE crf_id = $1`, [crfId]);
                const crfOid = crfOidResult.rows[0]?.oc_oid || `CRF_${crfId}`;
                const randomSuffix = Math.random().toString(36).substring(2, 8).toUpperCase();
                const groupOid = `IG_${crfOid.substring(2, 16)}_${randomSuffix}`;
                const newGroupResult = await client.query(`
          INSERT INTO item_group (
            name, crf_id, status_id, owner_id, date_created, oc_oid
          ) VALUES (
            $1, $2, 1, $3, NOW(), $4
          )
          RETURNING item_group_id
        `, [data.category || 'Form Fields', crfId, userId, groupOid]);
                itemGroupId = newGroupResult.rows[0].item_group_id;
            }
            else {
                itemGroupId = itemGroupResult.rows[0].item_group_id;
            }
            // Get existing items for this form
            const existingItemsResult = await client.query(`
        SELECT i.item_id, i.name, i.oc_oid
        FROM item i
        INNER JOIN item_group_metadata igm ON i.item_id = igm.item_id
        WHERE igm.crf_version_id = $1
      `, [crfVersionId]);
            const existingItems = new Map(existingItemsResult.rows.map(row => [row.name, row]));
            // Get CRF OID for generating item OIDs
            const crfOidResult = await client.query(`SELECT oc_oid FROM crf WHERE crf_id = $1`, [crfId]);
            const ocOid = crfOidResult.rows[0]?.oc_oid || `CRF_${crfId}`;
            // Process each field
            for (let i = 0; i < data.fields.length; i++) {
                const field = data.fields[i];
                const fieldName = field.label || field.name || `Field ${i + 1}`;
                const existingItem = existingItems.get(fieldName);
                // Serialize extended properties
                const extendedProps = serializeExtendedProperties(field);
                let description = field.helpText || field.description || '';
                if (extendedProps) {
                    description = description ? `${description}\n---EXTENDED_PROPS---\n${extendedProps}` : `---EXTENDED_PROPS---\n${extendedProps}`;
                }
                const dataTypeId = mapFieldTypeToDataType(field.type);
                let itemId;
                if (existingItem) {
                    // Update existing item
                    await client.query(`
            UPDATE item
            SET description = $1, units = $2, phi_status = $3, item_data_type_id = $4, date_updated = NOW()
            WHERE item_id = $5
          `, [description, field.unit || '', field.isPhiField || false, dataTypeId, existingItem.item_id]);
                    itemId = existingItem.item_id;
                    existingItems.delete(fieldName); // Mark as processed
                }
                else {
                    // Create new item
                    const itemRandom = Math.random().toString(36).substring(2, 6).toUpperCase();
                    const itemOid = `I_${ocOid.substring(2, 12)}_${i}_${itemRandom}`;
                    const newItemResult = await client.query(`
            INSERT INTO item (
              name, description, units, phi_status, item_data_type_id,
              status_id, owner_id, date_created, oc_oid
            ) VALUES (
              $1, $2, $3, $4, $5, 1, $6, NOW(), $7
            )
            RETURNING item_id
          `, [fieldName, description, field.unit || '', field.isPhiField || false, dataTypeId, userId, itemOid]);
                    itemId = newItemResult.rows[0].item_id;
                    // Link to item group
                    await client.query(`
            INSERT INTO item_group_metadata (
              item_group_id, crf_version_id, item_id, ordinal, show_group, repeating_group
            ) VALUES (
              $1, $2, $3, $4, true, false
            )
          `, [itemGroupId, crfVersionId, itemId, field.order || (i + 1)]);
                }
                // Handle response set - ALWAYS create one for every field
                let responseSetId;
                const responseTypeId = mapFieldTypeToResponseType(field.type);
                // Check for existing response set from item_form_metadata
                const existingRsResult = await client.query(`
          SELECT response_set_id FROM item_form_metadata
          WHERE item_id = $1 AND crf_version_id = $2
        `, [itemId, crfVersionId]);
                if (existingRsResult.rows.length > 0 && existingRsResult.rows[0].response_set_id) {
                    // Update existing response set
                    if (field.options && field.options.length > 0) {
                        const optionsText = field.options.map((o) => o.label).join(',');
                        const optionsValues = field.options.map((o) => o.value).join(',');
                        await client.query(`
              UPDATE response_set
              SET options_text = $1, options_values = $2, response_type_id = $3
              WHERE response_set_id = $4
            `, [optionsText, optionsValues, responseTypeId, existingRsResult.rows[0].response_set_id]);
                    }
                    responseSetId = existingRsResult.rows[0].response_set_id;
                }
                else {
                    // Create new response set (required for all fields, not just option fields)
                    if (field.options && field.options.length > 0) {
                        const optionsText = field.options.map((o) => o.label).join(',');
                        const optionsValues = field.options.map((o) => o.value).join(',');
                        const rsResult = await client.query(`
              INSERT INTO response_set (response_type_id, label, options_text, options_values, version_id)
              VALUES ($1, $2, $3, $4, $5)
              RETURNING response_set_id
            `, [responseTypeId, field.label, optionsText, optionsValues, crfVersionId]);
                        responseSetId = rsResult.rows[0].response_set_id;
                    }
                    else {
                        // Create basic response set for non-option fields
                        const rsResult = await client.query(`
              INSERT INTO response_set (response_type_id, label, version_id)
              VALUES ($1, $2, $3)
              RETURNING response_set_id
            `, [responseTypeId, field.label || 'Field', crfVersionId]);
                        responseSetId = rsResult.rows[0].response_set_id;
                    }
                }
                // Extract validation pattern
                let regexpPattern = null;
                let regexpErrorMsg = null;
                let widthDecimal = null;
                if (field.validationRules && field.validationRules.length > 0) {
                    const patternRule = field.validationRules.find(r => r.type === 'pattern');
                    if (patternRule) {
                        regexpPattern = patternRule.value;
                        regexpErrorMsg = patternRule.message || 'Invalid format';
                    }
                    const minRule = field.validationRules.find(r => r.type === 'min');
                    const maxRule = field.validationRules.find(r => r.type === 'max');
                    if (minRule || maxRule) {
                        widthDecimal = `${minRule?.value ?? ''},${maxRule?.value ?? ''}`;
                    }
                }
                if (!widthDecimal && (field.min !== undefined || field.max !== undefined)) {
                    widthDecimal = `${field.min ?? ''},${field.max ?? ''}`;
                }
                // Update or create item_form_metadata
                const existingMetaResult = await client.query(`
          SELECT 1 FROM item_form_metadata WHERE item_id = $1 AND crf_version_id = $2
        `, [itemId, crfVersionId]);
                if (existingMetaResult.rows.length > 0) {
                    await client.query(`
            UPDATE item_form_metadata
            SET response_set_id = $1, ordinal = $2, left_item_text = $3, required = $4,
                default_value = $5, regexp = $6, regexp_error_msg = $7, show_item = $8, width_decimal = $9
            WHERE item_id = $10 AND crf_version_id = $11
          `, [
                        responseSetId, field.order || (i + 1), field.placeholder || '',
                        field.required || field.isRequired || false,
                        field.defaultValue !== undefined ? String(field.defaultValue) : null,
                        regexpPattern, regexpErrorMsg,
                        field.hidden !== true && field.isHidden !== true,
                        widthDecimal,
                        itemId, crfVersionId
                    ]);
                }
                else {
                    await client.query(`
            INSERT INTO item_form_metadata (
              item_id, crf_version_id, section_id, response_set_id, ordinal,
              left_item_text, required, default_value, regexp, regexp_error_msg, show_item, width_decimal
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
          `, [
                        itemId, crfVersionId, sectionId, responseSetId, field.order || (i + 1),
                        field.placeholder || '', field.required || field.isRequired || false,
                        field.defaultValue !== undefined ? String(field.defaultValue) : null,
                        regexpPattern, regexpErrorMsg,
                        field.hidden !== true && field.isHidden !== true,
                        widthDecimal
                    ]);
                }
            }
            // Optionally remove items that were deleted (items still in existingItems map)
            // For safety, we'll just mark them as hidden instead of deleting
            for (const [name, item] of existingItems) {
                logger_1.logger.info('Hiding removed field', { itemId: item.item_id, name });
                await client.query(`
          UPDATE item_form_metadata SET show_item = false
          WHERE item_id = $1 AND crf_version_id = $2
        `, [item.item_id, crfVersionId]);
            }
            logger_1.logger.info('Form fields updated', { crfId, fieldCount: data.fields.length });
        }
        await client.query('COMMIT');
        logger_1.logger.info('Form template updated successfully', { crfId });
        // Track document update in audit trail (21 CFR Part 11)
        try {
            await (0, audit_service_1.trackUserAction)({
                userId,
                username: '',
                action: 'FORM_UPDATED',
                entityType: 'crf',
                entityId: crfId,
                details: `Updated form template: ${Object.keys(data).join(', ')}${data.fields ? ` with ${data.fields.length} fields` : ''}`
            });
        }
        catch (auditError) {
            logger_1.logger.warn('Failed to record form update audit', { error: auditError.message });
        }
        return {
            success: true,
            message: `Form template updated successfully${data.fields ? ` with ${data.fields.length} fields` : ''}`
        };
    }
    catch (error) {
        await client.query('ROLLBACK');
        logger_1.logger.error('Update form error', { error: error.message });
        return {
            success: false,
            message: `Failed to update form: ${error.message}`
        };
    }
    finally {
        client.release();
    }
};
exports.updateForm = updateForm;
/**
 * Delete a form template (soft delete by changing status)
 */
const deleteForm = async (crfId, userId) => {
    logger_1.logger.info('Deleting form template', { crfId, userId });
    try {
        // Check if form is in use
        const usageCheck = await database_1.pool.query(`
      SELECT COUNT(*) as count FROM event_crf ec
      JOIN crf_version cv ON ec.crf_version_id = cv.crf_version_id
      WHERE cv.crf_id = $1
    `, [crfId]);
        if (parseInt(usageCheck.rows[0].count) > 0) {
            return {
                success: false,
                message: 'Cannot delete form - it is being used by subjects'
            };
        }
        // Set status to removed (status_id = 5 typically)
        await database_1.pool.query(`
      UPDATE crf
      SET status_id = 5, date_updated = NOW(), update_id = $1
      WHERE crf_id = $2
    `, [userId, crfId]);
        logger_1.logger.info('Form template deleted successfully', { crfId });
        return {
            success: true,
            message: 'Form template deleted successfully'
        };
    }
    catch (error) {
        logger_1.logger.error('Delete form error', { error: error.message });
        return {
            success: false,
            message: `Failed to delete form: ${error.message}`
        };
    }
};
exports.deleteForm = deleteForm;
// =============================================================================
// TEMPLATE FORKING / VERSIONING FUNCTIONS
// =============================================================================
/**
 * Get all versions of a CRF
 * Returns version history for display
 */
const getFormVersions = async (crfId) => {
    logger_1.logger.info('Getting form versions', { crfId });
    try {
        const result = await database_1.pool.query(`
      SELECT 
        cv.crf_version_id,
        cv.name as version_name,
        cv.description,
        cv.revision_notes,
        cv.oc_oid,
        cv.status_id,
        s.name as status_name,
        cv.owner_id,
        cv.date_created,
        cv.date_updated,
        u.first_name || ' ' || u.last_name as created_by,
        (SELECT COUNT(*) FROM event_crf WHERE crf_version_id = cv.crf_version_id) as usage_count
      FROM crf_version cv
      INNER JOIN status s ON cv.status_id = s.status_id
      LEFT JOIN user_account u ON cv.owner_id = u.user_id
      WHERE cv.crf_id = $1
      ORDER BY cv.crf_version_id DESC
    `, [crfId]);
        logger_1.logger.info('Form versions retrieved', { crfId, count: result.rows.length });
        return {
            success: true,
            versions: result.rows.map(row => ({
                crfVersionId: row.crf_version_id,
                versionName: row.version_name,
                description: row.description,
                revisionNotes: row.revision_notes,
                oid: row.oc_oid,
                statusId: row.status_id,
                statusName: row.status_name,
                createdBy: row.created_by,
                dateCreated: row.date_created,
                dateUpdated: row.date_updated,
                usageCount: parseInt(row.usage_count) || 0,
                isInUse: parseInt(row.usage_count) > 0
            }))
        };
    }
    catch (error) {
        logger_1.logger.error('Get form versions error', { error: error.message, crfId });
        return {
            success: false,
            message: `Failed to get form versions: ${error.message}`
        };
    }
};
exports.getFormVersions = getFormVersions;
/**
 * Create a new version of an existing CRF
 * - Copies all fields/items from source version
 * - Creates new crf_version record
 * - Maintains link to parent CRF
 *
 * This implements "forking" at the version level - same CRF, new version
 */
const createFormVersion = async (crfId, data, userId) => {
    logger_1.logger.info('Creating new form version', { crfId, versionName: data.versionName, userId });
    const client = await database_1.pool.connect();
    try {
        await client.query('BEGIN');
        // 1. Get the source version (specified or latest)
        let sourceVersionId;
        if (data.copyFromVersionId) {
            // Verify the version belongs to this CRF
            const verifyResult = await client.query(`
        SELECT crf_version_id FROM crf_version 
        WHERE crf_version_id = $1 AND crf_id = $2
      `, [data.copyFromVersionId, crfId]);
            if (verifyResult.rows.length === 0) {
                await client.query('ROLLBACK');
                return { success: false, message: 'Source version not found or does not belong to this CRF' };
            }
            sourceVersionId = data.copyFromVersionId;
        }
        else {
            // Get latest version
            const latestResult = await client.query(`
        SELECT crf_version_id FROM crf_version 
        WHERE crf_id = $1 
        ORDER BY crf_version_id DESC 
        LIMIT 1
      `, [crfId]);
            if (latestResult.rows.length === 0) {
                await client.query('ROLLBACK');
                return { success: false, message: 'No existing version found to copy from' };
            }
            sourceVersionId = latestResult.rows[0].crf_version_id;
        }
        // 2. Get CRF info for OID generation
        const crfResult = await client.query(`
      SELECT name, oc_oid FROM crf WHERE crf_id = $1
    `, [crfId]);
        if (crfResult.rows.length === 0) {
            await client.query('ROLLBACK');
            return { success: false, message: 'CRF not found' };
        }
        const crfOid = crfResult.rows[0].oc_oid;
        const versionCount = await client.query(`
      SELECT COUNT(*) as count FROM crf_version WHERE crf_id = $1
    `, [crfId]);
        const nextVersionNum = parseInt(versionCount.rows[0].count) + 1;
        const newVersionOid = `${crfOid}_V${nextVersionNum}`;
        // 3. Create new version record
        const newVersionResult = await client.query(`
      INSERT INTO crf_version (
        crf_id, name, description, revision_notes, status_id, owner_id, date_created, oc_oid
      ) VALUES (
        $1, $2, $3, $4, 1, $5, NOW(), $6
      )
      RETURNING crf_version_id
    `, [
            crfId,
            data.versionName,
            `Version ${data.versionName}`,
            data.revisionNotes || `Created from version ${sourceVersionId}`,
            userId,
            newVersionOid
        ]);
        const newVersionId = newVersionResult.rows[0].crf_version_id;
        logger_1.logger.info('Created new version record', { newVersionId, sourceVersionId });
        // 4. Copy sections from source version
        const sectionMapping = {};
        const sectionsResult = await client.query(`
      SELECT section_id, label, title, instructions, subtitle, page_number_label,
             ordinal, parent_id, borders
      FROM section WHERE crf_version_id = $1
    `, [sourceVersionId]);
        for (const section of sectionsResult.rows) {
            const newSectionResult = await client.query(`
        INSERT INTO section (
          crf_version_id, status_id, label, title, instructions, subtitle,
          page_number_label, ordinal, parent_id, borders, owner_id, date_created
        ) VALUES (
          $1, 1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW()
        )
        RETURNING section_id
      `, [
                newVersionId,
                section.label,
                section.title,
                section.instructions,
                section.subtitle,
                section.page_number_label,
                section.ordinal,
                null, // parent_id will be mapped after
                section.borders,
                userId
            ]);
            sectionMapping[section.section_id] = newSectionResult.rows[0].section_id;
        }
        // 5. Copy item groups
        const itemGroupMapping = {};
        const itemGroupsResult = await client.query(`
      SELECT ig.item_group_id, ig.name, ig.oc_oid, 
             igm.header, igm.subheader, igm.layout, igm.repeat_number, 
             igm.repeat_max, igm.show_group, igm.ordinal, igm.borders
      FROM item_group ig
      INNER JOIN item_group_metadata igm ON ig.item_group_id = igm.item_group_id
      WHERE igm.crf_version_id = $1
    `, [sourceVersionId]);
        for (const group of itemGroupsResult.rows) {
            // Create new OID for item group
            const newGroupOid = group.oc_oid ?
                `${group.oc_oid}_V${nextVersionNum}` :
                `IG_${newVersionId}_${group.item_group_id}`;
            const newGroupResult = await client.query(`
        INSERT INTO item_group (
          name, oc_oid, status_id, owner_id, date_created
        ) VALUES (
          $1, $2, 1, $3, NOW()
        )
        RETURNING item_group_id
      `, [group.name, newGroupOid, userId]);
            const newGroupId = newGroupResult.rows[0].item_group_id;
            itemGroupMapping[group.item_group_id] = newGroupId;
            // Create item_group_metadata for new version
            await client.query(`
        INSERT INTO item_group_metadata (
          item_group_id, crf_version_id, header, subheader, layout,
          repeat_number, repeat_max, show_group, ordinal, borders
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9, $10
        )
      `, [
                newGroupId,
                newVersionId,
                group.header,
                group.subheader,
                group.layout,
                group.repeat_number,
                group.repeat_max,
                group.show_group,
                group.ordinal,
                group.borders
            ]);
        }
        // 6. Copy items and item_form_metadata
        const itemMapping = {};
        const itemsResult = await client.query(`
      SELECT i.item_id, i.name, i.description, i.units, i.phi_status, 
             i.item_data_type_id, i.item_reference_type_id, i.oc_oid,
             ifm.header, ifm.subheader, ifm.left_item_text, ifm.right_item_text,
             ifm.parent_id, ifm.column_number, ifm.section_id, ifm.ordinal,
             ifm.response_set_id, ifm.required, ifm.regexp, ifm.regexp_error_msg,
             ifm.show_item, ifm.question_number_label, ifm.default_value,
             ifm.width_decimal, ifm.response_layout
      FROM item i
      INNER JOIN item_form_metadata ifm ON i.item_id = ifm.item_id
      WHERE ifm.crf_version_id = $1
    `, [sourceVersionId]);
        for (const item of itemsResult.rows) {
            // Create new OID for item
            const newItemOid = item.oc_oid ?
                `${item.oc_oid}_V${nextVersionNum}` :
                `I_${newVersionId}_${item.item_id}`;
            const newItemResult = await client.query(`
        INSERT INTO item (
          name, description, units, phi_status, item_data_type_id,
          item_reference_type_id, status_id, owner_id, date_created, oc_oid
        ) VALUES (
          $1, $2, $3, $4, $5, $6, 1, $7, NOW(), $8
        )
        RETURNING item_id
      `, [
                item.name,
                item.description,
                item.units,
                item.phi_status,
                item.item_data_type_id,
                item.item_reference_type_id,
                userId,
                newItemOid
            ]);
            const newItemId = newItemResult.rows[0].item_id;
            itemMapping[item.item_id] = newItemId;
            // Create item_form_metadata for new version
            const newSectionId = sectionMapping[item.section_id] || null;
            await client.query(`
        INSERT INTO item_form_metadata (
          item_id, crf_version_id, header, subheader, left_item_text, right_item_text,
          parent_id, column_number, section_id, ordinal, response_set_id,
          required, regexp, regexp_error_msg, show_item, question_number_label,
          default_value, width_decimal, response_layout
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19
        )
      `, [
                newItemId,
                newVersionId,
                item.header,
                item.subheader,
                item.left_item_text,
                item.right_item_text,
                null, // parent_id mapping if needed
                item.column_number,
                newSectionId,
                item.ordinal,
                item.response_set_id, // Response sets are shared
                item.required,
                item.regexp,
                item.regexp_error_msg,
                item.show_item,
                item.question_number_label,
                item.default_value,
                item.width_decimal,
                item.response_layout
            ]);
            // Copy item_group_map if exists
            const groupMapResult = await client.query(`
        SELECT item_group_id FROM item_group_map
        WHERE item_id = $1 AND crf_version_id = $2
      `, [item.item_id, sourceVersionId]);
            if (groupMapResult.rows.length > 0) {
                const oldGroupId = groupMapResult.rows[0].item_group_id;
                const newGroupId = itemGroupMapping[oldGroupId];
                if (newGroupId) {
                    await client.query(`
            INSERT INTO item_group_map (item_group_id, item_id, crf_version_id)
            VALUES ($1, $2, $3)
          `, [newGroupId, newItemId, newVersionId]);
                }
            }
        }
        // 7. Copy SCD item metadata (conditional display rules)
        const scdResult = await client.query(`
      SELECT scd.scd_item_metadata_id, scd.scd_item_form_metadata_id, scd.control_item_form_metadata_id,
             scd.option_value, scd.message
      FROM scd_item_metadata scd
      INNER JOIN item_form_metadata ifm ON scd.scd_item_form_metadata_id = ifm.item_form_metadata_id
      WHERE ifm.crf_version_id = $1
    `, [sourceVersionId]);
        // Note: SCD copying requires mapping item_form_metadata IDs which is complex
        // For now, log that SCD rules need manual review
        if (scdResult.rows.length > 0) {
            logger_1.logger.info('SCD rules found in source version', {
                count: scdResult.rows.length,
                note: 'SCD rules may need manual configuration in new version'
            });
        }
        await client.query('COMMIT');
        logger_1.logger.info('Form version created successfully', {
            crfId,
            newVersionId,
            sourceVersionId,
            sectionsCopied: Object.keys(sectionMapping).length,
            itemsCopied: Object.keys(itemMapping).length
        });
        // Audit log
        try {
            await (0, audit_service_1.trackUserAction)({
                userId,
                username: '',
                action: 'FORM_VERSION_CREATED',
                entityType: 'crf_version',
                entityId: newVersionId,
                details: `Created version "${data.versionName}" from version ${sourceVersionId}`
            });
        }
        catch (auditError) {
            logger_1.logger.warn('Failed to record version creation audit', { error: auditError.message });
        }
        return {
            success: true,
            crfVersionId: newVersionId,
            message: `Version "${data.versionName}" created successfully`
        };
    }
    catch (error) {
        await client.query('ROLLBACK');
        logger_1.logger.error('Create form version error', { error: error.message, crfId });
        return {
            success: false,
            message: `Failed to create form version: ${error.message}`
        };
    }
    finally {
        client.release();
    }
};
exports.createFormVersion = createFormVersion;
/**
 * Fork (copy) an entire CRF to create a new independent form
 * - Creates new CRF record
 * - Copies specified version (or latest)
 * - Copies all items/sections/item_groups
 * - Updates OIDs to be unique
 *
 * This implements "forking" at the CRF level - completely new CRF
 */
const forkForm = async (sourceCrfId, data, userId) => {
    logger_1.logger.info('Forking form template', { sourceCrfId, newName: data.newName, userId });
    const client = await database_1.pool.connect();
    try {
        await client.query('BEGIN');
        // 1. Get source CRF info
        const sourceCrfResult = await client.query(`
      SELECT crf_id, name, description, oc_oid, source_study_id
      FROM crf WHERE crf_id = $1
    `, [sourceCrfId]);
        if (sourceCrfResult.rows.length === 0) {
            await client.query('ROLLBACK');
            return { success: false, message: 'Source CRF not found' };
        }
        const sourceCrf = sourceCrfResult.rows[0];
        // 2. Generate new OID for the forked CRF
        const timestamp = Date.now().toString().slice(-6);
        const newOid = `F_${data.newName.replace(/[^a-zA-Z0-9]/g, '_').toUpperCase().substring(0, 24)}_${timestamp}`;
        // Check if OID exists
        const existsCheck = await client.query(`SELECT crf_id FROM crf WHERE oc_oid = $1`, [newOid]);
        if (existsCheck.rows.length > 0) {
            await client.query('ROLLBACK');
            return { success: false, message: 'A form with this name already exists' };
        }
        // 3. Create new CRF
        const newCrfResult = await client.query(`
      INSERT INTO crf (
        name, description, status_id, owner_id, date_created, oc_oid, source_study_id
      ) VALUES (
        $1, $2, 1, $3, NOW(), $4, $5
      )
      RETURNING crf_id
    `, [
            data.newName,
            data.description || `Forked from ${sourceCrf.name}`,
            userId,
            newOid,
            data.targetStudyId || sourceCrf.source_study_id
        ]);
        const newCrfId = newCrfResult.rows[0].crf_id;
        logger_1.logger.info('Created forked CRF record', { newCrfId, sourceCrfId });
        // 4. Get latest version from source to copy
        const sourceVersionResult = await client.query(`
      SELECT crf_version_id, name, description
      FROM crf_version 
      WHERE crf_id = $1 
      ORDER BY crf_version_id DESC 
      LIMIT 1
    `, [sourceCrfId]);
        if (sourceVersionResult.rows.length === 0) {
            await client.query('ROLLBACK');
            return { success: false, message: 'No version found in source CRF' };
        }
        const sourceVersion = sourceVersionResult.rows[0];
        const sourceVersionId = sourceVersion.crf_version_id;
        // 5. Create initial version for new CRF
        const newVersionOid = `${newOid}_V1`;
        const newVersionResult = await client.query(`
      INSERT INTO crf_version (
        crf_id, name, description, revision_notes, status_id, owner_id, date_created, oc_oid
      ) VALUES (
        $1, 'v1.0', $2, $3, 1, $4, NOW(), $5
      )
      RETURNING crf_version_id
    `, [
            newCrfId,
            `Initial version (forked from ${sourceCrf.name})`,
            `Forked from CRF ID ${sourceCrfId}, version ${sourceVersion.name}`,
            userId,
            newVersionOid
        ]);
        const newVersionId = newVersionResult.rows[0].crf_version_id;
        // 6. Copy sections
        const sectionMapping = {};
        const sectionsResult = await client.query(`
      SELECT section_id, label, title, instructions, subtitle, page_number_label,
             ordinal, parent_id, borders
      FROM section WHERE crf_version_id = $1
    `, [sourceVersionId]);
        for (const section of sectionsResult.rows) {
            const newSectionResult = await client.query(`
        INSERT INTO section (
          crf_version_id, status_id, label, title, instructions, subtitle,
          page_number_label, ordinal, parent_id, borders, owner_id, date_created
        ) VALUES (
          $1, 1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW()
        )
        RETURNING section_id
      `, [
                newVersionId,
                section.label,
                section.title,
                section.instructions,
                section.subtitle,
                section.page_number_label,
                section.ordinal,
                null,
                section.borders,
                userId
            ]);
            sectionMapping[section.section_id] = newSectionResult.rows[0].section_id;
        }
        // 7. Copy item groups
        const itemGroupMapping = {};
        const itemGroupsResult = await client.query(`
      SELECT ig.item_group_id, ig.name, ig.oc_oid,
             igm.header, igm.subheader, igm.layout, igm.repeat_number,
             igm.repeat_max, igm.show_group, igm.ordinal, igm.borders
      FROM item_group ig
      INNER JOIN item_group_metadata igm ON ig.item_group_id = igm.item_group_id
      WHERE igm.crf_version_id = $1
    `, [sourceVersionId]);
        for (const group of itemGroupsResult.rows) {
            const newGroupOid = `IG_${newCrfId}_${Date.now().toString().slice(-4)}_${group.item_group_id}`;
            const newGroupResult = await client.query(`
        INSERT INTO item_group (name, oc_oid, status_id, owner_id, date_created)
        VALUES ($1, $2, 1, $3, NOW())
        RETURNING item_group_id
      `, [group.name, newGroupOid, userId]);
            const newGroupId = newGroupResult.rows[0].item_group_id;
            itemGroupMapping[group.item_group_id] = newGroupId;
            await client.query(`
        INSERT INTO item_group_metadata (
          item_group_id, crf_version_id, header, subheader, layout,
          repeat_number, repeat_max, show_group, ordinal, borders
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      `, [
                newGroupId, newVersionId, group.header, group.subheader, group.layout,
                group.repeat_number, group.repeat_max, group.show_group, group.ordinal, group.borders
            ]);
        }
        // 8. Copy items
        const itemsResult = await client.query(`
      SELECT i.item_id, i.name, i.description, i.units, i.phi_status,
             i.item_data_type_id, i.item_reference_type_id, i.oc_oid,
             ifm.header, ifm.subheader, ifm.left_item_text, ifm.right_item_text,
             ifm.parent_id, ifm.column_number, ifm.section_id, ifm.ordinal,
             ifm.response_set_id, ifm.required, ifm.regexp, ifm.regexp_error_msg,
             ifm.show_item, ifm.question_number_label, ifm.default_value,
             ifm.width_decimal, ifm.response_layout
      FROM item i
      INNER JOIN item_form_metadata ifm ON i.item_id = ifm.item_id
      WHERE ifm.crf_version_id = $1
    `, [sourceVersionId]);
        for (const item of itemsResult.rows) {
            const newItemOid = `I_${newCrfId}_${Date.now().toString().slice(-4)}_${item.item_id}`;
            const newItemResult = await client.query(`
        INSERT INTO item (
          name, description, units, phi_status, item_data_type_id,
          item_reference_type_id, status_id, owner_id, date_created, oc_oid
        ) VALUES ($1, $2, $3, $4, $5, $6, 1, $7, NOW(), $8)
        RETURNING item_id
      `, [
                item.name, item.description, item.units, item.phi_status,
                item.item_data_type_id, item.item_reference_type_id, userId, newItemOid
            ]);
            const newItemId = newItemResult.rows[0].item_id;
            const newSectionId = sectionMapping[item.section_id] || null;
            await client.query(`
        INSERT INTO item_form_metadata (
          item_id, crf_version_id, header, subheader, left_item_text, right_item_text,
          parent_id, column_number, section_id, ordinal, response_set_id,
          required, regexp, regexp_error_msg, show_item, question_number_label,
          default_value, width_decimal, response_layout
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19)
      `, [
                newItemId, newVersionId, item.header, item.subheader, item.left_item_text,
                item.right_item_text, null, item.column_number, newSectionId, item.ordinal,
                item.response_set_id, item.required, item.regexp, item.regexp_error_msg,
                item.show_item, item.question_number_label, item.default_value,
                item.width_decimal, item.response_layout
            ]);
            // Copy item_group_map
            const groupMapResult = await client.query(`
        SELECT item_group_id FROM item_group_map WHERE item_id = $1 AND crf_version_id = $2
      `, [item.item_id, sourceVersionId]);
            if (groupMapResult.rows.length > 0) {
                const oldGroupId = groupMapResult.rows[0].item_group_id;
                const newGroupId = itemGroupMapping[oldGroupId];
                if (newGroupId) {
                    await client.query(`
            INSERT INTO item_group_map (item_group_id, item_id, crf_version_id)
            VALUES ($1, $2, $3)
          `, [newGroupId, newItemId, newVersionId]);
                }
            }
        }
        await client.query('COMMIT');
        logger_1.logger.info('Form forked successfully', {
            sourceCrfId,
            newCrfId,
            newVersionId,
            sectionsCopied: Object.keys(sectionMapping).length,
            itemsCopied: itemsResult.rows.length
        });
        // Audit log
        try {
            await (0, audit_service_1.trackUserAction)({
                userId,
                username: '',
                action: 'FORM_FORKED',
                entityType: 'crf',
                entityId: newCrfId,
                details: `Forked from CRF "${sourceCrf.name}" (ID: ${sourceCrfId}) as "${data.newName}"`
            });
        }
        catch (auditError) {
            logger_1.logger.warn('Failed to record fork audit', { error: auditError.message });
        }
        return {
            success: true,
            newCrfId,
            message: `Form "${data.newName}" forked successfully`
        };
    }
    catch (error) {
        await client.query('ROLLBACK');
        logger_1.logger.error('Fork form error', { error: error.message, sourceCrfId });
        return {
            success: false,
            message: `Failed to fork form: ${error.message}`
        };
    }
    finally {
        client.release();
    }
};
exports.forkForm = forkForm;
exports.default = {
    saveFormData: exports.saveFormData,
    getFormData: exports.getFormData,
    getFormMetadata: exports.getFormMetadata,
    getFormStatus: exports.getFormStatus,
    validateFormData: exports.validateFormData,
    getStudyForms: exports.getStudyForms,
    getAllForms: exports.getAllForms,
    getFormById: exports.getFormById,
    createForm: exports.createForm,
    updateForm: exports.updateForm,
    deleteForm: exports.deleteForm,
    // Template Forking Functions
    getFormVersions: exports.getFormVersions,
    createFormVersion: exports.createFormVersion,
    forkForm: exports.forkForm
};
//# sourceMappingURL=form.service.js.map