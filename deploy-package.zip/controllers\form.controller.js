"use strict";
/**
 * Form Controller
 *
 * Handles form/CRF operations with audit tracking
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.fork = exports.createVersion = exports.getVersions = exports.remove = exports.update = exports.create = exports.getByStudy = exports.get = exports.list = exports.getStatus = exports.getMetadata = exports.getData = exports.saveData = void 0;
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const formService = __importStar(require("../services/hybrid/form.service"));
const audit_service_1 = require("../services/database/audit.service");
exports.saveData = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const result = await formService.saveFormData(req.body, user.userId, user.username);
    // Track form save action
    if (result.success) {
        await (0, audit_service_1.trackUserAction)({
            userId: user.userId,
            username: user.username,
            action: 'FORM_UPDATED',
            entityType: 'event_crf',
            entityId: req.body.eventCrfId || req.body.crfId,
            details: 'Form data saved'
        });
    }
    res.status(result.success ? 200 : 400).json(result);
});
exports.getData = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { eventCrfId } = req.params;
    const user = req.user;
    const result = await formService.getFormData(parseInt(eventCrfId));
    // Track form view
    if (user?.userId) {
        await (0, audit_service_1.trackDocumentAccess)(user.userId, user.username || user.userName, 'event_crf', parseInt(eventCrfId), undefined, 'view');
    }
    res.json({ success: true, data: result });
});
exports.getMetadata = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { crfId } = req.params;
    const user = req.user;
    const result = await formService.getFormMetadata(parseInt(crfId));
    if (!result) {
        res.status(404).json({ success: false, message: 'Form not found' });
        return;
    }
    // Track document access (21 CFR Part 11)
    if (user?.userId) {
        await (0, audit_service_1.trackDocumentAccess)(user.userId, user.username || user.userName, 'crf', parseInt(crfId), result.crf?.name, 'view');
    }
    res.json({ success: true, data: result });
});
exports.getStatus = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { eventCrfId } = req.params;
    const result = await formService.getFormStatus(parseInt(eventCrfId));
    if (!result) {
        res.status(404).json({ success: false, message: 'Form not found' });
        return;
    }
    res.json({ success: true, data: result });
});
exports.list = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const result = await formService.getAllForms();
    res.json({
        success: true,
        data: result,
        total: result.length
    });
});
exports.get = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const result = await formService.getFormById(parseInt(id));
    if (!result) {
        res.status(404).json({ success: false, message: 'Form not found' });
        return;
    }
    res.json({ success: true, data: result });
});
exports.getByStudy = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.query;
    if (!studyId) {
        res.status(400).json({ success: false, message: 'studyId is required' });
        return;
    }
    const result = await formService.getStudyForms(parseInt(studyId));
    res.json({
        success: true,
        data: result,
        total: result.length
    });
});
/**
 * Create a new form template (CRF)
 */
exports.create = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const result = await formService.createForm(req.body, user.userId);
    if (result.success) {
        await (0, audit_service_1.trackUserAction)({
            userId: user.userId,
            username: user.username || user.userName,
            action: 'FORM_CREATED',
            entityType: 'crf',
            entityId: result.crfId,
            details: `Created form: ${req.body.name}`
        });
    }
    res.status(result.success ? 201 : 400).json(result);
});
/**
 * Update a form template
 */
exports.update = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const user = req.user;
    const result = await formService.updateForm(parseInt(id), req.body, user.userId);
    if (result.success) {
        await (0, audit_service_1.trackUserAction)({
            userId: user.userId,
            username: user.username || user.userName,
            action: 'FORM_UPDATED',
            entityType: 'crf',
            entityId: parseInt(id),
            details: `Updated form: ${req.body.name || id}`
        });
    }
    res.status(result.success ? 200 : 400).json(result);
});
/**
 * Delete a form template
 */
exports.remove = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const user = req.user;
    const result = await formService.deleteForm(parseInt(id), user.userId);
    if (result.success) {
        await (0, audit_service_1.trackUserAction)({
            userId: user.userId,
            username: user.username || user.userName,
            action: 'FORM_DELETED',
            entityType: 'crf',
            entityId: parseInt(id),
            details: `Deleted form ID: ${id}`
        });
    }
    res.status(result.success ? 200 : 400).json(result);
});
// =============================================================================
// TEMPLATE FORKING / VERSIONING CONTROLLERS
// =============================================================================
/**
 * Get all versions of a form template
 */
exports.getVersions = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const user = req.user;
    const result = await formService.getFormVersions(parseInt(id));
    // Track access for audit (21 CFR Part 11)
    if (user?.userId && result.success) {
        await (0, audit_service_1.trackDocumentAccess)(user.userId, user.username || user.userName, 'crf_version_history', parseInt(id), undefined, 'view');
    }
    res.status(result.success ? 200 : 400).json(result);
});
/**
 * Create a new version of an existing form template
 * This is "forking" at the version level - same CRF, new version
 */
exports.createVersion = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const user = req.user;
    const { versionName, revisionNotes, copyFromVersionId } = req.body;
    if (!versionName) {
        res.status(400).json({ success: false, message: 'versionName is required' });
        return;
    }
    const result = await formService.createFormVersion(parseInt(id), { versionName, revisionNotes, copyFromVersionId }, user.userId);
    if (result.success) {
        await (0, audit_service_1.trackUserAction)({
            userId: user.userId,
            username: user.username || user.userName,
            action: 'FORM_VERSION_CREATED',
            entityType: 'crf_version',
            entityId: result.crfVersionId,
            details: `Created version "${versionName}" for form ID: ${id}`
        });
    }
    res.status(result.success ? 201 : 400).json(result);
});
/**
 * Fork (copy) an entire form template to create a new independent form
 * This is "forking" at the CRF level - completely new CRF
 */
exports.fork = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const user = req.user;
    const { newName, description, targetStudyId } = req.body;
    if (!newName) {
        res.status(400).json({ success: false, message: 'newName is required' });
        return;
    }
    const result = await formService.forkForm(parseInt(id), { newName, description, targetStudyId }, user.userId);
    if (result.success) {
        await (0, audit_service_1.trackUserAction)({
            userId: user.userId,
            username: user.username || user.userName,
            action: 'FORM_FORKED',
            entityType: 'crf',
            entityId: result.newCrfId,
            details: `Forked form ID ${id} as "${newName}"`
        });
    }
    res.status(result.success ? 201 : 400).json(result);
});
exports.default = {
    saveData: exports.saveData, getData: exports.getData, getMetadata: exports.getMetadata, getStatus: exports.getStatus,
    list: exports.list, get: exports.get, getByStudy: exports.getByStudy,
    create: exports.create, update: exports.update, remove: exports.remove,
    // Forking/Versioning
    getVersions: exports.getVersions, createVersion: exports.createVersion, fork: exports.fork
};
//# sourceMappingURL=form.controller.js.map