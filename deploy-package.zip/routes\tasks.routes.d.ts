/**
 * Tasks Routes
 *
 * Unified task management endpoints aggregating:
 * - Queries (discrepancy_note)
 * - Scheduled Visits (study_event)
 * - Data Entry (study_event/event_crf)
 * - Form Completion (event_crf)
 * - SDV Required (event_crf)
 * - Signature Required (event_crf)
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=tasks.routes.d.ts.map