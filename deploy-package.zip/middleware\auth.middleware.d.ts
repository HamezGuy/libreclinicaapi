import { Request, Response, NextFunction } from 'express';
export interface AuthRequest extends Request {
    user?: {
        userId: number;
        userName: string;
        email: string;
        userType: string;
        role: string;
        studyIds?: number[];
    };
}
/**
 * JWT Authentication Middleware (21 CFR Part 11 §11.10(d))
 * Verifies JWT token and enforces session timeout
 */
export declare const authMiddleware: (req: Request, res: Response, next: NextFunction) => void;
/**
 * Optional authentication - doesn't fail if no token
 */
export declare const optionalAuthMiddleware: (req: Request, res: Response, next: NextFunction) => void;
//# sourceMappingURL=auth.middleware.d.ts.map