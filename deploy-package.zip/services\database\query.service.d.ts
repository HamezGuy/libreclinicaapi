/**
 * Query Service (Hybrid)
 *
 * Discrepancy Note (Query) management combining SOAP and Database
 * - Use Database for reading queries
 * - Use SOAP for creating/updating queries (GxP compliant)
 */
import { PaginatedResponse } from '../../types';
/**
 * Get queries with filters
 */
export declare const getQueries: (filters: {
    studyId?: number;
    subjectId?: number;
    status?: string;
    page?: number;
    limit?: number;
}) => Promise<PaginatedResponse<any>>;
/**
 * Get query by ID with responses
 */
export declare const getQueryById: (queryId: number) => Promise<any>;
/**
 * Create query
 * Note: discrepancy_note links to entities via mapping tables (dn_item_data_map, etc.)
 */
export declare const createQuery: (data: {
    entityType: string;
    entityId: number;
    studyId: number;
    studySubjectId?: number;
    subjectId?: number;
    description: string;
    detailedNotes?: string;
    typeId?: number;
    queryType?: string;
}, userId: number) => Promise<{
    success: boolean;
    queryId?: number;
    message?: string;
}>;
/**
 * Add response to query
 * Creates a child discrepancy_note with parent_dn_id pointing to the parent query.
 * Optionally updates the parent status (e.g., to "Updated" when responding).
 */
export declare const addQueryResponse: (parentQueryId: number, data: {
    description: string;
    detailedNotes?: string;
    newStatusId?: number;
}, userId: number) => Promise<{
    success: boolean;
    responseId?: number;
    message?: string;
}>;
/**
 * Update query status with full audit trail
 *
 * Resolution Status IDs:
 * 1 = New, 2 = Updated, 3 = Resolution Proposed, 4 = Closed, 5 = Not Applicable
 */
export declare const updateQueryStatus: (queryId: number, statusId: number, userId: number, options?: {
    reason?: string;
    signature?: boolean;
}) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Close query with electronic signature (password verification)
 * 21 CFR Part 11 compliant - requires password re-authentication
 */
export declare const closeQueryWithSignature: (queryId: number, userId: number, data: {
    password: string;
    reason: string;
    meaning?: string;
}) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Get query audit trail
 */
export declare const getQueryAuditTrail: (queryId: number) => Promise<any[]>;
/**
 * Get query statistics for a study
 */
export declare const getQueryStats: (studyId: number) => Promise<any>;
/**
 * Get query types from database
 */
export declare const getQueryTypes: () => Promise<any[]>;
/**
 * Get resolution statuses from database
 */
export declare const getResolutionStatuses: () => Promise<any[]>;
/**
 * Get queries for a specific form (event_crf)
 */
export declare const getFormQueries: (eventCrfId: number) => Promise<any[]>;
/**
 * Reassign query to another user
 */
export declare const reassignQuery: (queryId: number, assignedUserId: number, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Get query counts by status
 */
export declare const getQueryCountByStatus: (studyId: number) => Promise<any[]>;
/**
 * Get query counts by type
 */
export declare const getQueryCountByType: (studyId: number) => Promise<any[]>;
/**
 * Get query thread (conversation history)
 */
export declare const getQueryThread: (queryId: number) => Promise<any[]>;
/**
 * Get overdue queries
 */
export declare const getOverdueQueries: (studyId: number, daysThreshold?: number) => Promise<any[]>;
/**
 * Get my assigned queries
 */
export declare const getMyAssignedQueries: (userId: number, studyId?: number) => Promise<any[]>;
declare const _default: {
    getQueries: (filters: {
        studyId?: number;
        subjectId?: number;
        status?: string;
        page?: number;
        limit?: number;
    }) => Promise<PaginatedResponse<any>>;
    getQueryById: (queryId: number) => Promise<any>;
    createQuery: (data: {
        entityType: string;
        entityId: number;
        studyId: number;
        studySubjectId?: number;
        subjectId?: number;
        description: string;
        detailedNotes?: string;
        typeId?: number;
        queryType?: string;
    }, userId: number) => Promise<{
        success: boolean;
        queryId?: number;
        message?: string;
    }>;
    addQueryResponse: (parentQueryId: number, data: {
        description: string;
        detailedNotes?: string;
        newStatusId?: number;
    }, userId: number) => Promise<{
        success: boolean;
        responseId?: number;
        message?: string;
    }>;
    updateQueryStatus: (queryId: number, statusId: number, userId: number, options?: {
        reason?: string;
        signature?: boolean;
    }) => Promise<{
        success: boolean;
        message?: string;
    }>;
    closeQueryWithSignature: (queryId: number, userId: number, data: {
        password: string;
        reason: string;
        meaning?: string;
    }) => Promise<{
        success: boolean;
        message?: string;
    }>;
    getQueryAuditTrail: (queryId: number) => Promise<any[]>;
    getQueryStats: (studyId: number) => Promise<any>;
    getQueryTypes: () => Promise<any[]>;
    getResolutionStatuses: () => Promise<any[]>;
    getFormQueries: (eventCrfId: number) => Promise<any[]>;
    reassignQuery: (queryId: number, assignedUserId: number, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    getQueryCountByStatus: (studyId: number) => Promise<any[]>;
    getQueryCountByType: (studyId: number) => Promise<any[]>;
    getQueryThread: (queryId: number) => Promise<any[]>;
    getOverdueQueries: (studyId: number, daysThreshold?: number) => Promise<any[]>;
    getMyAssignedQueries: (userId: number, studyId?: number) => Promise<any[]>;
};
export default _default;
//# sourceMappingURL=query.service.d.ts.map