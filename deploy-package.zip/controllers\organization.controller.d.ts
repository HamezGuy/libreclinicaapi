/**
 * Organization Controller
 *
 * Handles HTTP requests for organization management, invite codes,
 * access requests, and invitations
 */
import { Request, Response } from 'express';
/**
 * POST /api/organizations/register
 * Register a new organization with admin user (public endpoint)
 */
export declare const registerOrganization: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/organizations
 * Get organizations (admin only)
 */
export declare const listOrganizations: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/organizations/:id
 * Get organization by ID
 */
export declare const getOrganization: (req: Request, res: Response) => Promise<void>;
/**
 * PATCH /api/organizations/:id/status
 * Update organization status (approve/reject/suspend)
 */
export declare const updateStatus: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/organizations/my
 * Get current user's organizations
 */
export declare const getMyOrganizations: (req: Request, res: Response) => Promise<void>;
/**
 * POST /api/codes/validate
 * Validate an organization code (public endpoint)
 */
export declare const validateCode: (req: Request, res: Response) => Promise<void>;
/**
 * POST /api/codes/register
 * Register with an organization code (public endpoint)
 */
export declare const registerWithCode: (req: Request, res: Response) => Promise<void>;
/**
 * POST /api/organizations/:id/codes
 * Generate a new organization code
 */
export declare const generateCode: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/organizations/:id/codes
 * List organization codes
 */
export declare const listCodes: (req: Request, res: Response) => Promise<void>;
/**
 * PATCH /api/organizations/:orgId/codes/:codeId
 * Deactivate a code
 */
export declare const deactivateCode: (req: Request, res: Response) => Promise<void>;
/**
 * POST /api/access-requests
 * Create an access request (public endpoint)
 */
export declare const createAccessRequest: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/access-requests
 * List access requests (admin only)
 */
export declare const listAccessRequests: (req: Request, res: Response) => Promise<void>;
/**
 * PATCH /api/access-requests/:id
 * Review an access request (approve/reject)
 */
export declare const reviewAccessRequest: (req: Request, res: Response) => Promise<void>;
/**
 * POST /api/invitations
 * Create a user invitation
 */
export declare const createInvitation: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/invitations/:token/validate
 * Validate an invitation token (public endpoint)
 */
export declare const validateInvitation: (req: Request, res: Response) => Promise<void>;
/**
 * POST /api/invitations/:token/accept
 * Accept an invitation and create account (public endpoint)
 */
export declare const acceptInvitation: (req: Request, res: Response) => Promise<void>;
declare const _default: {
    registerOrganization: (req: Request, res: Response) => Promise<void>;
    listOrganizations: (req: Request, res: Response) => Promise<void>;
    getOrganization: (req: Request, res: Response) => Promise<void>;
    updateStatus: (req: Request, res: Response) => Promise<void>;
    getMyOrganizations: (req: Request, res: Response) => Promise<void>;
    validateCode: (req: Request, res: Response) => Promise<void>;
    registerWithCode: (req: Request, res: Response) => Promise<void>;
    generateCode: (req: Request, res: Response) => Promise<void>;
    listCodes: (req: Request, res: Response) => Promise<void>;
    deactivateCode: (req: Request, res: Response) => Promise<void>;
    createAccessRequest: (req: Request, res: Response) => Promise<void>;
    listAccessRequests: (req: Request, res: Response) => Promise<void>;
    reviewAccessRequest: (req: Request, res: Response) => Promise<void>;
    createInvitation: (req: Request, res: Response) => Promise<void>;
    validateInvitation: (req: Request, res: Response) => Promise<void>;
    acceptInvitation: (req: Request, res: Response) => Promise<void>;
};
export default _default;
//# sourceMappingURL=organization.controller.d.ts.map