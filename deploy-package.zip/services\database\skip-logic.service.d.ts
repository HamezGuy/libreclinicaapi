/**
 * Skip Logic Service
 *
 * Manages skip logic rules, form linking, and conditional field visibility.
 *
 * Features:
 * - CRUD operations for skip logic rules
 * - Form linking based on field values (e.g., open SAE form if AE = Yes)
 * - Evaluation of conditions at runtime
 * - Integration with LibreClinica's scd_item_metadata (Simple Conditional Display)
 *
 * 21 CFR Part 11 §11.10(h) - Device checks for data validity
 */
import { SkipLogicRule, SkipLogicCondition, FormLink, EvaluateSkipLogicResponse, CreateSkipLogicRuleRequest, CreateFormLinkRequest } from '../../types/skip-logic.types';
/**
 * Initialize skip logic tables if they don't exist
 */
export declare const initializeSkipLogicTables: () => Promise<boolean>;
/**
 * Get all skip logic rules for a CRF
 */
export declare const getSkipLogicRulesForCrf: (crfId: number) => Promise<SkipLogicRule[]>;
/**
 * Create a new skip logic rule
 */
export declare const createSkipLogicRule: (request: CreateSkipLogicRuleRequest, userId: number) => Promise<{
    success: boolean;
    ruleId?: number;
    message?: string;
}>;
/**
 * Update a skip logic rule
 */
export declare const updateSkipLogicRule: (ruleId: number, updates: Partial<CreateSkipLogicRuleRequest>, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Delete a skip logic rule
 */
export declare const deleteSkipLogicRule: (ruleId: number, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Get all form links for a source CRF
 */
export declare const getFormLinksForCrf: (crfId: number) => Promise<FormLink[]>;
/**
 * Get form links for a specific field
 */
export declare const getFormLinksForField: (crfId: number, fieldId: string) => Promise<FormLink[]>;
/**
 * Create a form link
 */
export declare const createFormLink: (request: CreateFormLinkRequest, userId: number) => Promise<{
    success: boolean;
    linkId?: number;
    message?: string;
}>;
/**
 * Delete a form link
 */
export declare const deleteFormLink: (linkId: number, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Evaluate all skip logic for a form and return field states
 */
export declare const evaluateSkipLogic: (crfId: number, formData: Record<string, any>, options?: {
    subjectId?: number;
    eventId?: number;
    includeFormLinks?: boolean;
}) => Promise<EvaluateSkipLogicResponse>;
/**
 * Evaluate conditions against form data
 */
export declare const evaluateConditions: (conditions: SkipLogicCondition[], formData: Record<string, any>) => boolean;
declare const _default: {
    initializeSkipLogicTables: () => Promise<boolean>;
    getSkipLogicRulesForCrf: (crfId: number) => Promise<SkipLogicRule[]>;
    createSkipLogicRule: (request: CreateSkipLogicRuleRequest, userId: number) => Promise<{
        success: boolean;
        ruleId?: number;
        message?: string;
    }>;
    updateSkipLogicRule: (ruleId: number, updates: Partial<CreateSkipLogicRuleRequest>, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    deleteSkipLogicRule: (ruleId: number, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    getFormLinksForCrf: (crfId: number) => Promise<FormLink[]>;
    getFormLinksForField: (crfId: number, fieldId: string) => Promise<FormLink[]>;
    createFormLink: (request: CreateFormLinkRequest, userId: number) => Promise<{
        success: boolean;
        linkId?: number;
        message?: string;
    }>;
    deleteFormLink: (linkId: number, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    evaluateSkipLogic: (crfId: number, formData: Record<string, any>, options?: {
        subjectId?: number;
        eventId?: number;
        includeFormLinks?: boolean;
    }) => Promise<EvaluateSkipLogicResponse>;
    evaluateConditions: (conditions: SkipLogicCondition[], formData: Record<string, any>) => boolean;
};
export default _default;
//# sourceMappingURL=skip-logic.service.d.ts.map