"use strict";
/**
 * Server Startup
 *
 * Main server entry point
 * - Database connection test
 * - SOAP connection test
 * - Server startup
 * - Graceful shutdown
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("./app"));
const environment_1 = require("./config/environment");
const database_1 = require("./config/database");
const logger_1 = require("./config/logger");
const soapClient_1 = require("./services/soap/soapClient");
const backup_scheduler_service_1 = require("./services/backup/backup-scheduler.service");
const PORT = environment_1.config.server.port || 3000;
const HOST = '0.0.0.0';
/**
 * Test database connection
 */
async function testDatabaseConnection() {
    try {
        const result = await database_1.pool.query('SELECT NOW() as current_time, version() as db_version');
        logger_1.logger.info('Database connection successful', {
            time: result.rows[0].current_time,
            version: result.rows[0].db_version
        });
        return true;
    }
    catch (error) {
        logger_1.logger.error('Database connection failed', {
            error: error.message,
            host: environment_1.config.libreclinica.database.host,
            database: environment_1.config.libreclinica.database.database
        });
        return false;
    }
}
/**
 * Verify and initialize audit tables
 * Ensures audit_user_login table exists for 21 CFR Part 11 compliance
 */
async function verifyAuditTables() {
    try {
        // Check if audit_user_login table exists
        const tableCheck = await database_1.pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'audit_user_login'
      ) as exists
    `);
        if (!tableCheck.rows[0].exists) {
            logger_1.logger.warn('audit_user_login table not found - creating...');
            // Create the table if it doesn't exist
            // Note: LibreClinica uses login_status_code (not login_status)
            await database_1.pool.query(`
        CREATE TABLE IF NOT EXISTS audit_user_login (
          id SERIAL PRIMARY KEY,
          user_name VARCHAR(255),
          user_account_id INTEGER,
          login_attempt_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          login_status_code INTEGER,
          details VARCHAR(500),
          version INTEGER DEFAULT 1
        )
      `);
            // Create index for performance
            await database_1.pool.query(`
        CREATE INDEX IF NOT EXISTS idx_audit_user_login_date 
        ON audit_user_login(login_attempt_date)
      `);
            await database_1.pool.query(`
        CREATE INDEX IF NOT EXISTS idx_audit_user_login_user 
        ON audit_user_login(user_account_id)
      `);
            logger_1.logger.info('audit_user_login table created successfully');
        }
        else {
            // Verify the table has data
            const countResult = await database_1.pool.query('SELECT COUNT(*) as count FROM audit_user_login');
            logger_1.logger.info('audit_user_login table verified', {
                recordCount: parseInt(countResult.rows[0].count)
            });
        }
        // Also verify audit_user_api_log table
        const apiLogCheck = await database_1.pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'audit_user_api_log'
      ) as exists
    `);
        if (!apiLogCheck.rows[0].exists) {
            logger_1.logger.info('Creating audit_user_api_log table...');
            await database_1.pool.query(`
        CREATE TABLE IF NOT EXISTS audit_user_api_log (
          id SERIAL PRIMARY KEY,
          audit_id VARCHAR(36) NOT NULL UNIQUE,
          user_id INTEGER,
          username VARCHAR(255) NOT NULL,
          user_role VARCHAR(50),
          http_method VARCHAR(10) NOT NULL,
          endpoint_path VARCHAR(500) NOT NULL,
          query_params TEXT,
          request_body TEXT,
          response_status INTEGER,
          ip_address VARCHAR(45),
          user_agent TEXT,
          duration_ms INTEGER,
          created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
      `);
            logger_1.logger.info('audit_user_api_log table created');
        }
    }
    catch (error) {
        logger_1.logger.error('Failed to verify audit tables', {
            error: error.message
        });
        // Don't fail startup, but log the error
    }
}
/**
 * Test SOAP connection
 */
async function testSoapConnection() {
    // Skip SOAP if disabled in config
    if (!environment_1.config.libreclinica.soapEnabled) {
        logger_1.logger.info('SOAP disabled - using direct database access only');
        return false;
    }
    try {
        const soapClient = (0, soapClient_1.getSoapClient)();
        const isConnected = await soapClient.testConnection('study');
        if (isConnected) {
            logger_1.logger.info('SOAP connection successful', {
                url: environment_1.config.libreclinica.soapUrl
            });
            return true;
        }
        else {
            logger_1.logger.warn('SOAP connection test failed', {
                url: environment_1.config.libreclinica.soapUrl
            });
            return false;
        }
    }
    catch (error) {
        logger_1.logger.warn('SOAP connection test error', {
            error: error.message,
            url: environment_1.config.libreclinica.soapUrl
        });
        // Don't fail startup on SOAP error - it might not be available yet
        return false;
    }
}
/**
 * Initialize backup scheduler
 */
async function initializeBackupScheduler() {
    try {
        await (0, backup_scheduler_service_1.initializeScheduler)();
    }
    catch (error) {
        logger_1.logger.error('Failed to initialize backup scheduler', {
            error: error.message
        });
        // Don't fail startup, but log the error
    }
}
/**
 * Start the server
 */
async function startServer() {
    try {
        logger_1.logger.info('Starting LibreClinica API server...');
        // Test database connection
        const dbConnected = await testDatabaseConnection();
        if (!dbConnected) {
            logger_1.logger.error('Cannot start server: Database connection failed');
            process.exit(1);
        }
        // Verify audit tables exist (21 CFR Part 11 compliance)
        await verifyAuditTables();
        // Test SOAP connection (warning only)
        await testSoapConnection();
        // Initialize backup scheduler (21 CFR Part 11 compliant automated backups)
        await initializeBackupScheduler();
        // Start Express server
        const server = app_1.default.listen(PORT, HOST, () => {
            logger_1.logger.info(` LibreClinica API started successfully`, {
                port: PORT,
                host: HOST,
                environment: process.env.NODE_ENV || 'development',
                nodeVersion: process.version
            });
            logger_1.logger.info('API endpoints:', {
                health: `http://${HOST}:${PORT}/health`,
                api: `http://${HOST}:${PORT}/api`,
                auth: `http://${HOST}:${PORT}/api/auth/login`
            });
            logger_1.logger.info('Security features enabled:', {
                helmet: 'enabled',
                cors: 'enabled',
                rateLimiting: 'enabled',
                auditLogging: 'enabled',
                jwtAuth: 'enabled'
            });
        });
        // Graceful shutdown handlers
        const gracefulShutdown = (signal) => {
            logger_1.logger.info(`${signal} received, starting graceful shutdown...`);
            server.close(async () => {
                logger_1.logger.info('HTTP server closed');
                try {
                    await database_1.pool.end();
                    logger_1.logger.info('Database connections closed');
                    logger_1.logger.info('Graceful shutdown completed');
                    process.exit(0);
                }
                catch (error) {
                    logger_1.logger.error('Error during shutdown', { error: error.message });
                    process.exit(1);
                }
            });
            // Force shutdown after 30 seconds
            setTimeout(() => {
                logger_1.logger.error('Forced shutdown after timeout');
                process.exit(1);
            }, 30000);
        };
        // Handle shutdown signals
        process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
        process.on('SIGINT', () => gracefulShutdown('SIGINT'));
        // Handle uncaught errors
        process.on('uncaughtException', (error) => {
            logger_1.logger.error('Uncaught exception', {
                error: error.message,
                stack: error.stack
            });
            process.exit(1);
        });
        process.on('unhandledRejection', (reason) => {
            logger_1.logger.error('Unhandled rejection', {
                reason: reason?.message || reason
            });
            process.exit(1);
        });
    }
    catch (error) {
        logger_1.logger.error('Server startup failed', {
            error: error.message,
            stack: error.stack
        });
        process.exit(1);
    }
}
// Start the server
startServer();
//# sourceMappingURL=server.js.map