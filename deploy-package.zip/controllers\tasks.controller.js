"use strict";
/**
 * Tasks Controller
 *
 * Handles API requests for the unified task system.
 * Aggregates work items from multiple LibreClinica tables:
 * - discrepancy_note (queries)
 * - study_event (scheduled visits)
 * - event_crf (forms, SDV, signatures)
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getOverdueTasks = exports.getTasksByType = exports.getTask = exports.getUserTaskSummary = exports.getTaskSummary = exports.getUserTasks = exports.getTasks = void 0;
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const tasksService = __importStar(require("../services/database/tasks.service"));
/**
 * Get tasks for current user
 * GET /api/tasks
 */
exports.getTasks = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { studyId, types, status, priority, includeQueries, limit, offset } = req.query;
    const filters = {
        userId: user?.userId,
        username: user?.username,
        studyId: studyId ? parseInt(studyId) : undefined,
        types: types ? types.split(',') : undefined,
        status: status,
        priority: priority,
        includeQueries: includeQueries !== 'false', // Default to true
        limit: limit ? parseInt(limit) : 50,
        offset: offset ? parseInt(offset) : 0
    };
    const result = await tasksService.getUserTasks(filters);
    res.json(result);
});
/**
 * Get tasks for specific user
 * GET /api/tasks/user/:username
 */
exports.getUserTasks = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { username } = req.params;
    const { studyId, types, status, priority, limit } = req.query;
    const filters = {
        username,
        studyId: studyId ? parseInt(studyId) : undefined,
        types: types ? types.split(',') : undefined,
        status: status,
        priority: priority,
        limit: limit ? parseInt(limit) : 50
    };
    const result = await tasksService.getUserTasks(filters);
    res.json(result);
});
/**
 * Get task summary for current user
 * GET /api/tasks/summary
 */
exports.getTaskSummary = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { studyId, includeQueries } = req.query;
    const filters = {
        userId: user?.userId,
        username: user?.username,
        studyId: studyId ? parseInt(studyId) : undefined,
        includeQueries: includeQueries !== 'false' // Default to true
    };
    const result = await tasksService.getTaskSummary(filters);
    res.json(result);
});
/**
 * Get task summary for specific user
 * GET /api/tasks/user/:username/summary
 */
exports.getUserTaskSummary = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { username } = req.params;
    const { studyId } = req.query;
    const filters = {
        username,
        studyId: studyId ? parseInt(studyId) : undefined
    };
    const result = await tasksService.getTaskSummary(filters);
    res.json(result);
});
/**
 * Get single task by ID
 * GET /api/tasks/:taskId
 */
exports.getTask = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { taskId } = req.params;
    const result = await tasksService.getTaskById(taskId);
    if (!result.data) {
        res.status(404).json({ success: false, message: 'Task not found' });
        return;
    }
    res.json(result);
});
/**
 * Get tasks by type
 * GET /api/tasks/type/:type
 */
exports.getTasksByType = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { type } = req.params;
    const { studyId, limit } = req.query;
    const validTypes = [
        'query', 'scheduled_visit', 'data_entry',
        'form_completion', 'sdv_required', 'signature_required'
    ];
    if (!validTypes.includes(type)) {
        res.status(400).json({ success: false, message: 'Invalid task type' });
        return;
    }
    const filters = {
        userId: user?.userId,
        username: user?.username,
        studyId: studyId ? parseInt(studyId) : undefined,
        types: [type],
        limit: limit ? parseInt(limit) : 50
    };
    const result = await tasksService.getUserTasks(filters);
    res.json(result);
});
/**
 * Get overdue tasks
 * GET /api/tasks/overdue
 */
exports.getOverdueTasks = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { studyId, limit } = req.query;
    const filters = {
        userId: user?.userId,
        username: user?.username,
        studyId: studyId ? parseInt(studyId) : undefined,
        status: 'overdue',
        limit: limit ? parseInt(limit) : 50
    };
    const result = await tasksService.getUserTasks(filters);
    // Filter to only overdue tasks
    result.data = result.data.filter(t => t.status === 'overdue');
    result.total = result.data.length;
    res.json(result);
});
exports.default = {
    getTasks: exports.getTasks,
    getUserTasks: exports.getUserTasks,
    getTaskSummary: exports.getTaskSummary,
    getUserTaskSummary: exports.getUserTaskSummary,
    getTask: exports.getTask,
    getTasksByType: exports.getTasksByType,
    getOverdueTasks: exports.getOverdueTasks
};
//# sourceMappingURL=tasks.controller.js.map