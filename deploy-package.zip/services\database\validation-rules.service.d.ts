/**
 * Validation Rules Service
 *
 * Manages validation rules for CRFs (forms) in LibreClinica
 *
 * LibreClinica stores validation at the item level in item_form_metadata:
 * - regexp: Regular expression pattern
 * - regexp_error_msg: Error message when validation fails
 * - required: Whether the field is required
 *
 * This service extends that with a custom rules table for advanced validations.
 *
 * 21 CFR Part 11 §11.10(h) - Device checks (validation rules)
 */
export interface ValidationRule {
    id: number;
    crfId: number;
    crfVersionId?: number;
    itemId?: number;
    name: string;
    description: string;
    ruleType: 'range' | 'format' | 'required' | 'consistency' | 'business_logic' | 'cross_form';
    fieldPath: string;
    severity: 'error' | 'warning';
    errorMessage: string;
    warningMessage?: string;
    active: boolean;
    minValue?: number;
    maxValue?: number;
    pattern?: string;
    operator?: string;
    compareFieldPath?: string;
    customExpression?: string;
    dateCreated: Date;
    dateUpdated?: Date;
    createdBy: number;
    updatedBy?: number;
}
export interface CreateValidationRuleRequest {
    crfId: number;
    crfVersionId?: number;
    itemId?: number;
    name: string;
    description?: string;
    ruleType: string;
    fieldPath: string;
    severity: string;
    errorMessage: string;
    warningMessage?: string;
    minValue?: number;
    maxValue?: number;
    pattern?: string;
    operator?: string;
    compareFieldPath?: string;
    customExpression?: string;
}
/**
 * Initialize the validation_rules table if it doesn't exist
 * Uses simple columns without foreign key constraints to avoid dependency issues
 */
export declare const initializeValidationRulesTable: () => Promise<boolean>;
/**
 * Get all validation rules for a CRF
 */
export declare const getRulesForCrf: (crfId: number) => Promise<ValidationRule[]>;
/**
 * Get all validation rules for a study (all CRFs)
 *
 * Returns unique CRFs associated with the study through:
 * 1. Event definitions (edc -> sed -> study)
 * 2. Source study ID
 * 3. Fallback to all available CRFs if none found
 *
 * Uses UNION to combine sources and GROUP BY to deduplicate
 */
export declare const getRulesForStudy: (studyId: number) => Promise<{
    crfId: number;
    crfName: string;
    rules: ValidationRule[];
}[]>;
/**
 * Get a single validation rule by ID
 */
export declare const getRuleById: (ruleId: number) => Promise<ValidationRule | null>;
/**
 * Create a new validation rule
 */
export declare const createRule: (rule: CreateValidationRuleRequest, userId: number) => Promise<{
    success: boolean;
    ruleId?: number;
    message?: string;
}>;
/**
 * Update a validation rule
 */
export declare const updateRule: (ruleId: number, updates: Partial<CreateValidationRuleRequest>, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Toggle validation rule active state
 */
export declare const toggleRule: (ruleId: number, active: boolean, userId: number) => Promise<{
    success: boolean;
}>;
/**
 * Delete a validation rule
 */
export declare const deleteRule: (ruleId: number, userId: number) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Validate form data against rules
 *
 * @param crfId - The CRF ID to validate against
 * @param formData - The form data to validate
 * @param options - Optional parameters for query creation
 * @param options.createQueries - If true, creates queries for validation failures
 * @param options.studyId - Study ID for query creation
 * @param options.subjectId - Subject ID for query creation
 * @param options.eventCrfId - Event CRF ID for query creation
 * @param options.userId - User ID who triggered validation
 */
export declare const validateFormData: (crfId: number, formData: Record<string, any>, options?: {
    createQueries?: boolean;
    studyId?: number;
    subjectId?: number;
    eventCrfId?: number;
    userId?: number;
}) => Promise<{
    valid: boolean;
    errors: {
        fieldPath: string;
        message: string;
        severity: string;
        queryId?: number;
    }[];
    warnings: {
        fieldPath: string;
        message: string;
    }[];
    queriesCreated?: number;
}>;
declare const _default: {
    initializeValidationRulesTable: () => Promise<boolean>;
    getRulesForCrf: (crfId: number) => Promise<ValidationRule[]>;
    getRulesForStudy: (studyId: number) => Promise<{
        crfId: number;
        crfName: string;
        rules: ValidationRule[];
    }[]>;
    getRuleById: (ruleId: number) => Promise<ValidationRule | null>;
    createRule: (rule: CreateValidationRuleRequest, userId: number) => Promise<{
        success: boolean;
        ruleId?: number;
        message?: string;
    }>;
    updateRule: (ruleId: number, updates: Partial<CreateValidationRuleRequest>, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    toggleRule: (ruleId: number, active: boolean, userId: number) => Promise<{
        success: boolean;
    }>;
    deleteRule: (ruleId: number, userId: number) => Promise<{
        success: boolean;
        message?: string;
    }>;
    validateFormData: (crfId: number, formData: Record<string, any>, options?: {
        createQueries?: boolean;
        studyId?: number;
        subjectId?: number;
        eventCrfId?: number;
        userId?: number;
    }) => Promise<{
        valid: boolean;
        errors: {
            fieldPath: string;
            message: string;
            severity: string;
            queryId?: number;
        }[];
        warnings: {
            fieldPath: string;
            message: string;
        }[];
        queriesCreated?: number;
    }>;
};
export default _default;
//# sourceMappingURL=validation-rules.service.d.ts.map