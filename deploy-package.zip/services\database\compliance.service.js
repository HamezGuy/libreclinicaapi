"use strict";
/**
 * 21 CFR Part 11 Compliance Service
 *
 * This service ensures proper integration with LibreClinica's compliance features:
 * - Uses LibreClinica's audit_log_event table and event types
 * - Properly logs electronic signatures
 * - Ensures audit trail integrity
 *
 * IMPORTANT: LibreClinica uses DATABASE TRIGGERS to automatically log changes.
 * These triggers fire when data is modified in:
 * - item_data (form field values)
 * - event_crf (form instances)
 * - study_event (visits)
 * - study_subject (subjects)
 * - subject (global subject records)
 * - subject_group_map (randomization)
 * - dn_item_data_map (discrepancy notes)
 * - event_definition_crf (form definitions)
 *
 * This service handles operations NOT covered by triggers:
 * - Electronic signatures with password verification
 * - API-level audit entries
 * - Custom compliance logging
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getComplianceStatus = exports.getAuditTrail = exports.verifyPasswordForCompliance = exports.logStudyEventLock = exports.logSDVVerification = exports.logElectronicSignature = exports.logLibreClinicaAuditEvent = exports.LibreClinicaAuditEventType = void 0;
const database_1 = require("../../config/database");
const logger_1 = require("../../config/logger");
const crypto_1 = __importDefault(require("crypto"));
/**
 * LibreClinica Audit Event Types
 * These are the EXACT event types from LibreClinica's audit_log_event_type table
 */
var LibreClinicaAuditEventType;
(function (LibreClinicaAuditEventType) {
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["ITEM_DATA_VALUE_UPDATED"] = 1] = "ITEM_DATA_VALUE_UPDATED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["STUDY_SUBJECT_CREATED"] = 2] = "STUDY_SUBJECT_CREATED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["STUDY_SUBJECT_STATUS_CHANGED"] = 3] = "STUDY_SUBJECT_STATUS_CHANGED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["STUDY_SUBJECT_VALUE_CHANGED"] = 4] = "STUDY_SUBJECT_VALUE_CHANGED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["SUBJECT_CREATED"] = 5] = "SUBJECT_CREATED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["SUBJECT_STATUS_CHANGED"] = 6] = "SUBJECT_STATUS_CHANGED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["SUBJECT_GLOBAL_VALUE_CHANGED"] = 7] = "SUBJECT_GLOBAL_VALUE_CHANGED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["EVENT_CRF_MARKED_COMPLETE"] = 8] = "EVENT_CRF_MARKED_COMPLETE";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["EVENT_CRF_PROPERTIES_CHANGED"] = 9] = "EVENT_CRF_PROPERTIES_CHANGED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["EVENT_CRF_IDE_COMPLETE"] = 10] = "EVENT_CRF_IDE_COMPLETE";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["EVENT_CRF_DDE_COMPLETE"] = 11] = "EVENT_CRF_DDE_COMPLETE";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["ITEM_DATA_STATUS_CHANGED"] = 12] = "ITEM_DATA_STATUS_CHANGED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["ITEM_DATA_DELETED"] = 13] = "ITEM_DATA_DELETED";
    // ELECTRONIC SIGNATURE EVENT TYPES (21 CFR Part 11 §11.50)
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["EVENT_CRF_COMPLETE_WITH_PASSWORD"] = 14] = "EVENT_CRF_COMPLETE_WITH_PASSWORD";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["EVENT_CRF_IDE_COMPLETE_WITH_PASSWORD"] = 15] = "EVENT_CRF_IDE_COMPLETE_WITH_PASSWORD";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["EVENT_CRF_DDE_COMPLETE_WITH_PASSWORD"] = 16] = "EVENT_CRF_DDE_COMPLETE_WITH_PASSWORD";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["STUDY_EVENT_SCHEDULED"] = 17] = "STUDY_EVENT_SCHEDULED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["STUDY_EVENT_DATA_ENTRY_STARTED"] = 18] = "STUDY_EVENT_DATA_ENTRY_STARTED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["STUDY_EVENT_COMPLETED"] = 19] = "STUDY_EVENT_COMPLETED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["STUDY_EVENT_STOPPED"] = 20] = "STUDY_EVENT_STOPPED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["STUDY_EVENT_SKIPPED"] = 21] = "STUDY_EVENT_SKIPPED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["STUDY_EVENT_LOCKED"] = 22] = "STUDY_EVENT_LOCKED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["STUDY_EVENT_REMOVED"] = 23] = "STUDY_EVENT_REMOVED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["STUDY_EVENT_START_DATE_CHANGED"] = 24] = "STUDY_EVENT_START_DATE_CHANGED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["STUDY_EVENT_END_DATE_CHANGED"] = 25] = "STUDY_EVENT_END_DATE_CHANGED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["STUDY_EVENT_LOCATION_CHANGED"] = 26] = "STUDY_EVENT_LOCATION_CHANGED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["SUBJECT_SITE_ASSIGNMENT"] = 27] = "SUBJECT_SITE_ASSIGNMENT";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["SUBJECT_GROUP_ASSIGNMENT"] = 28] = "SUBJECT_GROUP_ASSIGNMENT";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["SUBJECT_GROUP_CHANGED"] = 29] = "SUBJECT_GROUP_CHANGED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["ITEM_DATA_REPEATING_ROW_INSERTED"] = 30] = "ITEM_DATA_REPEATING_ROW_INSERTED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["STUDY_EVENT_SIGNED"] = 31] = "STUDY_EVENT_SIGNED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["EVENT_CRF_SDV_STATUS"] = 32] = "EVENT_CRF_SDV_STATUS";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["CHANGE_CRF_VERSION"] = 33] = "CHANGE_CRF_VERSION";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["STUDY_EVENT_RESTORED"] = 35] = "STUDY_EVENT_RESTORED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["EVENT_CRF_DELETED"] = 40] = "EVENT_CRF_DELETED";
    LibreClinicaAuditEventType[LibreClinicaAuditEventType["EVENT_CRF_STARTED"] = 41] = "EVENT_CRF_STARTED";
})(LibreClinicaAuditEventType || (exports.LibreClinicaAuditEventType = LibreClinicaAuditEventType = {}));
/**
 * Log an audit event using LibreClinica's audit_log_event table
 * This uses the EXACT schema and event types from LibreClinica
 */
const logLibreClinicaAuditEvent = async (eventTypeId, userId, params) => {
    logger_1.logger.info('Logging LibreClinica audit event', { eventTypeId, userId, params });
    try {
        const query = `
      INSERT INTO audit_log_event (
        audit_date,
        audit_table,
        user_id,
        entity_id,
        entity_name,
        old_value,
        new_value,
        audit_log_event_type_id,
        reason_for_change,
        event_crf_id,
        study_event_id,
        event_crf_version_id
      ) VALUES (
        NOW(), $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11
      )
      RETURNING audit_id
    `;
        const result = await database_1.pool.query(query, [
            params.auditTable,
            userId,
            params.entityId || null,
            params.entityName || null,
            params.oldValue || null,
            params.newValue || null,
            eventTypeId,
            params.reasonForChange || null,
            params.eventCrfId || null,
            params.studyEventId || null,
            params.eventCrfVersionId || null
        ]);
        const auditId = result.rows[0].audit_id;
        logger_1.logger.info('LibreClinica audit event logged', { auditId, eventTypeId });
        return { success: true, auditId };
    }
    catch (error) {
        logger_1.logger.error('Failed to log LibreClinica audit event', { error: error.message });
        return { success: false, error: error.message };
    }
};
exports.logLibreClinicaAuditEvent = logLibreClinicaAuditEvent;
/**
 * Log Electronic Signature with proper 21 CFR Part 11 compliance
 *
 * This uses LibreClinica's e-signature event types:
 * - Event CRF complete with password (14)
 * - Study Event signed (31)
 */
const logElectronicSignature = async (userId, username, params) => {
    logger_1.logger.info('Logging electronic signature (21 CFR Part 11 §11.50)', { userId, username, params });
    // Determine the correct event type based on entity
    let eventTypeId;
    if (params.entityType === 'event_crf') {
        eventTypeId = LibreClinicaAuditEventType.EVENT_CRF_COMPLETE_WITH_PASSWORD;
    }
    else if (params.entityType === 'study_event') {
        eventTypeId = LibreClinicaAuditEventType.STUDY_EVENT_SIGNED;
    }
    else {
        // Default to CRF complete with password
        eventTypeId = LibreClinicaAuditEventType.EVENT_CRF_COMPLETE_WITH_PASSWORD;
    }
    // Create the signature manifest per §11.50
    const signatureManifest = JSON.stringify({
        type: 'electronic_signature',
        version: '1.0',
        signer: username,
        meaning: params.meaning,
        timestamp: new Date().toISOString(),
        cfr_compliance: {
            '11.50': 'Signature includes printed name, date/time, and meaning',
            '11.100': 'Signature is unique to individual',
            '11.200': 'Two-factor authentication (username + password)'
        }
    });
    return (0, exports.logLibreClinicaAuditEvent)(eventTypeId, userId, {
        auditTable: params.entityType,
        entityId: params.entityId,
        entityName: params.entityName,
        newValue: signatureManifest,
        reasonForChange: `Electronic signature applied: ${params.meaning}`,
        eventCrfId: params.eventCrfId,
        studyEventId: params.studyEventId
    });
};
exports.logElectronicSignature = logElectronicSignature;
/**
 * Log SDV (Source Data Verification) completion
 * Uses LibreClinica's EVENT_CRF_SDV_STATUS (32) event type
 */
const logSDVVerification = async (userId, params) => {
    logger_1.logger.info('Logging SDV verification', { userId, params });
    return (0, exports.logLibreClinicaAuditEvent)(LibreClinicaAuditEventType.EVENT_CRF_SDV_STATUS, userId, {
        auditTable: 'event_crf',
        entityId: params.eventCrfId,
        entityName: params.entityName,
        oldValue: params.verified ? 'false' : 'true',
        newValue: params.verified ? 'true' : 'false',
        reasonForChange: params.verified ? 'SDV completed' : 'SDV reverted',
        eventCrfId: params.eventCrfId,
        studyEventId: params.studyEventId
    });
};
exports.logSDVVerification = logSDVVerification;
/**
 * Log Study Event Lock/Unlock
 * Uses LibreClinica's STUDY_EVENT_LOCKED (22) event type
 */
const logStudyEventLock = async (userId, params) => {
    logger_1.logger.info('Logging study event lock', { userId, params });
    return (0, exports.logLibreClinicaAuditEvent)(LibreClinicaAuditEventType.STUDY_EVENT_LOCKED, userId, {
        auditTable: 'study_event',
        entityId: params.studyEventId,
        entityName: params.entityName,
        newValue: params.locked ? 'locked' : 'unlocked',
        reasonForChange: params.reason,
        studyEventId: params.studyEventId
    });
};
exports.logStudyEventLock = logStudyEventLock;
/**
 * Verify password for electronic signature
 * Uses MD5 hash for LibreClinica compatibility
 */
const verifyPasswordForCompliance = async (userId, password) => {
    try {
        const query = `
      SELECT passwd, status_id 
      FROM user_account 
      WHERE user_id = $1
    `;
        const result = await database_1.pool.query(query, [userId]);
        if (result.rows.length === 0) {
            return { success: false, message: 'User not found' };
        }
        const user = result.rows[0];
        // status_id: 1 = active, 5 = locked
        if (user.status_id !== 1) {
            return { success: false, message: 'Account is not active' };
        }
        // Hash password using MD5 (LibreClinica compatibility)
        const passwordHash = crypto_1.default.createHash('md5').update(password).digest('hex');
        if (passwordHash !== user.passwd) {
            return { success: false, message: 'Invalid password' };
        }
        return { success: true };
    }
    catch (error) {
        logger_1.logger.error('Password verification error', { error: error.message });
        return { success: false, message: 'Verification failed' };
    }
};
exports.verifyPasswordForCompliance = verifyPasswordForCompliance;
/**
 * Get audit trail for an entity
 * Returns LibreClinica audit log entries
 */
const getAuditTrail = async (entityType, entityId, limit = 50) => {
    try {
        let whereClause;
        switch (entityType) {
            case 'event_crf':
                whereClause = `ale.event_crf_id = $1 OR (ale.audit_table = 'event_crf' AND ale.entity_id = $1)`;
                break;
            case 'study_event':
                whereClause = `ale.study_event_id = $1 OR (ale.audit_table = 'study_event' AND ale.entity_id = $1)`;
                break;
            case 'study_subject':
                whereClause = `ale.audit_table = 'study_subject' AND ale.entity_id = $1`;
                break;
            case 'item_data':
                whereClause = `ale.audit_table = 'item_data' AND ale.entity_id = $1`;
                break;
            default:
                whereClause = `ale.entity_id = $1`;
        }
        const query = `
      SELECT 
        ale.audit_id,
        ale.audit_date,
        ale.audit_table,
        ale.entity_id,
        ale.entity_name,
        ale.old_value,
        ale.new_value,
        ale.reason_for_change,
        alet.name as event_type,
        ua.user_name,
        ua.first_name || ' ' || ua.last_name as full_name
      FROM audit_log_event ale
      LEFT JOIN audit_log_event_type alet ON ale.audit_log_event_type_id = alet.audit_log_event_type_id
      LEFT JOIN user_account ua ON ale.user_id = ua.user_id
      WHERE ${whereClause}
      ORDER BY ale.audit_date DESC
      LIMIT $2
    `;
        const result = await database_1.pool.query(query, [entityId, limit]);
        return {
            success: true,
            data: result.rows.map(row => ({
                auditId: row.audit_id,
                auditDate: row.audit_date,
                auditTable: row.audit_table,
                entityId: row.entity_id,
                entityName: row.entity_name,
                oldValue: row.old_value,
                newValue: row.new_value,
                reasonForChange: row.reason_for_change,
                eventType: row.event_type,
                userName: row.user_name,
                fullName: row.full_name
            }))
        };
    }
    catch (error) {
        logger_1.logger.error('Get audit trail error', { error: error.message });
        return { success: false, error: error.message };
    }
};
exports.getAuditTrail = getAuditTrail;
/**
 * Check 21 CFR Part 11 compliance status
 * Returns a summary of compliance features
 */
const getComplianceStatus = async () => {
    try {
        // Check triggers
        const triggersResult = await database_1.pool.query(`
      SELECT COUNT(*) as count 
      FROM information_schema.triggers 
      WHERE trigger_schema = 'public'
    `);
        // Check recent audit entries (last 24 hours)
        const auditResult = await database_1.pool.query(`
      SELECT COUNT(*) as count 
      FROM audit_log_event 
      WHERE audit_date > NOW() - INTERVAL '24 hours'
    `);
        // Check if e-signature event types exist
        const esigResult = await database_1.pool.query(`
      SELECT COUNT(*) as count 
      FROM audit_log_event_type 
      WHERE audit_log_event_type_id IN (14, 15, 16, 31)
    `);
        return {
            success: true,
            data: {
                auditTrailEnabled: parseInt(triggersResult.rows[0].count) > 0,
                triggersActive: parseInt(triggersResult.rows[0].count),
                recentAuditEntries: parseInt(auditResult.rows[0].count),
                electronicSignaturesConfigured: parseInt(esigResult.rows[0].count) === 4,
                passwordHashingMethod: 'MD5 (LibreClinica standard)'
            }
        };
    }
    catch (error) {
        logger_1.logger.error('Compliance status check error', { error: error.message });
        return { success: false };
    }
};
exports.getComplianceStatus = getComplianceStatus;
exports.default = {
    logLibreClinicaAuditEvent: exports.logLibreClinicaAuditEvent,
    logElectronicSignature: exports.logElectronicSignature,
    logSDVVerification: exports.logSDVVerification,
    logStudyEventLock: exports.logStudyEventLock,
    verifyPasswordForCompliance: exports.verifyPasswordForCompliance,
    getAuditTrail: exports.getAuditTrail,
    getComplianceStatus: exports.getComplianceStatus,
    LibreClinicaAuditEventType
};
//# sourceMappingURL=compliance.service.js.map