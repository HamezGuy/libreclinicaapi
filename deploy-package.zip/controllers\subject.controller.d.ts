/**
 * Subject Controller
 *
 * Handles all subject/patient-related API endpoints including:
 * - CRUD operations
 * - Progress tracking
 * - Events and forms
 *
 * All operations are tracked in the audit trail.
 */
import { Request, Response } from 'express';
export declare const list: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const get: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const create: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getProgress: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Update subject
 */
export declare const update: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Update subject status
 */
export declare const updateStatus: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Soft delete subject (set status to removed)
 */
export declare const remove: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get subject events
 */
export declare const getEvents: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get subject forms/CRFs
 */
export declare const getForms: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    list: (req: Request, res: Response, next: import("express").NextFunction) => void;
    get: (req: Request, res: Response, next: import("express").NextFunction) => void;
    create: (req: Request, res: Response, next: import("express").NextFunction) => void;
    update: (req: Request, res: Response, next: import("express").NextFunction) => void;
    updateStatus: (req: Request, res: Response, next: import("express").NextFunction) => void;
    remove: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getProgress: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getEvents: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getForms: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=subject.controller.d.ts.map