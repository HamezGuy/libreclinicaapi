"use strict";
/**
 * Backup Scheduler Service - 21 CFR Part 11 Compliant
 *
 * Implements automatic backup scheduling per SOP-008 7.3.1:
 * - Full Backup: Weekly (Sunday 2:00 AM) - Retention: 4 weeks
 * - Incremental Backup: Daily (2:00 AM) - Retention: 7 days
 * - Transaction Log Backup: Hourly - Retention: 24 hours
 *
 * Uses node-cron for scheduling with audit trail for all operations.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.initializeScheduler = exports.triggerImmediateBackup = exports.getSchedulerStatus = exports.stopScheduler = exports.startScheduler = void 0;
const cron = __importStar(require("node-cron"));
const logger_1 = require("../../config/logger");
const backupService = __importStar(require("./backup.service"));
const backup_service_1 = require("./backup.service");
const database_1 = require("../../config/database");
const scheduledTasks = {
    fullBackup: null,
    incrementalBackup: null,
    transactionLogBackup: null,
    cleanup: null
};
const schedulerStatus = {
    running: false,
    startedAt: null,
    lastFullBackup: null,
    lastIncrementalBackup: null,
    lastTransactionLogBackup: null,
    lastCleanup: null,
    nextFullBackup: null,
    nextIncrementalBackup: null,
    errors: []
};
/**
 * Record scheduler audit event directly to database
 * Uses only columns that exist in native LibreClinica audit_log_event table:
 * - audit_log_event_type_id, audit_date, audit_table, entity_id, entity_name,
 * - user_id, old_value, new_value, reason_for_change, event_crf_id
 */
const recordSchedulerAudit = async (action, details) => {
    try {
        await database_1.pool.query(`
      INSERT INTO audit_log_event (
        audit_log_event_type_id,
        audit_date,
        audit_table,
        entity_id,
        entity_name,
        user_id,
        new_value
      ) VALUES (
        COALESCE(
          (SELECT audit_log_event_type_id FROM audit_log_event_type WHERE name ILIKE '%system%' OR name ILIKE '%other%' LIMIT 1),
          1
        ), 
        NOW(), 
        'backup_scheduler', 
        0, 
        $1, 
        0, 
        $2
      )
    `, [action, JSON.stringify(details)]);
    }
    catch (error) {
        logger_1.logger.warn('Could not record scheduler audit', { error: error.message, action });
    }
};
/**
 * Calculate next run time from cron expression
 */
const getNextRunTime = (cronExpression) => {
    try {
        const now = new Date();
        // Simple calculation for common patterns
        if (cronExpression === '0 2 * * 0') {
            // Sunday 2 AM
            const next = new Date(now);
            next.setHours(2, 0, 0, 0);
            const daysUntilSunday = (7 - next.getDay()) % 7;
            next.setDate(next.getDate() + (daysUntilSunday === 0 && now.getHours() >= 2 ? 7 : daysUntilSunday));
            return next;
        }
        else if (cronExpression === '0 2 * * 1-6') {
            // Mon-Sat 2 AM
            const next = new Date(now);
            next.setHours(2, 0, 0, 0);
            if (now.getHours() >= 2) {
                next.setDate(next.getDate() + 1);
            }
            if (next.getDay() === 0) {
                next.setDate(next.getDate() + 1);
            }
            return next;
        }
        else if (cronExpression === '0 * * * *') {
            // Every hour
            const next = new Date(now);
            next.setMinutes(0, 0, 0);
            next.setHours(next.getHours() + 1);
            return next;
        }
        return null;
    }
    catch {
        return null;
    }
};
/**
 * Execute backup with error handling and logging
 */
const executeBackup = async (type, description) => {
    logger_1.logger.info(`Scheduled ${description} starting`, { type });
    try {
        const result = await backupService.performBackup(type, 0, 'scheduler');
        if (result.success) {
            logger_1.logger.info(`Scheduled ${description} completed`, {
                type,
                backupId: result.data?.backupId,
                size: result.data?.backupSize
            });
            // Update status
            switch (type) {
                case backup_service_1.BackupType.FULL:
                    schedulerStatus.lastFullBackup = new Date();
                    break;
                case backup_service_1.BackupType.INCREMENTAL:
                    schedulerStatus.lastIncrementalBackup = new Date();
                    break;
                case backup_service_1.BackupType.TRANSACTION_LOG:
                    schedulerStatus.lastTransactionLogBackup = new Date();
                    break;
            }
            // Clear old errors for this type
            schedulerStatus.errors = schedulerStatus.errors.filter(e => !e.includes(description));
        }
        else {
            const errorMsg = `${description} failed: ${result.message}`;
            logger_1.logger.error(errorMsg);
            schedulerStatus.errors.push(`${new Date().toISOString()}: ${errorMsg}`);
            // Keep only last 10 errors
            if (schedulerStatus.errors.length > 10) {
                schedulerStatus.errors = schedulerStatus.errors.slice(-10);
            }
        }
    }
    catch (error) {
        const errorMsg = `${description} error: ${error.message}`;
        logger_1.logger.error(errorMsg, { error });
        schedulerStatus.errors.push(`${new Date().toISOString()}: ${errorMsg}`);
    }
};
/**
 * Execute cleanup with error handling
 */
const executeCleanup = async () => {
    logger_1.logger.info('Scheduled backup cleanup starting');
    try {
        const result = await backupService.cleanupOldBackups(0, 'scheduler');
        if (result.success) {
            schedulerStatus.lastCleanup = new Date();
            logger_1.logger.info('Scheduled backup cleanup completed', {
                deleted: result.data?.deleted,
                freed: result.data?.freed
            });
        }
        else {
            logger_1.logger.error('Scheduled backup cleanup failed', { message: result.message });
        }
    }
    catch (error) {
        logger_1.logger.error('Scheduled backup cleanup error', { error: error.message });
    }
};
/**
 * Start backup scheduler
 *
 * @param fullBackupCron - Cron expression for full backups (default: Sunday 2 AM)
 * @param incrementalBackupCron - Cron expression for incremental backups (default: Mon-Sat 2 AM)
 * @param transactionLogCron - Cron expression for transaction log backups (default: every hour)
 */
const startScheduler = async (fullBackupCron = '0 2 * * 0', incrementalBackupCron = '0 2 * * 1-6', transactionLogCron = '0 * * * *') => {
    if (schedulerStatus.running) {
        logger_1.logger.warn('Backup scheduler is already running');
        return;
    }
    logger_1.logger.info('Starting backup scheduler', {
        fullBackupCron,
        incrementalBackupCron,
        transactionLogCron
    });
    // Audit: Scheduler started
    await recordSchedulerAudit('scheduler_started', {
        fullBackupCron,
        incrementalBackupCron,
        transactionLogCron
    });
    // Get timezone from environment or default to UTC
    const timezone = process.env.BACKUP_TIMEZONE || 'UTC';
    // Schedule full backup (Weekly - Sunday 2 AM)
    if (cron.validate(fullBackupCron)) {
        scheduledTasks.fullBackup = cron.schedule(fullBackupCron, () => {
            executeBackup(backup_service_1.BackupType.FULL, 'full backup');
        }, {
            timezone
        });
        logger_1.logger.info('Full backup scheduled', { cron: fullBackupCron, timezone });
    }
    else {
        logger_1.logger.error('Invalid full backup cron expression', { cron: fullBackupCron });
    }
    // Schedule incremental backup (Daily - Mon-Sat 2 AM)
    if (cron.validate(incrementalBackupCron)) {
        scheduledTasks.incrementalBackup = cron.schedule(incrementalBackupCron, () => {
            executeBackup(backup_service_1.BackupType.INCREMENTAL, 'incremental backup');
        }, {
            timezone
        });
        logger_1.logger.info('Incremental backup scheduled', { cron: incrementalBackupCron, timezone });
    }
    else {
        logger_1.logger.error('Invalid incremental backup cron expression', { cron: incrementalBackupCron });
    }
    // Schedule transaction log backup (Hourly)
    if (cron.validate(transactionLogCron)) {
        scheduledTasks.transactionLogBackup = cron.schedule(transactionLogCron, () => {
            executeBackup(backup_service_1.BackupType.TRANSACTION_LOG, 'transaction log backup');
        }, {
            timezone
        });
        logger_1.logger.info('Transaction log backup scheduled', { cron: transactionLogCron, timezone });
    }
    else {
        logger_1.logger.error('Invalid transaction log backup cron expression', { cron: transactionLogCron });
    }
    // Schedule cleanup (Daily at 3 AM)
    const cleanupCron = '0 3 * * *';
    if (cron.validate(cleanupCron)) {
        scheduledTasks.cleanup = cron.schedule(cleanupCron, () => {
            executeCleanup();
        }, {
            timezone
        });
        logger_1.logger.info('Backup cleanup scheduled', { cron: cleanupCron, timezone });
    }
    schedulerStatus.running = true;
    schedulerStatus.startedAt = new Date();
    schedulerStatus.nextFullBackup = getNextRunTime(fullBackupCron);
    schedulerStatus.nextIncrementalBackup = getNextRunTime(incrementalBackupCron);
    logger_1.logger.info('Backup scheduler started successfully');
};
exports.startScheduler = startScheduler;
/**
 * Stop backup scheduler
 */
const stopScheduler = async () => {
    if (!schedulerStatus.running) {
        logger_1.logger.warn('Backup scheduler is not running');
        return;
    }
    logger_1.logger.info('Stopping backup scheduler');
    // Stop all scheduled tasks
    if (scheduledTasks.fullBackup) {
        scheduledTasks.fullBackup.stop();
        scheduledTasks.fullBackup = null;
    }
    if (scheduledTasks.incrementalBackup) {
        scheduledTasks.incrementalBackup.stop();
        scheduledTasks.incrementalBackup = null;
    }
    if (scheduledTasks.transactionLogBackup) {
        scheduledTasks.transactionLogBackup.stop();
        scheduledTasks.transactionLogBackup = null;
    }
    if (scheduledTasks.cleanup) {
        scheduledTasks.cleanup.stop();
        scheduledTasks.cleanup = null;
    }
    // Audit: Scheduler stopped
    await recordSchedulerAudit('scheduler_stopped', {});
    schedulerStatus.running = false;
    logger_1.logger.info('Backup scheduler stopped');
};
exports.stopScheduler = stopScheduler;
/**
 * Get scheduler status
 */
const getSchedulerStatus = () => {
    return { ...schedulerStatus };
};
exports.getSchedulerStatus = getSchedulerStatus;
/**
 * Trigger immediate backup (manual trigger)
 */
const triggerImmediateBackup = async (type, userId, username) => {
    logger_1.logger.info('Manual backup triggered', { type, userId, username });
    const result = await backupService.performBackup(type, userId, username);
    return {
        success: result.success,
        backupId: result.data?.backupId,
        message: result.message || ''
    };
};
exports.triggerImmediateBackup = triggerImmediateBackup;
/**
 * Initialize scheduler on application startup if enabled
 */
const initializeScheduler = async () => {
    const enabled = process.env.BACKUP_SCHEDULER_ENABLED !== 'false';
    if (enabled) {
        logger_1.logger.info('Backup scheduler auto-start enabled');
        try {
            const config = backupService.getBackupConfig();
            await (0, exports.startScheduler)(config.schedules.full, config.schedules.incremental, config.schedules.transactionLog);
        }
        catch (error) {
            logger_1.logger.error('Failed to start backup scheduler', { error: error.message });
        }
    }
    else {
        logger_1.logger.info('Backup scheduler auto-start disabled (set BACKUP_SCHEDULER_ENABLED=true to enable)');
    }
};
exports.initializeScheduler = initializeScheduler;
exports.default = {
    startScheduler: exports.startScheduler,
    stopScheduler: exports.stopScheduler,
    getSchedulerStatus: exports.getSchedulerStatus,
    triggerImmediateBackup: exports.triggerImmediateBackup,
    initializeScheduler: exports.initializeScheduler
};
//# sourceMappingURL=backup-scheduler.service.js.map