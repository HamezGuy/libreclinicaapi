"use strict";
/**
 * Express Application Setup
 *
 * Main application configuration with all middleware and routes
 * - Security (Helmet, CORS)
 * - Body parsing
 * - Audit logging
 * - Rate limiting
 * - Routes
 * - Error handling
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const helmet_1 = __importDefault(require("helmet"));
const cors_1 = __importDefault(require("cors"));
const environment_1 = require("./config/environment");
const logger_1 = require("./config/logger");
const audit_middleware_1 = require("./middleware/audit.middleware");
const errorHandler_middleware_1 = require("./middleware/errorHandler.middleware");
const rateLimiter_middleware_1 = require("./middleware/rateLimiter.middleware");
// Import routes
const auth_routes_1 = __importDefault(require("./routes/auth.routes"));
const subject_routes_1 = __importDefault(require("./routes/subject.routes"));
const study_routes_1 = __importDefault(require("./routes/study.routes"));
const form_routes_1 = __importDefault(require("./routes/form.routes"));
const query_routes_1 = __importDefault(require("./routes/query.routes"));
const audit_routes_1 = __importDefault(require("./routes/audit.routes"));
const dashboard_routes_1 = __importDefault(require("./routes/dashboard.routes"));
const user_routes_1 = __importDefault(require("./routes/user.routes"));
const workflow_routes_1 = __importDefault(require("./routes/workflow.routes"));
const event_routes_1 = __importDefault(require("./routes/event.routes"));
// New routes merged from ElectronicDataCaptureReal/backend
const ai_routes_1 = __importDefault(require("./routes/ai.routes"));
const sdv_routes_1 = __importDefault(require("./routes/sdv.routes"));
const randomization_routes_1 = __importDefault(require("./routes/randomization.routes"));
const monitoring_routes_1 = __importDefault(require("./routes/monitoring.routes"));
const coding_routes_1 = __importDefault(require("./routes/coding.routes"));
const data_locks_routes_1 = __importDefault(require("./routes/data-locks.routes"));
// WoundScanner integration
const wounds_routes_1 = __importDefault(require("./routes/wounds.routes"));
// SOAP diagnostics and health
const soap_routes_1 = __importDefault(require("./routes/soap.routes"));
// LibreClinica native API proxy
const libreclinica_proxy_routes_1 = __importDefault(require("./routes/libreclinica-proxy.routes"));
// Validation rules
const validation_rules_routes_1 = __importDefault(require("./routes/validation-rules.routes"));
// Electronic Signatures (21 CFR Part 11)
const esignature_routes_1 = __importDefault(require("./routes/esignature.routes"));
// 21 CFR Part 11 Compliance
const compliance_routes_1 = __importDefault(require("./routes/compliance.routes"));
// Study Parameters (enrollment configuration)
const studyParameters_routes_1 = __importDefault(require("./routes/studyParameters.routes"));
// Study Groups (randomization/treatment arms)
const studyGroups_routes_1 = __importDefault(require("./routes/studyGroups.routes"));
// Unified Tasks (aggregates queries, visits, forms, SDV, signatures)
const tasks_routes_1 = __importDefault(require("./routes/tasks.routes"));
// Data Export (CSV, ODM XML) - Part 11 compliant via SOAP
const export_routes_1 = __importDefault(require("./routes/export.routes"));
// Data Import (CSV, ODM XML) - Part 11 compliant via SOAP
const import_routes_1 = __importDefault(require("./routes/import.routes"));
// Adverse Event (AE/SAE) Tracking - Part 11 compliant via SOAP
const ae_routes_1 = __importDefault(require("./routes/ae.routes"));
// File Uploads for CRF fields (response_type = 4)
const files_routes_1 = __importDefault(require("./routes/files.routes"));
// Backup and Recovery (21 CFR Part 11 compliant)
const backup_routes_1 = __importDefault(require("./routes/backup.routes"));
// Print/PDF Generation (21 CFR Part 11 compliant)
const print_routes_1 = __importDefault(require("./routes/print.routes"));
// Double Data Entry (21 CFR Part 11 compliant) - Uses NATIVE LibreClinica tables
const dde_routes_1 = __importDefault(require("./routes/dde.routes"));
// Organization management, invite codes, access requests
const organization_routes_1 = __importDefault(require("./routes/organization.routes"));
// Skip Logic and Form Linking
const skip_logic_routes_1 = __importDefault(require("./routes/skip-logic.routes"));
// Site/Location Management
const site_routes_1 = __importDefault(require("./routes/site.routes"));
// Form Layout (column configuration)
const form_layout_routes_1 = __importDefault(require("./routes/form-layout.routes"));
// ============================================================================
// FEATURE FLAGS FOR CUSTOM TABLE EXTENSIONS
// ============================================================================
// The following features use custom acc_* tables that extend LibreClinica.
// These tables have been migrated and are available in the database.
// Set environment variables to 'false' to disable specific features if needed.
// ============================================================================
const ENABLE_EMAIL_NOTIFICATIONS = process.env.ENABLE_EMAIL_NOTIFICATIONS !== 'false';
const ENABLE_SUBJECT_TRANSFERS = process.env.ENABLE_SUBJECT_TRANSFERS !== 'false';
const ENABLE_ECONSENT = process.env.ENABLE_ECONSENT !== 'false';
const ENABLE_EPRO = process.env.ENABLE_EPRO !== 'false';
const ENABLE_RTSM = process.env.ENABLE_RTSM !== 'false';
// Conditionally import routes only when enabled
let emailRoutes, transferRoutes, consentRoutes, eproRoutes, rtsmRoutes;
const app = (0, express_1.default)();
// Trust proxy - Required when behind nginx/load balancer for correct IP detection
// This ensures rate limiting and logging work correctly with X-Forwarded-For headers
app.set('trust proxy', 1);
// ============================================================================
// SECURITY MIDDLEWARE
// ============================================================================
// Helmet - Security headers
app.use((0, helmet_1.default)({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'"],
            scriptSrc: ["'self'"],
            imgSrc: ["'self'", 'data:', 'https:'],
        },
    },
    hsts: {
        maxAge: 31536000,
        includeSubDomains: true,
        preload: true
    }
}));
// CORS - Cross-Origin Resource Sharing
// In production, nginx handles CORS to avoid duplicate headers
// Only enable CORS middleware in development
if (environment_1.config.server.env !== 'production') {
    const corsOptions = {
        origin: (origin, callback) => {
            // Allow requests with no origin (like mobile apps or curl)
            if (!origin) {
                callback(null, true);
                return;
            }
            // Check configured origins
            const allowedOrigins = environment_1.config.security.allowedOrigins.length > 0
                ? environment_1.config.security.allowedOrigins
                : ['http://localhost:4200', 'http://localhost:3000', 'http://localhost:3001'];
            // Check for exact match or wildcard patterns
            const isAllowed = allowedOrigins.some(allowed => {
                if (allowed.includes('*')) {
                    const pattern = allowed
                        .replace(/[.+?^${}()|[\]\\]/g, '\\$&')
                        .replace(/\*/g, '[^.]+');
                    return new RegExp(`^${pattern}$`).test(origin);
                }
                return allowed === origin;
            });
            if (isAllowed) {
                callback(null, true);
            }
            else {
                logger_1.logger.warn('CORS blocked request', { origin, allowedOrigins });
                callback(null, true);
            }
        },
        credentials: true,
        optionsSuccessStatus: 200,
        methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
        allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept']
    };
    app.use((0, cors_1.default)(corsOptions));
    logger_1.logger.info('CORS middleware enabled (development mode)');
}
else {
    logger_1.logger.info('CORS handled by nginx (production mode)');
}
// ============================================================================
// BODY PARSING
// ============================================================================
app.use(express_1.default.json({ limit: '10mb' }));
app.use(express_1.default.urlencoded({ extended: true, limit: '10mb' }));
// ============================================================================
// AUDIT LOGGING
// ============================================================================
app.use(audit_middleware_1.auditMiddleware);
// ============================================================================
// GENERAL RATE LIMITING
// ============================================================================
app.use('/api', rateLimiter_middleware_1.apiRateLimiter);
// ============================================================================
// HEALTH CHECK
// ============================================================================
app.get('/health', (req, res) => {
    res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        environment: process.env.NODE_ENV || 'development',
        version: '1.0.0'
    });
});
app.get('/api/health', async (req, res) => {
    let soapStatus = 'disabled';
    if (environment_1.config.libreclinica.soapEnabled) {
        try {
            const { getSoapClient } = await Promise.resolve().then(() => __importStar(require('./services/soap/soapClient')));
            const soapClient = getSoapClient();
            const isConnected = await soapClient.testConnection('studySubject');
            soapStatus = isConnected ? 'connected' : 'unavailable';
        }
        catch {
            soapStatus = 'error';
        }
    }
    res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        services: {
            database: 'connected',
            soap: soapStatus,
            rest_api: 'active'
        },
        mode: environment_1.config.libreclinica.soapEnabled ? 'hybrid' : 'database_only',
        soapUrl: environment_1.config.libreclinica.soapEnabled ? environment_1.config.libreclinica.soapUrl : null
    });
});
// ============================================================================
// API ROUTES
// ============================================================================
app.use('/api/auth', auth_routes_1.default);
app.use('/api/subjects', subject_routes_1.default);
app.use('/api/studies', study_routes_1.default);
app.use('/api/forms', form_routes_1.default);
app.use('/api/queries', query_routes_1.default);
app.use('/api/audit', audit_routes_1.default);
app.use('/api/dashboard', dashboard_routes_1.default);
app.use('/api/users', user_routes_1.default);
app.use('/api/workflows', workflow_routes_1.default);
app.use('/api/events', event_routes_1.default);
// New routes merged from ElectronicDataCaptureReal/backend
app.use('/api/ai', ai_routes_1.default);
app.use('/api/sdv', sdv_routes_1.default);
app.use('/api/randomization', randomization_routes_1.default);
app.use('/api/monitoring', monitoring_routes_1.default);
app.use('/api/coding', coding_routes_1.default);
app.use('/api/data-locks', data_locks_routes_1.default);
// WoundScanner integration
app.use('/api/wounds', wounds_routes_1.default);
// SOAP diagnostics and health
app.use('/api/soap', soap_routes_1.default);
// LibreClinica native API proxy (forwards to LibreClinica's REST endpoints)
app.use('/api/libreclinica', libreclinica_proxy_routes_1.default);
// Validation rules management
app.use('/api/validation-rules', validation_rules_routes_1.default);
// Electronic Signatures (21 CFR Part 11 compliant)
app.use('/api/esignature', esignature_routes_1.default);
// 21 CFR Part 11 Compliance Status and Audit Trail
app.use('/api/compliance', compliance_routes_1.default);
// Study Parameters (enrollment configuration)
app.use('/api/study-parameters', studyParameters_routes_1.default);
// Study Groups (randomization/treatment arms)
app.use('/api/study-groups', studyGroups_routes_1.default);
// Unified Tasks (aggregates real LibreClinica work items)
app.use('/api/tasks', tasks_routes_1.default);
// Data Export (Part 11 compliant - uses LibreClinica SOAP)
app.use('/api/export', export_routes_1.default);
// Data Import (Part 11 compliant - uses LibreClinica SOAP)
app.use('/api/import', import_routes_1.default);
// Adverse Events (Part 11 compliant - AEs are CRF forms)
app.use('/api/ae', ae_routes_1.default);
// File Uploads (Part 11 compliant - for CRF file fields)
app.use('/api/files', files_routes_1.default);
// Backup and Recovery (Part 11 compliant - database backups)
app.use('/api/backup', backup_routes_1.default);
// Print/PDF Generation (Part 11 compliant - form printing, casebooks, audit trails)
app.use('/api/print', print_routes_1.default);
// Double Data Entry (Part 11 compliant - uses NATIVE LibreClinica tables)
app.use('/api/dde', dde_routes_1.default);
// Organization management, invite codes, access requests
app.use('/api/organizations', organization_routes_1.default);
// Skip Logic, Form Linking, and Branching
app.use('/api/skip-logic', skip_logic_routes_1.default);
// Site/Location Management
app.use('/api/sites', site_routes_1.default);
app.use('/api/form-layout', form_layout_routes_1.default);
// ============================================================================
// CONDITIONAL ROUTES - Require custom acc_* tables
// ============================================================================
// These routes are DISABLED by default. To enable:
// 1. Run the corresponding migration script from /migrations/
// 2. Set the environment variable to 'true'
// ============================================================================
if (ENABLE_EMAIL_NOTIFICATIONS) {
    const emailRoutes = require('./routes/email.routes').default;
    app.use('/api/email', emailRoutes);
    logger_1.logger.info('✅ Email Notifications enabled (acc_email_* tables required)');
}
else {
    app.use('/api/email', (req, res) => {
        res.status(503).json({
            success: false,
            error: 'Email Notifications feature is disabled',
            message: 'This feature requires custom database tables. Set ENABLE_EMAIL_NOTIFICATIONS=true and run migrations/email_notifications.sql'
        });
    });
}
if (ENABLE_SUBJECT_TRANSFERS) {
    const transferRoutes = require('./routes/transfer.routes').default;
    app.use('/api/transfers', transferRoutes);
    logger_1.logger.info('✅ Subject Transfers enabled (acc_transfer_log table required)');
}
else {
    app.use('/api/transfers', (req, res) => {
        res.status(503).json({
            success: false,
            error: 'Subject Transfers feature is disabled',
            message: 'This feature requires custom database tables. Set ENABLE_SUBJECT_TRANSFERS=true and run migrations/subject_transfer.sql'
        });
    });
}
if (ENABLE_ECONSENT) {
    const consentRoutes = require('./routes/consent.routes').default;
    app.use('/api/consent', consentRoutes);
    logger_1.logger.info('✅ eConsent enabled (acc_consent_* tables required)');
}
else {
    app.use('/api/consent', (req, res) => {
        res.status(503).json({
            success: false,
            error: 'eConsent feature is disabled',
            message: 'This feature requires custom database tables. Set ENABLE_ECONSENT=true and run migrations/econsent.sql'
        });
    });
}
if (ENABLE_EPRO) {
    const eproRoutes = require('./routes/epro.routes').default;
    app.use('/api/epro', eproRoutes);
    logger_1.logger.info('✅ ePRO/Patient Portal enabled (acc_pro_* tables required)');
}
else {
    app.use('/api/epro', (req, res) => {
        res.status(503).json({
            success: false,
            error: 'ePRO/Patient Portal feature is disabled',
            message: 'This feature requires custom database tables. Set ENABLE_EPRO=true and run migrations/epro_patient_portal.sql'
        });
    });
}
if (ENABLE_RTSM) {
    const rtsmRoutes = require('./routes/rtsm.routes').default;
    app.use('/api/rtsm', rtsmRoutes);
    logger_1.logger.info('✅ RTSM/IRT enabled (acc_kit_* tables required)');
}
else {
    app.use('/api/rtsm', (req, res) => {
        res.status(503).json({
            success: false,
            error: 'RTSM/IRT feature is disabled',
            message: 'This feature requires custom database tables. Set ENABLE_RTSM=true and run migrations/rtsm_irt.sql'
        });
    });
}
// ============================================================================
// ROOT ENDPOINT
// ============================================================================
app.get('/', (req, res) => {
    res.json({
        name: 'LibreClinica REST API',
        version: '1.0.0',
        description: '21 CFR Part 11 Compliant REST API for LibreClinica with SOAP support',
        documentation: '/api/docs',
        health: '/health',
        mode: environment_1.config.libreclinica.soapEnabled ? 'Hybrid (REST + SOAP)' : 'REST Only (Database Direct)',
        soapEnabled: environment_1.config.libreclinica.soapEnabled,
        soapUrl: environment_1.config.libreclinica.soapEnabled ? environment_1.config.libreclinica.soapUrl : null,
        endpoints: {
            auth: '/api/auth',
            subjects: '/api/subjects',
            studies: '/api/studies',
            forms: '/api/forms',
            queries: '/api/queries',
            audit: '/api/audit',
            dashboard: '/api/dashboard',
            users: '/api/users',
            workflows: '/api/workflows',
            events: '/api/events',
            ai: '/api/ai',
            sdv: '/api/sdv',
            randomization: '/api/randomization',
            monitoring: '/api/monitoring',
            coding: '/api/coding',
            dataLocks: '/api/data-locks',
            wounds: '/api/wounds',
            esignature: '/api/esignature - 21 CFR Part 11 compliant electronic signatures',
            soap: '/api/soap - SOAP status, diagnostics, and configuration',
            libreclinica: '/api/libreclinica - Proxy to LibreClinica native REST APIs',
            export: '/api/export - Data export (CSV, ODM XML) via LibreClinica SOAP',
            import: '/api/import - Data import (CSV, ODM XML) via LibreClinica SOAP',
            ae: '/api/ae - Adverse Event tracking (SAE/AE) via LibreClinica SOAP',
            backup: '/api/backup - Database backup and recovery (21 CFR Part 11 compliant)',
            print: '/api/print - PDF generation for forms, casebooks, and audit trails',
            dde: '/api/dde - Double data entry workflow (uses native LibreClinica tables)',
            organizations: '/api/organizations - Organization management, invite codes, access requests',
            skipLogic: '/api/skip-logic - Skip logic rules, form linking, and conditional visibility',
            sites: '/api/sites - Site/location management and patient-site assignments',
            // Conditional features - require custom tables
            email: ENABLE_EMAIL_NOTIFICATIONS ? '/api/email - Email notifications (ENABLED)' : '/api/email - DISABLED (requires acc_email_* tables)',
            transfers: ENABLE_SUBJECT_TRANSFERS ? '/api/transfers - Subject transfers (ENABLED)' : '/api/transfers - DISABLED (requires acc_transfer_log table)',
            consent: ENABLE_ECONSENT ? '/api/consent - eConsent (ENABLED)' : '/api/consent - DISABLED (requires acc_consent_* tables)',
            epro: ENABLE_EPRO ? '/api/epro - ePRO/Patient Portal (ENABLED)' : '/api/epro - DISABLED (requires acc_pro_* tables)',
            rtsm: ENABLE_RTSM ? '/api/rtsm - RTSM/IRT (ENABLED)' : '/api/rtsm - DISABLED (requires acc_kit_* tables)'
        },
        featureFlags: {
            email_notifications: ENABLE_EMAIL_NOTIFICATIONS,
            subject_transfers: ENABLE_SUBJECT_TRANSFERS,
            econsent: ENABLE_ECONSENT,
            epro: ENABLE_EPRO,
            rtsm: ENABLE_RTSM
        },
        libreclinicaNativeProxies: {
            metadata: '/api/libreclinica/metadata/:studyOid - Get study metadata (proxies to LibreClinica)',
            clinicaldata: '/api/libreclinica/clinicaldata/:studyOid/:subjectId/:eventOid/:formVersionOid - Get form data',
            openrosa: '/api/libreclinica/openrosa/:studyOid/* - ODK-compatible API',
            systemStatus: '/api/libreclinica/system/status - LibreClinica system status',
            available: '/api/libreclinica/available - Check if LibreClinica is reachable'
        },
        soapEndpoints: {
            status: '/api/soap/status - Check SOAP connection status',
            services: '/api/soap/services - Check individual SOAP services',
            config: '/api/soap/config - View SOAP configuration (admin)',
            test: '/api/soap/test - Run SOAP connectivity test (admin)',
            diagnostics: '/api/soap/diagnostics - Full SOAP diagnostics (admin)',
            reconnect: '/api/soap/reconnect - Force SOAP reconnection (admin)'
        }
    });
});
// ============================================================================
// ERROR HANDLING
// ============================================================================
// 404 handler
app.use(errorHandler_middleware_1.notFoundHandler);
// Global error handler
app.use(errorHandler_middleware_1.errorHandler);
// ============================================================================
// EXPORT
// ============================================================================
exports.default = app;
//# sourceMappingURL=app.js.map