/**
 * Data Locks Service
 * Uses event_crf.status_id = 6 (locked) from LibreClinica
 */
export declare const getLockedRecords: (filters: {
    studyId?: number;
    subjectId?: number;
    page?: number;
    limit?: number;
}) => Promise<{
    success: boolean;
    data: any[];
    pagination: {
        page: number;
        limit: number;
        total: number;
    };
}>;
export declare const lockRecord: (eventCrfId: number, userId: number) => Promise<{
    success: boolean;
    message: string;
    data?: undefined;
} | {
    success: boolean;
    data: any;
    message?: undefined;
}>;
export declare const unlockRecord: (eventCrfId: number, userId: number) => Promise<{
    success: boolean;
    message: string;
}>;
//# sourceMappingURL=data-locks.service.d.ts.map