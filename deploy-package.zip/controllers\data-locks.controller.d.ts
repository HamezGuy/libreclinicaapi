/**
 * Data Locks Controller
 */
import { Request, Response } from 'express';
export declare const list: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const lock: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const unlock: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    list: (req: Request, res: Response, next: import("express").NextFunction) => void;
    lock: (req: Request, res: Response, next: import("express").NextFunction) => void;
    unlock: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=data-locks.controller.d.ts.map