/**
 * Form Layout Routes
 *
 * API endpoints for form layout management:
 * - GET /form-layout/:crfVersionId - Get layout configuration
 * - GET /form-layout/:crfVersionId/render - Get layout for rendering
 * - POST /form-layout - Save layout configuration
 * - PUT /form-layout/field/:itemFormMetadataId - Update single field position
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=form-layout.routes.d.ts.map