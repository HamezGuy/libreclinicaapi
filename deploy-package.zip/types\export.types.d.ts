/**
 * Data Export Types - Using LibreClinica Models
 * Matches DatasetBean, ExportFormatBean, and ODM export structures
 */
export interface DatasetConfig {
    datasetId?: number;
    studyId: number;
    name: string;
    description?: string;
    dateStart?: Date | string;
    dateEnd?: Date | string;
    eventIds?: number[];
    itemIds?: number[];
    subjectIds?: number[];
    showEventLocation: boolean;
    showEventStart: boolean;
    showEventEnd: boolean;
    showSubjectDob: boolean;
    showSubjectGender: boolean;
    showSubjectStatus: boolean;
    showSubjectSecondaryId: boolean;
    showSubjectUniqueId: boolean;
    showCRFstatus: boolean;
    showCRFversion: boolean;
    showCRFinterviewerName: boolean;
    showCRFinterviewerDate: boolean;
}
export type ExportFormat = 'csv' | 'excel' | 'odm' | 'json' | 'sas';
export declare const EXPORT_FORMAT_MIME: Record<ExportFormat, string>;
export interface ExportSubjectData {
    subjectOID: string;
    studySubjectId: string;
    uniqueIdentifier?: string;
    status: string;
    statusId: number;
    secondaryId?: string;
    dateOfBirth?: string;
    gender?: string;
    enrollmentDate?: string;
    studyEventData: ExportStudyEventData[];
}
export interface ExportStudyEventData {
    studyEventOID: string;
    studyEventRepeatKey: string;
    eventName: string;
    location?: string;
    startDate?: string;
    endDate?: string;
    status: string;
    formData: ExportFormData[];
}
export interface ExportFormData {
    formOID: string;
    formName: string;
    crfVersion: string;
    interviewerName?: string;
    interviewDate?: string;
    status: string;
    completionStatus: string;
    itemGroupData: ExportItemGroupData[];
}
export interface ExportItemGroupData {
    itemGroupOID: string;
    itemGroupName: string;
    repeatKey: string;
    items: ExportItemData[];
}
export interface ExportItemData {
    itemOID: string;
    itemName: string;
    value: string;
    dataType: string;
    units?: string;
}
export interface ExportMetadata {
    studyId: number;
    studyName: string;
    studyOID: string;
    events: {
        eventId: number;
        eventOID: string;
        eventName: string;
        crfs: {
            crfId: number;
            crfOID: string;
            crfName: string;
            items: {
                itemId: number;
                itemOID: string;
                itemName: string;
                dataType: string;
            }[];
        }[];
    }[];
}
export interface ExportResult {
    format: ExportFormat;
    filename: string;
    content: string | Buffer;
    mimeType: string;
    recordCount: number;
}
//# sourceMappingURL=export.types.d.ts.map