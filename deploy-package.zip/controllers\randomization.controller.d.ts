/**
 * Randomization Controller
 */
import { Request, Response } from 'express';
export declare const list: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const create: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getGroups: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get randomization statistics for a study
 */
export declare const getStats: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Check if subject can be randomized
 */
export declare const canRandomize: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get subject's randomization info
 */
export declare const getSubjectRandomization: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Remove randomization
 */
export declare const remove: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get unblinding events
 */
export declare const getUnblindingEvents: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Unblind a subject
 */
export declare const unblind: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    list: (req: Request, res: Response, next: import("express").NextFunction) => void;
    create: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getGroups: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getStats: (req: Request, res: Response, next: import("express").NextFunction) => void;
    canRandomize: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getSubjectRandomization: (req: Request, res: Response, next: import("express").NextFunction) => void;
    remove: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getUnblindingEvents: (req: Request, res: Response, next: import("express").NextFunction) => void;
    unblind: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=randomization.controller.d.ts.map