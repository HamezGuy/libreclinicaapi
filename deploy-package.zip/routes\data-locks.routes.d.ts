/**
 * Data Locks Routes
 *
 * 21 CFR Part 11 Compliance:
 * - Locking/unlocking data requires electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=data-locks.routes.d.ts.map