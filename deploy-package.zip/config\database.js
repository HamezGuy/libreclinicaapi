"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pool = exports.db = void 0;
const pg_1 = require("pg");
const environment_1 = require("./environment");
const logger_1 = require("./logger");
class DatabaseConnection {
    constructor() {
        // Use test database in test environment
        if (process.env.NODE_ENV === 'test') {
            // Import test database pool
            try {
                const { testDb } = require('../../tests/utils/test-db');
                this.pool = testDb.pool;
                logger_1.logger.info('Using in-memory test database');
                return;
            }
            catch (error) {
                logger_1.logger.warn('Could not load test database, using regular pool');
            }
        }
        // Log the database configuration for debugging
        logger_1.logger.info('Database configuration', {
            host: environment_1.config.libreclinica.database.host,
            port: environment_1.config.libreclinica.database.port,
            database: environment_1.config.libreclinica.database.database,
            user: environment_1.config.libreclinica.database.user,
            connectionTimeoutMillis: environment_1.config.libreclinica.database.connectionTimeoutMillis
        });
        this.pool = new pg_1.Pool(environment_1.config.libreclinica.database);
        // Test connection on startup
        this.pool.on('connect', () => {
            logger_1.logger.info('Database connection established');
        });
        this.pool.on('error', (err) => {
            logger_1.logger.error('Unexpected database error', { error: err.message });
        });
        // Test the connection immediately
        this.testConnection();
    }
    async testConnection() {
        try {
            const client = await this.pool.connect();
            const result = await client.query('SELECT NOW()');
            logger_1.logger.info('Database connection test successful', {
                serverTime: result.rows[0].now
            });
            client.release();
        }
        catch (error) {
            logger_1.logger.error('Database connection test failed', {
                error: error.message
            });
        }
    }
    async query(text, params) {
        const start = Date.now();
        try {
            const result = await this.pool.query(text, params);
            const duration = Date.now() - start;
            logger_1.logger.debug('Database query executed', {
                duration,
                rows: result.rowCount,
                query: text.substring(0, 100) // Log first 100 chars
            });
            return result;
        }
        catch (error) {
            const duration = Date.now() - start;
            logger_1.logger.error('Database query error', {
                error: error.message,
                duration,
                query: text.substring(0, 100)
            });
            throw error;
        }
    }
    async connect() {
        return this.pool.connect();
    }
    async end() {
        await this.pool.end();
    }
    async getClient() {
        return this.pool.connect();
    }
    async transaction(callback) {
        const client = await this.pool.connect();
        try {
            await client.query('BEGIN');
            const result = await callback(client);
            await client.query('COMMIT');
            return result;
        }
        catch (error) {
            await client.query('ROLLBACK');
            throw error;
        }
        finally {
            client.release();
        }
    }
    async close() {
        await this.pool.end();
        logger_1.logger.info('Database connection pool closed');
    }
}
exports.db = new DatabaseConnection();
exports.pool = exports.db; // Alias db as pool since it has query/connect methods now
//# sourceMappingURL=database.js.map