"use strict";
/**
 * PDF Generation Types
 *
 * 21 CFR Part 11 compliant PDF generation for:
 * - Form printing (blank and completed)
 * - Casebook generation
 * - Audit trail export
 */
Object.defineProperty(exports, "__esModule", { value: true });
// Types are exported inline above
//# sourceMappingURL=pdf.types.js.map