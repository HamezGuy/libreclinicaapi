/**
 * Event Routes
 *
 * Study Event (Phase) management routes
 * Includes CRF (Template) assignment to events
 *
 * 21 CFR Part 11 Compliance:
 * - Event creation/modification requires electronic signature (§11.50)
 * - CRF assignment requires electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=event.routes.d.ts.map