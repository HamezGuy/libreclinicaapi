/**
 * Event Controller
 *
 * Handles study event (phase) operations
 */
import { Request, Response } from 'express';
/**
 * List events - accepts studyId as query param for frontend compatibility
 */
export declare const listEvents: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getStudyEvents: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getEvent: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getSubjectEvents: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getEventCRFs: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get patient's event_crfs for a specific study_event instance
 * These are the editable copies of templates for this patient's phase
 */
export declare const getPatientEventCRFs: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const scheduleEvent: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const create: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const update: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const remove: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get available CRFs that can be assigned to an event
 */
export declare const getAvailableCrfs: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Assign a CRF to a study event
 */
export declare const assignCrf: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Update CRF settings for an event
 */
export declare const updateEventCrf: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Remove CRF from event
 */
export declare const removeCrf: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Reorder CRFs within an event
 */
export declare const reorderCrfs: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Bulk assign CRFs to event
 */
export declare const bulkAssignCrfs: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    getStudyEvents: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getEvent: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getSubjectEvents: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getEventCRFs: (req: Request, res: Response, next: import("express").NextFunction) => void;
    scheduleEvent: (req: Request, res: Response, next: import("express").NextFunction) => void;
    create: (req: Request, res: Response, next: import("express").NextFunction) => void;
    update: (req: Request, res: Response, next: import("express").NextFunction) => void;
    remove: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getAvailableCrfs: (req: Request, res: Response, next: import("express").NextFunction) => void;
    assignCrf: (req: Request, res: Response, next: import("express").NextFunction) => void;
    updateEventCrf: (req: Request, res: Response, next: import("express").NextFunction) => void;
    removeCrf: (req: Request, res: Response, next: import("express").NextFunction) => void;
    reorderCrfs: (req: Request, res: Response, next: import("express").NextFunction) => void;
    bulkAssignCrfs: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=event.controller.d.ts.map