"use strict";
/**
 * Organization Controller
 *
 * Handles HTTP requests for organization management, invite codes,
 * access requests, and invitations
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.acceptInvitation = exports.validateInvitation = exports.createInvitation = exports.reviewAccessRequest = exports.listAccessRequests = exports.createAccessRequest = exports.deactivateCode = exports.listCodes = exports.generateCode = exports.registerWithCode = exports.validateCode = exports.getMyOrganizations = exports.updateStatus = exports.getOrganization = exports.listOrganizations = exports.registerOrganization = void 0;
const logger_1 = require("../config/logger");
const organizationService = __importStar(require("../services/database/organization.service"));
// ============================================================================
// Organization Endpoints
// ============================================================================
/**
 * POST /api/organizations/register
 * Register a new organization with admin user (public endpoint)
 */
const registerOrganization = async (req, res) => {
    try {
        const { organizationDetails, adminDetails } = req.body;
        if (!organizationDetails || !adminDetails) {
            res.status(400).json({
                success: false,
                message: 'Organization details and admin details are required'
            });
            return;
        }
        // Map frontend field names to service field names
        const orgData = {
            name: organizationDetails.name,
            type: organizationDetails.type,
            email: organizationDetails.email,
            phone: organizationDetails.phone,
            website: organizationDetails.website,
            street: organizationDetails.street,
            city: organizationDetails.city,
            state: organizationDetails.state,
            postalCode: organizationDetails.postalCode,
            country: organizationDetails.country
        };
        const adminData = {
            firstName: adminDetails.firstName,
            lastName: adminDetails.lastName,
            email: adminDetails.email,
            phone: adminDetails.phone,
            professionalTitle: adminDetails.professionalTitle,
            credentials: adminDetails.credentials,
            password: adminDetails.password
        };
        const result = await organizationService.createOrganizationWithAdmin(orgData, adminData);
        if (result.success) {
            res.status(201).json({
                success: true,
                data: {
                    organizationId: result.organizationId,
                    userId: result.userId
                },
                message: result.message
            });
        }
        else {
            res.status(400).json({
                success: false,
                message: result.message
            });
        }
    }
    catch (error) {
        logger_1.logger.error('Register organization error', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};
exports.registerOrganization = registerOrganization;
/**
 * GET /api/organizations
 * Get organizations (admin only)
 */
const listOrganizations = async (req, res) => {
    try {
        const { status, type, page, limit } = req.query;
        const result = await organizationService.getOrganizations({
            status: status,
            type: type,
            page: page ? parseInt(page) : undefined,
            limit: limit ? parseInt(limit) : undefined
        });
        res.json({
            success: true,
            data: result.data,
            pagination: {
                total: result.total,
                page: page ? parseInt(page) : 1,
                limit: limit ? parseInt(limit) : 20
            }
        });
    }
    catch (error) {
        logger_1.logger.error('List organizations error', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};
exports.listOrganizations = listOrganizations;
/**
 * GET /api/organizations/:id
 * Get organization by ID
 */
const getOrganization = async (req, res) => {
    try {
        const organizationId = parseInt(req.params.id);
        const organization = await organizationService.getOrganizationById(organizationId);
        if (!organization) {
            res.status(404).json({
                success: false,
                message: 'Organization not found'
            });
            return;
        }
        res.json({
            success: true,
            data: organization
        });
    }
    catch (error) {
        logger_1.logger.error('Get organization error', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};
exports.getOrganization = getOrganization;
/**
 * PATCH /api/organizations/:id/status
 * Update organization status (approve/reject/suspend)
 */
const updateStatus = async (req, res) => {
    try {
        const organizationId = parseInt(req.params.id);
        const { status, notes } = req.body;
        const userId = req.user?.userId;
        if (!userId) {
            res.status(401).json({
                success: false,
                message: 'Authentication required'
            });
            return;
        }
        if (!['active', 'suspended', 'inactive'].includes(status)) {
            res.status(400).json({
                success: false,
                message: 'Invalid status. Must be: active, suspended, or inactive'
            });
            return;
        }
        const result = await organizationService.updateOrganizationStatus(organizationId, status, userId, notes);
        if (result.success) {
            res.json({
                success: true,
                message: result.message
            });
        }
        else {
            res.status(400).json({
                success: false,
                message: result.message
            });
        }
    }
    catch (error) {
        logger_1.logger.error('Update organization status error', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};
exports.updateStatus = updateStatus;
/**
 * GET /api/organizations/my
 * Get current user's organizations
 */
const getMyOrganizations = async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId) {
            res.status(401).json({
                success: false,
                message: 'Authentication required'
            });
            return;
        }
        const organizations = await organizationService.getUserOrganizations(userId);
        res.json({
            success: true,
            data: organizations
        });
    }
    catch (error) {
        logger_1.logger.error('Get my organizations error', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};
exports.getMyOrganizations = getMyOrganizations;
// ============================================================================
// Organization Code Endpoints
// ============================================================================
/**
 * POST /api/codes/validate
 * Validate an organization code (public endpoint)
 */
const validateCode = async (req, res) => {
    try {
        const { code } = req.body;
        if (!code) {
            res.status(400).json({
                success: false,
                isValid: false,
                message: 'Code is required'
            });
            return;
        }
        const result = await organizationService.validateOrganizationCode(code);
        res.json({
            success: true,
            ...result
        });
    }
    catch (error) {
        logger_1.logger.error('Validate code error', { error: error.message });
        res.status(500).json({
            success: false,
            isValid: false,
            message: 'Internal server error'
        });
    }
};
exports.validateCode = validateCode;
/**
 * POST /api/codes/register
 * Register with an organization code (public endpoint)
 */
const registerWithCode = async (req, res) => {
    try {
        const { code, email, password, firstName, lastName, phone } = req.body;
        if (!code || !email || !password || !firstName || !lastName) {
            res.status(400).json({
                success: false,
                message: 'Code, email, password, firstName, and lastName are required'
            });
            return;
        }
        const ipAddress = req.ip || req.headers['x-forwarded-for'];
        const result = await organizationService.registerWithCode(code, { email, password, firstName, lastName, phone }, ipAddress);
        if (result.success) {
            res.status(201).json({
                success: true,
                data: {
                    userId: result.userId,
                    organizationId: result.organizationId
                },
                message: result.message
            });
        }
        else {
            res.status(400).json({
                success: false,
                message: result.message
            });
        }
    }
    catch (error) {
        logger_1.logger.error('Register with code error', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};
exports.registerWithCode = registerWithCode;
/**
 * POST /api/organizations/:id/codes
 * Generate a new organization code
 */
const generateCode = async (req, res) => {
    try {
        const organizationId = parseInt(req.params.id);
        const userId = req.user?.userId;
        const { maxUses, expiresAt, defaultRole } = req.body;
        if (!userId) {
            res.status(401).json({
                success: false,
                message: 'Authentication required'
            });
            return;
        }
        const result = await organizationService.generateOrganizationCode(organizationId, userId, {
            maxUses,
            expiresAt: expiresAt ? new Date(expiresAt) : undefined,
            defaultRole
        });
        if (result.success) {
            res.status(201).json({
                success: true,
                data: {
                    code: result.code,
                    codeId: result.codeId
                }
            });
        }
        else {
            res.status(400).json({
                success: false,
                message: result.message
            });
        }
    }
    catch (error) {
        logger_1.logger.error('Generate code error', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};
exports.generateCode = generateCode;
/**
 * GET /api/organizations/:id/codes
 * List organization codes
 */
const listCodes = async (req, res) => {
    try {
        const organizationId = parseInt(req.params.id);
        const codes = await organizationService.getOrganizationCodes(organizationId);
        res.json({
            success: true,
            data: codes
        });
    }
    catch (error) {
        logger_1.logger.error('List codes error', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};
exports.listCodes = listCodes;
/**
 * PATCH /api/organizations/:orgId/codes/:codeId
 * Deactivate a code
 */
const deactivateCode = async (req, res) => {
    try {
        const codeId = parseInt(req.params.codeId);
        const userId = req.user?.userId;
        if (!userId) {
            res.status(401).json({
                success: false,
                message: 'Authentication required'
            });
            return;
        }
        const result = await organizationService.deactivateOrganizationCode(codeId, userId);
        if (result.success) {
            res.json({
                success: true,
                message: result.message
            });
        }
        else {
            res.status(400).json({
                success: false,
                message: result.message
            });
        }
    }
    catch (error) {
        logger_1.logger.error('Deactivate code error', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};
exports.deactivateCode = deactivateCode;
// ============================================================================
// Access Request Endpoints
// ============================================================================
/**
 * POST /api/access-requests
 * Create an access request (public endpoint)
 */
const createAccessRequest = async (req, res) => {
    try {
        const { email, firstName, lastName, phone, organizationName, professionalTitle, credentials, reason, organizationId, requestedRole } = req.body;
        if (!email || !firstName || !lastName) {
            res.status(400).json({
                success: false,
                message: 'Email, firstName, and lastName are required'
            });
            return;
        }
        const result = await organizationService.createAccessRequest({
            email, firstName, lastName, phone,
            organizationName, professionalTitle, credentials,
            reason, organizationId, requestedRole
        });
        if (result.success) {
            res.status(201).json({
                success: true,
                data: {
                    requestId: result.requestId
                },
                message: result.message
            });
        }
        else {
            res.status(400).json({
                success: false,
                message: result.message
            });
        }
    }
    catch (error) {
        logger_1.logger.error('Create access request error', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};
exports.createAccessRequest = createAccessRequest;
/**
 * GET /api/access-requests
 * List access requests (admin only)
 */
const listAccessRequests = async (req, res) => {
    try {
        const { status, organizationId, page, limit } = req.query;
        const result = await organizationService.getAccessRequests({
            status: status,
            organizationId: organizationId ? parseInt(organizationId) : undefined,
            page: page ? parseInt(page) : undefined,
            limit: limit ? parseInt(limit) : undefined
        });
        res.json({
            success: true,
            data: result.data,
            pagination: {
                total: result.total,
                page: page ? parseInt(page) : 1,
                limit: limit ? parseInt(limit) : 20
            }
        });
    }
    catch (error) {
        logger_1.logger.error('List access requests error', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};
exports.listAccessRequests = listAccessRequests;
/**
 * PATCH /api/access-requests/:id
 * Review an access request (approve/reject)
 */
const reviewAccessRequest = async (req, res) => {
    try {
        const requestId = parseInt(req.params.id);
        const userId = req.user?.userId;
        const { decision, notes, password } = req.body;
        if (!userId) {
            res.status(401).json({
                success: false,
                message: 'Authentication required'
            });
            return;
        }
        if (!['approved', 'rejected'].includes(decision)) {
            res.status(400).json({
                success: false,
                message: 'Decision must be: approved or rejected'
            });
            return;
        }
        const result = await organizationService.reviewAccessRequest(requestId, userId, decision, notes, password);
        if (result.success) {
            res.json({
                success: true,
                data: {
                    userId: result.userId
                },
                message: result.message
            });
        }
        else {
            res.status(400).json({
                success: false,
                message: result.message
            });
        }
    }
    catch (error) {
        logger_1.logger.error('Review access request error', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};
exports.reviewAccessRequest = reviewAccessRequest;
// ============================================================================
// Invitation Endpoints
// ============================================================================
/**
 * POST /api/invitations
 * Create a user invitation
 */
const createInvitation = async (req, res) => {
    try {
        const userId = req.user?.userId;
        const { email, organizationId, studyId, role, message, expiresInDays } = req.body;
        if (!userId) {
            res.status(401).json({
                success: false,
                message: 'Authentication required'
            });
            return;
        }
        if (!email) {
            res.status(400).json({
                success: false,
                message: 'Email is required'
            });
            return;
        }
        const result = await organizationService.createInvitation(email, userId, {
            organizationId,
            studyId,
            role,
            message,
            expiresInDays
        });
        if (result.success) {
            res.status(201).json({
                success: true,
                data: {
                    token: result.token,
                    invitationId: result.invitationId,
                    // Generate full invitation link
                    invitationLink: `/register/invitation/${result.token}`
                }
            });
        }
        else {
            res.status(400).json({
                success: false,
                message: result.message
            });
        }
    }
    catch (error) {
        logger_1.logger.error('Create invitation error', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};
exports.createInvitation = createInvitation;
/**
 * GET /api/invitations/:token/validate
 * Validate an invitation token (public endpoint)
 */
const validateInvitation = async (req, res) => {
    try {
        const { token } = req.params;
        const result = await organizationService.validateInvitation(token);
        res.json({
            success: true,
            ...result
        });
    }
    catch (error) {
        logger_1.logger.error('Validate invitation error', { error: error.message });
        res.status(500).json({
            success: false,
            isValid: false,
            message: 'Internal server error'
        });
    }
};
exports.validateInvitation = validateInvitation;
/**
 * POST /api/invitations/:token/accept
 * Accept an invitation and create account (public endpoint)
 */
const acceptInvitation = async (req, res) => {
    try {
        const { token } = req.params;
        const { password, firstName, lastName, phone } = req.body;
        if (!password || !firstName || !lastName) {
            res.status(400).json({
                success: false,
                message: 'Password, firstName, and lastName are required'
            });
            return;
        }
        const result = await organizationService.acceptInvitation(token, {
            password,
            firstName,
            lastName,
            phone
        });
        if (result.success) {
            res.status(201).json({
                success: true,
                data: {
                    userId: result.userId
                },
                message: result.message
            });
        }
        else {
            res.status(400).json({
                success: false,
                message: result.message
            });
        }
    }
    catch (error) {
        logger_1.logger.error('Accept invitation error', { error: error.message });
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};
exports.acceptInvitation = acceptInvitation;
exports.default = {
    // Organizations
    registerOrganization: exports.registerOrganization,
    listOrganizations: exports.listOrganizations,
    getOrganization: exports.getOrganization,
    updateStatus: exports.updateStatus,
    getMyOrganizations: exports.getMyOrganizations,
    // Codes
    validateCode: exports.validateCode,
    registerWithCode: exports.registerWithCode,
    generateCode: exports.generateCode,
    listCodes: exports.listCodes,
    deactivateCode: exports.deactivateCode,
    // Access Requests
    createAccessRequest: exports.createAccessRequest,
    listAccessRequests: exports.listAccessRequests,
    reviewAccessRequest: exports.reviewAccessRequest,
    // Invitations
    createInvitation: exports.createInvitation,
    validateInvitation: exports.validateInvitation,
    acceptInvitation: exports.acceptInvitation
};
//# sourceMappingURL=organization.controller.js.map