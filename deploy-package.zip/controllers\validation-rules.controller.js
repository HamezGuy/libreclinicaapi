"use strict";
/**
 * Validation Rules Controller
 *
 * Manages validation rules for CRFs/forms
 * 21 CFR Part 11 §11.10(h) - Device checks (validation rules)
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.testRule = exports.validateData = exports.deleteRule = exports.toggleRule = exports.updateRule = exports.createRule = exports.getRule = exports.getRulesForStudy = exports.getRulesForCrf = void 0;
const validationRulesService = __importStar(require("../services/database/validation-rules.service"));
const audit_service_1 = require("../services/database/audit.service");
const logger_1 = require("../config/logger");
/**
 * Get validation rules for a CRF
 */
const getRulesForCrf = async (req, res, next) => {
    try {
        const { crfId } = req.params;
        const rules = await validationRulesService.getRulesForCrf(parseInt(crfId));
        const response = {
            success: true,
            data: rules
        };
        res.json(response);
    }
    catch (error) {
        logger_1.logger.error('Get CRF validation rules error:', error);
        next(error);
    }
};
exports.getRulesForCrf = getRulesForCrf;
/**
 * Get validation rules for a study (all CRFs)
 */
const getRulesForStudy = async (req, res, next) => {
    try {
        const { studyId } = req.params;
        const rules = await validationRulesService.getRulesForStudy(parseInt(studyId));
        const response = {
            success: true,
            data: rules
        };
        res.json(response);
    }
    catch (error) {
        logger_1.logger.error('Get study validation rules error:', error);
        next(error);
    }
};
exports.getRulesForStudy = getRulesForStudy;
/**
 * Get a single validation rule
 */
const getRule = async (req, res, next) => {
    try {
        const { ruleId } = req.params;
        const rule = await validationRulesService.getRuleById(parseInt(ruleId));
        if (!rule) {
            res.status(404).json({ success: false, message: 'Rule not found' });
            return;
        }
        const response = {
            success: true,
            data: rule
        };
        res.json(response);
    }
    catch (error) {
        logger_1.logger.error('Get validation rule error:', error);
        next(error);
    }
};
exports.getRule = getRule;
/**
 * Create a new validation rule
 */
const createRule = async (req, res, next) => {
    try {
        const user = req.user;
        const ruleData = req.body;
        const result = await validationRulesService.createRule(ruleData, user.userId);
        if (result.success) {
            // Audit trail
            await (0, audit_service_1.trackUserAction)({
                userId: user.userId,
                username: user.username || user.userName,
                action: 'VALIDATION_RULE_CREATED',
                entityType: 'validation_rule',
                entityId: result.ruleId,
                details: `Created validation rule: ${ruleData.name} for CRF ${ruleData.crfId}`
            });
        }
        res.status(result.success ? 201 : 400).json(result);
    }
    catch (error) {
        logger_1.logger.error('Create validation rule error:', error);
        next(error);
    }
};
exports.createRule = createRule;
/**
 * Update a validation rule
 */
const updateRule = async (req, res, next) => {
    try {
        const user = req.user;
        const { ruleId } = req.params;
        const updates = req.body;
        const result = await validationRulesService.updateRule(parseInt(ruleId), updates, user.userId);
        if (result.success) {
            await (0, audit_service_1.trackUserAction)({
                userId: user.userId,
                username: user.username || user.userName,
                action: 'VALIDATION_RULE_UPDATED',
                entityType: 'validation_rule',
                entityId: parseInt(ruleId),
                details: `Updated validation rule: ${updates.name || ruleId}`
            });
        }
        res.status(result.success ? 200 : 400).json(result);
    }
    catch (error) {
        logger_1.logger.error('Update validation rule error:', error);
        next(error);
    }
};
exports.updateRule = updateRule;
/**
 * Toggle validation rule active state
 */
const toggleRule = async (req, res, next) => {
    try {
        const user = req.user;
        const { ruleId } = req.params;
        const { active } = req.body;
        const result = await validationRulesService.toggleRule(parseInt(ruleId), active, user.userId);
        if (result.success) {
            await (0, audit_service_1.trackUserAction)({
                userId: user.userId,
                username: user.username || user.userName,
                action: active ? 'VALIDATION_RULE_ACTIVATED' : 'VALIDATION_RULE_DEACTIVATED',
                entityType: 'validation_rule',
                entityId: parseInt(ruleId),
                details: `Rule ${active ? 'activated' : 'deactivated'}`
            });
        }
        res.json(result);
    }
    catch (error) {
        logger_1.logger.error('Toggle validation rule error:', error);
        next(error);
    }
};
exports.toggleRule = toggleRule;
/**
 * Delete a validation rule
 */
const deleteRule = async (req, res, next) => {
    try {
        const user = req.user;
        const { ruleId } = req.params;
        const result = await validationRulesService.deleteRule(parseInt(ruleId), user.userId);
        if (result.success) {
            await (0, audit_service_1.trackUserAction)({
                userId: user.userId,
                username: user.username || user.userName,
                action: 'VALIDATION_RULE_DELETED',
                entityType: 'validation_rule',
                entityId: parseInt(ruleId),
                details: `Deleted validation rule ID: ${ruleId}`
            });
        }
        res.json(result);
    }
    catch (error) {
        logger_1.logger.error('Delete validation rule error:', error);
        next(error);
    }
};
exports.deleteRule = deleteRule;
/**
 * Validate form data against rules
 *
 * Accepts options from query params OR request body:
 * - createQueries: If true, creates queries (discrepancy notes) for validation failures
 * - studyId: Required if createQueries is true
 * - subjectId: Optional, links query to subject
 * - eventCrfId: Optional, links query to event CRF
 *
 * Request body can contain:
 * - formData: The actual form data to validate (if separate from other fields)
 * - Or: form fields directly in the body
 */
const validateData = async (req, res, next) => {
    try {
        const user = req.user;
        const { crfId } = req.params;
        // Support options from both query params and body for flexibility
        const createQueriesQuery = req.query.createQueries;
        const createQueriesBody = req.body.createQueries;
        const options = {
            createQueries: createQueriesQuery === 'true' || createQueriesBody === true,
            studyId: req.body.studyId || (req.query.studyId ? parseInt(req.query.studyId) : undefined),
            subjectId: req.body.subjectId || (req.query.subjectId ? parseInt(req.query.subjectId) : undefined),
            eventCrfId: req.body.eventCrfId || (req.query.eventCrfId ? parseInt(req.query.eventCrfId) : undefined),
            userId: user?.userId
        };
        // Support formData as nested object or form fields directly in body
        const formData = req.body.formData || (() => {
            // Extract form fields by removing metadata fields
            const { createQueries, studyId, subjectId, eventCrfId, formData: _, ...fields } = req.body;
            return fields;
        })();
        const result = await validationRulesService.validateFormData(parseInt(crfId), formData, options);
        // Audit trail if queries were created
        if (result.queriesCreated && result.queriesCreated > 0) {
            await (0, audit_service_1.trackUserAction)({
                userId: user.userId,
                username: user.username || user.userName,
                action: 'VALIDATION_QUERIES_CREATED',
                entityType: 'validation',
                entityId: parseInt(crfId),
                details: `Created ${result.queriesCreated} queries from validation failures`
            });
        }
        const response = {
            success: true,
            data: result
        };
        res.json(response);
    }
    catch (error) {
        logger_1.logger.error('Validate form data error:', error);
        next(error);
    }
};
exports.validateData = validateData;
/**
 * Test a single rule against test data
 */
const testRule = async (req, res, next) => {
    try {
        const { rule, testValue, testData } = req.body;
        // Create a mock rule object
        const mockRule = {
            id: 0,
            crfId: 0,
            name: rule.name || 'Test Rule',
            description: '',
            ruleType: rule.ruleType,
            fieldPath: 'testField',
            severity: rule.severity || 'error',
            errorMessage: rule.errorMessage || 'Validation failed',
            active: true,
            minValue: rule.minValue,
            maxValue: rule.maxValue,
            pattern: rule.pattern,
            operator: rule.operator,
            compareFieldPath: rule.compareFieldPath,
            dateCreated: new Date(),
            createdBy: 0
        };
        // Build test data object
        const data = testData || { testField: testValue };
        if (!testData) {
            data.testField = testValue;
        }
        // Validate
        const result = await validationRulesService.validateFormData(0, {
            [rule.fieldPath || 'testField']: testValue,
            ...testData
        });
        // Since we're testing a single rule, manually check
        let valid = true;
        if (rule.ruleType === 'required') {
            valid = testValue !== null && testValue !== undefined && testValue !== '';
        }
        else if (rule.ruleType === 'range') {
            const numValue = Number(testValue);
            if (isNaN(numValue)) {
                valid = false;
            }
            else {
                if (rule.minValue !== undefined && numValue < rule.minValue)
                    valid = false;
                if (rule.maxValue !== undefined && numValue > rule.maxValue)
                    valid = false;
            }
        }
        else if (rule.ruleType === 'format' && rule.pattern) {
            try {
                const regex = new RegExp(rule.pattern);
                valid = regex.test(String(testValue));
            }
            catch {
                valid = true;
            }
        }
        res.json({
            success: true,
            data: {
                valid,
                message: valid ? 'Validation passed' : rule.errorMessage
            }
        });
    }
    catch (error) {
        logger_1.logger.error('Test rule error:', error);
        next(error);
    }
};
exports.testRule = testRule;
exports.default = {
    getRulesForCrf: exports.getRulesForCrf,
    getRulesForStudy: exports.getRulesForStudy,
    getRule: exports.getRule,
    createRule: exports.createRule,
    updateRule: exports.updateRule,
    toggleRule: exports.toggleRule,
    deleteRule: exports.deleteRule,
    validateData: exports.validateData,
    testRule: exports.testRule
};
//# sourceMappingURL=validation-rules.controller.js.map