"use strict";
/**
 * Audit Service
 *
 * Handles audit trail queries from LibreClinica database
 * - Query audit_log_event table
 * - Filter by study, subject, user, date range
 * - Export audit trail (CSV, PDF, JSON)
 * - Subject-specific audit history
 *
 * Compliance: 21 CFR Part 11 §11.10(e) - Audit Trail
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLoginStatistics = exports.getLoginHistory = exports.exportAuditLogs = exports.getAuditStats = exports.recordElectronicSignature = exports.getFormAuditTrail = exports.getSubjectAuditTrail = exports.getAuditLogs = exports.trackDocumentAccess = exports.trackUserAction = exports.AuditEventTypes = exports.recordAuditEvent = exports.getComplianceReport = exports.getAuditSummary = exports.getFormAudit = exports.getAuditableTables = exports.getAuditEventTypes = exports.getAuditStatistics = exports.exportAuditTrailCSV = exports.getRecentAuditEvents = exports.getSubjectAudit = exports.getAuditTrail = void 0;
const database_1 = require("../../config/database");
const logger_1 = require("../../config/logger");
/**
 * Get audit trail with filters
 * Main method for querying audit history
 */
const getAuditTrail = async (query) => {
    logger_1.logger.info('Querying audit trail', query);
    try {
        const { studyId, subjectId, userId, eventType, startDate, endDate, page = 1, limit = 50 } = query;
        const offset = (page - 1) * limit;
        // Build dynamic WHERE clause
        const conditions = ['1=1'];
        const params = [];
        let paramIndex = 1;
        // Note: audit_log_event table doesn't have direct study_id or subject_id columns
        // These would need to be joined through related tables if needed
        if (userId) {
            conditions.push(`ale.user_id = $${paramIndex++}`);
            params.push(userId);
        }
        if (eventType) {
            conditions.push(`alet.name ILIKE $${paramIndex++}`);
            params.push(`%${eventType}%`);
        }
        if (startDate) {
            conditions.push(`ale.audit_date >= $${paramIndex++}`);
            params.push(startDate);
        }
        if (endDate) {
            conditions.push(`ale.audit_date <= $${paramIndex++}`);
            params.push(endDate);
        }
        const whereClause = conditions.join(' AND ');
        // Get total count
        const countQuery = `
      SELECT COUNT(*) as total
      FROM audit_log_event ale
      LEFT JOIN audit_log_event_type alet ON ale.audit_log_event_type_id = alet.audit_log_event_type_id
      WHERE ${whereClause}
    `;
        const countResult = await database_1.pool.query(countQuery, params);
        const total = parseInt(countResult.rows[0].total);
        // Get paginated results
        const dataQuery = `
      SELECT 
        ale.audit_id,
        ale.audit_date,
        ale.audit_table,
        ale.user_id,
        u.user_name,
        u.first_name || ' ' || u.last_name as user_full_name,
        ale.entity_id,
        ale.entity_name,
        ale.old_value,
        ale.new_value,
        ale.audit_log_event_type_id,
        alet.name as event_type,
        ale.reason_for_change,
        ale.event_crf_id
      FROM audit_log_event ale
      LEFT JOIN audit_log_event_type alet ON ale.audit_log_event_type_id = alet.audit_log_event_type_id
      LEFT JOIN user_account u ON ale.user_id = u.user_id
      WHERE ${whereClause}
      ORDER BY ale.audit_date DESC
      LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
    `;
        params.push(limit, offset);
        const dataResult = await database_1.pool.query(dataQuery, params);
        logger_1.logger.info('Audit trail query successful', {
            total,
            page,
            limit,
            returned: dataResult.rows.length
        });
        return {
            success: true,
            data: dataResult.rows,
            pagination: {
                page,
                limit,
                total,
                totalPages: Math.ceil(total / limit)
            }
        };
    }
    catch (error) {
        logger_1.logger.error('Audit trail query error', {
            error: error.message,
            query
        });
        throw error;
    }
};
exports.getAuditTrail = getAuditTrail;
/**
 * Get audit trail for specific subject
 * Returns complete audit history for a subject
 */
const getSubjectAudit = async (subjectId, page = 1, limit = 100) => {
    logger_1.logger.info('Querying subject audit trail', { subjectId });
    return await (0, exports.getAuditTrail)({
        subjectId,
        page,
        limit
    });
};
exports.getSubjectAudit = getSubjectAudit;
/**
 * Get recent audit events
 * Returns most recent audit events across all studies
 * COMBINES: audit_log_event (data changes) + audit_user_login (login/logout events)
 */
const getRecentAuditEvents = async (limit = 50) => {
    logger_1.logger.info('Querying recent audit events', { limit });
    try {
        // Combined query: data events + login events
        const query = `
      (
        SELECT 
          ale.audit_id::text as audit_id,
          ale.audit_date,
          ale.audit_table,
          ale.user_id,
          u.user_name,
          u.first_name || ' ' || u.last_name as user_full_name,
          ale.entity_id,
          ale.entity_name,
          COALESCE(alet.name, 'Data Change') as event_type,
          ale.old_value,
          ale.new_value,
          'data' as event_category
        FROM audit_log_event ale
        LEFT JOIN audit_log_event_type alet ON ale.audit_log_event_type_id = alet.audit_log_event_type_id
        LEFT JOIN user_account u ON ale.user_id = u.user_id
      )
      UNION ALL
      (
        SELECT 
          'login_' || aul.id::text as audit_id,
          aul.login_attempt_date as audit_date,
          'user_login' as audit_table,
          aul.user_account_id as user_id,
          aul.user_name,
          u.first_name || ' ' || u.last_name as user_full_name,
          aul.user_account_id as entity_id,
          aul.user_name as entity_name,
          CASE 
            WHEN aul.login_status_code = 1 THEN 'User Login'
            WHEN aul.login_status_code = 2 THEN 'User Logout'
            ELSE 'Failed Login Attempt'
          END as event_type,
          NULL as old_value,
          aul.details as new_value,
          'login' as event_category
        FROM audit_user_login aul
        LEFT JOIN user_account u ON aul.user_account_id = u.user_id
      )
      ORDER BY audit_date DESC
      LIMIT $1
    `;
        const result = await database_1.pool.query(query, [limit]);
        return result.rows;
    }
    catch (error) {
        logger_1.logger.error('Recent audit events query error', {
            error: error.message
        });
        throw error;
    }
};
exports.getRecentAuditEvents = getRecentAuditEvents;
/**
 * Export audit trail to CSV
 * Note: audit_log_event does NOT have study_id or subject_id columns
 * We filter by audit_table and date range instead
 */
const exportAuditTrailCSV = async (request) => {
    logger_1.logger.info('Exporting audit trail to CSV', request);
    try {
        const { startDate, endDate } = request;
        const query = `
      SELECT 
        ale.audit_date,
        u.user_name,
        u.first_name || ' ' || u.last_name as user_full_name,
        alet.name as event_type,
        ale.audit_table,
        ale.entity_id,
        ale.entity_name,
        ale.old_value,
        ale.new_value,
        ale.reason_for_change
      FROM audit_log_event ale
      LEFT JOIN audit_log_event_type alet ON ale.audit_log_event_type_id = alet.audit_log_event_type_id
      LEFT JOIN user_account u ON ale.user_id = u.user_id
      WHERE ale.audit_date >= $1
        AND ale.audit_date <= $2
      ORDER BY ale.audit_date ASC
    `;
        const result = await database_1.pool.query(query, [startDate, endDate]);
        // Build CSV
        const headers = [
            'Audit Date',
            'Username',
            'User Full Name',
            'Event Type',
            'Table',
            'Entity ID',
            'Entity Name',
            'Old Value',
            'New Value',
            'Reason for Change'
        ];
        let csv = headers.join(',') + '\n';
        for (const row of result.rows) {
            const values = [
                row.audit_date,
                row.user_name,
                `"${row.user_full_name || ''}"`,
                `"${row.event_type || ''}"`,
                row.audit_table,
                row.entity_id || '',
                `"${row.entity_name || ''}"`,
                `"${row.old_value || ''}"`,
                `"${row.new_value || ''}"`,
                `"${row.reason_for_change || ''}"`
            ];
            csv += values.join(',') + '\n';
        }
        logger_1.logger.info('Audit trail exported to CSV', {
            rowCount: result.rows.length
        });
        return csv;
    }
    catch (error) {
        logger_1.logger.error('Audit trail CSV export error', {
            error: error.message,
            request
        });
        throw error;
    }
};
exports.exportAuditTrailCSV = exportAuditTrailCSV;
/**
 * Get audit statistics
 * COMBINES: audit_log_event (data changes) + audit_user_login (login/logout events)
 */
const getAuditStatistics = async (days = 30) => {
    logger_1.logger.info('Calculating audit statistics', { days });
    try {
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - days);
        // Get data event stats
        const dataEventsQuery = `
      SELECT 
        COUNT(*) as total_data_events,
        COUNT(DISTINCT ale.user_id) as data_unique_users,
        COUNT(CASE WHEN alet.name LIKE '%Data%' OR alet.name LIKE '%Entry%' THEN 1 END) as data_entry_events,
        COUNT(CASE WHEN alet.name LIKE '%Subject%' THEN 1 END) as subject_events,
        COUNT(CASE WHEN alet.name LIKE '%Query%' OR alet.name LIKE '%Discrepancy%' THEN 1 END) as query_events,
        COUNT(CASE WHEN alet.name LIKE '%SDV%' OR alet.name LIKE '%Verif%' THEN 1 END) as sdv_events
      FROM audit_log_event ale
      LEFT JOIN audit_log_event_type alet ON ale.audit_log_event_type_id = alet.audit_log_event_type_id
      WHERE ale.audit_date >= $1
    `;
        // Get login event stats from audit_user_login
        const loginEventsQuery = `
      SELECT 
        COUNT(*) as total_login_events,
        COUNT(DISTINCT user_account_id) as login_unique_users,
        COUNT(CASE WHEN login_status_code = 1 THEN 1 END) as successful_logins,
        COUNT(CASE WHEN login_status_code = 0 THEN 1 END) as failed_logins,
        COUNT(CASE WHEN login_status_code = 2 THEN 1 END) as logouts
      FROM audit_user_login
      WHERE login_attempt_date >= $1
    `;
        const [dataResult, loginResult] = await Promise.all([
            database_1.pool.query(dataEventsQuery, [startDate]),
            database_1.pool.query(loginEventsQuery, [startDate])
        ]);
        const dataStats = dataResult.rows[0] || {};
        const loginStats = loginResult.rows[0] || {};
        return {
            total_events: parseInt(dataStats.total_data_events || 0) + parseInt(loginStats.total_login_events || 0),
            unique_users: Math.max(parseInt(dataStats.data_unique_users || 0), parseInt(loginStats.login_unique_users || 0)),
            active_days: days,
            // Login events (from audit_user_login)
            login_events: parseInt(loginStats.successful_logins || 0),
            failed_login_events: parseInt(loginStats.failed_logins || 0),
            logout_events: parseInt(loginStats.logouts || 0),
            // Data events (from audit_log_event)
            data_events: parseInt(dataStats.data_entry_events || 0),
            subject_events: parseInt(dataStats.subject_events || 0),
            query_events: parseInt(dataStats.query_events || 0),
            sdv_events: parseInt(dataStats.sdv_events || 0)
        };
    }
    catch (error) {
        logger_1.logger.error('Audit statistics error', {
            error: error.message
        });
        throw error;
    }
};
exports.getAuditStatistics = getAuditStatistics;
/**
 * Get audit event types from database
 */
const getAuditEventTypes = async () => {
    logger_1.logger.info('Getting audit event types');
    try {
        const query = `
      SELECT 
        audit_log_event_type_id as id,
        name,
        description
      FROM audit_log_event_type
      ORDER BY audit_log_event_type_id
    `;
        const result = await database_1.pool.query(query);
        return result.rows;
    }
    catch (error) {
        logger_1.logger.error('Get audit event types error', { error: error.message });
        return [];
    }
};
exports.getAuditEventTypes = getAuditEventTypes;
/**
 * Get auditable tables list
 */
const getAuditableTables = async () => {
    logger_1.logger.info('Getting auditable tables');
    try {
        const query = `
      SELECT DISTINCT audit_table as name,
        COUNT(*) as event_count
      FROM audit_log_event
      GROUP BY audit_table
      ORDER BY event_count DESC
    `;
        const result = await database_1.pool.query(query);
        return result.rows;
    }
    catch (error) {
        logger_1.logger.error('Get auditable tables error', { error: error.message });
        return [];
    }
};
exports.getAuditableTables = getAuditableTables;
/**
 * Get form/CRF specific audit trail
 */
const getFormAudit = async (eventCrfId) => {
    logger_1.logger.info('Getting form audit', { eventCrfId });
    try {
        const query = `
      SELECT 
        ale.audit_id,
        ale.audit_date,
        ale.audit_table,
        u.user_name,
        u.first_name || ' ' || u.last_name as user_full_name,
        ale.entity_id,
        ale.entity_name,
        ale.old_value,
        ale.new_value,
        alet.name as event_type,
        ale.reason_for_change
      FROM audit_log_event ale
      LEFT JOIN audit_log_event_type alet ON ale.audit_log_event_type_id = alet.audit_log_event_type_id
      LEFT JOIN user_account u ON ale.user_id = u.user_id
      WHERE ale.event_crf_id = $1
      ORDER BY ale.audit_date DESC
    `;
        const result = await database_1.pool.query(query, [eventCrfId]);
        return result.rows;
    }
    catch (error) {
        logger_1.logger.error('Get form audit error', { error: error.message });
        return [];
    }
};
exports.getFormAudit = getFormAudit;
/**
 * Get audit by date range with summary
 */
const getAuditSummary = async (startDate, endDate) => {
    logger_1.logger.info('Getting audit summary', { startDate, endDate });
    try {
        const query = `
      SELECT 
        DATE(ale.audit_date) as date,
        alet.name as event_type,
        COUNT(*) as count
      FROM audit_log_event ale
      LEFT JOIN audit_log_event_type alet ON ale.audit_log_event_type_id = alet.audit_log_event_type_id
      WHERE ale.audit_date >= $1 AND ale.audit_date <= $2
      GROUP BY DATE(ale.audit_date), alet.name
      ORDER BY date DESC, count DESC
    `;
        const result = await database_1.pool.query(query, [startDate, endDate]);
        // Group by date
        const summary = {};
        for (const row of result.rows) {
            const dateKey = row.date?.toISOString().split('T')[0];
            if (!summary[dateKey]) {
                summary[dateKey] = { date: dateKey, events: {}, total: 0 };
            }
            summary[dateKey].events[row.event_type] = parseInt(row.count);
            summary[dateKey].total += parseInt(row.count);
        }
        return {
            success: true,
            data: Object.values(summary)
        };
    }
    catch (error) {
        logger_1.logger.error('Get audit summary error', { error: error.message });
        return { success: false, data: [] };
    }
};
exports.getAuditSummary = getAuditSummary;
/**
 * Get compliance report
 * Returns audit data formatted for 21 CFR Part 11 compliance reports
 */
const getComplianceReport = async (request) => {
    logger_1.logger.info('Generating compliance report', request);
    try {
        const { startDate, endDate } = request;
        // Get summary statistics
        const statsQuery = `
      SELECT 
        COUNT(*) as total_events,
        COUNT(DISTINCT ale.user_id) as unique_users,
        COUNT(DISTINCT DATE(ale.audit_date)) as active_days,
        MIN(ale.audit_date) as first_event,
        MAX(ale.audit_date) as last_event
      FROM audit_log_event ale
      WHERE ale.audit_date >= $1 AND ale.audit_date <= $2
    `;
        const statsResult = await database_1.pool.query(statsQuery, [startDate, endDate]);
        const stats = statsResult.rows[0];
        // Get events by type
        const typeQuery = `
      SELECT 
        alet.name as event_type,
        COUNT(*) as count
      FROM audit_log_event ale
      LEFT JOIN audit_log_event_type alet ON ale.audit_log_event_type_id = alet.audit_log_event_type_id
      WHERE ale.audit_date >= $1 AND ale.audit_date <= $2
      GROUP BY alet.name
      ORDER BY count DESC
    `;
        const typeResult = await database_1.pool.query(typeQuery, [startDate, endDate]);
        // Get user activity
        const userQuery = `
      SELECT 
        u.user_name,
        u.first_name || ' ' || u.last_name as user_full_name,
        COUNT(*) as event_count
      FROM audit_log_event ale
      INNER JOIN user_account u ON ale.user_id = u.user_id
      WHERE ale.audit_date >= $1 AND ale.audit_date <= $2
      GROUP BY u.user_name, u.first_name, u.last_name
      ORDER BY event_count DESC
    `;
        const userResult = await database_1.pool.query(userQuery, [startDate, endDate]);
        // Get login events
        const loginQuery = `
      SELECT 
        aul.login_attempt_date,
        aul.user_name,
        aul.login_status
      FROM audit_user_login aul
      WHERE aul.login_attempt_date >= $1 AND aul.login_attempt_date <= $2
      ORDER BY aul.login_attempt_date DESC
      LIMIT 100
    `;
        const loginResult = await database_1.pool.query(loginQuery, [startDate, endDate]);
        return {
            success: true,
            data: {
                reportPeriod: { startDate, endDate },
                generatedAt: new Date().toISOString(),
                summary: {
                    totalEvents: parseInt(stats.total_events),
                    uniqueUsers: parseInt(stats.unique_users),
                    activeDays: parseInt(stats.active_days),
                    firstEvent: stats.first_event,
                    lastEvent: stats.last_event
                },
                eventsByType: typeResult.rows.map(r => ({
                    type: r.event_type,
                    count: parseInt(r.count)
                })),
                userActivity: userResult.rows.map(r => ({
                    userName: r.user_name,
                    fullName: r.user_full_name,
                    eventCount: parseInt(r.event_count)
                })),
                recentLogins: loginResult.rows
            }
        };
    }
    catch (error) {
        logger_1.logger.error('Compliance report error', { error: error.message });
        return { success: false, message: error.message };
    }
};
exports.getComplianceReport = getComplianceReport;
/**
 * Record audit event directly to database
 * Uses LibreClinica's CORRECT audit_log_event schema
 */
const recordAuditEvent = async (data) => {
    logger_1.logger.info('Recording audit event to database', {
        audit_table: data.audit_table,
        entity_id: data.entity_id,
        user_id: data.user_id
    });
    try {
        // LibreClinica's actual audit_log_event columns:
        // audit_id (SERIAL), audit_date, audit_table, user_id, entity_id, entity_name,
        // old_value, new_value, audit_log_event_type_id, reason_for_change,
        // event_crf_id, study_event_id, event_crf_version_id, item_data_repeat_key
        // NOTE: There is NO study_id column in audit_log_event!
        const query = `
      INSERT INTO audit_log_event (
        audit_date, 
        audit_table, 
        user_id, 
        entity_id, 
        entity_name,
        old_value, 
        new_value, 
        audit_log_event_type_id, 
        reason_for_change,
        event_crf_id,
        study_event_id
      ) VALUES (
        NOW(), $1, $2, $3, $4, $5, $6, $7, $8, $9, $10
      ) RETURNING audit_id
    `;
        const result = await database_1.pool.query(query, [
            data.audit_table,
            data.user_id,
            data.entity_id,
            data.user_name, // entity_name
            data.old_value || null,
            data.new_value || null,
            data.audit_log_event_type_id,
            data.reason_for_change || null,
            data.event_crf_id || null,
            data.study_event_id || null
        ]);
        return {
            success: true,
            data: { audit_id: result.rows[0].audit_id },
            message: 'Audit event recorded'
        };
    }
    catch (error) {
        logger_1.logger.error('Failed to record audit event', { error: error.message });
        return { success: false, message: error.message };
    }
};
exports.recordAuditEvent = recordAuditEvent;
/**
 * Common audit event types for tracking user actions
 */
exports.AuditEventTypes = {
    // Document/Form access
    FORM_VIEWED: 1,
    FORM_CREATED: 2,
    FORM_UPDATED: 3,
    FORM_DELETED: 4,
    FORM_SIGNED: 5,
    // Subject access
    SUBJECT_VIEWED: 10,
    SUBJECT_CREATED: 11,
    SUBJECT_UPDATED: 12,
    // Study access
    STUDY_ACCESSED: 20,
    STUDY_EXPORTED: 21,
    // Query events  
    QUERY_CREATED: 30,
    QUERY_RESPONDED: 31,
    QUERY_CLOSED: 32,
    // SDV events
    SDV_VERIFIED: 40,
    SDV_REJECTED: 41,
    // Report events
    REPORT_GENERATED: 50,
    AUDIT_EXPORTED: 51
};
/**
 * Track user action - Simplified API for controllers to record audit events
 * Uses LibreClinica's CORRECT audit_log_event schema
 *
 * @example
 * await trackUserAction({
 *   userId: user.userId,
 *   username: user.username,
 *   action: 'FORM_VIEWED',
 *   entityType: 'event_crf',
 *   entityId: eventCrfId,
 *   details: 'Viewed wound assessment form'
 * });
 */
const trackUserAction = async (data) => {
    try {
        // Map action to event type ID (or use 1 as default)
        const eventTypeId = exports.AuditEventTypes[data.action] || 1;
        // Use LibreClinica's CORRECT column order
        // NOTE: There is NO study_id column in audit_log_event!
        const query = `
      INSERT INTO audit_log_event (
        audit_date, 
        audit_table, 
        user_id,
        entity_id, 
        entity_name, 
        old_value, 
        new_value, 
        audit_log_event_type_id,
        reason_for_change,
        event_crf_id,
        study_event_id
      ) VALUES (
        NOW(), $1, $2, $3, $4, $5, $6, $7, $8, $9, $10
      ) RETURNING audit_id
    `;
        const result = await database_1.pool.query(query, [
            data.entityType, // audit_table
            data.userId, // user_id
            data.entityId || null, // entity_id
            data.entityName || data.username, // entity_name
            data.oldValue || null, // old_value
            data.newValue || data.details || null, // new_value
            eventTypeId, // audit_log_event_type_id
            data.details || `${data.action} by ${data.username}`, // reason_for_change
            data.eventCrfId || null, // event_crf_id
            data.studyEventId || null // study_event_id
        ]);
        logger_1.logger.info('User action tracked', {
            action: data.action,
            entityType: data.entityType,
            entityId: data.entityId,
            userId: data.userId
        });
        return { success: true, auditId: result.rows[0].audit_id };
    }
    catch (error) {
        logger_1.logger.error('Failed to track user action', {
            error: error.message,
            action: data.action
        });
        return { success: false };
    }
};
exports.trackUserAction = trackUserAction;
/**
 * Track document/form access
 */
const trackDocumentAccess = async (userId, username, documentType, documentId, documentName, action = 'view') => {
    const actionMap = {
        view: 'FORM_VIEWED',
        edit: 'FORM_UPDATED',
        sign: 'FORM_SIGNED',
        export: 'AUDIT_EXPORTED'
    };
    await (0, exports.trackUserAction)({
        userId,
        username,
        action: actionMap[action],
        entityType: documentType,
        entityId: documentId,
        entityName: documentName,
        details: `${action} ${documentType} ${documentName || documentId}`
    });
};
exports.trackDocumentAccess = trackDocumentAccess;
/**
 * Get audit logs with flexible filtering
 * Alias for getAuditTrail with additional parameters
 */
const getAuditLogs = async (params) => {
    const page = Math.floor((params.offset || 0) / (params.limit || 50)) + 1;
    return (0, exports.getAuditTrail)({
        studyId: params.studyId,
        userId: params.userId,
        eventType: params.eventType,
        startDate: params.startDate,
        endDate: params.endDate,
        limit: params.limit || 50,
        page
    });
};
exports.getAuditLogs = getAuditLogs;
/**
 * Get subject audit trail
 * Alias for getSubjectAudit with API response format
 */
const getSubjectAuditTrail = async (subjectId) => {
    const result = await (0, exports.getSubjectAudit)(subjectId);
    return {
        success: result.success,
        data: result.data,
        message: result.success ? 'Subject audit trail retrieved' : 'Failed to retrieve audit trail'
    };
};
exports.getSubjectAuditTrail = getSubjectAuditTrail;
/**
 * Get form audit trail
 * Alias for getFormAudit with API response format
 */
const getFormAuditTrail = async (eventCrfId) => {
    const data = await (0, exports.getFormAudit)(eventCrfId);
    return {
        success: true,
        data,
        message: 'Form audit trail retrieved'
    };
};
exports.getFormAuditTrail = getFormAuditTrail;
/**
 * Record electronic signature to database
 */
const recordElectronicSignature = async (data) => {
    logger_1.logger.info('Recording electronic signature to database', {
        entity_type: data.entity_type,
        entity_id: data.entity_id,
        signer_username: data.signer_username
    });
    try {
        // Record as audit event with signature flag
        const query = `
      INSERT INTO audit_log_event (
        audit_date, audit_table, entity_id, user_id, 
        audit_log_event_type_id, new_value, reason_for_change
      ) 
      SELECT 
        $1, $2, $3, u.user_id, 30, $4, $5
      FROM user_account u
      WHERE u.user_name = $6
      RETURNING audit_id
    `;
        const signatureValue = JSON.stringify({
            type: 'electronic_signature',
            meaning: data.meaning,
            signed_at: data.signed_at.toISOString()
        });
        const result = await database_1.pool.query(query, [
            data.signed_at,
            data.entity_type,
            data.entity_id,
            signatureValue,
            data.reason_for_change || `Electronic signature: ${data.meaning}`,
            data.signer_username
        ]);
        if (result.rows.length === 0) {
            return { success: false, message: 'User not found for signature' };
        }
        return {
            success: true,
            data: { signature_id: result.rows[0].audit_id },
            message: 'Electronic signature recorded'
        };
    }
    catch (error) {
        logger_1.logger.error('Failed to record electronic signature', { error: error.message });
        return { success: false, message: error.message };
    }
};
exports.recordElectronicSignature = recordElectronicSignature;
/**
 * Get audit statistics for dashboard
 */
const getAuditStats = async (days = 30) => {
    const stats = await (0, exports.getAuditStatistics)(days);
    return {
        success: true,
        data: {
            totalEvents: parseInt(stats.total_events || '0'),
            uniqueUsers: parseInt(stats.unique_users || '0'),
            activeDays: parseInt(stats.active_days || '0'),
            byType: {
                login: parseInt(stats.login_events || '0'),
                data: parseInt(stats.data_events || '0'),
                subject: parseInt(stats.subject_events || '0'),
                query: parseInt(stats.query_events || '0')
            }
        }
    };
};
exports.getAuditStats = getAuditStats;
/**
 * Export audit logs in specified format
 */
const exportAuditLogs = async (params, format = 'csv') => {
    if (format === 'csv') {
        const csv = await (0, exports.exportAuditTrailCSV)({
            studyId: params.studyId || 0,
            startDate: params.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
            endDate: params.endDate || new Date().toISOString(),
            format: 'csv'
        });
        return { success: true, data: csv, format: 'csv' };
    }
    else {
        const result = await (0, exports.getAuditTrail)({
            studyId: params.studyId,
            startDate: params.startDate,
            endDate: params.endDate,
            limit: 10000
        });
        return { success: true, data: result.data, format: 'json' };
    }
};
exports.exportAuditLogs = exportAuditLogs;
/**
 * Get login history from audit_user_login table
 * Returns all login/logout/failed login events
 *
 * 21 CFR Part 11 §11.10(e) - Audit Trail for login events
 *
 * @param params.userId - Filter by specific user
 * @param params.startDate - Filter events after this date
 * @param params.endDate - Filter events before this date
 * @param params.status - Filter by status: 'success' (1), 'failed' (0), 'logout' (2), or 'all'
 * @param params.limit - Maximum number of records
 * @param params.offset - Pagination offset
 */
const getLoginHistory = async (params) => {
    logger_1.logger.info('Querying login history', params);
    try {
        const conditions = ['1=1'];
        const queryParams = [];
        let paramIndex = 1;
        if (params.userId) {
            conditions.push(`aul.user_account_id = $${paramIndex++}`);
            queryParams.push(params.userId);
        }
        if (params.username) {
            conditions.push(`aul.user_name ILIKE $${paramIndex++}`);
            queryParams.push(`%${params.username}%`);
        }
        if (params.startDate) {
            conditions.push(`aul.login_attempt_date >= $${paramIndex++}`);
            queryParams.push(params.startDate);
        }
        if (params.endDate) {
            conditions.push(`aul.login_attempt_date <= $${paramIndex++}`);
            queryParams.push(params.endDate);
        }
        if (params.status && params.status !== 'all') {
            const statusMap = {
                'success': 1,
                'failed': 0,
                'logout': 2
            };
            conditions.push(`aul.login_status_code = $${paramIndex++}`);
            queryParams.push(statusMap[params.status]);
        }
        const whereClause = conditions.join(' AND ');
        const limit = params.limit || 100;
        const offset = params.offset || 0;
        // Get total count
        const countQuery = `
      SELECT COUNT(*) as total
      FROM audit_user_login aul
      WHERE ${whereClause}
    `;
        const countResult = await database_1.pool.query(countQuery, queryParams);
        const total = parseInt(countResult.rows[0].total);
        // Get paginated results
        // Note: audit_user_login has NO audit_date column, use login_attempt_date
        const dataQuery = `
      SELECT 
        aul.id,
        aul.user_name as username,
        aul.user_account_id as user_id,
        u.first_name,
        u.last_name,
        u.first_name || ' ' || u.last_name as user_full_name,
        u.email,
        aul.login_attempt_date as audit_date,
        aul.login_attempt_date,
        aul.login_status_code as login_status,
        CASE 
          WHEN aul.login_status_code = 1 THEN 'success'
          WHEN aul.login_status_code = 2 THEN 'logout'
          ELSE 'failed'
        END as status_text,
        CASE 
          WHEN aul.login_status_code = 1 THEN 'User Login'
          WHEN aul.login_status_code = 2 THEN 'User Logout'
          ELSE 'Failed Login Attempt'
        END as event_type,
        aul.details,
        aul.version
      FROM audit_user_login aul
      LEFT JOIN user_account u ON aul.user_account_id = u.user_id
      WHERE ${whereClause}
      ORDER BY aul.login_attempt_date DESC
      LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
    `;
        queryParams.push(limit, offset);
        const dataResult = await database_1.pool.query(dataQuery, queryParams);
        logger_1.logger.info('Login history query successful', {
            total,
            returned: dataResult.rows.length
        });
        return {
            success: true,
            data: dataResult.rows,
            pagination: { total, limit, offset }
        };
    }
    catch (error) {
        logger_1.logger.error('Login history query error', { error: error.message });
        return {
            success: false,
            data: [],
            pagination: { total: 0, limit: params.limit || 100, offset: params.offset || 0 }
        };
    }
};
exports.getLoginHistory = getLoginHistory;
/**
 * Get login statistics for compliance reporting
 * Returns counts of successful logins, failed attempts, and logouts
 */
const getLoginStatistics = async (days = 30) => {
    logger_1.logger.info('Calculating login statistics', { days });
    try {
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - days);
        // Get summary stats
        // Note: column is login_status_code (not login_status)
        const summaryQuery = `
      SELECT 
        COUNT(CASE WHEN login_status_code = 1 THEN 1 END) as successful_logins,
        COUNT(CASE WHEN login_status_code = 0 THEN 1 END) as failed_logins,
        COUNT(CASE WHEN login_status_code = 2 THEN 1 END) as logouts,
        COUNT(DISTINCT user_account_id) FILTER (WHERE user_account_id IS NOT NULL) as unique_users
      FROM audit_user_login
      WHERE login_attempt_date >= $1
    `;
        const summaryResult = await database_1.pool.query(summaryQuery, [startDate]);
        const summary = summaryResult.rows[0];
        // Get daily breakdown
        const dailyQuery = `
      SELECT 
        DATE(login_attempt_date) as date,
        COUNT(CASE WHEN login_status_code = 1 THEN 1 END) as success,
        COUNT(CASE WHEN login_status_code = 0 THEN 1 END) as failed,
        COUNT(CASE WHEN login_status_code = 2 THEN 1 END) as logout
      FROM audit_user_login
      WHERE login_attempt_date >= $1
      GROUP BY DATE(login_attempt_date)
      ORDER BY date DESC
    `;
        const dailyResult = await database_1.pool.query(dailyQuery, [startDate]);
        return {
            success: true,
            data: {
                successfulLogins: parseInt(summary.successful_logins) || 0,
                failedLogins: parseInt(summary.failed_logins) || 0,
                logouts: parseInt(summary.logouts) || 0,
                uniqueUsers: parseInt(summary.unique_users) || 0,
                byDay: dailyResult.rows.map(row => ({
                    date: row.date?.toISOString().split('T')[0],
                    success: parseInt(row.success) || 0,
                    failed: parseInt(row.failed) || 0,
                    logout: parseInt(row.logout) || 0
                }))
            }
        };
    }
    catch (error) {
        logger_1.logger.error('Login statistics error', { error: error.message });
        return {
            success: false,
            data: {
                successfulLogins: 0,
                failedLogins: 0,
                logouts: 0,
                uniqueUsers: 0,
                byDay: []
            }
        };
    }
};
exports.getLoginStatistics = getLoginStatistics;
exports.default = {
    getAuditTrail: exports.getAuditTrail,
    getSubjectAudit: exports.getSubjectAudit,
    getRecentAuditEvents: exports.getRecentAuditEvents,
    exportAuditTrailCSV: exports.exportAuditTrailCSV,
    getAuditStatistics: exports.getAuditStatistics,
    getAuditEventTypes: exports.getAuditEventTypes,
    getAuditableTables: exports.getAuditableTables,
    getFormAudit: exports.getFormAudit,
    getAuditSummary: exports.getAuditSummary,
    getComplianceReport: exports.getComplianceReport,
    // New functions for hybrid service
    recordAuditEvent: exports.recordAuditEvent,
    getAuditLogs: exports.getAuditLogs,
    getSubjectAuditTrail: exports.getSubjectAuditTrail,
    getFormAuditTrail: exports.getFormAuditTrail,
    recordElectronicSignature: exports.recordElectronicSignature,
    getAuditStats: exports.getAuditStats,
    exportAuditLogs: exports.exportAuditLogs,
    // User action tracking
    trackUserAction: exports.trackUserAction,
    trackDocumentAccess: exports.trackDocumentAccess,
    AuditEventTypes: exports.AuditEventTypes,
    // Login audit
    getLoginHistory: exports.getLoginHistory,
    getLoginStatistics: exports.getLoginStatistics
};
//# sourceMappingURL=audit.service.js.map