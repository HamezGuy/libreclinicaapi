/**
 * Query Routes
 *
 * 21 CFR Part 11 Compliance:
 * - Query creation requires electronic signature (§11.50)
 * - Query responses require electronic signature (§11.50)
 * - Query closure requires electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=query.routes.d.ts.map