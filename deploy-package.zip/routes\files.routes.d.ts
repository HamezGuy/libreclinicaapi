/**
 * File Upload Routes
 *
 * Handles file uploads for CRF fields (response_type = 4).
 * Files are stored locally or in cloud storage and referenced
 * in the crf_version_media table.
 *
 * Endpoints:
 * - POST /api/files - Upload a single file
 * - POST /api/files/batch - Upload multiple files
 * - GET /api/files/:id - Get file metadata
 * - GET /api/files/:id/download - Download file
 * - GET /api/files/:id/thumbnail - Get thumbnail (images only)
 * - GET /api/files/item/:itemId - Get files for a form item
 * - GET /api/files/crf-version/:crfVersionId - Get all files for a CRF version
 * - DELETE /api/files/:id - Delete a file
 *
 * 21 CFR Part 11 Compliant:
 * - Audit trail for uploads/deletions
 * - User authentication required
 * - File integrity verification
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=files.routes.d.ts.map