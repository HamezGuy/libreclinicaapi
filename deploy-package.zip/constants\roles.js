"use strict";
/**
 * LibreClinica Role Constants
 *
 * These role definitions match the LibreClinica Role.java constants exactly.
 * Roles are stored in study_user_role.role_name as strings.
 *
 * Source: org.akaza.openclinica.bean.core.Role
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.canSubmitData = exports.canManageStudy = exports.isAdmin = exports.roleHasPermission = exports.getHighestRole = exports.getRoleByName = exports.getRoleById = exports.ALL_ROLES = exports.STUDY_ROLE_MAP = exports.SITE_ROLE_MAP = exports.ROLES = void 0;
/**
 * LibreClinica role definitions
 * These match the Role.java constants exactly
 */
exports.ROLES = {
    INVALID: {
        id: 0,
        name: 'invalid',
        description: 'Invalid Role',
        canSubmitData: false,
        canExtractData: false,
        canManageStudy: false,
        canMonitor: false
    },
    ADMIN: {
        id: 1,
        name: 'admin',
        description: 'System_Administrator',
        canSubmitData: true,
        canExtractData: true,
        canManageStudy: true,
        canMonitor: true
    },
    COORDINATOR: {
        id: 2,
        name: 'coordinator',
        description: 'Study_Coordinator',
        canSubmitData: true,
        canExtractData: true,
        canManageStudy: true,
        canMonitor: false
    },
    STUDYDIRECTOR: {
        id: 3,
        name: 'director',
        description: 'Study_Director',
        canSubmitData: true,
        canExtractData: true,
        canManageStudy: true,
        canMonitor: false
    },
    INVESTIGATOR: {
        id: 4,
        name: 'Investigator',
        description: 'Investigator',
        canSubmitData: true,
        canExtractData: true,
        canManageStudy: false,
        canMonitor: false
    },
    RESEARCHASSISTANT: {
        id: 5,
        name: 'ra',
        description: 'Data_Entry_Person',
        canSubmitData: true,
        canExtractData: false,
        canManageStudy: false,
        canMonitor: false
    },
    MONITOR: {
        id: 6,
        name: 'monitor',
        description: 'Monitor',
        canSubmitData: false,
        canExtractData: false,
        canManageStudy: false,
        canMonitor: true
    },
    RESEARCHASSISTANT2: {
        id: 7,
        name: 'ra2',
        description: 'site_Data_Entry_Person2',
        canSubmitData: true,
        canExtractData: false,
        canManageStudy: false,
        canMonitor: false
    }
};
/**
 * Site-level role name mappings (used for sites/child studies)
 * Maps role ID to site-specific role name
 */
exports.SITE_ROLE_MAP = {
    2: 'site_Study_Coordinator',
    3: 'site_Study_Director',
    4: 'site_investigator',
    5: 'site_Data_Entry_Person',
    6: 'site_monitor',
    7: 'site_Data_Entry_Person2'
};
/**
 * Study-level role name mappings (used for parent studies)
 * Maps role ID to study-specific role name
 */
exports.STUDY_ROLE_MAP = {
    2: 'Study_Coordinator',
    3: 'Study_Director',
    4: 'Investigator',
    5: 'Data_Entry_Person',
    6: 'Monitor'
};
/**
 * All roles as array (excluding INVALID)
 */
exports.ALL_ROLES = [
    exports.ROLES.ADMIN,
    exports.ROLES.COORDINATOR,
    exports.ROLES.STUDYDIRECTOR,
    exports.ROLES.INVESTIGATOR,
    exports.ROLES.RESEARCHASSISTANT,
    exports.ROLES.MONITOR,
    exports.ROLES.RESEARCHASSISTANT2
];
/**
 * Get role by ID
 */
const getRoleById = (id) => {
    const role = exports.ALL_ROLES.find(r => r.id === id);
    return role || exports.ROLES.INVALID;
};
exports.getRoleById = getRoleById;
/**
 * Get role by name (matches role_name column in study_user_role)
 * Handles both study and site role names
 */
const getRoleByName = (name) => {
    // Normalize the name (lowercase for comparison)
    const normalizedName = name.toLowerCase().trim();
    // Direct match on role name
    for (const role of exports.ALL_ROLES) {
        if (role.name.toLowerCase() === normalizedName) {
            return role;
        }
    }
    // Match on description
    for (const role of exports.ALL_ROLES) {
        if (role.description.toLowerCase() === normalizedName) {
            return role;
        }
    }
    // Match site role names
    const siteRoleMappings = {
        'site_study_coordinator': exports.ROLES.COORDINATOR,
        'site_study_director': exports.ROLES.STUDYDIRECTOR,
        'site_investigator': exports.ROLES.INVESTIGATOR,
        'site_data_entry_person': exports.ROLES.RESEARCHASSISTANT,
        'site_monitor': exports.ROLES.MONITOR,
        'site_data_entry_person2': exports.ROLES.RESEARCHASSISTANT2
    };
    if (siteRoleMappings[normalizedName]) {
        return siteRoleMappings[normalizedName];
    }
    // Match study role names
    const studyRoleMappings = {
        'study_coordinator': exports.ROLES.COORDINATOR,
        'study_director': exports.ROLES.STUDYDIRECTOR,
        'investigator': exports.ROLES.INVESTIGATOR,
        'data_entry_person': exports.ROLES.RESEARCHASSISTANT,
        'monitor': exports.ROLES.MONITOR,
        'system_administrator': exports.ROLES.ADMIN
    };
    if (studyRoleMappings[normalizedName]) {
        return studyRoleMappings[normalizedName];
    }
    return exports.ROLES.INVALID;
};
exports.getRoleByName = getRoleByName;
/**
 * Get the highest privilege role from a list of role names
 * Lower ID = higher privilege (admin=1 is highest)
 */
const getHighestRole = (roleNames) => {
    let highestRole = exports.ROLES.INVALID;
    for (const name of roleNames) {
        const role = (0, exports.getRoleByName)(name);
        if (role.id !== 0 && (highestRole.id === 0 || role.id < highestRole.id)) {
            highestRole = role;
        }
    }
    return highestRole;
};
exports.getHighestRole = getHighestRole;
/**
 * Check if a role has a specific permission
 */
const roleHasPermission = (roleName, permission) => {
    const role = (0, exports.getRoleByName)(roleName);
    switch (permission) {
        case 'submitData':
            return role.canSubmitData;
        case 'extractData':
            return role.canExtractData;
        case 'manageStudy':
            return role.canManageStudy;
        case 'monitor':
            return role.canMonitor;
        default:
            return false;
    }
};
exports.roleHasPermission = roleHasPermission;
/**
 * Check if user is admin
 */
const isAdmin = (roleName) => {
    const role = (0, exports.getRoleByName)(roleName);
    return role.id === exports.ROLES.ADMIN.id;
};
exports.isAdmin = isAdmin;
/**
 * Check if user can manage studies (Coordinator, Director, or Admin)
 */
const canManageStudy = (roleName) => {
    const role = (0, exports.getRoleByName)(roleName);
    return role.canManageStudy;
};
exports.canManageStudy = canManageStudy;
/**
 * Check if user can submit data (most roles except monitor and invalid)
 */
const canSubmitData = (roleName) => {
    const role = (0, exports.getRoleByName)(roleName);
    return role.canSubmitData;
};
exports.canSubmitData = canSubmitData;
exports.default = {
    ROLES: exports.ROLES,
    ALL_ROLES: exports.ALL_ROLES,
    SITE_ROLE_MAP: exports.SITE_ROLE_MAP,
    STUDY_ROLE_MAP: exports.STUDY_ROLE_MAP,
    getRoleById: exports.getRoleById,
    getRoleByName: exports.getRoleByName,
    getHighestRole: exports.getHighestRole,
    roleHasPermission: exports.roleHasPermission,
    isAdmin: exports.isAdmin,
    canManageStudy: exports.canManageStudy,
    canSubmitData: exports.canSubmitData
};
//# sourceMappingURL=roles.js.map