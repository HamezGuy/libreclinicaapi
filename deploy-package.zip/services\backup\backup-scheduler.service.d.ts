/**
 * Backup Scheduler Service - 21 CFR Part 11 Compliant
 *
 * Implements automatic backup scheduling per SOP-008 7.3.1:
 * - Full Backup: Weekly (Sunday 2:00 AM) - Retention: 4 weeks
 * - Incremental Backup: Daily (2:00 AM) - Retention: 7 days
 * - Transaction Log Backup: Hourly - Retention: 24 hours
 *
 * Uses node-cron for scheduling with audit trail for all operations.
 */
import { BackupType } from './backup.service';
/**
 * Scheduler status
 */
interface SchedulerStatus {
    running: boolean;
    startedAt: Date | null;
    lastFullBackup: Date | null;
    lastIncrementalBackup: Date | null;
    lastTransactionLogBackup: Date | null;
    lastCleanup: Date | null;
    nextFullBackup: Date | null;
    nextIncrementalBackup: Date | null;
    errors: string[];
}
/**
 * Start backup scheduler
 *
 * @param fullBackupCron - Cron expression for full backups (default: Sunday 2 AM)
 * @param incrementalBackupCron - Cron expression for incremental backups (default: Mon-Sat 2 AM)
 * @param transactionLogCron - Cron expression for transaction log backups (default: every hour)
 */
export declare const startScheduler: (fullBackupCron?: string, incrementalBackupCron?: string, transactionLogCron?: string) => Promise<void>;
/**
 * Stop backup scheduler
 */
export declare const stopScheduler: () => Promise<void>;
/**
 * Get scheduler status
 */
export declare const getSchedulerStatus: () => SchedulerStatus;
/**
 * Trigger immediate backup (manual trigger)
 */
export declare const triggerImmediateBackup: (type: BackupType, userId: number, username: string) => Promise<{
    success: boolean;
    backupId?: string;
    message: string;
}>;
/**
 * Initialize scheduler on application startup if enabled
 */
export declare const initializeScheduler: () => Promise<void>;
declare const _default: {
    startScheduler: (fullBackupCron?: string, incrementalBackupCron?: string, transactionLogCron?: string) => Promise<void>;
    stopScheduler: () => Promise<void>;
    getSchedulerStatus: () => SchedulerStatus;
    triggerImmediateBackup: (type: BackupType, userId: number, username: string) => Promise<{
        success: boolean;
        backupId?: string;
        message: string;
    }>;
    initializeScheduler: () => Promise<void>;
};
export default _default;
//# sourceMappingURL=backup-scheduler.service.d.ts.map