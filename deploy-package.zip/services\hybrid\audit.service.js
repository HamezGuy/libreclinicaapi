"use strict";
/**
 * Hybrid Audit Service
 *
 * Combines SOAP and Database operations for audit trail management
 * 21 CFR Part 11 §11.10(e) - Audit Trail Compliance
 *
 * Strategy:
 * - SOAP: Used for recording audit events when LibreClinica is available
 *         Ensures native LibreClinica audit logging is maintained
 * - Database: Used for querying audit data and as fallback when SOAP unavailable
 *            Direct access is faster for reads
 *
 * This dual-mode approach ensures:
 * 1. Full audit trail is maintained in LibreClinica's native format
 * 2. Fast query access for dashboard and reporting
 * 3. System continues to work when SOAP is unavailable
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getServiceStatus = exports.getComplianceReport = exports.exportAuditLogs = exports.getAuditStats = exports.recordElectronicSignature = exports.getFormAuditTrail = exports.getSubjectAuditTrail = exports.getAuditLogs = exports.recordAuditEvent = void 0;
const environment_1 = require("../../config/environment");
const logger_1 = require("../../config/logger");
const auditSoap = __importStar(require("../soap/auditSoap.service"));
const auditDb = __importStar(require("../database/audit.service"));
/**
 * Record an audit event
 * Uses SOAP when available for GxP compliance, falls back to database
 */
const recordAuditEvent = async (record) => {
    logger_1.logger.info('Recording audit event (hybrid)', {
        auditTable: record.auditTable,
        entityId: record.entityId,
        eventTypeId: record.eventTypeId,
        soapEnabled: environment_1.config.libreclinica.soapEnabled
    });
    // Always record in database first (fast, reliable)
    const dbResult = await auditDb.recordAuditEvent({
        audit_table: record.auditTable,
        entity_id: record.entityId,
        user_id: record.userId,
        user_name: record.username,
        audit_log_event_type_id: record.eventTypeId,
        old_value: record.oldValue,
        new_value: record.newValue,
        reason_for_change: record.reasonForChange
    });
    // If SOAP is enabled, also record via SOAP for LibreClinica native audit
    if (environment_1.config.libreclinica.soapEnabled) {
        try {
            const soapRecord = {
                auditDate: new Date(),
                auditTable: record.auditTable,
                entityId: record.entityId,
                entityName: record.entityName,
                userId: record.userId,
                username: record.username,
                eventTypeId: record.eventTypeId,
                oldValue: record.oldValue,
                newValue: record.newValue,
                reasonForChange: record.reasonForChange
            };
            const soapResult = await auditSoap.recordAuditEvent(soapRecord, record.userId, record.username);
            if (!soapResult.success) {
                logger_1.logger.warn('SOAP audit recording failed, database record maintained', {
                    error: soapResult.message,
                    entityId: record.entityId
                });
            }
            else {
                logger_1.logger.info('Audit recorded via both SOAP and database', {
                    dbAuditId: dbResult.data?.audit_id,
                    soapAuditId: soapResult.data?.auditId
                });
            }
        }
        catch (error) {
            logger_1.logger.warn('SOAP audit recording error, database record maintained', {
                error: error.message,
                entityId: record.entityId
            });
        }
    }
    return {
        success: dbResult.success,
        data: { auditId: dbResult.data?.audit_id || 0 },
        message: dbResult.message
    };
};
exports.recordAuditEvent = recordAuditEvent;
/**
 * Get audit logs with filtering
 * Uses database for fast queries
 */
const getAuditLogs = async (params) => {
    logger_1.logger.info('Fetching audit logs (hybrid)', params);
    // Use database for queries (faster, more flexible)
    const result = await auditDb.getAuditLogs({
        studyId: params.studyId,
        userId: params.userId,
        eventType: params.eventType,
        startDate: params.startDate,
        endDate: params.endDate,
        limit: params.limit || 50,
        offset: params.offset || ((params.page || 1) - 1) * (params.limit || 50)
    });
    return result;
};
exports.getAuditLogs = getAuditLogs;
/**
 * Get subject audit trail
 * Tries SOAP first for complete ODM audit data, falls back to database
 */
const getSubjectAuditTrail = async (studyId, subjectId, userId, username) => {
    logger_1.logger.info('Fetching subject audit trail (hybrid)', {
        studyId,
        subjectId,
        soapEnabled: environment_1.config.libreclinica.soapEnabled
    });
    // Try SOAP first if enabled (gets complete ODM audit format)
    if (environment_1.config.libreclinica.soapEnabled) {
        try {
            const soapResult = await auditSoap.getSubjectAuditTrail(studyId, subjectId, userId, username);
            if (soapResult.success && soapResult.data && soapResult.data.length > 0) {
                logger_1.logger.info('Subject audit trail fetched via SOAP', {
                    subjectId,
                    recordCount: soapResult.data.length
                });
                return soapResult;
            }
        }
        catch (error) {
            logger_1.logger.warn('SOAP subject audit trail failed, falling back to database', {
                error: error.message,
                subjectId
            });
        }
    }
    // Fallback to database
    const dbResult = await auditDb.getSubjectAuditTrail(subjectId);
    return dbResult;
};
exports.getSubjectAuditTrail = getSubjectAuditTrail;
/**
 * Get form audit trail
 * Tries SOAP first, falls back to database
 */
const getFormAuditTrail = async (eventCrfId, userId, username) => {
    logger_1.logger.info('Fetching form audit trail (hybrid)', {
        eventCrfId,
        soapEnabled: environment_1.config.libreclinica.soapEnabled
    });
    // Try SOAP first if enabled
    if (environment_1.config.libreclinica.soapEnabled) {
        try {
            const soapResult = await auditSoap.getFormAuditTrail(eventCrfId, userId, username);
            if (soapResult.success && soapResult.data && soapResult.data.length > 0) {
                logger_1.logger.info('Form audit trail fetched via SOAP', {
                    eventCrfId,
                    recordCount: soapResult.data.length
                });
                return soapResult;
            }
        }
        catch (error) {
            logger_1.logger.warn('SOAP form audit trail failed, falling back to database', {
                error: error.message,
                eventCrfId
            });
        }
    }
    // Fallback to database
    const dbResult = await auditDb.getFormAuditTrail(eventCrfId);
    return dbResult;
};
exports.getFormAuditTrail = getFormAuditTrail;
/**
 * Record electronic signature
 * Must use SOAP for proper LibreClinica integration (falls back to database)
 */
const recordElectronicSignature = async (entityType, entityId, signature, userId, authenticatedUsername) => {
    logger_1.logger.info('Recording electronic signature (hybrid)', {
        entityType,
        entityId,
        signerUsername: signature.username,
        soapEnabled: environment_1.config.libreclinica.soapEnabled
    });
    // Try SOAP first if enabled (preferred for GxP compliance)
    if (environment_1.config.libreclinica.soapEnabled) {
        try {
            const soapResult = await auditSoap.recordElectronicSignature(entityType, entityId, signature, userId, authenticatedUsername);
            if (soapResult.success) {
                // Also record in database for backup
                await auditDb.recordElectronicSignature({
                    entity_type: entityType,
                    entity_id: entityId,
                    signer_username: signature.username,
                    meaning: signature.meaning,
                    reason_for_change: signature.reasonForChange,
                    signed_at: new Date()
                });
                logger_1.logger.info('Electronic signature recorded via SOAP and database', {
                    entityId,
                    signerUsername: signature.username
                });
                return soapResult;
            }
        }
        catch (error) {
            logger_1.logger.warn('SOAP signature failed, falling back to database', {
                error: error.message,
                entityId
            });
        }
    }
    // Fallback to database-only recording
    const dbResult = await auditDb.recordElectronicSignature({
        entity_type: entityType,
        entity_id: entityId,
        signer_username: signature.username,
        meaning: signature.meaning,
        reason_for_change: signature.reasonForChange,
        signed_at: new Date()
    });
    if (dbResult.success) {
        logger_1.logger.info('Electronic signature recorded via database (SOAP unavailable)', {
            entityId,
            signerUsername: signature.username
        });
    }
    return {
        success: dbResult.success,
        data: { signatureId: dbResult.data?.signature_id || entityId },
        message: dbResult.message
    };
};
exports.recordElectronicSignature = recordElectronicSignature;
/**
 * Get audit statistics
 * Uses database for aggregation queries
 */
const getAuditStats = async (days = 30) => {
    return auditDb.getAuditStats(days);
};
exports.getAuditStats = getAuditStats;
/**
 * Export audit logs
 * Uses database for complete data export
 */
const exportAuditLogs = async (params, format = 'csv') => {
    return auditDb.exportAuditLogs(params, format);
};
exports.exportAuditLogs = exportAuditLogs;
/**
 * Get compliance report
 * Uses database for report generation
 */
const getComplianceReport = async (studyId, startDate, endDate) => {
    return auditDb.getComplianceReport({
        studyId,
        startDate,
        endDate
    });
};
exports.getComplianceReport = getComplianceReport;
/**
 * Get SOAP/Database mode status
 */
const getServiceStatus = () => {
    const soapEnabled = environment_1.config.libreclinica.soapEnabled;
    return {
        soapEnabled,
        mode: soapEnabled ? 'soap_primary' : 'database_only',
        description: soapEnabled
            ? 'SOAP primary with database backup (GxP compliant mode)'
            : 'Database only mode (SOAP disabled)'
    };
};
exports.getServiceStatus = getServiceStatus;
exports.default = {
    recordAuditEvent: exports.recordAuditEvent,
    getAuditLogs: exports.getAuditLogs,
    getSubjectAuditTrail: exports.getSubjectAuditTrail,
    getFormAuditTrail: exports.getFormAuditTrail,
    recordElectronicSignature: exports.recordElectronicSignature,
    getAuditStats: exports.getAuditStats,
    exportAuditLogs: exports.exportAuditLogs,
    getComplianceReport: exports.getComplianceReport,
    getServiceStatus: exports.getServiceStatus
};
//# sourceMappingURL=audit.service.js.map