/**
 * LibreClinica Core Models
 *
 * These TypeScript interfaces match the actual LibreClinica Java Bean classes.
 * All frontend and API code should use these models for consistency.
 *
 * Source: LibreClinica\core\src\main\java\org\akaza\openclinica\bean\
 */
/**
 * Base entity that all LibreClinica entities extend
 * Matches AuditableEntityBean.java
 */
export interface AuditableEntity {
    id: number;
    name?: string;
    status: Status;
    statusId: number;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
    updateId?: number;
    active?: boolean;
}
/**
 * LibreClinica Status values
 * Matches bean/core/Status.java EXACTLY
 *
 * From Status.java:
 *   INVALID = 0, AVAILABLE = 1, UNAVAILABLE = 2, PRIVATE = 3, PENDING = 4,
 *   DELETED = 5, LOCKED = 6, AUTO_DELETED = 7, SIGNED = 8, FROZEN = 9,
 *   SOURCE_DATA_VERIFICATION = 10, RESET = 11
 */
export type Status = 'invalid' | 'available' | 'unavailable' | 'private' | 'pending' | 'removed' | 'locked' | 'auto-removed' | 'signed' | 'frozen' | 'source_data_verification' | 'reset';
export declare const STATUS_MAP: Record<number, Status>;
export declare function getStatusFromId(statusId: number): Status;
export declare function getStatusId(status: Status): number;
/**
 * User Account - matches UserAccountBean.java
 */
export interface UserAccount {
    userId: number;
    userName: string;
    firstName: string;
    lastName: string;
    email: string;
    institutionalAffiliation?: string;
    phone?: string;
    passwd?: string;
    passwdTimestamp?: Date | string;
    passwdChallengeQuestion?: string;
    passwdChallengeAnswer?: string;
    enabled: boolean;
    accountNonLocked: boolean;
    lockCounter?: number;
    lastVisitDate?: Date | string;
    sysAdmin: boolean;
    techAdmin: boolean;
    activeStudyId?: number;
    runWebservices?: boolean;
    enableApiKey?: boolean;
    apiKey?: string;
    accessCode?: string;
    authtype?: 'STANDARD' | 'MARKED' | 'TWO_FACTOR';
    authsecret?: string;
    timeZone?: string;
    statusId: number;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
    updateId?: number;
    notes?: string;
    roles?: StudyUserRole[];
}
/**
 * User Type - matches UserType.java
 */
export type UserType = 'USER' | 'SYSADMIN' | 'TECHADMIN';
/**
 * Study User Role - matches StudyUserRoleBean.java
 */
export interface StudyUserRole {
    userName: string;
    studyId: number;
    roleName: string;
    statusId: number;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
    updateId?: number;
}
/**
 * Role - matches Role.java
 */
export type Role = 'system_administrator' | 'investigator' | 'clinical_research_coordinator' | 'ra' | 'monitor' | 'study_director' | 'data_specialist' | 'data_entry_person' | 'guest';
/**
 * Maps database role names (as stored in study_user_role.role_name) to display names.
 * The Role type above uses canonical names, but the database may store shorter versions.
 */
export declare const ROLE_DISPLAY_MAP: Record<string, string>;
/**
 * Gets the display name for a role.
 * @param roleCode The role code from the database
 * @returns Human-readable role name
 */
export declare function getRoleDisplayName(roleCode: string): string;
/**
 * Study - matches StudyBean.java exactly
 */
export interface Study {
    studyId: number;
    parentStudyId?: number;
    parentStudyName?: string;
    name: string;
    officialTitle?: string;
    identifier: string;
    secondaryIdentifier?: string;
    oid?: string;
    summary?: string;
    protocolDescription?: string;
    datePlannedStart?: Date | string;
    datePlannedEnd?: Date | string;
    type: StudyType;
    protocolType?: string;
    phase?: string;
    expectedTotalEnrollment?: number;
    subjectCount?: number;
    sponsor?: string;
    collaborators?: string;
    principalInvestigator?: string;
    facilityName?: string;
    facilityCity?: string;
    facilityState?: string;
    facilityZip?: string;
    facilityCountry?: string;
    facilityRecruitmentStatus?: string;
    facilityContactName?: string;
    facilityContactDegree?: string;
    facilityContactPhone?: string;
    facilityContactEmail?: string;
    protocolDateVerification?: Date | string;
    medlineIdentifier?: string;
    resultsReference?: boolean;
    url?: string;
    urlDescription?: string;
    conditions?: string;
    keywords?: string;
    eligibility?: string;
    gender?: string;
    ageMin?: string;
    ageMax?: string;
    healthyVolunteerAccepted?: boolean;
    purpose?: string;
    allocation?: string;
    masking?: string;
    control?: string;
    assignment?: string;
    endpoint?: string;
    interventions?: string;
    duration?: string;
    selection?: string;
    timing?: string;
    studyParameterConfig?: StudyParameterConfig;
    mailNotification?: string;
    contactEmail?: string;
    statusId: number;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
    updateId?: number;
    genetic?: boolean;
    published?: boolean;
    schemaName?: string;
    envType?: string;
    studyEnvUuid?: string;
    studyEnvSiteUuid?: string;
    studyUuid?: string;
}
/**
 * Study Type - matches StudyType.java
 */
/**
 * Study Type - maps to study_type table
 * Database values: 1='genetic', 2='observational', 3='interventional', 4='other'
 * 'nongenetic' is a legacy alias for non-genetic studies
 */
export type StudyType = 'genetic' | 'nongenetic' | 'observational' | 'interventional' | 'other';
/**
 * Maps study_type_id to StudyType
 */
export declare const STUDY_TYPE_MAP: Record<number, StudyType>;
/**
 * Get study type from type_id
 */
export declare function getStudyType(typeId: number): StudyType;
/**
 * Study Parameter Config - matches StudyParameterConfig.java
 */
export interface StudyParameterConfig {
    collectDob?: string;
    discrepancyManagement?: boolean;
    genderRequired?: string;
    subjectPersonIdRequired?: string;
    subjectIdGeneration?: string;
    subjectIdPrefixSuffix?: string;
    personIdShownOnCrf?: string;
    secondaryLabelViewable?: boolean;
    eventLocationRequired?: boolean;
    studySubjectIdLabel?: string;
    secondaryIdLabel?: string;
    dateOfEnrollmentForStudyRequired?: string;
}
/**
 * Study Subject - matches StudySubjectBean.java
 * This is the primary "patient" model in LibreClinica
 */
export interface StudySubject {
    studySubjectId: number;
    label: string;
    secondaryLabel?: string;
    subjectId: number;
    studyId: number;
    enrollmentDate?: Date | string;
    oid?: string;
    statusId: number;
    status?: Status;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
    updateId?: number;
    uniqueIdentifier?: string;
    gender?: string;
    dateOfBirth?: Date | string;
    dobCollected?: boolean;
    studyName?: string;
    siteName?: string;
    eventStartDate?: Date | string;
    timeZone?: string;
    studyGroupMaps?: SubjectGroupMap[];
}
/**
 * Subject - matches SubjectBean.java
 * Base subject entity (demographics)
 */
export interface Subject {
    subjectId: number;
    uniqueIdentifier: string;
    dateOfBirth?: Date | string;
    gender: string;
    dobCollected: boolean;
    fatherId?: number;
    motherId?: number;
    statusId: number;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
    updateId?: number;
    label?: string;
    studyIdentifier?: string;
}
/**
 * Subject Group Map - matches SubjectGroupMapBean.java
 */
export interface SubjectGroupMap {
    id: number;
    studyGroupClassId: number;
    studyGroupId: number;
    studySubjectId: number;
    notes?: string;
    statusId: number;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
}
/**
 * Study Phase (Study Event Definition) - matches StudyEventDefinitionBean.java
 *
 * In LibreClinica, a "Study Event Definition" defines a phase/visit in the study protocol.
 * This is the TEMPLATE that defines what phases exist in a study.
 * When a patient is enrolled, study_event records are created based on these definitions.
 *
 * Database Table: study_event_definition
 */
export interface StudyPhase {
    studyEventDefinitionId: number;
    studyId: number;
    name: string;
    description?: string;
    category?: string;
    type: 'scheduled' | 'unscheduled' | 'common';
    ordinal: number;
    repeating: boolean;
    statusId: number;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
    updateId?: number;
    oid?: string;
    crfCount?: number;
    usageCount?: number;
    statusName?: string;
    assignedCrfs?: EventDefinitionCRF[];
}
/**
 * Convert database row (snake_case) to StudyPhase (camelCase)
 */
export declare function toStudyPhase(row: any): StudyPhase;
/**
 * Study Event - matches StudyEventBean.java
 *
 * An INSTANCE of a study phase for a specific subject.
 * Created when a patient is scheduled for a phase.
 *
 * Database Table: study_event
 */
export interface StudyEvent {
    studyEventId: number;
    studyEventDefinitionId: number;
    studySubjectId: number;
    location?: string;
    sampleOrdinal: number;
    dateStarted?: Date | string;
    dateEnded?: Date | string;
    startTimeFlag?: boolean;
    endTimeFlag?: boolean;
    subjectEventStatus: SubjectEventStatus;
    statusId: number;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
    updateId?: number;
    studyEventDefinition?: StudyEventDefinition;
    eventCRFs?: EventCRF[];
    studySubjectLabel?: string;
    scheduledDatePast?: boolean;
    repeatingNum?: number;
    editable?: boolean;
}
/**
 * Subject Event Status - matches SubjectEventStatus.java
 */
export type SubjectEventStatus = 'scheduled' | 'not_scheduled' | 'data_entry_started' | 'completed' | 'stopped' | 'skipped' | 'locked' | 'signed';
export declare const SUBJECT_EVENT_STATUS_MAP: Record<number, SubjectEventStatus>;
/**
 * Study Event Definition - matches StudyEventDefinitionBean.java
 * Template for study events
 */
export interface StudyEventDefinition {
    studyEventDefinitionId: number;
    studyId: number;
    name: string;
    description?: string;
    category?: string;
    type: string;
    ordinal: number;
    repeating: boolean;
    statusId: number;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
    updateId?: number;
    oid?: string;
    crfOrdinal?: number;
    eventDefinitionCRFs?: EventDefinitionCRF[];
}
/**
 * CRF - matches CRFBean.java
 * Case Report Form template
 */
/**
 * CRF - matches CRFBean.java
 * Case Report Form template
 *
 * NOTE: The studyId field maps to the 'source_study_id' column in the database,
 * which represents the study the CRF was originally created for. The database
 * also has a 'study_id' column which may be different or null.
 */
export interface CRF {
    crfId: number;
    studyId?: number;
    name: string;
    description?: string;
    oid?: string;
    statusId: number;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
    updateId?: number;
    versions?: CRFVersion[];
    selected?: boolean;
}
/**
 * CRF Version - matches CRFVersionBean.java
 */
export interface CRFVersion {
    crfVersionId: number;
    crfId: number;
    name: string;
    description?: string;
    revisionNotes?: string;
    oid?: string;
    statusId: number;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
    updateId?: number;
}
/**
 * Event Definition CRF - maps CRFs to event definitions
 */
export interface EventDefinitionCRF {
    eventDefinitionCrfId: number;
    studyEventDefinitionId: number;
    studyId: number;
    crfId: number;
    requiredCrf: boolean;
    doubleEntry: boolean;
    electronicSignature: boolean;
    hidecrF: boolean;
    evaluatedCrf: boolean;
    tabbingMode?: string;
    defaultVersionId?: number;
    defaultVersionName?: string;
    ordinal: number;
    sourceDataVerification?: number;
    statusId: number;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
    updateId?: number;
    crf?: CRF;
    versions?: CRFVersion[];
}
/**
 * Event CRF - matches EventCRFBean.java
 * An instance of a CRF for a study event
 */
export interface EventCRF {
    eventCrfId: number;
    studyEventId: number;
    crfVersionId: number;
    studySubjectId: number;
    dateInterviewed?: Date | string;
    interviewerName?: string;
    completionStatusId: number;
    validatorId?: number;
    dateValidate?: Date | string;
    dateValidateCompleted?: Date | string;
    validatorAnnotations?: string;
    validateString?: string;
    annotations?: string;
    dateCompleted?: Date | string;
    electronicSignatureStatus: boolean;
    sdvStatus: boolean;
    sdvUpdateId?: number;
    statusId: number;
    status?: Status;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
    updateId?: number;
    studySubjectName?: string;
    eventName?: string;
    studyName?: string;
    eventOrdinal?: number;
    crf?: CRF;
    crfVersion?: CRFVersion;
    stage?: DataEntryStage;
    studySubject?: StudySubject;
    studyEvent?: StudyEvent;
}
/**
 * Data Entry Stage - matches DataEntryStage.java EXACTLY
 *
 * From DataEntryStage.java:
 *   INVALID = 0, UNCOMPLETED = 1, INITIAL_DATA_ENTRY = 2,
 *   INITIAL_DATA_ENTRY_COMPLETE = 3, DOUBLE_DATA_ENTRY = 4,
 *   DOUBLE_DATA_ENTRY_COMPLETE = 5, ADMINISTRATIVE_EDITING = 6, LOCKED = 7
 */
export type DataEntryStage = 'invalid' | 'not_started' | 'initial_data_entry' | 'initial_data_entry_complete' | 'double_data_entry' | 'data_entry_complete' | 'administrative_editing' | 'locked';
export declare const DATA_ENTRY_STAGE_MAP: Record<number, DataEntryStage>;
/**
 * Completion Status - matches CompletionStatus.java and database completion_status table
 *
 * Database values (completion_status table):
 *   1 = 'not_started'
 *   2 = 'initial_data_entry'
 *   3 = 'data_entry_started'
 *   4 = 'complete'
 *   5 = 'signed'
 */
export type CompletionStatus = 'not_started' | 'initial_data_entry' | 'data_entry_started' | 'complete' | 'signed';
export declare const COMPLETION_STATUS_MAP: Record<number, CompletionStatus>;
export declare function getCompletionStatusFromId(completionStatusId: number): CompletionStatus;
export declare function getCompletionStatusId(status: CompletionStatus): number;
/**
 * Item Data - matches ItemDataBean.java
 * Individual field value in a CRF
 */
export interface ItemData {
    itemDataId: number;
    itemId: number;
    eventCrfId: number;
    value?: string;
    ordinal: number;
    deleted: boolean;
    oldStatusId?: number;
    statusId: number;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
    updateId?: number;
}
/**
 * Item - matches ItemBean.java
 * Field definition in a CRF
 */
export interface Item {
    itemId: number;
    name: string;
    description?: string;
    units?: string;
    phiStatus: boolean;
    itemDataTypeId: number;
    itemReferenceTypeId?: number;
    statusId: number;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
    updateId?: number;
    oid?: string;
}
/**
 * Discrepancy Note (Query) - matches DiscrepancyNoteBean.java
 */
export interface DiscrepancyNote {
    discrepancyNoteId: number;
    description: string;
    detailedNotes?: string;
    discrepancyNoteTypeId: number;
    resolutionStatusId: number;
    entityType: string;
    entityId?: number;
    columnName?: string;
    studyId: number;
    studySubjectId?: number;
    eventCrfId?: number;
    assignedUserId?: number;
    parentDnId?: number;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
}
export type DiscrepancyNoteType = 'Query' | 'Failed Validation Check' | 'Annotation' | 'Reason for Change';
export type ResolutionStatus = 'New' | 'Updated' | 'Resolved' | 'Closed' | 'Not Applicable';
/**
 * Study Group Class - matches StudyGroupClassBean.java
 * Defines a category of groups (e.g., "Treatment Arm", "Cohort", "Stratum")
 */
export interface StudyGroupClass {
    studyGroupClassId: number;
    studyId: number;
    name: string;
    groupClassTypeId: number;
    subjectAssignment?: string;
    statusId: number;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
    updateId?: number;
    groups?: StudyGroup[];
}
/**
 * Study Group - matches StudyGroupBean.java
 * An individual group within a class (e.g., "Placebo", "Drug A 10mg", "Drug A 20mg")
 */
export interface StudyGroup {
    studyGroupId: number;
    studyGroupClassId: number;
    name: string;
    description?: string;
    statusId: number;
    ownerId: number;
    dateCreated: Date | string;
    dateUpdated?: Date | string;
    updateId?: number;
    subjectCount?: number;
}
/**
 * Group Class Types - from LibreClinica
 */
export type GroupClassType = 'arm' | 'family' | 'dynamic' | 'subject_groups';
export declare const GROUP_CLASS_TYPE_MAP: Record<number, GroupClassType>;
/**
 * Audit Log Event - matches AuditLogEvent.java
 * Extended with computed/joined fields for complete audit trail display
 * 21 CFR Part 11 §11.10(e) - Complete Audit Trail
 */
export interface AuditLogEvent {
    auditId: number;
    auditDate: Date | string;
    userId: number;
    userName?: string;
    userFullName?: string;
    userEmail?: string;
    userRole?: string;
    auditTable: string;
    entityId?: number;
    entityName?: string;
    oldValue?: string;
    newValue?: string;
    eventTypeId: number;
    eventTypeName?: string;
    reasonForChange?: string;
    studyId?: number;
    studyName?: string;
    subjectId?: number;
    subjectLabel?: string;
    eventCrfId?: number;
    crfName?: string;
    studyEventId?: number;
    studyEventName?: string;
    itemId?: number;
    itemName?: string;
    itemDataRepeatKey?: number;
    sessionId?: string;
    ipAddress?: string;
    userAgent?: string;
    eventCategory?: 'data' | 'login' | 'query' | 'signature' | 'access' | 'system';
}
/**
 * Study Subject with full details (joined data)
 */
export interface StudySubjectWithDetails extends StudySubject {
    subject: Subject;
    study: Study;
    events: StudyEvent[];
    progress: SubjectProgress;
}
/**
 * Subject Progress statistics
 */
export interface SubjectProgress {
    totalEvents: number;
    completedEvents: number;
    eventCompletionPercentage?: number;
    totalForms: number;
    completedForms: number;
    formCompletionPercentage?: number;
    openQueries?: number;
    percentComplete: number;
}
/**
 * Paginated response
 */
export interface PaginatedResponse<T> {
    success: boolean;
    data: T[];
    pagination: {
        page: number;
        limit: number;
        total: number;
        totalPages: number;
    };
}
/**
 * API Response wrapper
 */
export interface ApiResponse<T = any> {
    success: boolean;
    data?: T;
    message?: string;
    errors?: string[];
}
/**
 * Convert database row (snake_case) to Subject (camelCase)
 */
export declare function toSubject(row: any): Subject;
/**
 * Convert database row (snake_case) to StudySubject (camelCase)
 */
export declare function toStudySubject(row: any): StudySubject;
/**
 * Convert database row (snake_case) to Study (camelCase)
 */
export declare function toStudy(row: any): Study;
/**
 * Convert database row (snake_case) to StudyEvent (camelCase)
 */
export declare function toStudyEvent(row: any): StudyEvent;
/**
 * Convert database row (snake_case) to EventCRF (camelCase)
 */
export declare function toEventCRF(row: any): EventCRF;
/**
 * Convert database row (snake_case) to CRF (camelCase)
 */
export declare function toCRF(row: any): CRF;
/**
 * Convert database row (snake_case) to UserAccount (camelCase)
 */
export declare function toUserAccount(row: any): UserAccount;
/**
 * Lock history entry for audit trail
 */
export interface LockHistory {
    id: string;
    lockId: string;
    action: 'locked' | 'unlocked';
    performedBy: string;
    performedByName: string;
    performedAt: Date;
    reason: string;
    ipAddress?: string;
}
/**
 * Unlock request for locked data
 */
export interface UnlockRequest {
    id: string;
    lockId: string;
    requestedBy: string;
    requestedByName: string;
    requestedAt: Date;
    reason: string;
    status: 'pending' | 'approved' | 'rejected';
    reviewedBy?: string;
    reviewedAt?: Date;
}
/**
 * Lock statistics summary
 */
export interface LockStatistics {
    totalLocks: number;
    lockedForms: number;
    lockedSubjects: number;
    pendingUnlockRequests: number;
}
/**
 * Conditional rule for form display logic
 */
export interface ConditionalRule {
    fieldId: string;
    operator: string;
    value: any;
}
/**
 * Form section (maps to ItemGroup display)
 */
export interface FormSection {
    id: string;
    name: string;
    description?: string;
    order: number;
}
/**
 * Form permissions for access control
 */
export interface FormPermissions {
    canView: boolean;
    canEdit: boolean;
    canCreate: boolean;
    canDelete: boolean;
    canPublish: boolean;
    canSign: boolean;
    canReview: boolean;
}
/**
 * Workflow types
 */
export type WorkflowType = 'form_review' | 'data_query' | 'electronic_signature' | 'study_event';
export type WorkflowStatus = 'pending' | 'in_progress' | 'completed' | 'cancelled';
export type WorkflowPriority = 'high' | 'medium' | 'low';
/**
 * Workflow task for task management
 */
export interface WorkflowTask {
    id: string;
    workflowId: string;
    title: string;
    description: string;
    type: WorkflowType;
    status: WorkflowStatus;
    priority: WorkflowPriority;
    assignedTo: string[];
    createdAt: Date;
    dueDate?: Date;
    completedAt?: Date;
    requiresSignature: boolean;
}
/**
 * User task summary for dashboard
 */
export interface UserTaskSummary {
    userId: string;
    userName: string;
    tasks: {
        overdue: WorkflowTask[];
        pending: WorkflowTask[];
        inProgress: WorkflowTask[];
    };
    statistics: {
        totalActive: number;
        completedToday: number;
        overdueCount: number;
    };
}
/**
 * Query response (child of DiscrepancyNote)
 */
export interface QueryResponse {
    id: string;
    respondedByName: string;
    respondedByRole: string;
    respondedAt: Date;
    responseText: string;
    attachments?: {
        fileName: string;
        fileUrl: string;
    }[];
}
/**
 * Phase transition rule for study workflow
 */
export interface PhaseTransitionRule {
    fromPhaseId: string;
    toPhaseId: string;
    condition?: string;
}
declare const _default: {
    STATUS_MAP: Record<number, Status>;
    SUBJECT_EVENT_STATUS_MAP: Record<number, SubjectEventStatus>;
    DATA_ENTRY_STAGE_MAP: Record<number, DataEntryStage>;
    COMPLETION_STATUS_MAP: Record<number, CompletionStatus>;
    getStatusFromId: typeof getStatusFromId;
    getStatusId: typeof getStatusId;
    getCompletionStatusFromId: typeof getCompletionStatusFromId;
    getCompletionStatusId: typeof getCompletionStatusId;
    toStudySubject: typeof toStudySubject;
    toStudy: typeof toStudy;
    toStudyEvent: typeof toStudyEvent;
    toStudyPhase: typeof toStudyPhase;
    toEventCRF: typeof toEventCRF;
    toCRF: typeof toCRF;
    toUserAccount: typeof toUserAccount;
};
export default _default;
//# sourceMappingURL=libreclinica-models.d.ts.map