"use strict";
/**
 * Randomization Routes
 *
 * 21 CFR Part 11 Compliance:
 * - Randomization requires electronic signature (§11.50)
 * - Unblinding requires electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const authorization_middleware_1 = require("../middleware/authorization.middleware");
const part11_middleware_1 = require("../middleware/part11.middleware");
const randomizationController = __importStar(require("../controllers/randomization.controller"));
const router = express_1.default.Router();
router.use(auth_middleware_1.authMiddleware);
// List and statistics (no signature required)
router.get('/', randomizationController.list);
router.get('/stats', randomizationController.getStats);
router.get('/groups/:studyId', randomizationController.getGroups);
router.get('/unblinding-events', randomizationController.getUnblindingEvents);
// Subject-specific (no signature required for reading)
router.get('/subject/:subjectId', randomizationController.getSubjectRandomization);
router.get('/subject/:subjectId/can-randomize', randomizationController.canRandomize);
// Actions (signature required)
router.post('/', (0, authorization_middleware_1.requireRole)('investigator', 'coordinator', 'admin'), (0, part11_middleware_1.requireSignatureFor)('I confirm this subject meets randomization criteria'), randomizationController.create);
router.delete('/subject/:subjectId', (0, authorization_middleware_1.requireRole)('admin'), (0, part11_middleware_1.requireSignatureFor)('I authorize removal of this randomization assignment'), randomizationController.remove);
router.post('/subject/:subjectId/unblind', (0, authorization_middleware_1.requireRole)('investigator', 'admin'), (0, part11_middleware_1.requireSignatureFor)('I authorize unblinding of treatment assignment for this subject'), randomizationController.unblind);
exports.default = router;
//# sourceMappingURL=randomization.routes.js.map