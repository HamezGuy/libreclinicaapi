/**
 * Email Worker
 *
 * Background worker that processes the email queue.
 * Should be run as a separate process or scheduled task.
 */
/**
 * Start the email worker
 */
export declare function startEmailWorker(): void;
/**
 * Stop the email worker
 */
export declare function stopEmailWorker(): void;
/**
 * Force process queue immediately (for testing/admin)
 */
export declare function forceProcessQueue(): Promise<{
    processed: number;
    sent: number;
    failed: number;
    errors: string[];
}>;
/**
 * Force send digest (for testing/admin)
 */
export declare function forceSendDigest(userId?: number): Promise<void>;
declare const _default: {
    startEmailWorker: typeof startEmailWorker;
    stopEmailWorker: typeof stopEmailWorker;
    forceProcessQueue: typeof forceProcessQueue;
    forceSendDigest: typeof forceSendDigest;
};
export default _default;
//# sourceMappingURL=email-worker.d.ts.map