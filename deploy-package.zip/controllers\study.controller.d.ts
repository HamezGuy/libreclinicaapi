/**
 * Study Controller
 *
 * Handles all study-related API endpoints including:
 * - CRUD operations for studies
 * - Study metadata, forms, sites, events
 * - Study statistics and enrollment data
 */
import { Request, Response } from 'express';
export declare const list: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const get: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getMetadata: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getForms: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const create: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const update: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const remove: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get study sites (child studies with parent_study_id = studyId)
 */
export declare const getSites: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get study events/phases (study_event_definition)
 */
export declare const getEvents: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get study statistics
 */
export declare const getStats: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get study users with roles
 */
export declare const getUsers: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    list: (req: Request, res: Response, next: import("express").NextFunction) => void;
    get: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getMetadata: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getForms: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getSites: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getEvents: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getStats: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getUsers: (req: Request, res: Response, next: import("express").NextFunction) => void;
    create: (req: Request, res: Response, next: import("express").NextFunction) => void;
    update: (req: Request, res: Response, next: import("express").NextFunction) => void;
    remove: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=study.controller.d.ts.map