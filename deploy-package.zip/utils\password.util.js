"use strict";
/**
 * Password Utility
 *
 * Password hashing, validation, and complexity checks
 * - MD5 hashing for LibreClinica legacy compatibility (SOAP WS-Security)
 * - bcrypt for new password storage (Part 11 compliant)
 * - Dual-authentication support for migration period
 * - Password complexity validation (21 CFR Part 11)
 * - Password expiration checking
 * - Account lockout management
 *
 * Compliance: 21 CFR Part 11 §11.300 - Password Controls
 *
 * MD5 LEGACY DOCUMENTATION:
 * -------------------------
 * LibreClinica's SOAP WS-Security requires MD5 password hashes.
 * This is a known limitation of the LibreClinica platform.
 *
 * Mitigation:
 * 1. All NEW passwords are stored with bcrypt (secure)
 * 2. MD5 hash is ONLY used for SOAP authentication to LibreClinica
 * 3. Passwords are never stored as plaintext
 * 4. Strong password policies compensate for MD5 weakness
 * 5. Account lockout prevents brute-force attacks
 *
 * Migration Path:
 * - When user logs in with MD5 password, upgrade to bcrypt
 * - Store bcrypt hash in extended user table
 * - Use bcrypt for API auth, MD5 only for SOAP proxy
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPasswordStrengthLabel = exports.calculatePasswordStrength = exports.sanitizePasswordForLog = exports.isLockoutExpired = exports.calculateLockoutDuration = exports.shouldLockAccount = exports.generateRandomPassword = exports.isPasswordPreviouslyUsed = exports.getDaysUntilPasswordExpires = exports.isPasswordExpired = exports.validatePassword = exports.verifyAndUpgrade = exports.hashPasswordDual = exports.upgradePasswordHash = exports.comparePasswordAny = exports.detectHashType = exports.comparePasswordBcrypt = exports.comparePasswordMD5 = exports.hashPasswordBcrypt = exports.hashPasswordMD5 = exports.PasswordHashType = void 0;
const crypto_1 = __importDefault(require("crypto"));
const bcrypt_1 = __importDefault(require("bcrypt"));
const environment_1 = require("../config/environment");
const logger_1 = require("../config/logger");
/**
 * Password hash type identifier
 */
var PasswordHashType;
(function (PasswordHashType) {
    PasswordHashType["MD5"] = "md5";
    PasswordHashType["BCRYPT"] = "bcrypt";
    PasswordHashType["UNKNOWN"] = "unknown";
})(PasswordHashType || (exports.PasswordHashType = PasswordHashType = {}));
/**
 * Default password policy - 8 chars + 1 special character
 */
const DEFAULT_POLICY = {
    minLength: environment_1.config.part11.passwordMinLength || 8,
    requireUppercase: false,
    requireLowercase: false,
    requireNumber: false,
    requireSpecialChar: true, // Require at least 1 special character
    expirationDays: environment_1.config.part11.passwordExpiryDays || 365,
    preventReuse: 0
};
/**
 * Hash password using MD5 (LibreClinica compatibility)
 * LibreClinica uses MD5 for password storage
 *
 * Note: MD5 is not recommended for new systems, but we need
 * compatibility with existing LibreClinica authentication
 */
const hashPasswordMD5 = (password) => {
    const hash = crypto_1.default.createHash('md5');
    hash.update(password);
    return hash.digest('hex');
};
exports.hashPasswordMD5 = hashPasswordMD5;
/**
 * Hash password using bcrypt (for new/extended features)
 * More secure than MD5, use for additional API security
 */
const hashPasswordBcrypt = async (password) => {
    const saltRounds = 10;
    const hash = await bcrypt_1.default.hash(password, saltRounds);
    return hash;
};
exports.hashPasswordBcrypt = hashPasswordBcrypt;
/**
 * Compare password with MD5 hash
 * For LibreClinica authentication
 */
const comparePasswordMD5 = (password, hash) => {
    const passwordHash = (0, exports.hashPasswordMD5)(password);
    return passwordHash === hash;
};
exports.comparePasswordMD5 = comparePasswordMD5;
/**
 * Compare password with bcrypt hash
 * For additional API authentication
 */
const comparePasswordBcrypt = async (password, hash) => {
    try {
        return await bcrypt_1.default.compare(password, hash);
    }
    catch (error) {
        logger_1.logger.error('Password comparison error', { error: error.message });
        return false;
    }
};
exports.comparePasswordBcrypt = comparePasswordBcrypt;
/**
 * Detect the hash type from a stored password hash
 */
const detectHashType = (hash) => {
    if (!hash)
        return PasswordHashType.UNKNOWN;
    // bcrypt hashes start with $2a$, $2b$, or $2y$ and are 60 chars
    if (hash.match(/^\$2[aby]\$\d{2}\$.{53}$/)) {
        return PasswordHashType.BCRYPT;
    }
    // MD5 hashes are 32 hex characters
    if (hash.match(/^[a-f0-9]{32}$/i)) {
        return PasswordHashType.MD5;
    }
    return PasswordHashType.UNKNOWN;
};
exports.detectHashType = detectHashType;
/**
 * Compare password with any hash type (auto-detect)
 * Supports both MD5 (legacy) and bcrypt (secure)
 */
const comparePasswordAny = async (password, hash) => {
    const hashType = (0, exports.detectHashType)(hash);
    switch (hashType) {
        case PasswordHashType.BCRYPT:
            const bcryptValid = await (0, exports.comparePasswordBcrypt)(password, hash);
            return { valid: bcryptValid, hashType, needsUpgrade: false };
        case PasswordHashType.MD5:
            const md5Valid = (0, exports.comparePasswordMD5)(password, hash);
            // MD5 passwords should be upgraded to bcrypt
            return { valid: md5Valid, hashType, needsUpgrade: md5Valid };
        default:
            logger_1.logger.warn('Unknown password hash type', { hashLength: hash?.length });
            return { valid: false, hashType, needsUpgrade: false };
    }
};
exports.comparePasswordAny = comparePasswordAny;
/**
 * Upgrade a password from MD5 to bcrypt
 * Call this after successful MD5 authentication
 *
 * @returns Object with both hashes (MD5 for SOAP, bcrypt for API)
 */
const upgradePasswordHash = async (password) => {
    const md5Hash = (0, exports.hashPasswordMD5)(password);
    const bcryptHash = await (0, exports.hashPasswordBcrypt)(password);
    logger_1.logger.info('Password hash upgraded from MD5 to bcrypt');
    return { md5Hash, bcryptHash };
};
exports.upgradePasswordHash = upgradePasswordHash;
/**
 * Hash password for dual storage (both MD5 and bcrypt)
 * - MD5 hash is used ONLY for LibreClinica SOAP authentication
 * - bcrypt hash is used for API authentication
 *
 * @returns Object with both hashes
 */
const hashPasswordDual = async (password) => {
    const [bcryptHash] = await Promise.all([
        (0, exports.hashPasswordBcrypt)(password)
    ]);
    return {
        md5Hash: (0, exports.hashPasswordMD5)(password), // For SOAP WS-Security only
        bcryptHash // For secure API authentication
    };
};
exports.hashPasswordDual = hashPasswordDual;
/**
 * Verify password and return both hash types for storage upgrade
 * Use this during login to transparently upgrade MD5 to bcrypt
 */
const verifyAndUpgrade = async (password, storedHash, storedBcryptHash) => {
    // If we have a bcrypt hash, verify against it (preferred)
    if (storedBcryptHash) {
        const bcryptValid = await (0, exports.comparePasswordBcrypt)(password, storedBcryptHash);
        return { valid: bcryptValid, shouldUpdateDatabase: false };
    }
    // Fall back to MD5 verification
    const hashType = (0, exports.detectHashType)(storedHash);
    if (hashType === PasswordHashType.MD5) {
        const md5Valid = (0, exports.comparePasswordMD5)(password, storedHash);
        if (md5Valid) {
            // Password is correct - upgrade to bcrypt
            const bcryptHash = await (0, exports.hashPasswordBcrypt)(password);
            logger_1.logger.info('Password verified via MD5, upgrading to bcrypt');
            return {
                valid: true,
                upgradedBcryptHash: bcryptHash,
                shouldUpdateDatabase: true
            };
        }
        return { valid: false, shouldUpdateDatabase: false };
    }
    if (hashType === PasswordHashType.BCRYPT) {
        const bcryptValid = await (0, exports.comparePasswordBcrypt)(password, storedHash);
        return { valid: bcryptValid, shouldUpdateDatabase: false };
    }
    return { valid: false, shouldUpdateDatabase: false };
};
exports.verifyAndUpgrade = verifyAndUpgrade;
/**
 * Validate password against policy
 * Returns validation result with specific error messages
 * SIMPLIFIED - Only basic length check by default
 */
const validatePassword = (password, policy = DEFAULT_POLICY) => {
    const errors = [];
    // Check minimum length only
    if (password.length < policy.minLength) {
        errors.push(`Password must be at least ${policy.minLength} characters long`);
    }
    // Optional checks - only if enabled in policy
    if (policy.requireUppercase && !/[A-Z]/.test(password)) {
        errors.push('Password must contain at least one uppercase letter');
    }
    if (policy.requireLowercase && !/[a-z]/.test(password)) {
        errors.push('Password must contain at least one lowercase letter');
    }
    if (policy.requireNumber && !/\d/.test(password)) {
        errors.push('Password must contain at least one number');
    }
    if (policy.requireSpecialChar && !/[@$!%*?&#^()_+=\-]/.test(password)) {
        errors.push('Password must contain at least one special character');
    }
    return {
        isValid: errors.length === 0,
        errors
    };
};
exports.validatePassword = validatePassword;
/**
 * Check if password is expired
 * Based on password change date and policy expiration days
 */
const isPasswordExpired = (passwordChangedDate, policy = DEFAULT_POLICY) => {
    const now = new Date();
    const expirationDate = new Date(passwordChangedDate);
    expirationDate.setDate(expirationDate.getDate() + policy.expirationDays);
    return now > expirationDate;
};
exports.isPasswordExpired = isPasswordExpired;
/**
 * Get days until password expires
 */
const getDaysUntilPasswordExpires = (passwordChangedDate, policy = DEFAULT_POLICY) => {
    const now = new Date();
    const expirationDate = new Date(passwordChangedDate);
    expirationDate.setDate(expirationDate.getDate() + policy.expirationDays);
    const diffTime = expirationDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
};
exports.getDaysUntilPasswordExpires = getDaysUntilPasswordExpires;
/**
 * Check if password was previously used
 * Prevents password reuse
 */
const isPasswordPreviouslyUsed = (password, previousPasswordHashes) => {
    const passwordHash = (0, exports.hashPasswordMD5)(password);
    return previousPasswordHashes.includes(passwordHash);
};
exports.isPasswordPreviouslyUsed = isPasswordPreviouslyUsed;
/**
 * Generate random password
 * Useful for temporary passwords or password reset
 */
const generateRandomPassword = (length = 16, includeSpecialChars = true) => {
    const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lowercase = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';
    const specialChars = '@$!%*?&';
    let charset = uppercase + lowercase + numbers;
    if (includeSpecialChars) {
        charset += specialChars;
    }
    let password = '';
    // Ensure at least one character from each required set
    password += uppercase.charAt(Math.floor(Math.random() * uppercase.length));
    password += lowercase.charAt(Math.floor(Math.random() * lowercase.length));
    password += numbers.charAt(Math.floor(Math.random() * numbers.length));
    if (includeSpecialChars) {
        password += specialChars.charAt(Math.floor(Math.random() * specialChars.length));
    }
    // Fill remaining length with random characters
    for (let i = password.length; i < length; i++) {
        password += charset.charAt(Math.floor(Math.random() * charset.length));
    }
    // Shuffle the password
    password = password.split('').sort(() => Math.random() - 0.5).join('');
    return password;
};
exports.generateRandomPassword = generateRandomPassword;
/**
 * Check account lockout status
 * Returns true if account should be locked due to failed login attempts
 */
const shouldLockAccount = (failedAttempts, maxAttempts = environment_1.config.part11.maxLoginAttempts || 5) => {
    return failedAttempts >= maxAttempts;
};
exports.shouldLockAccount = shouldLockAccount;
/**
 * Calculate lockout duration
 * Returns lockout duration in minutes based on failed attempts
 */
const calculateLockoutDuration = (failedAttempts) => {
    // Progressive lockout: 15, 30, 60, 120 minutes
    if (failedAttempts <= 5)
        return 15;
    if (failedAttempts <= 10)
        return 30;
    if (failedAttempts <= 15)
        return 60;
    return 120; // 2 hours for repeated attempts
};
exports.calculateLockoutDuration = calculateLockoutDuration;
/**
 * Check if account lockout has expired
 */
const isLockoutExpired = (lockoutUntil) => {
    if (!lockoutUntil)
        return true;
    return new Date() > new Date(lockoutUntil);
};
exports.isLockoutExpired = isLockoutExpired;
/**
 * Sanitize password for logging
 * Never log actual passwords
 */
const sanitizePasswordForLog = (password) => {
    return '***REDACTED***';
};
exports.sanitizePasswordForLog = sanitizePasswordForLog;
/**
 * Calculate password strength
 * Returns score from 0 (weak) to 100 (strong)
 */
const calculatePasswordStrength = (password) => {
    let score = 0;
    // Length score (up to 30 points)
    score += Math.min(password.length * 2, 30);
    // Character variety (up to 40 points)
    if (/[a-z]/.test(password))
        score += 10;
    if (/[A-Z]/.test(password))
        score += 10;
    if (/\d/.test(password))
        score += 10;
    if (/[@$!%*?&]/.test(password))
        score += 10;
    // Additional complexity (up to 30 points)
    const uniqueChars = new Set(password).size;
    score += Math.min(uniqueChars, 15);
    // Penalty for patterns
    if (/(.)\1{2,}/.test(password))
        score -= 10;
    if (/(?:123|abc|qwe)/i.test(password))
        score -= 10;
    return Math.max(0, Math.min(100, score));
};
exports.calculatePasswordStrength = calculatePasswordStrength;
/**
 * Get password strength label
 */
const getPasswordStrengthLabel = (score) => {
    if (score < 30)
        return 'Weak';
    if (score < 60)
        return 'Fair';
    if (score < 80)
        return 'Good';
    return 'Strong';
};
exports.getPasswordStrengthLabel = getPasswordStrengthLabel;
exports.default = {
    // Hash type detection
    PasswordHashType,
    detectHashType: exports.detectHashType,
    // Legacy MD5 (for LibreClinica SOAP only)
    hashPasswordMD5: exports.hashPasswordMD5,
    comparePasswordMD5: exports.comparePasswordMD5,
    // Secure bcrypt (for API authentication)
    hashPasswordBcrypt: exports.hashPasswordBcrypt,
    comparePasswordBcrypt: exports.comparePasswordBcrypt,
    // Dual authentication (MD5 + bcrypt)
    comparePasswordAny: exports.comparePasswordAny,
    hashPasswordDual: exports.hashPasswordDual,
    upgradePasswordHash: exports.upgradePasswordHash,
    verifyAndUpgrade: exports.verifyAndUpgrade,
    // Validation and policy
    validatePassword: exports.validatePassword,
    isPasswordExpired: exports.isPasswordExpired,
    getDaysUntilPasswordExpires: exports.getDaysUntilPasswordExpires,
    isPasswordPreviouslyUsed: exports.isPasswordPreviouslyUsed,
    generateRandomPassword: exports.generateRandomPassword,
    // Account lockout
    shouldLockAccount: exports.shouldLockAccount,
    calculateLockoutDuration: exports.calculateLockoutDuration,
    isLockoutExpired: exports.isLockoutExpired,
    // Strength checking
    calculatePasswordStrength: exports.calculatePasswordStrength,
    getPasswordStrengthLabel: exports.getPasswordStrengthLabel
};
//# sourceMappingURL=password.util.js.map