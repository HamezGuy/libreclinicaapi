/**
 * Audit Controller
 */
import { Request, Response } from 'express';
export declare const get: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const exportCsv: (req: Request, res: Response, next: import("express").NextFunction) => void;
export declare const getSubjectAudit: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get audit event types
 */
export declare const getEventTypes: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get auditable tables list
 */
export declare const getTables: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get audit statistics
 */
export declare const getStats: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get form audit trail
 */
export declare const getFormAudit: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get audit summary by date range
 */
export declare const getSummary: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get compliance report
 */
export declare const getComplianceReport: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get recent audit events
 */
export declare const getRecent: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get login history
 * Returns login/logout/failed login events from audit_user_login
 *
 * 21 CFR Part 11 §11.10(e) - Audit Trail for login events
 */
export declare const getLoginHistory: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get login statistics
 * Returns login/logout/failed counts and daily breakdown
 */
export declare const getLoginStats: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    get: (req: Request, res: Response, next: import("express").NextFunction) => void;
    exportCsv: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getSubjectAudit: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getEventTypes: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getTables: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getStats: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getFormAudit: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getSummary: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getComplianceReport: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getRecent: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getLoginHistory: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getLoginStats: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=audit.controller.d.ts.map