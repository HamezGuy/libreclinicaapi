/**
 * Report Service
 *
 * Generates reports for regulatory compliance
 * RED X Feature: Reports API
 *
 * Formats: CSV, PDF (future: Excel)
 */
/**
 * Generate enrollment report
 */
export declare const generateEnrollmentReport: (studyId: number, startDate: Date, endDate: Date, format?: "csv" | "pdf") => Promise<string>;
/**
 * Generate data completion report
 */
export declare const generateCompletionReport: (studyId: number, format?: "csv" | "pdf") => Promise<string>;
/**
 * Generate query/discrepancy report
 * Note: discrepancy_note does NOT have study_subject_id column
 * Subject info is linked through mapping tables (dn_study_subject_map, etc.)
 */
export declare const generateQueryReport: (studyId: number, format?: "csv" | "pdf") => Promise<string>;
declare const _default: {
    generateEnrollmentReport: (studyId: number, startDate: Date, endDate: Date, format?: "csv" | "pdf") => Promise<string>;
    generateCompletionReport: (studyId: number, format?: "csv" | "pdf") => Promise<string>;
    generateQueryReport: (studyId: number, format?: "csv" | "pdf") => Promise<string>;
};
export default _default;
//# sourceMappingURL=report.service.d.ts.map