"use strict";
/**
 * User Routes
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const controller = __importStar(require("../controllers/user.controller"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const authorization_middleware_1 = require("../middleware/authorization.middleware");
const validation_middleware_1 = require("../middleware/validation.middleware");
const rateLimiter_middleware_1 = require("../middleware/rateLimiter.middleware");
const router = express_1.default.Router();
router.use(auth_middleware_1.authMiddleware);
router.use((0, authorization_middleware_1.requireRole)('admin', 'coordinator'));
// User CRUD
router.get('/', (0, validation_middleware_1.validate)({ query: validation_middleware_1.userSchemas.list }), controller.list);
router.get('/:id', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.get);
router.post('/', rateLimiter_middleware_1.userCreationRateLimiter, (0, validation_middleware_1.validate)({ body: validation_middleware_1.userSchemas.create }), controller.create);
router.put('/:id', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam, body: validation_middleware_1.userSchemas.update }), controller.update);
router.delete('/:id', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.remove);
// Role management
router.get('/meta/roles', controller.getRoles);
router.post('/:id/assign-study', (0, validation_middleware_1.validate)({ params: validation_middleware_1.commonSchemas.idParam }), controller.assignToStudy);
router.get('/:id/role/:studyId', controller.getUserRole);
exports.default = router;
//# sourceMappingURL=user.routes.js.map