import { Request, Response, NextFunction } from 'express';
/**
 * Role-based authorization middleware (21 CFR Part 11 §11.10(g))
 * Checks user permissions for the requested operation
 *
 * LibreClinica User Types:
 * - user_type_id 1: business_admin (has all privileges)
 * - user_type_id 2: tech-admin (has technical privileges)
 * - user_type_id 3: user (standard user)
 */
export declare const requireRole: (...allowedRoles: string[]) => (req: Request, res: Response, next: NextFunction) => Promise<void>;
/**
 * Check if user has access to specific study
 */
export declare const requireStudyAccess: (studyIdParam?: string) => (req: Request, res: Response, next: NextFunction) => Promise<void>;
//# sourceMappingURL=authorization.middleware.d.ts.map