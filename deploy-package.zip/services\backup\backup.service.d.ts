/**
 * Backup Service - 21 CFR Part 11 Compliant
 *
 * SIMPLE, WORKING database backup using Docker PostgreSQL
 *
 * This service runs pg_dump INSIDE the Docker container where PostgreSQL
 * tools are guaranteed to be available.
 */
import { ApiResponse } from '../../types';
export declare enum BackupType {
    FULL = "full",
    INCREMENTAL = "incremental",
    TRANSACTION_LOG = "transaction_log"
}
export declare enum BackupStatus {
    PENDING = "pending",
    IN_PROGRESS = "in_progress",
    COMPLETED = "completed",
    FAILED = "failed",
    VERIFIED = "verified"
}
export interface BackupConfig {
    backupDir: string;
    containerName: string;
    retentionDays: {
        full: number;
        incremental: number;
        transactionLog: number;
    };
    schedules: {
        full: string;
        incremental: string;
        transactionLog: string;
    };
}
export interface BackupRecord {
    backupId: string;
    backupType: BackupType;
    backupDateTime: Date;
    backupSize: number;
    backupDuration: number;
    backupLocation: string;
    checksum: string;
    checksumAlgorithm: string;
    verificationStatus: BackupStatus;
    retentionUntil: Date;
    databaseName: string;
    databaseHost: string;
    userId?: number;
    username?: string;
    error?: string;
}
export declare const getBackupConfig: () => BackupConfig;
/**
 * Perform backup using pg_dump INSIDE Docker container
 */
export declare const performBackup: (type: BackupType, userId?: number, username?: string) => Promise<ApiResponse<BackupRecord>>;
export declare const listBackups: (type?: BackupType, limit?: number) => Promise<ApiResponse<BackupRecord[]>>;
export declare const getBackup: (backupId: string) => Promise<ApiResponse<BackupRecord>>;
export declare const verifyBackup: (backupId: string, userId: number, username: string) => Promise<ApiResponse<{
    verified: boolean;
    checksum: string;
}>>;
export declare const cleanupOldBackups: (userId?: number, username?: string) => Promise<ApiResponse<{
    deleted: number;
    freed: number;
}>>;
export declare const getBackupStats: () => Promise<ApiResponse<any>>;
export declare const restoreBackup: (backupId: string, userId: number, username: string) => Promise<ApiResponse<any>>;
declare const _default: {
    performBackup: (type: BackupType, userId?: number, username?: string) => Promise<ApiResponse<BackupRecord>>;
    listBackups: (type?: BackupType, limit?: number) => Promise<ApiResponse<BackupRecord[]>>;
    getBackup: (backupId: string) => Promise<ApiResponse<BackupRecord>>;
    verifyBackup: (backupId: string, userId: number, username: string) => Promise<ApiResponse<{
        verified: boolean;
        checksum: string;
    }>>;
    cleanupOldBackups: (userId?: number, username?: string) => Promise<ApiResponse<{
        deleted: number;
        freed: number;
    }>>;
    getBackupStats: () => Promise<ApiResponse<any>>;
    restoreBackup: (backupId: string, userId: number, username: string) => Promise<ApiResponse<any>>;
    getBackupConfig: () => BackupConfig;
    BackupType: typeof BackupType;
    BackupStatus: typeof BackupStatus;
};
export default _default;
//# sourceMappingURL=backup.service.d.ts.map