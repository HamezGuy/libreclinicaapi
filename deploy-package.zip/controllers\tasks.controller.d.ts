/**
 * Tasks Controller
 *
 * Handles API requests for the unified task system.
 * Aggregates work items from multiple LibreClinica tables:
 * - discrepancy_note (queries)
 * - study_event (scheduled visits)
 * - event_crf (forms, SDV, signatures)
 */
import { Request, Response } from 'express';
/**
 * Get tasks for current user
 * GET /api/tasks
 */
export declare const getTasks: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get tasks for specific user
 * GET /api/tasks/user/:username
 */
export declare const getUserTasks: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get task summary for current user
 * GET /api/tasks/summary
 */
export declare const getTaskSummary: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get task summary for specific user
 * GET /api/tasks/user/:username/summary
 */
export declare const getUserTaskSummary: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get single task by ID
 * GET /api/tasks/:taskId
 */
export declare const getTask: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get tasks by type
 * GET /api/tasks/type/:type
 */
export declare const getTasksByType: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get overdue tasks
 * GET /api/tasks/overdue
 */
export declare const getOverdueTasks: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    getTasks: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getUserTasks: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getTaskSummary: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getUserTaskSummary: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getTask: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getTasksByType: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getOverdueTasks: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=tasks.controller.d.ts.map