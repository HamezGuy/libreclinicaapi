"use strict";
/**
 * SDV (Source Data Verification) Controller
 *
 * Handles SDV operations for LibreClinica:
 * - List SDV records with filtering
 * - Get individual SDV record details
 * - Get form data for SDV preview
 * - Verify/Unverify operations with audit trail
 * - Bulk verification
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.unverify = exports.getByVisit = exports.getStats = exports.getSubjectStatus = exports.bulkVerify = exports.verify = exports.getFormData = exports.get = exports.list = void 0;
const errorHandler_middleware_1 = require("../middleware/errorHandler.middleware");
const sdvService = __importStar(require("../services/database/sdv.service"));
exports.list = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId, subjectId, status, page, limit } = req.query;
    const result = await sdvService.getSDVRecords({
        studyId: studyId ? parseInt(studyId) : undefined,
        subjectId: subjectId ? parseInt(subjectId) : undefined,
        status: status,
        page: parseInt(page) || 1,
        limit: parseInt(limit) || 20
    });
    res.json(result);
});
exports.get = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const result = await sdvService.getSDVById(parseInt(id));
    if (!result) {
        res.status(404).json({ success: false, message: 'SDV record not found' });
        return;
    }
    res.json({ success: true, data: result });
});
/**
 * Get form data for SDV preview
 * Returns all item_data for the specified event_crf
 */
exports.getFormData = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { id } = req.params;
    const result = await sdvService.getSDVFormData(parseInt(id));
    res.json(result);
});
exports.verify = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { id } = req.params;
    const result = await sdvService.verifySDV(parseInt(id), user.userId);
    res.json(result);
});
/**
 * Bulk verify multiple SDV records
 */
exports.bulkVerify = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { eventCrfIds } = req.body;
    if (!eventCrfIds || !Array.isArray(eventCrfIds)) {
        res.status(400).json({ success: false, message: 'eventCrfIds array is required' });
        return;
    }
    const result = await sdvService.bulkVerifySDV(eventCrfIds, user.userId);
    res.json(result);
});
/**
 * Get SDV status for a subject
 */
exports.getSubjectStatus = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { subjectId } = req.params;
    const result = await sdvService.getSubjectSDVStatus(parseInt(subjectId));
    res.json(result);
});
/**
 * Get SDV statistics for a study
 */
exports.getStats = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.query;
    if (!studyId) {
        res.status(400).json({ success: false, message: 'studyId is required' });
        return;
    }
    const result = await sdvService.getSDVStats(parseInt(studyId));
    res.json(result);
});
/**
 * Get SDV by visit/event
 */
exports.getByVisit = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const { studyId } = req.query;
    if (!studyId) {
        res.status(400).json({ success: false, message: 'studyId is required' });
        return;
    }
    const result = await sdvService.getSDVByVisit(parseInt(studyId));
    res.json(result);
});
/**
 * Unverify SDV record
 */
exports.unverify = (0, errorHandler_middleware_1.asyncHandler)(async (req, res) => {
    const user = req.user;
    const { id } = req.params;
    const result = await sdvService.unverifySDV(parseInt(id), user.userId);
    res.json(result);
});
exports.default = { list: exports.list, get: exports.get, verify: exports.verify, bulkVerify: exports.bulkVerify, getSubjectStatus: exports.getSubjectStatus, getStats: exports.getStats, getByVisit: exports.getByVisit, unverify: exports.unverify };
//# sourceMappingURL=sdv.controller.js.map