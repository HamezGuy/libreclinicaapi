/**
 * Electronic Signature Service
 *
 * 21 CFR Part 11 Compliant Electronic Signature Implementation
 *
 * This service provides:
 * - Password verification for signatures (§11.200)
 * - Signature application and tracking (§11.50)
 * - Audit trail of all signature events (§11.10(e))
 * - User certification management (§11.100(c))
 *
 * Key database tables used:
 * - event_crf (electronic_signature_status column)
 * - event_definition_crf (electronic_signature column for requirements)
 * - audit_log_event (signature audit trail)
 * - user_account (password verification)
 */
/**
 * Signature meaning types per 21 CFR Part 11 §11.50
 */
export type SignatureMeaning = 'authorship' | 'approval' | 'responsibility' | 'review' | 'verification' | 'acknowledgment';
/**
 * Entity types that can be signed
 */
export type SignableEntityType = 'event_crf' | 'study_event' | 'study_subject' | 'discrepancy_note' | 'data_lock';
export interface SignatureRequest {
    userId: number;
    username: string;
    userFullName: string;
    entityType: SignableEntityType;
    entityId: number;
    password: string;
    meaning: SignatureMeaning;
    reasonForSigning?: string;
}
export interface SignatureRecord {
    signatureId: number;
    entityType: string;
    entityId: number;
    signedBy: string;
    signedByFullName: string;
    signedAt: Date;
    meaning: SignatureMeaning;
    reasonForSigning: string;
    ipAddress?: string;
}
/**
 * Verify user's password for electronic signature
 * Uses MD5 hash like LibreClinica for compatibility
 *
 * @param userId User ID
 * @param username Username for logging
 * @param password Plain text password to verify
 */
export declare const verifyPasswordForSignature: (userId: number, username: string, password: string) => Promise<{
    success: boolean;
    message?: string;
}>;
/**
 * Apply electronic signature to an entity
 * 21 CFR Part 11 compliant signature application
 */
export declare const applyElectronicSignature: (request: SignatureRequest) => Promise<{
    success: boolean;
    data?: {
        signatureId: number;
    };
    message?: string;
}>;
/**
 * Get signature status for an entity
 */
export declare const getSignatureStatus: (entityType: string, entityId: number) => Promise<{
    success: boolean;
    data?: any;
    message?: string;
}>;
/**
 * Get signature history for an entity
 */
export declare const getSignatureHistory: (entityType: string, entityId: number) => Promise<{
    success: boolean;
    data?: SignatureRecord[];
    message?: string;
}>;
/**
 * Get pending signatures for a user
 */
export declare const getPendingSignatures: (userId: number, studyId?: number) => Promise<{
    success: boolean;
    data?: any[];
    message?: string;
}>;
/**
 * Certify user for electronic signatures
 * 21 CFR Part 11 §11.100(c)
 */
export declare const certifyUser: (userId: number, username: string, password: string, acknowledgment: string) => Promise<{
    success: boolean;
    data?: any;
    message?: string;
}>;
/**
 * Get study e-signature requirements
 */
export declare const getStudySignatureRequirements: (studyId: number) => Promise<{
    success: boolean;
    data?: any[];
    message?: string;
}>;
declare const _default: {
    verifyPasswordForSignature: (userId: number, username: string, password: string) => Promise<{
        success: boolean;
        message?: string;
    }>;
    applyElectronicSignature: (request: SignatureRequest) => Promise<{
        success: boolean;
        data?: {
            signatureId: number;
        };
        message?: string;
    }>;
    getSignatureStatus: (entityType: string, entityId: number) => Promise<{
        success: boolean;
        data?: any;
        message?: string;
    }>;
    getSignatureHistory: (entityType: string, entityId: number) => Promise<{
        success: boolean;
        data?: SignatureRecord[];
        message?: string;
    }>;
    getPendingSignatures: (userId: number, studyId?: number) => Promise<{
        success: boolean;
        data?: any[];
        message?: string;
    }>;
    certifyUser: (userId: number, username: string, password: string, acknowledgment: string) => Promise<{
        success: boolean;
        data?: any;
        message?: string;
    }>;
    getStudySignatureRequirements: (studyId: number) => Promise<{
        success: boolean;
        data?: any[];
        message?: string;
    }>;
};
export default _default;
//# sourceMappingURL=esignature.service.d.ts.map