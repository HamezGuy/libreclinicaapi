/**
 * Audit SOAP Service
 *
 * Handles audit trail operations via LibreClinica SOAP API
 * CRITICAL for 21 CFR Part 11 compliance - maintains tamper-evident audit trail
 *
 * SOAP Operations:
 * - Record audit events in LibreClinica's native audit log
 * - Retrieve audit trail for subjects, CRFs, and data changes
 * - Support electronic signature recording
 *
 * The audit trail in LibreClinica maintains:
 * - WHO: User performing action
 * - WHAT: Nature of the change
 * - WHEN: Timestamp (system-generated, cannot be modified)
 * - WHY: Reason for change (required for modifications)
 */
import { ApiResponse } from '../../types';
/**
 * Audit event types matching LibreClinica's audit_log_event_type table
 */
export declare enum AuditEventType {
    SUBJECT_CREATED = 1,
    SUBJECT_UPDATED = 2,
    SUBJECT_STATUS_CHANGED = 3,
    SUBJECT_REASSIGNED = 4,
    SUBJECT_REMOVED = 5,
    STUDY_EVENT_SCHEDULED = 6,
    STUDY_EVENT_STARTED = 7,
    STUDY_EVENT_COMPLETED = 8,
    STUDY_EVENT_SKIPPED = 9,
    STUDY_EVENT_STOPPED = 10,
    CRF_INITIAL_DATA_ENTRY = 11,
    CRF_UPDATED = 12,
    CRF_MARKED_COMPLETE = 13,
    CRF_SDV_VERIFIED = 14,
    CRF_LOCKED = 15,
    CRF_SIGNED = 16,
    ITEM_DATA_INSERTED = 17,
    ITEM_DATA_UPDATED = 18,
    ITEM_DATA_DELETED = 19,
    QUERY_OPENED = 20,
    QUERY_UPDATED = 21,
    QUERY_RESOLVED = 22,
    QUERY_CLOSED = 23,
    ESIGNATURE_ADDED = 30,
    ESIGNATURE_REMOVED = 31,
    USER_LOGIN = 40,
    USER_LOGOUT = 41,
    LOGIN_FAILED = 42,
    PASSWORD_CHANGED = 43,
    ACCOUNT_LOCKED = 44
}
/**
 * Audit record structure for SOAP operations
 */
export interface AuditRecord {
    auditId?: number;
    auditDate: Date;
    auditTable: string;
    entityId: number;
    entityName?: string;
    userId: number;
    username: string;
    eventTypeId: AuditEventType;
    eventTypeName?: string;
    oldValue?: string;
    newValue?: string;
    reasonForChange?: string;
    electronicSignature?: {
        username: string;
        meaning: string;
        timestamp: Date;
    };
}
/**
 * Audit query parameters
 */
export interface AuditQueryParams {
    studyId?: number;
    subjectId?: number;
    eventCrfId?: number;
    userId?: number;
    eventTypeId?: AuditEventType;
    startDate?: string;
    endDate?: string;
    entityType?: 'study' | 'subject' | 'event' | 'crf' | 'item';
    limit?: number;
    offset?: number;
}
/**
 * Record an audit event via SOAP
 * This ensures the audit entry is recorded in LibreClinica's native audit system
 */
export declare const recordAuditEvent: (record: AuditRecord, userId: number, username: string) => Promise<ApiResponse<{
    auditId: number;
}>>;
/**
 * Get audit trail for a subject via SOAP
 * Returns complete audit history for 21 CFR Part 11 compliance
 */
export declare const getSubjectAuditTrail: (studyId: number, subjectId: number, userId: number, username: string) => Promise<ApiResponse<AuditRecord[]>>;
/**
 * Get form-level audit trail via SOAP
 */
export declare const getFormAuditTrail: (eventCrfId: number, userId: number, username: string) => Promise<ApiResponse<AuditRecord[]>>;
/**
 * Record electronic signature via SOAP
 * 21 CFR Part 11 §11.100 - Electronic signature must be linked to record
 */
export declare const recordElectronicSignature: (entityType: "crf" | "subject" | "event", entityId: number, signature: {
    username: string;
    password: string;
    meaning: string;
    reasonForChange?: string;
}, userId: number, username: string) => Promise<ApiResponse<{
    signatureId: number;
}>>;
declare const _default: {
    recordAuditEvent: (record: AuditRecord, userId: number, username: string) => Promise<ApiResponse<{
        auditId: number;
    }>>;
    getSubjectAuditTrail: (studyId: number, subjectId: number, userId: number, username: string) => Promise<ApiResponse<AuditRecord[]>>;
    getFormAuditTrail: (eventCrfId: number, userId: number, username: string) => Promise<ApiResponse<AuditRecord[]>>;
    recordElectronicSignature: (entityType: "crf" | "subject" | "event", entityId: number, signature: {
        username: string;
        password: string;
        meaning: string;
        reasonForChange?: string;
    }, userId: number, username: string) => Promise<ApiResponse<{
        signatureId: number;
    }>>;
    AuditEventType: typeof AuditEventType;
};
export default _default;
//# sourceMappingURL=auditSoap.service.d.ts.map