/**
 * Study Groups Routes
 *
 * API endpoints for managing study group classes and subject group assignments.
 * Used for randomization, treatment arms, demographics grouping, etc.
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=studyGroups.routes.d.ts.map