/**
 * Authentication Controller
 *
 * Handles authentication endpoints
 * - Username/password login
 * - Google OAuth login
 * - Token refresh
 * - Token verification
 * - Capture token generation (WoundScanner)
 */
import { Request, Response } from 'express';
/**
 * Login with username/password
 */
export declare const login: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Login with Google OAuth
 */
export declare const googleLogin: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Refresh access token
 */
export declare const refresh: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Verify current token
 */
export declare const verify: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Logout - Record logout in audit trail
 * 21 CFR Part 11 §11.10(e) - Audit Trail compliance
 */
export declare const logout: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Generate a capture token for WoundScanner iOS app
 * POST /api/auth/capture-token
 *
 * This creates a short-lived token that includes patient/template context
 * for the iOS app to use during wound capture.
 */
export declare const generateCaptureToken: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Validate a capture token from WoundScanner iOS app
 * POST /api/auth/validate-token
 *
 * Called by iOS app when it receives a deep link with a token.
 * Validates the token and returns user/patient context.
 */
export declare const validateCaptureToken: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Get current user's profile
 * GET /api/auth/profile
 */
export declare const getProfile: (req: Request, res: Response, next: import("express").NextFunction) => void;
/**
 * Update current user's profile (self-service)
 * PUT /api/auth/profile
 *
 * Users can update their own: firstName, lastName, email, phone, institutionalAffiliation, timeZone
 * They CANNOT change: username, role, status
 */
export declare const updateProfile: (req: Request, res: Response, next: import("express").NextFunction) => void;
declare const _default: {
    login: (req: Request, res: Response, next: import("express").NextFunction) => void;
    googleLogin: (req: Request, res: Response, next: import("express").NextFunction) => void;
    refresh: (req: Request, res: Response, next: import("express").NextFunction) => void;
    verify: (req: Request, res: Response, next: import("express").NextFunction) => void;
    logout: (req: Request, res: Response, next: import("express").NextFunction) => void;
    generateCaptureToken: (req: Request, res: Response, next: import("express").NextFunction) => void;
    validateCaptureToken: (req: Request, res: Response, next: import("express").NextFunction) => void;
    getProfile: (req: Request, res: Response, next: import("express").NextFunction) => void;
    updateProfile: (req: Request, res: Response, next: import("express").NextFunction) => void;
};
export default _default;
//# sourceMappingURL=auth.controller.d.ts.map