/**
 * Adverse Event Service
 *
 * Uses EXISTING LibreClinica SOAP APIs for Part 11 compliance:
 * - dataSoap.service.ts for importing AE data (ODM format)
 * - eventSoap.service.ts for scheduling AE events
 *
 * LibreClinica Models Used:
 * - CRF (admin/CRFBean.java) - AE form template
 * - EventCRF (submit/EventCRFBean.java) - AE form instance
 * - ItemData (submit/ItemDataBean.java) - AE field values
 * - StudyEventDefinition (managestudy/StudyEventDefinitionBean.java) - AE event type
 *
 * AEs are just CRF forms with specific fields - no special tables needed!
 */
export interface AEFormConfig {
    eventOID: string;
    formOID: string;
    itemGroupOID: string;
    items: {
        term: string;
        meddraCode?: string;
        onsetDate: string;
        resolutionDate?: string;
        severity: string;
        isSerious: string;
        causality?: string;
        outcome?: string;
        action?: string;
    };
}
declare const DEFAULT_AE_CONFIG: AEFormConfig;
export interface AdverseEvent {
    aeId?: number;
    subjectOID: string;
    aeTerm: string;
    meddraCode?: string;
    onsetDate: string;
    resolutionDate?: string;
    severity: 'Mild' | 'Moderate' | 'Severe';
    isSerious: boolean;
    seriousnessCriteria?: {
        resultsDeath?: boolean;
        lifeThreatening?: boolean;
        hospitalization?: boolean;
        disability?: boolean;
        congenitalAnomaly?: boolean;
        medicallyImportant?: boolean;
    };
    causalityAssessment?: string;
    outcome?: string;
    actionTaken?: string;
}
export interface AEReportResult {
    success: boolean;
    eventCrfId?: number;
    message?: string;
    errors?: string[];
}
export interface AESummary {
    totalAEs: number;
    seriousAEs: number;
    openAEs: number;
    resolvedAEs: number;
    bySeverity: {
        severity: string;
        count: number;
    }[];
    recentAEs: {
        aeId: number;
        subjectLabel: string;
        aeTerm: string;
        onsetDate: string;
        isSerious: boolean;
    }[];
}
/**
 * Report a new Adverse Event
 * Uses EXISTING dataSoap.service for Part 11 compliance
 */
export declare const reportAdverseEvent: (studyOID: string, ae: AdverseEvent, userId: number, username: string, aeConfig?: AEFormConfig) => Promise<AEReportResult>;
/**
 * Get AE Summary for dashboard
 * READ-ONLY summary queries - counts only, no clinical values exposed
 */
export declare const getAESummary: (studyId: number) => Promise<AESummary>;
/**
 * Get AEs for a specific subject
 */
export declare const getSubjectAEs: (studyId: number, subjectId: number) => Promise<{
    aeId: number;
    aeTerm: string;
    onsetDate: string;
    severity: string;
    isSerious: boolean;
    status: string;
}[]>;
export { DEFAULT_AE_CONFIG };
declare const _default: {
    reportAdverseEvent: (studyOID: string, ae: AdverseEvent, userId: number, username: string, aeConfig?: AEFormConfig) => Promise<AEReportResult>;
    getAESummary: (studyId: number) => Promise<AESummary>;
    getSubjectAEs: (studyId: number, subjectId: number) => Promise<{
        aeId: number;
        aeTerm: string;
        onsetDate: string;
        severity: string;
        isSerious: boolean;
        status: string;
    }[]>;
    DEFAULT_AE_CONFIG: AEFormConfig;
};
export default _default;
//# sourceMappingURL=adverse-event.service.d.ts.map