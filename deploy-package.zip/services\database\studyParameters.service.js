"use strict";
/**
 * Study Parameters Service
 *
 * Fetches and manages study configuration parameters from LibreClinica database.
 * These parameters control enrollment behavior, subject ID generation, etc.
 *
 * Database Tables:
 * - study_parameter: Reference table of all possible parameters
 * - study_parameter_value: Per-study parameter values
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateNextSubjectId = exports.initializeStudyParameters = exports.saveStudyParameters = exports.getRawStudyParameters = exports.getStudyParameters = exports.getAvailableParameters = void 0;
const database_1 = require("../../config/database");
const logger_1 = require("../../config/logger");
/**
 * Get all available study parameters (reference data)
 */
const getAvailableParameters = async () => {
    const query = `
    SELECT 
      study_parameter_id,
      handle,
      name,
      description,
      default_value,
      inheritable,
      overridable
    FROM study_parameter
    ORDER BY study_parameter_id
  `;
    try {
        const result = await database_1.pool.query(query);
        return result.rows.map(row => ({
            id: row.study_parameter_id,
            handle: row.handle,
            name: row.name || row.handle,
            description: row.description || '',
            defaultValue: row.default_value,
            inheritable: row.inheritable,
            overridable: row.overridable
        }));
    }
    catch (error) {
        logger_1.logger.error('Failed to get available parameters', { error: error.message });
        throw error;
    }
};
exports.getAvailableParameters = getAvailableParameters;
/**
 * Get study parameters for a specific study
 * Falls back to defaults from parent study or system defaults
 */
const getStudyParameters = async (studyId) => {
    logger_1.logger.info('Fetching study parameters', { studyId });
    try {
        // First, get the parent study ID (if this is a site)
        const parentQuery = `SELECT parent_study_id FROM study WHERE study_id = $1`;
        const parentResult = await database_1.pool.query(parentQuery, [studyId]);
        const parentStudyId = parentResult.rows[0]?.parent_study_id;
        // Get parameters - check study first, then parent, then defaults
        const query = `
      SELECT 
        sp.handle as parameter,
        COALESCE(
          spv_study.value,
          spv_parent.value,
          sp.default_value
        ) as value,
        sp.default_value
      FROM study_parameter sp
      LEFT JOIN study_parameter_value spv_study 
        ON sp.handle = spv_study.parameter AND spv_study.study_id = $1
      LEFT JOIN study_parameter_value spv_parent 
        ON sp.handle = spv_parent.parameter AND spv_parent.study_id = $2
      ORDER BY sp.study_parameter_id
    `;
        const result = await database_1.pool.query(query, [studyId, parentStudyId || studyId]);
        // Convert raw values to typed config
        const config = parseParameterValues(result.rows);
        logger_1.logger.info('Study parameters fetched', { studyId, config });
        return config;
    }
    catch (error) {
        logger_1.logger.error('Failed to get study parameters', { studyId, error: error.message });
        // Return defaults on error
        return getDefaultParameters();
    }
};
exports.getStudyParameters = getStudyParameters;
/**
 * Get raw parameter values for a study (useful for editing)
 */
const getRawStudyParameters = async (studyId) => {
    const query = `
    SELECT parameter, value
    FROM study_parameter_value
    WHERE study_id = $1
  `;
    try {
        const result = await database_1.pool.query(query, [studyId]);
        const params = {};
        for (const row of result.rows) {
            params[row.parameter] = row.value;
        }
        return params;
    }
    catch (error) {
        logger_1.logger.error('Failed to get raw study parameters', { studyId, error: error.message });
        return {};
    }
};
exports.getRawStudyParameters = getRawStudyParameters;
/**
 * Save study parameters
 */
const saveStudyParameters = async (studyId, parameters, userId) => {
    const client = await database_1.pool.connect();
    try {
        await client.query('BEGIN');
        for (const [handle, value] of Object.entries(parameters)) {
            // Check if parameter exists for this study
            const existsQuery = `
        SELECT study_parameter_value_id 
        FROM study_parameter_value 
        WHERE study_id = $1 AND parameter = $2
      `;
            const existsResult = await client.query(existsQuery, [studyId, handle]);
            if (existsResult.rows.length > 0) {
                // Update existing
                await client.query(`
          UPDATE study_parameter_value 
          SET value = $1 
          WHERE study_id = $2 AND parameter = $3
        `, [value, studyId, handle]);
            }
            else {
                // Insert new
                await client.query(`
          INSERT INTO study_parameter_value (study_id, parameter, value)
          VALUES ($1, $2, $3)
        `, [studyId, handle, value]);
            }
        }
        await client.query('COMMIT');
        logger_1.logger.info('Study parameters saved', { studyId, paramCount: Object.keys(parameters).length });
    }
    catch (error) {
        await client.query('ROLLBACK');
        logger_1.logger.error('Failed to save study parameters', { studyId, error: error.message });
        throw error;
    }
    finally {
        client.release();
    }
};
exports.saveStudyParameters = saveStudyParameters;
/**
 * Initialize default parameters for a new study
 */
const initializeStudyParameters = async (studyId, userId) => {
    const defaults = await (0, exports.getAvailableParameters)();
    const params = {};
    for (const param of defaults) {
        params[param.handle] = param.defaultValue;
    }
    await (0, exports.saveStudyParameters)(studyId, params, userId);
};
exports.initializeStudyParameters = initializeStudyParameters;
/**
 * Parse raw parameter values into typed config
 */
function parseParameterValues(rows) {
    const valueMap = {};
    for (const row of rows) {
        valueMap[row.parameter] = row.value || row.default_value;
    }
    return {
        collectDob: parseCollectDob(valueMap['collectDob']),
        discrepancyManagement: valueMap['discrepancyManagement'] === 'true',
        subjectPersonIdRequired: parseRequiredOption(valueMap['subjectPersonIdRequired']),
        genderRequired: valueMap['genderRequired'] === 'true' || valueMap['genderRequired'] === 'required',
        subjectIdGeneration: parseIdGeneration(valueMap['subjectIdGeneration']),
        subjectIdPrefixSuffix: valueMap['subjectIdPrefixSuffix'] || '',
        interviewerNameRequired: parseRequiredOption(valueMap['interviewerNameRequired']),
        interviewerNameDefault: valueMap['interviewerNameDefault'] === 'blank' ? 'blank' : 'user_name',
        interviewerNameEditable: valueMap['interviewerNameEditable'] === 'editable' || valueMap['interviewerNameEditable'] === 'true',
        interviewDateRequired: parseRequiredOption(valueMap['interviewDateRequired']),
        interviewDateDefault: valueMap['interviewDateDefault'] === 'blank' ? 'blank' : 'eventDate',
        interviewDateEditable: valueMap['interviewDateEditable'] === 'editable' || valueMap['interviewDateEditable'] === 'true',
        personIdShownOnCRF: valueMap['personIdShownOnCRF'] === 'true',
        secondaryLabelViewable: valueMap['secondaryLabelViewable'] !== 'not viewable',
        adminForcedReasonForChange: valueMap['adminForcedReasonForChange'] === 'true',
        eventLocationRequired: parseRequiredOption(valueMap['eventLocationRequired']),
        participantPortal: valueMap['participantPortal'] === 'enabled' ? 'enabled' : 'disabled',
        randomization: valueMap['randomization'] === 'enabled' ? 'enabled' : 'disabled'
    };
}
function parseCollectDob(value) {
    if (value === '1' || value === 'required' || value === 'full')
        return 'required';
    if (value === '2' || value === 'year_only')
        return 'year_only';
    return 'not_used';
}
function parseRequiredOption(value) {
    if (value === 'required' || value === 'true')
        return 'required';
    if (value === 'optional')
        return 'optional';
    return 'not_used';
}
function parseIdGeneration(value) {
    if (value === 'auto editable' || value === 'auto_editable')
        return 'auto_editable';
    if (value === 'auto non-editable' || value === 'auto_non_editable')
        return 'auto_non_editable';
    return 'manual';
}
/**
 * Get default parameters when database fetch fails
 */
function getDefaultParameters() {
    return {
        collectDob: 'required',
        discrepancyManagement: true,
        subjectPersonIdRequired: 'required',
        genderRequired: true,
        subjectIdGeneration: 'manual',
        subjectIdPrefixSuffix: '',
        interviewerNameRequired: 'required',
        interviewerNameDefault: 'blank',
        interviewerNameEditable: true,
        interviewDateRequired: 'required',
        interviewDateDefault: 'eventDate',
        interviewDateEditable: true,
        personIdShownOnCRF: false,
        secondaryLabelViewable: false,
        adminForcedReasonForChange: true,
        eventLocationRequired: 'not_used',
        participantPortal: 'disabled',
        randomization: 'disabled'
    };
}
/**
 * Generate next subject ID based on study settings
 */
const generateNextSubjectId = async (studyId) => {
    const params = await (0, exports.getStudyParameters)(studyId);
    if (params.subjectIdGeneration === 'manual') {
        return ''; // Don't auto-generate for manual
    }
    // Get the greatest existing label and increment
    const query = `
    SELECT MAX(CAST(
      CASE 
        WHEN label ~ '^[0-9]+$' THEN label 
        ELSE '0' 
      END AS INTEGER
    )) as max_label
    FROM study_subject
    WHERE study_id = $1 OR study_id IN (
      SELECT study_id FROM study WHERE parent_study_id = $1
    )
  `;
    try {
        const result = await database_1.pool.query(query, [studyId]);
        const nextNum = (result.rows[0]?.max_label || 0) + 1;
        // Apply prefix/suffix if configured
        const prefix = params.subjectIdPrefixSuffix || '';
        if (prefix) {
            // Format: [PREFIX][AUTO#][SUFFIX] - parse and apply
            return prefix.replace('[AUTO#]', nextNum.toString().padStart(4, '0'));
        }
        return nextNum.toString();
    }
    catch (error) {
        logger_1.logger.error('Failed to generate subject ID', { studyId, error: error.message });
        return '';
    }
};
exports.generateNextSubjectId = generateNextSubjectId;
//# sourceMappingURL=studyParameters.service.js.map