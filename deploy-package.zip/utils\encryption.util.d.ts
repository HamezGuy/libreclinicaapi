/**
 * Data Encryption Utility
 *
 * 21 CFR Part 11 §11.10(a) - Data-at-Rest Encryption
 *
 * Provides field-level encryption for sensitive data using AES-256-GCM
 * This supplements volume-level encryption for defense-in-depth
 *
 * Features:
 * - AES-256-GCM authenticated encryption
 * - Unique IV per encryption operation
 * - Key derivation from master secret
 * - PostgreSQL pgcrypto compatibility layer
 */
/**
 * Encrypt sensitive data using AES-256-GCM
 *
 * @param plaintext - The data to encrypt
 * @returns Base64-encoded encrypted data with IV and auth tag
 */
export declare function encryptField(plaintext: string): string;
/**
 * Decrypt data encrypted with encryptField
 *
 * @param encryptedData - The encrypted data string
 * @returns Decrypted plaintext
 */
export declare function decryptField(encryptedData: string): string;
/**
 * Check if a field value is encrypted
 */
export declare function isEncrypted(value: string): boolean;
/**
 * Encrypt an object's specified fields
 *
 * @param obj - Object to encrypt fields in
 * @param fieldsToEncrypt - Array of field names to encrypt
 * @returns Object with specified fields encrypted
 */
export declare function encryptObjectFields<T extends object>(obj: T, fieldsToEncrypt: (keyof T)[]): T;
/**
 * Decrypt an object's specified fields
 *
 * @param obj - Object to decrypt fields in
 * @param fieldsToDecrypt - Array of field names to decrypt
 * @returns Object with specified fields decrypted
 */
export declare function decryptObjectFields<T extends object>(obj: T, fieldsToDecrypt: (keyof T)[]): T;
/**
 * Generate a secure random encryption key
 * Use this to generate a new master key for production
 */
export declare function generateMasterKey(): string;
/**
 * Generate a secure random salt
 */
export declare function generateSalt(): string;
/**
 * Hash sensitive data for comparison without decryption
 * Uses SHA-256 with application salt
 */
export declare function hashForComparison(data: string): string;
/**
 * PostgreSQL pgcrypto compatibility - generate SQL for encryption
 * Use this when you need to encrypt data directly in SQL queries
 *
 * NOTE: Requires pgcrypto extension to be installed:
 * CREATE EXTENSION IF NOT EXISTS pgcrypto;
 */
export declare function getPgCryptoEncryptSQL(columnAlias: string, keyParam?: string): string;
/**
 * PostgreSQL pgcrypto compatibility - generate SQL for decryption
 */
export declare function getPgCryptoDecryptSQL(columnAlias: string, keyParam?: string): string;
/**
 * Sensitive field definitions for different entity types
 * These fields should be encrypted at rest
 */
export declare const SENSITIVE_FIELDS: {
    subject: string[];
    user: string[];
    itemData: string[];
    adverseEvent: string[];
    consent: string[];
};
declare const _default: {
    encryptField: typeof encryptField;
    decryptField: typeof decryptField;
    isEncrypted: typeof isEncrypted;
    encryptObjectFields: typeof encryptObjectFields;
    decryptObjectFields: typeof decryptObjectFields;
    generateMasterKey: typeof generateMasterKey;
    generateSalt: typeof generateSalt;
    hashForComparison: typeof hashForComparison;
    getPgCryptoEncryptSQL: typeof getPgCryptoEncryptSQL;
    getPgCryptoDecryptSQL: typeof getPgCryptoDecryptSQL;
    SENSITIVE_FIELDS: {
        subject: string[];
        user: string[];
        itemData: string[];
        adverseEvent: string[];
        consent: string[];
    };
};
export default _default;
//# sourceMappingURL=encryption.util.d.ts.map