/**
 * Organization Routes
 *
 * Routes for organization management, invite codes, access requests, and invitations
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=organization.routes.d.ts.map