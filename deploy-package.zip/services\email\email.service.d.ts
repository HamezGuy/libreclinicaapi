/**
 * Email Service
 *
 * Email notification system with:
 * - Template-based email sending
 * - Queue-based delivery for reliability
 * - SMTP integration
 * - User preference management
 * - 21 CFR Part 11 audit logging
 */
import { EmailTemplate, EmailRequest, DirectEmailRequest, NotificationPreference, UpdatePreferenceRequest, NotificationType, EmailSendResult, QueueProcessResult } from './email.types';
/**
 * Get email template by name
 */
export declare function getTemplate(templateName: string): Promise<EmailTemplate | null>;
/**
 * List all email templates
 */
export declare function listTemplates(): Promise<EmailTemplate[]>;
/**
 * Queue an email for sending
 */
export declare function queueEmail(request: EmailRequest): Promise<number | null>;
/**
 * Queue a direct email (without template)
 */
export declare function queueDirectEmail(request: DirectEmailRequest): Promise<number | null>;
/**
 * Send email directly via SMTP (for testing or immediate send)
 * Note: In production, this would use nodemailer
 */
export declare function sendEmailDirect(to: string, subject: string, htmlBody: string, textBody?: string): Promise<EmailSendResult>;
/**
 * Process the email queue
 */
export declare function processEmailQueue(batchSize?: number): Promise<QueueProcessResult>;
/**
 * Get user notification preferences
 */
export declare function getUserPreferences(userId: number): Promise<NotificationPreference[]>;
/**
 * Get user preference for a specific notification type
 */
export declare function getPreference(userId: number, notificationType: NotificationType, studyId?: number): Promise<NotificationPreference | null>;
/**
 * Update user notification preference
 */
export declare function updatePreference(request: UpdatePreferenceRequest): Promise<boolean>;
/**
 * Check if user wants email for a notification type
 */
export declare function shouldSendEmail(userId: number, notificationType: NotificationType, studyId?: number): Promise<boolean>;
/**
 * Check if notification should be included in digest
 */
export declare function shouldIncludeInDigest(userId: number, notificationType: NotificationType, studyId?: number): Promise<boolean>;
/**
 * Get email queue status
 */
export declare function getQueueStatus(): Promise<{
    pending: number;
    sent: number;
    failed: number;
    total: number;
}>;
/**
 * Cancel a queued email
 */
export declare function cancelEmail(queueId: number): Promise<boolean>;
/**
 * Retry a failed email
 */
export declare function retryEmail(queueId: number): Promise<boolean>;
declare const _default: {
    getTemplate: typeof getTemplate;
    listTemplates: typeof listTemplates;
    queueEmail: typeof queueEmail;
    queueDirectEmail: typeof queueDirectEmail;
    sendEmailDirect: typeof sendEmailDirect;
    processEmailQueue: typeof processEmailQueue;
    getUserPreferences: typeof getUserPreferences;
    getPreference: typeof getPreference;
    updatePreference: typeof updatePreference;
    shouldSendEmail: typeof shouldSendEmail;
    shouldIncludeInDigest: typeof shouldIncludeInDigest;
    getQueueStatus: typeof getQueueStatus;
    cancelEmail: typeof cancelEmail;
    retryEmail: typeof retryEmail;
};
export default _default;
//# sourceMappingURL=email.service.d.ts.map