/**
 * Study Parameters Service
 *
 * Fetches and manages study configuration parameters from LibreClinica database.
 * These parameters control enrollment behavior, subject ID generation, etc.
 *
 * Database Tables:
 * - study_parameter: Reference table of all possible parameters
 * - study_parameter_value: Per-study parameter values
 */
export interface StudyParameterConfig {
    collectDob: 'required' | 'year_only' | 'not_used';
    discrepancyManagement: boolean;
    subjectPersonIdRequired: 'required' | 'optional' | 'not_used';
    genderRequired: boolean;
    subjectIdGeneration: 'manual' | 'auto_editable' | 'auto_non_editable';
    subjectIdPrefixSuffix: string;
    interviewerNameRequired: 'required' | 'optional' | 'not_used';
    interviewerNameDefault: 'blank' | 'user_name';
    interviewerNameEditable: boolean;
    interviewDateRequired: 'required' | 'optional' | 'not_used';
    interviewDateDefault: 'blank' | 'eventDate';
    interviewDateEditable: boolean;
    personIdShownOnCRF: boolean;
    secondaryLabelViewable: boolean;
    adminForcedReasonForChange: boolean;
    eventLocationRequired: 'required' | 'optional' | 'not_used';
    participantPortal: 'enabled' | 'disabled';
    randomization: 'enabled' | 'disabled';
}
/**
 * Get all available study parameters (reference data)
 */
export declare const getAvailableParameters: () => Promise<any[]>;
/**
 * Get study parameters for a specific study
 * Falls back to defaults from parent study or system defaults
 */
export declare const getStudyParameters: (studyId: number) => Promise<StudyParameterConfig>;
/**
 * Get raw parameter values for a study (useful for editing)
 */
export declare const getRawStudyParameters: (studyId: number) => Promise<Record<string, string>>;
/**
 * Save study parameters
 */
export declare const saveStudyParameters: (studyId: number, parameters: Record<string, string>, userId: number) => Promise<void>;
/**
 * Initialize default parameters for a new study
 */
export declare const initializeStudyParameters: (studyId: number, userId: number) => Promise<void>;
/**
 * Generate next subject ID based on study settings
 */
export declare const generateNextSubjectId: (studyId: number) => Promise<string>;
//# sourceMappingURL=studyParameters.service.d.ts.map