"use strict";
/**
 * 21 CFR Part 11 Compliance Middleware
 *
 * Provides compliance features for FDA 21 CFR Part 11:
 * - §11.10(e) Audit Trails: Complete, immutable audit records
 * - §11.10(k) Time Stamps: UTC timestamps for all events
 * - §11.50 Electronic Signatures: Verification and non-repudiation
 * - §11.10(d) Access Controls: Role-based authorization
 *
 * Usage:
 *   import { part11Audit, requireSignature, verifyPassword } from './part11.middleware';
 *   router.post('/critical-action', part11Audit('ENTITY_UPDATED'), requireSignature, handler);
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SignatureMeanings = exports.Part11EventTypes = void 0;
exports.recordPart11Audit = recordPart11Audit;
exports.part11Audit = part11Audit;
exports.verifyElectronicSignature = verifyElectronicSignature;
exports.requireSignature = requireSignature;
exports.requireSignatureFor = requireSignatureFor;
exports.createAuditFromRequest = createAuditFromRequest;
exports.formatPart11Timestamp = formatPart11Timestamp;
exports.isValidPart11Timestamp = isValidPart11Timestamp;
exports.verifyAuditChainIntegrity = verifyAuditChainIntegrity;
const database_1 = require("../config/database");
const logger_1 = require("../config/logger");
const crypto_1 = __importDefault(require("crypto"));
const password_util_1 = require("../utils/password.util");
/**
 * Generate SHA-256 hash for audit integrity
 * Creates a cryptographic hash chain for tamper detection per §11.10(e)
 */
function generateAuditHash(previousHash, timestamp, userId, eventType, entityType, entityId, oldValue, newValue) {
    const dataToHash = [
        previousHash || 'GENESIS',
        timestamp.toISOString(),
        userId.toString(),
        eventType.toString(),
        entityType,
        entityId?.toString() || 'null',
        oldValue || '',
        newValue || ''
    ].join('|');
    return crypto_1.default.createHash('sha256').update(dataToHash).digest('hex');
}
/**
 * Part 11 Audit Event Types
 * These map to audit_log_event_type_id in LibreClinica
 */
exports.Part11EventTypes = {
    // Document/Record Events
    RECORD_CREATED: 1,
    RECORD_UPDATED: 2,
    RECORD_DELETED: 3,
    RECORD_VIEWED: 4,
    RECORD_EXPORTED: 5,
    // Electronic Signature Events
    SIGNATURE_APPLIED: 10,
    SIGNATURE_VERIFIED: 11,
    SIGNATURE_REJECTED: 12,
    // Access Control Events
    ACCESS_GRANTED: 20,
    ACCESS_DENIED: 21,
    PERMISSION_CHANGED: 22,
    // System Events
    SYSTEM_CONFIGURATION_CHANGED: 30,
    BACKUP_CREATED: 31,
    DATA_IMPORTED: 32,
    DATA_EXPORTED: 33,
    // Consent Events (custom for eConsent)
    CONSENT_DOCUMENTED: 40,
    CONSENT_WITHDRAWN: 41,
    CONSENT_VERSION_ACTIVATED: 42,
    // ePRO Events
    PRO_INSTRUMENT_CREATED: 50,
    PRO_ASSIGNMENT_CREATED: 51,
    PRO_RESPONSE_SUBMITTED: 52,
    PRO_REMINDER_SENT: 53,
    // RTSM Events
    KIT_REGISTERED: 60,
    KIT_DISPENSED: 61,
    KIT_RETURNED: 62,
    SHIPMENT_CREATED: 63,
    SHIPMENT_RECEIVED: 64,
    TEMPERATURE_EXCURSION: 65,
    // Transfer Events
    TRANSFER_INITIATED: 70,
    TRANSFER_APPROVED: 71,
    TRANSFER_COMPLETED: 72,
    TRANSFER_CANCELLED: 73,
    // Email Events
    EMAIL_TEMPLATE_UPDATED: 80,
    EMAIL_QUEUED: 81,
    EMAIL_SENT: 82,
    NOTIFICATION_PREFERENCE_CHANGED: 83
};
/**
 * Record a Part 11 compliant audit event
 *
 * Requirements per §11.10(e):
 * - User identification (user_id)
 * - Date and time (UTC timestamp)
 * - Action performed (event type)
 * - Old value (before change)
 * - New value (after change)
 * - Reason for change (if applicable)
 *
 * Additional compliance features:
 * - IP address for non-repudiation
 * - User agent for device identification
 * - Cryptographic hash chain for tamper detection
 */
async function recordPart11Audit(userId, userName, eventType, entityType, entityId, entityName, oldValue, newValue, reasonForChange, additionalData) {
    const timestamp = new Date(); // UTC timestamp
    try {
        // Format values for storage (JSON stringify objects)
        const oldValueStr = oldValue !== undefined && oldValue !== null
            ? (typeof oldValue === 'object' ? JSON.stringify(oldValue) : String(oldValue))
            : null;
        const newValueStr = newValue !== undefined && newValue !== null
            ? (typeof newValue === 'object' ? JSON.stringify(newValue) : String(newValue))
            : null;
        // Get the previous audit hash for chain integrity (§11.10(e) tamper detection)
        let previousHash = null;
        try {
            const prevResult = await database_1.pool.query(`
        SELECT entity_name FROM audit_log_event 
        WHERE audit_table = $1 
        ORDER BY audit_id DESC LIMIT 1
      `, [entityType]);
            if (prevResult.rows.length > 0 && prevResult.rows[0].entity_name) {
                try {
                    const prevData = JSON.parse(prevResult.rows[0].entity_name);
                    previousHash = prevData.integrityHash || null;
                }
                catch { /* ignore parse errors */ }
            }
        }
        catch { /* ignore if can't get previous hash */ }
        // Generate cryptographic hash for this audit record
        const integrityHash = generateAuditHash(previousHash, timestamp, userId, eventType, entityType, entityId, oldValueStr, newValueStr);
        // Build comprehensive audit record per §11.10(e)
        const auditRecord = {
            entityName: entityName || userName,
            ipAddress: additionalData?.ipAddress || 'system',
            signatureMeaning: additionalData?.signatureMeaning,
            integrityHash, // SHA-256 hash chain for tamper detection
            previousHash: previousHash || 'GENESIS'
        };
        // Insert into LibreClinica's audit_log_event table
        // This table structure is compliant with Part 11 requirements
        const result = await database_1.pool.query(`
      INSERT INTO audit_log_event (
        audit_date,
        audit_table,
        user_id,
        entity_id,
        entity_name,
        old_value,
        new_value,
        audit_log_event_type_id,
        reason_for_change,
        event_crf_id,
        study_event_id
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11
      ) RETURNING audit_id
    `, [
            timestamp,
            entityType,
            userId,
            entityId,
            JSON.stringify(auditRecord),
            oldValueStr,
            newValueStr,
            eventType,
            reasonForChange,
            additionalData?.eventCrfId || null,
            additionalData?.studyEventId || null
        ]);
        const auditId = result.rows[0].audit_id;
        logger_1.logger.info('Part 11 audit recorded', {
            auditId,
            userId,
            eventType,
            entityType,
            entityId,
            timestamp: timestamp.toISOString(),
            integrityHash: integrityHash.substring(0, 16) + '...' // Log partial hash
        });
        return { auditId, timestamp, integrityHash };
    }
    catch (error) {
        logger_1.logger.error('Failed to record Part 11 audit', {
            error: error.message,
            userId,
            eventType,
            entityType
        });
        throw error;
    }
}
/**
 * Middleware to create Part 11 audit context
 * Attaches audit context to request for later use
 */
function part11Audit(eventType, entityType, options) {
    return (req, res, next) => {
        const eventTypeId = typeof eventType === 'number'
            ? eventType
            : exports.Part11EventTypes[eventType];
        req.part11 = {
            eventType: eventTypeId,
            entityType,
            signatureRequired: options?.signatureRequired || false,
            ipAddress: req.ip || req.socket.remoteAddress,
            userAgent: req.get('User-Agent')
        };
        next();
    };
}
/**
 * Verify user password for electronic signature
 * Required for critical operations per §11.50
 *
 * The signature must be:
 * - Unique to the individual (tied to their password)
 * - Linked to the record being signed
 * - Include the meaning of the signature
 */
async function verifyElectronicSignature(userId, password, meaning) {
    try {
        // Get user's password hash from database
        // First check if user_account_extended table exists, then use appropriate query
        let userResult;
        // Check if user_account_extended table exists
        const tableCheck = await database_1.pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'user_account_extended'
      ) as table_exists
    `);
        const hasExtendedTable = tableCheck.rows[0]?.table_exists === true;
        if (hasExtendedTable) {
            // Use query with extended table for bcrypt password
            userResult = await database_1.pool.query(`
        SELECT u.user_id, u.user_name, u.passwd, u.first_name, u.last_name,
               uae.bcrypt_passwd
        FROM user_account u
        LEFT JOIN user_account_extended uae ON u.user_id = uae.user_id
        WHERE u.user_id = $1 AND u.status_id = 1
      `, [userId]);
        }
        else {
            // Use basic query without extended table
            logger_1.logger.debug('user_account_extended table not found, using basic auth');
            userResult = await database_1.pool.query(`
        SELECT user_id, user_name, passwd, first_name, last_name,
               NULL as bcrypt_passwd
        FROM user_account
        WHERE user_id = $1 AND status_id = 1
      `, [userId]);
        }
        if (userResult.rows.length === 0) {
            return { verified: false, userName: '', error: 'User not found or inactive' };
        }
        const user = userResult.rows[0];
        // Use dual-auth verification (supports both MD5 legacy and bcrypt)
        const verification = await (0, password_util_1.verifyAndUpgrade)(password, user.passwd, // MD5 hash from LibreClinica
        user.bcrypt_passwd // bcrypt hash if available
        );
        if (!verification.valid) {
            // Log failed signature attempt (security event)
            await recordPart11Audit(userId, user.user_name, exports.Part11EventTypes.SIGNATURE_REJECTED, 'electronic_signature', userId, `${user.first_name} ${user.last_name}`, null, { meaning, reason: 'Invalid password' }, 'Electronic signature rejected - invalid password');
            return { verified: false, userName: user.user_name, error: 'Invalid password' };
        }
        // If password was verified and needs bcrypt upgrade, store it
        if (verification.shouldUpdateDatabase && verification.upgradedBcryptHash) {
            try {
                await database_1.pool.query(`
          INSERT INTO user_account_extended (user_id, bcrypt_passwd, passwd_upgraded_at, password_version)
          VALUES ($1, $2, NOW(), 2)
          ON CONFLICT (user_id) DO UPDATE SET 
            bcrypt_passwd = EXCLUDED.bcrypt_passwd,
            passwd_upgraded_at = NOW()
        `, [userId, verification.upgradedBcryptHash]);
            }
            catch (upgradeError) {
                logger_1.logger.warn('Failed to upgrade password during signature', { userId, error: upgradeError.message });
            }
        }
        // Log successful signature verification
        await recordPart11Audit(userId, user.user_name, exports.Part11EventTypes.SIGNATURE_VERIFIED, 'electronic_signature', userId, `${user.first_name} ${user.last_name}`, null, { meaning, verified: true }, `Electronic signature verified: ${meaning}`);
        return { verified: true, userName: user.user_name };
    }
    catch (error) {
        logger_1.logger.error('Electronic signature verification failed', { error: error.message });
        return { verified: false, userName: '', error: 'Verification system error' };
    }
}
/**
 * Middleware to require electronic signature for critical operations
 * Per §11.50, electronic signatures must be verified before critical changes
 */
async function requireSignature(req, res, next) {
    const { password, signatureMeaning } = req.body;
    const userId = req.user?.userId;
    if (!userId) {
        return res.status(401).json({
            success: false,
            message: 'Authentication required for electronic signature'
        });
    }
    if (!password) {
        return res.status(400).json({
            success: false,
            message: 'Electronic signature (password) required for this operation',
            requiresSignature: true
        });
    }
    const meaning = signatureMeaning || 'Action authorized';
    const verification = await verifyElectronicSignature(userId, password, meaning);
    if (!verification.verified) {
        return res.status(403).json({
            success: false,
            message: verification.error || 'Electronic signature verification failed',
            requiresSignature: true
        });
    }
    // Attach signature context to Part 11 audit
    if (req.part11) {
        req.part11.signatureVerified = true;
        req.part11.signatureMeaning = meaning;
    }
    next();
}
/**
 * Signature meanings for different operation types
 * Per §11.50(a), signature meaning must be clearly indicated
 */
exports.SignatureMeanings = {
    // Form operations
    FORM_DATA_SAVE: 'I attest that this data entry is accurate and complete',
    FORM_DATA_UPDATE: 'I authorize this change to existing data',
    FORM_COMPLETE: 'I confirm this form is complete and accurate',
    FORM_LOCK: 'I authorize locking this form from further edits',
    // Study operations  
    STUDY_CREATE: 'I authorize the creation of this clinical study',
    STUDY_UPDATE: 'I authorize modifications to this study configuration',
    STUDY_DELETE: 'I authorize the removal of this study',
    // Subject/Patient operations
    SUBJECT_ENROLL: 'I confirm this subject meets enrollment criteria',
    SUBJECT_UPDATE: 'I authorize modifications to subject information',
    SUBJECT_WITHDRAW: 'I authorize withdrawal of this subject from the study',
    SUBJECT_DELETE: 'I authorize the removal of this subject record',
    // Event operations
    EVENT_CREATE: 'I authorize the creation of this study event definition',
    EVENT_SCHEDULE: 'I confirm scheduling of this study event',
    EVENT_UPDATE: 'I authorize modifications to this event',
    EVENT_DELETE: 'I authorize the removal of this event',
    // Query operations
    QUERY_CREATE: 'I am raising this data query for resolution',
    QUERY_RESPOND: 'I am providing this response to the query',
    QUERY_CLOSE: 'I confirm this query is resolved and authorize closure',
    // CRF Template operations
    CRF_CREATE: 'I authorize the creation of this case report form',
    CRF_UPDATE: 'I authorize modifications to this form template',
    CRF_DELETE: 'I authorize the removal of this form template',
    CRF_ASSIGN: 'I authorize assignment of this form to the study event',
    // Site/Location operations
    SITE_CREATE: 'I authorize the creation of this study site',
    SITE_UPDATE: 'I authorize modifications to this site configuration',
    SITE_DELETE: 'I authorize the removal of this study site',
    // Subject Transfer operations
    SUBJECT_TRANSFER: 'I authorize the transfer of this subject to another site',
    // Staff Assignment operations
    STAFF_ASSIGN: 'I authorize assignment of this user to the site',
    STAFF_REMOVE: 'I authorize removal of this user from the site',
    // Skip Logic/Form Linking operations
    RULE_CREATE: 'I authorize the creation of this form rule',
    RULE_UPDATE: 'I authorize modifications to this form rule',
    RULE_DELETE: 'I authorize the removal of this form rule',
    FORM_LINK_CREATE: 'I authorize the creation of this form link',
    FORM_LINK_UPDATE: 'I authorize modifications to this form link',
    FORM_LINK_DELETE: 'I authorize the removal of this form link',
    // General
    APPROVE: 'I approve this action',
    REJECT: 'I reject this action',
    VERIFY: 'I verify the accuracy of this information',
    AUTHORIZE: 'I authorize this action'
};
/**
 * Factory function to create signature requirement middleware with specific meaning
 *
 * @param defaultMeaning - The default signature meaning if not provided in request
 * @returns Middleware that requires electronic signature
 */
function requireSignatureFor(defaultMeaning) {
    return async function (req, res, next) {
        const { password, signatureMeaning } = req.body;
        const userId = req.user?.userId;
        if (!userId) {
            return res.status(401).json({
                success: false,
                message: 'Authentication required for electronic signature'
            });
        }
        // Development mode bypass - allows operations without signature for testing
        // WARNING: Must be disabled in production for 21 CFR Part 11 compliance
        const isDevelopment = process.env.NODE_ENV !== 'production';
        const bypassSignature = isDevelopment && process.env.BYPASS_SIGNATURE === 'true';
        if (!password && !bypassSignature) {
            return res.status(400).json({
                success: false,
                message: 'Electronic signature (password) required for this operation',
                requiresSignature: true,
                signatureMeaning: defaultMeaning
            });
        }
        // If bypassing in development, log and continue without verification
        if (!password && bypassSignature) {
            logger_1.logger.warn('⚠️ Signature bypassed in development mode', {
                userId,
                operation: defaultMeaning,
                warning: 'THIS MUST BE DISABLED IN PRODUCTION'
            });
            req.part11 = {
                eventType: exports.Part11EventTypes.SIGNATURE_APPLIED,
                entityType: 'signature',
                signatureVerified: false,
                signatureMeaning: `[DEV BYPASS] ${defaultMeaning}`,
                ipAddress: req.ip || req.socket.remoteAddress,
                userAgent: req.get('User-Agent')
            };
            return next();
        }
        const meaning = signatureMeaning || defaultMeaning;
        const verification = await verifyElectronicSignature(userId, password, meaning);
        if (!verification.verified) {
            return res.status(403).json({
                success: false,
                message: verification.error || 'Electronic signature verification failed',
                requiresSignature: true
            });
        }
        // Attach signature context to Part 11 audit
        if (req.part11) {
            req.part11.signatureVerified = true;
            req.part11.signatureMeaning = meaning;
        }
        else {
            req.part11 = {
                eventType: exports.Part11EventTypes.SIGNATURE_APPLIED,
                entityType: 'signature',
                signatureVerified: true,
                signatureMeaning: meaning,
                ipAddress: req.ip || req.socket.remoteAddress,
                userAgent: req.get('User-Agent')
            };
        }
        next();
    };
}
/**
 * Helper function to create audit entry from request context
 * Call this at the end of successful operations
 */
async function createAuditFromRequest(req, entityId, entityName, oldValue, newValue, reason) {
    if (!req.part11 || !req.user) {
        logger_1.logger.warn('Part 11 audit context missing');
        return null;
    }
    try {
        return await recordPart11Audit(req.user.userId, req.user.userName, req.part11.eventType, req.part11.entityType, entityId, entityName, oldValue, newValue, reason || req.part11.reasonForChange || null, {
            ipAddress: req.part11.ipAddress,
            signatureMeaning: req.part11.signatureMeaning
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to create audit from request', { error });
        return null;
    }
}
/**
 * Helper to format timestamp as ISO 8601 UTC string
 * Required for §11.10(k) time stamp compliance
 */
function formatPart11Timestamp(date) {
    return (date || new Date()).toISOString();
}
/**
 * Validate that a timestamp is in correct Part 11 format
 */
function isValidPart11Timestamp(timestamp) {
    const iso8601Regex = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{3})?Z$/;
    return iso8601Regex.test(timestamp);
}
/**
 * Verify audit log chain integrity
 * Detects any tampering with audit records per §11.10(e)
 *
 * @param entityType - The entity type to verify (e.g., 'study_subject', 'event_crf')
 * @param limit - Maximum number of records to verify (default: 1000)
 * @returns Verification result with any detected integrity violations
 */
async function verifyAuditChainIntegrity(entityType, limit = 1000) {
    logger_1.logger.info('Starting audit chain integrity verification', { entityType, limit });
    try {
        // Get audit records ordered by ID
        const result = await database_1.pool.query(`
      SELECT audit_id, audit_date, user_id, audit_log_event_type_id,
             entity_id, entity_name, old_value, new_value
      FROM audit_log_event
      WHERE audit_table = $1
      ORDER BY audit_id ASC
      LIMIT $2
    `, [entityType, limit]);
        const records = result.rows;
        const violations = [];
        let previousHash = null;
        let validCount = 0;
        for (const record of records) {
            let storedData = {};
            try {
                storedData = JSON.parse(record.entity_name || '{}');
            }
            catch { /* ignore */ }
            // Skip records without integrity hash (legacy records)
            if (!storedData.integrityHash) {
                validCount++;
                continue;
            }
            // Recalculate the expected hash
            const expectedHash = generateAuditHash(storedData.previousHash || null, new Date(record.audit_date), record.user_id, record.audit_log_event_type_id, entityType, record.entity_id, record.old_value, record.new_value);
            if (expectedHash === storedData.integrityHash) {
                validCount++;
                previousHash = storedData.integrityHash;
            }
            else {
                violations.push({
                    auditId: record.audit_id,
                    expectedHash,
                    actualHash: storedData.integrityHash,
                    timestamp: record.audit_date
                });
                logger_1.logger.warn('Audit chain integrity violation detected', {
                    auditId: record.audit_id,
                    entityType,
                    expectedHash: expectedHash.substring(0, 16) + '...',
                    actualHash: storedData.integrityHash.substring(0, 16) + '...'
                });
            }
        }
        const verified = violations.length === 0;
        logger_1.logger.info('Audit chain verification complete', {
            entityType,
            verified,
            totalRecords: records.length,
            validRecords: validCount,
            invalidRecords: violations.length
        });
        return {
            verified,
            totalRecords: records.length,
            validRecords: validCount,
            invalidRecords: violations.length,
            violations
        };
    }
    catch (error) {
        logger_1.logger.error('Audit chain verification failed', { error: error.message });
        throw error;
    }
}
exports.default = {
    Part11EventTypes: exports.Part11EventTypes,
    SignatureMeanings: exports.SignatureMeanings,
    recordPart11Audit,
    part11Audit,
    verifyElectronicSignature,
    requireSignature,
    requireSignatureFor,
    verifyAuditChainIntegrity,
    createAuditFromRequest,
    formatPart11Timestamp,
    isValidPart11Timestamp
};
//# sourceMappingURL=part11.middleware.js.map