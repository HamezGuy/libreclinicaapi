"use strict";
/**
 * Authentication Routes
 *
 * Includes WoundScanner capture token endpoints
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const controller = __importStar(require("../controllers/auth.controller"));
const validation_middleware_1 = require("../middleware/validation.middleware");
const rateLimiter_middleware_1 = require("../middleware/rateLimiter.middleware");
const auth_middleware_1 = require("../middleware/auth.middleware");
const router = express_1.default.Router();
// Public routes with appropriate rate limiting
// Login and Google auth use strict rate limiting (10 per 15 min)
router.post('/login', rateLimiter_middleware_1.authRateLimiter, (0, validation_middleware_1.validate)({ body: validation_middleware_1.authSchemas.login }), controller.login);
router.post('/google', rateLimiter_middleware_1.authRateLimiter, (0, validation_middleware_1.validate)({ body: validation_middleware_1.authSchemas.googleAuth }), controller.googleLogin);
// Refresh uses more generous rate limiting (60 per 15 min)
router.post('/refresh', rateLimiter_middleware_1.refreshRateLimiter, (0, validation_middleware_1.validate)({ body: validation_middleware_1.authSchemas.refreshToken }), controller.refresh);
// Token validation for iOS app (no auth - token in body)
router.post('/validate-token', controller.validateCaptureToken);
// Protected routes (auth required)
router.get('/verify', auth_middleware_1.authMiddleware, controller.verify);
router.post('/logout', auth_middleware_1.authMiddleware, controller.logout);
// Profile management (self-service)
router.get('/profile', auth_middleware_1.authMiddleware, controller.getProfile);
router.put('/profile', auth_middleware_1.authMiddleware, controller.updateProfile);
// Capture token generation (requires auth)
router.post('/capture-token', auth_middleware_1.authMiddleware, controller.generateCaptureToken);
exports.default = router;
//# sourceMappingURL=auth.routes.js.map