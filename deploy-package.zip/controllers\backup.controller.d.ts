/**
 * Backup Controller - 21 CFR Part 11 Compliant
 *
 * REST API endpoints for backup management with full audit trail.
 * Implements SOP-008 Section 7.3 (Record Backup) requirements.
 *
 * All operations require administrative privileges and are fully audited.
 */
import { Request, Response } from 'express';
/**
 * Get backup system status and statistics
 * GET /api/backup/status
 */
export declare const getBackupStatus: (req: Request, res: Response) => Promise<void>;
/**
 * List all backups
 * GET /api/backup/list
 * Query params: type (full|incremental|transaction_log), limit
 */
export declare const listBackups: (req: Request, res: Response) => Promise<void>;
/**
 * Get specific backup details
 * GET /api/backup/:backupId
 */
export declare const getBackup: (req: Request, res: Response) => Promise<void>;
/**
 * Trigger manual backup
 * POST /api/backup/trigger
 * Body: { type: 'full' | 'incremental' | 'transaction_log' }
 */
export declare const triggerBackup: (req: Request, res: Response) => Promise<void>;
/**
 * Verify backup integrity
 * POST /api/backup/:backupId/verify
 */
export declare const verifyBackup: (req: Request, res: Response) => Promise<void>;
/**
 * Initiate backup restore (requires confirmation)
 * POST /api/backup/:backupId/restore
 * Body: { targetDatabase?: string, confirmRestore: boolean }
 */
export declare const restoreBackup: (req: Request, res: Response) => Promise<void>;
/**
 * Start backup scheduler
 * POST /api/backup/scheduler/start
 */
export declare const startScheduler: (req: Request, res: Response) => Promise<void>;
/**
 * Stop backup scheduler
 * POST /api/backup/scheduler/stop
 */
export declare const stopScheduler: (req: Request, res: Response) => Promise<void>;
/**
 * Get scheduler status
 * GET /api/backup/scheduler/status
 */
export declare const getSchedulerStatus: (req: Request, res: Response) => Promise<void>;
/**
 * Run cleanup of expired backups
 * POST /api/backup/cleanup
 */
export declare const cleanupBackups: (req: Request, res: Response) => Promise<void>;
/**
 * Get backup configuration
 * GET /api/backup/config
 */
export declare const getBackupConfig: (req: Request, res: Response) => Promise<void>;
declare const _default: {
    getBackupStatus: (req: Request, res: Response) => Promise<void>;
    listBackups: (req: Request, res: Response) => Promise<void>;
    getBackup: (req: Request, res: Response) => Promise<void>;
    triggerBackup: (req: Request, res: Response) => Promise<void>;
    verifyBackup: (req: Request, res: Response) => Promise<void>;
    restoreBackup: (req: Request, res: Response) => Promise<void>;
    startScheduler: (req: Request, res: Response) => Promise<void>;
    stopScheduler: (req: Request, res: Response) => Promise<void>;
    getSchedulerStatus: (req: Request, res: Response) => Promise<void>;
    cleanupBackups: (req: Request, res: Response) => Promise<void>;
    getBackupConfig: (req: Request, res: Response) => Promise<void>;
};
export default _default;
//# sourceMappingURL=backup.controller.d.ts.map