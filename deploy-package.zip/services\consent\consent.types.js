"use strict";
/**
 * eConsent Types
 *
 * Type definitions for the electronic consent module.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=consent.types.js.map