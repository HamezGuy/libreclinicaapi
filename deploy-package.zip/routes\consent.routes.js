"use strict";
/**
 * Consent Routes
 *
 * API endpoints for eConsent management.
 *
 * 21 CFR Part 11 Compliance:
 * - Consent recording requires electronic signature (§11.50)
 * - Consent withdrawal requires electronic signature (§11.50)
 * - All changes are logged to audit trail (§11.10(e))
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_middleware_1 = require("../middleware/auth.middleware");
const part11_middleware_1 = require("../middleware/part11.middleware");
const logger_1 = require("../config/logger");
const consent_service_1 = require("../services/consent/consent.service");
const router = (0, express_1.Router)();
/**
 * Require admin or investigator role
 */
const requireAdminOrInvestigator = async (req, res, next) => {
    const user = req.user;
    if (!user) {
        return res.status(401).json({ success: false, message: 'Not authenticated' });
    }
    const allowedRoles = ['admin', 'investigator', 'study_director'];
    if (!allowedRoles.includes(user.role)) {
        return res.status(403).json({ success: false, message: 'Insufficient permissions' });
    }
    next();
};
// ============================================================================
// Document Management
// ============================================================================
/**
 * POST /api/consent/documents
 * Create a consent document
 */
router.post('/documents', auth_middleware_1.authMiddleware, requireAdminOrInvestigator, async (req, res) => {
    try {
        const userId = req.user?.userId;
        const doc = await (0, consent_service_1.createConsentDocument)({ ...req.body, createdBy: userId });
        res.json({ success: true, data: doc });
    }
    catch (error) {
        logger_1.logger.error('Error creating consent document', { error: error.message });
        res.status(400).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/consent/studies/:studyId/documents
 * List consent documents for a study
 */
router.get('/studies/:studyId/documents', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const studyId = parseInt(req.params.studyId);
        const documents = await (0, consent_service_1.listConsentDocuments)(studyId);
        res.json({ success: true, data: documents });
    }
    catch (error) {
        logger_1.logger.error('Error listing consent documents', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/consent/documents/:id
 * Get a consent document
 */
router.get('/documents/:id', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const documentId = parseInt(req.params.id);
        const doc = await (0, consent_service_1.getConsentDocument)(documentId);
        if (!doc) {
            return res.status(404).json({ success: false, message: 'Document not found' });
        }
        res.json({ success: true, data: doc });
    }
    catch (error) {
        logger_1.logger.error('Error getting consent document', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * PUT /api/consent/documents/:id
 * Update a consent document
 */
router.put('/documents/:id', auth_middleware_1.authMiddleware, requireAdminOrInvestigator, async (req, res) => {
    try {
        const documentId = parseInt(req.params.id);
        const doc = await (0, consent_service_1.updateConsentDocument)(documentId, req.body);
        if (!doc) {
            return res.status(404).json({ success: false, message: 'Document not found' });
        }
        res.json({ success: true, data: doc });
    }
    catch (error) {
        logger_1.logger.error('Error updating consent document', { error: error.message });
        res.status(400).json({ success: false, message: error.message });
    }
});
// ============================================================================
// Version Management
// ============================================================================
/**
 * POST /api/consent/documents/:id/versions
 * Create a new version
 */
router.post('/documents/:id/versions', auth_middleware_1.authMiddleware, requireAdminOrInvestigator, async (req, res) => {
    try {
        const documentId = parseInt(req.params.id);
        const userId = req.user?.userId;
        const version = await (0, consent_service_1.createConsentVersion)({ ...req.body, documentId, createdBy: userId });
        res.json({ success: true, data: version });
    }
    catch (error) {
        logger_1.logger.error('Error creating consent version', { error: error.message });
        res.status(400).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/consent/versions/:id
 * Get a version
 */
router.get('/versions/:id', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const versionId = parseInt(req.params.id);
        const version = await (0, consent_service_1.getConsentVersion)(versionId);
        if (!version) {
            return res.status(404).json({ success: false, message: 'Version not found' });
        }
        res.json({ success: true, data: version });
    }
    catch (error) {
        logger_1.logger.error('Error getting consent version', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/consent/documents/:id/active-version
 * Get active version for a document
 */
router.get('/documents/:id/active-version', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const documentId = parseInt(req.params.id);
        const version = await (0, consent_service_1.getActiveVersion)(documentId);
        if (!version) {
            return res.status(404).json({ success: false, message: 'No active version' });
        }
        res.json({ success: true, data: version });
    }
    catch (error) {
        logger_1.logger.error('Error getting active version', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * POST /api/consent/versions/:id/activate
 * Activate a version (requires electronic signature per §11.50)
 */
router.post('/versions/:id/activate', auth_middleware_1.authMiddleware, requireAdminOrInvestigator, (0, part11_middleware_1.requireSignatureFor)('I authorize activation of this consent document version'), async (req, res) => {
    try {
        const versionId = parseInt(req.params.id);
        const userId = req.user?.userId;
        const version = await (0, consent_service_1.activateConsentVersion)(versionId, userId);
        res.json({ success: true, data: version });
    }
    catch (error) {
        logger_1.logger.error('Error activating consent version', { error: error.message });
        res.status(400).json({ success: false, message: error.message });
    }
});
// ============================================================================
// Subject Consent
// ============================================================================
/**
 * POST /api/consent/subjects/:studySubjectId/consent
 * Record subject consent (requires electronic signature per §11.50)
 */
router.post('/subjects/:studySubjectId/consent', auth_middleware_1.authMiddleware, (0, part11_middleware_1.requireSignatureFor)('I confirm informed consent has been obtained from this subject'), async (req, res) => {
    try {
        const studySubjectId = parseInt(req.params.studySubjectId);
        const userId = req.user?.userId;
        const consent = await (0, consent_service_1.recordConsent)({
            ...req.body,
            studySubjectId,
            consentedBy: userId,
            subjectIpAddress: req.ip,
            subjectUserAgent: req.get('User-Agent')
        });
        res.json({ success: true, data: consent });
    }
    catch (error) {
        logger_1.logger.error('Error recording consent', { error: error.message });
        res.status(400).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/consent/subjects/:studySubjectId/consent
 * Get subject consent history
 */
router.get('/subjects/:studySubjectId/consent', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const studySubjectId = parseInt(req.params.studySubjectId);
        const consents = await (0, consent_service_1.getSubjectConsent)(studySubjectId);
        res.json({ success: true, data: consents });
    }
    catch (error) {
        logger_1.logger.error('Error getting subject consent', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/consent/subjects/:studySubjectId/has-consent
 * Check if subject has valid consent
 */
router.get('/subjects/:studySubjectId/has-consent', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const studySubjectId = parseInt(req.params.studySubjectId);
        const hasConsent = await (0, consent_service_1.hasValidConsent)(studySubjectId);
        res.json({ success: true, data: { hasValidConsent: hasConsent } });
    }
    catch (error) {
        logger_1.logger.error('Error checking consent', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
/**
 * POST /api/consent/:consentId/withdraw
 * Withdraw consent (requires electronic signature per §11.50)
 */
router.post('/:consentId/withdraw', auth_middleware_1.authMiddleware, (0, part11_middleware_1.requireSignatureFor)('I confirm withdrawal of consent for this subject'), async (req, res) => {
    try {
        const consentId = parseInt(req.params.consentId);
        const { reason } = req.body;
        const userId = req.user?.userId;
        if (!reason) {
            return res.status(400).json({ success: false, message: 'Reason is required' });
        }
        const consent = await (0, consent_service_1.withdrawConsent)(consentId, reason, userId);
        res.json({ success: true, data: consent });
    }
    catch (error) {
        logger_1.logger.error('Error withdrawing consent', { error: error.message });
        res.status(400).json({ success: false, message: error.message });
    }
});
// ============================================================================
// Re-consent
// ============================================================================
/**
 * POST /api/consent/reconsent/request
 * Request re-consent for a subject
 */
router.post('/reconsent/request', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const userId = req.user?.userId;
        const request = await (0, consent_service_1.requestReconsent)({ ...req.body, requestedBy: userId });
        res.json({ success: true, data: request });
    }
    catch (error) {
        logger_1.logger.error('Error requesting re-consent', { error: error.message });
        res.status(400).json({ success: false, message: error.message });
    }
});
/**
 * GET /api/consent/studies/:studyId/reconsent/pending
 * Get pending re-consent requests
 */
router.get('/studies/:studyId/reconsent/pending', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const studyId = parseInt(req.params.studyId);
        const requests = await (0, consent_service_1.getPendingReconsents)(studyId);
        res.json({ success: true, data: requests });
    }
    catch (error) {
        logger_1.logger.error('Error getting pending re-consents', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
// ============================================================================
// Study Consents
// ============================================================================
/**
 * GET /api/consent/studies/:studyId/consents
 * List all subject consents for a study
 */
router.get('/studies/:studyId/consents', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const studyId = parseInt(req.params.studyId);
        const { status, limit } = req.query;
        // Get dashboard which includes recent consents
        const dashboard = await (0, consent_service_1.getConsentDashboard)(studyId);
        // Return recent consents (which include the needed fields)
        // In a full implementation, this would query acc_subject_consent table
        let consents = dashboard.recentConsents || [];
        if (status) {
            consents = consents.filter((c) => c.consentStatus === status);
        }
        if (limit) {
            consents = consents.slice(0, parseInt(limit));
        }
        res.json({ success: true, data: consents });
    }
    catch (error) {
        logger_1.logger.error('Error listing study consents', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
// ============================================================================
// Dashboard
// ============================================================================
/**
 * GET /api/consent/studies/:studyId/dashboard
 * Get consent dashboard
 */
router.get('/studies/:studyId/dashboard', auth_middleware_1.authMiddleware, async (req, res) => {
    try {
        const studyId = parseInt(req.params.studyId);
        const dashboard = await (0, consent_service_1.getConsentDashboard)(studyId);
        res.json({ success: true, data: dashboard });
    }
    catch (error) {
        logger_1.logger.error('Error getting consent dashboard', { error: error.message });
        res.status(500).json({ success: false, message: error.message });
    }
});
exports.default = router;
//# sourceMappingURL=consent.routes.js.map